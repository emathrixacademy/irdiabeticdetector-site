# TASKS.md — DFU Thermography Screening Station

Master task list for the full build. The developer works top to bottom, ticks
each box when its "Done when" is met, and commits after every task.

Legend:
- `[ ]` not started · `[x]` done · `[~]` done in code, waiting for hardware verification (or, in Phase 2, for data) · `[!]` blocked, see BLOCKERS.md
- **[HW]** needs the real Pi 5 and hardware. On any other machine, build it
  against the fakes, test it there, mark `[~]`, and move on.

Client acceptance: **October 30, 2026**. Annex A line numbers are shown as (A1)…(A14).

---

## Phase 0 — Project scaffold

- [x] **0.1 Repo init.** `git init`, `.gitignore` (calibration/, config/config.yaml, data/, *.npy, *.hef, *.onnx over 50 MB, .venv/, __pycache__/), `LICENSE` stating eMathrix background IP, no open-source licence.
  Done when: clean `git status` after first commit.
- [x] **0.2 Python project.** `pyproject.toml` (Python 3.11+, ruff, pytest, mypy settings), `requirements.txt` (runtime) and `requirements-dev.txt`. Pi-only packages (`picamera2`, `hailo_platform`, `lgpio`) are imported lazily and never pinned through pip.
  Done when: `pip install -r requirements-dev.txt` works on a non-Pi machine.
- [x] **0.3 Package skeleton.** All folders from README section 5 with `__init__.py`.
- [x] **0.4 Tooling.** `ruff check`, `ruff format --check`, `mypy src`, `pytest` all pass on the empty skeleton. `Makefile` or `tasks.py` with `test`, `lint`, `run`, `run-fake` targets.
- [x] **0.5 Working files.** Create `PROGRESS.md`, `DECISIONS.md`, `BLOCKERS.md` (empty templates).

## Phase 1 — Config and data model

- [x] **1.1 Config.** `config/config.example.yaml` with every value from the project guide "Code conventions". Loader validates types and ranges and refuses to start on a bad value.
  Done when: tests cover a valid file, a missing key, and an out-of-range threshold.
- [x] **1.2 Config hash.** Stable SHA-256 of the effective config, stored with every scan.
- [x] **1.3 Data model.** Dataclasses: `ThermalFrame` (temps_c array, raw array, timestamp, ffc_state), `ColorFrame`, `AmbientReading`, `ScanRecord`, `RegionResult`, `AsymmetryResult`, `ClassifierResult`, `FusedResult`. No field anywhere named `grade` or `wagner` on model outputs.
- [x] **1.4 Reference code.** Validator for the anonymised patient reference code (pattern configurable). Rejects anything that looks like a name.
- [x] **1.5 Logging.** Central logging setup; a test proves no log line contains a reference code or image data.

## Phase 2 — Hardware interfaces and fakes

- [x] **2.1 Interfaces.** Abstract classes: `ThermalCamera`, `ColorCamera`, `InteriorLight`, `CaptureButton`, `StatusLed`, `AmbientSensor`, `Accelerator`. Factory picks real or fake from config.
- [x] **2.2 Synthetic fixtures.** Generator script producing paired fixtures: two plantar-shaped feet on a cool background, configurable per-region temperatures, known hot spots at deltas of 0.0, 1.5, 2.19, 2.2, 2.21, 3.5 °C, plus matching RGB frames. Saved under `tests/fixtures/`.
- [x] **2.3 Fakes.** Fake drivers replaying fixtures, fake FFC states, fake ambient values (in and out of range), fake button presses, fake accelerator returning a deterministic class.
- [x] **2.4 run-fake.** `python -m src.app --fake` runs the full app on a laptop.
  Done when: one complete fake scan writes a record.

## Phase 3 — Thermal path

- [x] **3.1 Y16 conversion.** `raw / 100 - 273.15`, vectorised; rejects frames outside a plausible range (configurable, default 0–60 °C for skin scenes).
- [x] **3.2 Frame validity.** Rejects stale frames (age limit), frames during or right after FFC, all-zero or saturated frames. Raises, never substitutes.
- [x] **3.3 Calibration file.** Per-unit offset/gain loaded from `calibration/thermal.yaml`; absence is an error on real hardware, allowed with a warning in fake mode.
- [~] **3.4 [HW] PureThermal driver.** V4L2 Y16 capture from the PureThermal 3; FFC trigger and FFC-state readout over the UVC extension (based on GroupGets purethermal1-uvc-capture). Confirm TLinear radiometry is on; refuse to run if not.
- [~] **3.5 [HW] Reference check tool.** `python -m src.diagnostics.thermal_reference` prompts for a reference thermometer value, reads the Lepton at the target, reports the error, writes the result to `calibration/`. (A9)

## Phase 4 — Colour camera and GPIO

- [~] **4.1 [HW] Camera Module 3 driver.** `picamera2`, manual focus at the calibrated lens position (~2.4 dioptres), exposure and white balance locked after the LED is on, fixed resolution from config.
- [~] **4.2 [HW] GPIO.** `gpiozero` + `lgpio`: interior LED (MOSFET), capture button with debounce, status LED states (idle, acclimatising, ready, capturing, error). (A6)
- [~] **4.3 [HW] Ambient sensor.** I2C temperature/humidity driver behind `AmbientSensor`. Model is TBD: write the interface, implement for SHT31 by default, record the choice in DECISIONS.md. (A7)
- [~] **4.4 [HW] Hardware self-check.** `python -m src.diagnostics.check_hardware` verifies Hailo (`hailortcli fw-control identify`), Camera Module 3, PureThermal enumeration, Y16 mode, GPIO, ambient sensor. Clear pass/fail per item. (A4, A5)

## Phase 5 — Capture sequencer

- [x] **5.1 Gates.** Ambient 22–25 °C gate and 900 s acclimatisation timer per reference code. Refuse with a clear reason. No bypass flag. Tests for in-range, below, above, timer not met.
- [x] **5.2 Sequence.** FFC → wait → LED on → colour frame → LED off → settle delay → thermal frame. Order and delays enforced and tested with fakes.
- [x] **5.3 Paired record.** One trigger produces exactly one paired colour + thermal record; any failure leaves no half-record. (A8)
- [x] **5.4 Timing log.** Record timestamps of each step in the scan metadata.

## Phase 6 — Registration

- [x] **6.1 Calibration target procedure.** Document in `docs/calibration.md` a target visible to both cameras (e.g. a perforated metal plate over a warm surface). Write the tool that detects matching points in both frames and fits a homography.
- [x] **6.2 Apply registration.** Map colour to the thermal field and resolution; crop to thermal FOV. Never upsample thermal. Store the homography in `calibration/registration.yaml`.
- [x] **6.3 Registration check.** Overlay image for the UI and a numeric reprojection error; fail calibration above a configurable limit. (A10)

## Phase 7 — Segmentation

- [x] **7.1 Plantar mask.** Segment feet from background on the temperature frame (adaptive threshold above ambient plus morphology); reject frames where fewer or more than two feet are found.
- [x] **7.2 Left/right.** Separate the two feet; determine sidedness from geometry (hallux side), require operator confirmation on the touchscreen, and record which was used.
- [x] **7.3 Normalisation.** Mirror the right foot, align both to a common orientation and scale using principal axes and foot length.
- [x] **7.4 Both feet in frame.** Detect a foot cut off at the frame edge and refuse the scan. (A2)

## Phase 8 — Asymmetry

- [x] **8.1 Regions.** Fixed plantar region map (hallux, lesser toes, 1st metatarsal head, central metatarsal heads, 5th metatarsal head, medial midfoot, lateral midfoot, heel) defined as normalised polygons in config.
- [x] **8.2 Delta-T.** Mean temperature per region per foot; delta = left − right; flag `abs(delta) >= 2.2` (inclusive). Also compute a pixel-wise contralateral difference map for display.
- [x] **8.3 Tests.** Fixtures at 2.19 (no flag), 2.2 (flag), 2.21 (flag), and a symmetric foot (no flags). (A11)

## Phase 9 — Inference on the Pi

- [x] **9.1 Preprocessing.** Same resize/normalise as training, defined once and shared by training and inference code.
- [~] **9.2 [HW] HailoRT runner.** Load `.hef`, run on the registered colour crop, return class index, label and confidence. Labels come from a model metadata file.
- [x] **9.3 Dev runner.** ONNX Runtime CPU runner implementing the same interface for laptops.
- [x] **9.4 Output naming.** Classifier output is stored as `predicted_class`, never as a grade. Test enforces it. (A12)

## Phase 10 — Training pipeline (off-device, `training/`)

- [x] **10.1 Manifest.** Dataset manifest CSV: `patient_id, image_path, label, source, capture_session`. Validator rejects rows missing `patient_id`.
- [x] **10.2 Data-quality report.** Per-class image and patient counts, images per patient, missing metadata, class imbalance warning. Never silently drops or rebalances.
- [x] **10.3 Patient-level splits.** Grouped k-fold by `patient_id`; a test proves no patient appears in both train and test in any fold.
- [x] **10.4 Training.** MobileNetV2 transfer learning (PyTorch), class weighting option, augmentation, deterministic seeds, per-fold metrics written to a report. No accuracy targets asserted.
- [x] **10.5 Export.** ONNX export with fixed input shape matching 9.1; ONNX Runtime parity check against the PyTorch model.
- [~] **10.6 Hailo compile script.** Script and instructions for the Hailo Dataflow Compiler on x86 (parse → optimise with a calibration set exported from station captures → compile to `.hef` for Hailo-8L). Mark `[~]` if the compiler is not installed.

## Phase 11 — Fusion and storage

- [x] **11.1 Fusion.** `FusedResult` combining region flags, max delta, flagged-region list and classifier class/confidence. No diagnosis wording anywhere.
- [x] **11.2 Storage layout.** `data/<session_id>/<scan_id>/` with colour PNG, raw Y16 `.npy`, temperature `.npy`, overlay PNG, `meta.json`. (A13)
- [x] **11.3 CSV log.** Append-only, atomic writes, one row per scan: reference code, timestamps, ambient temp and humidity, config hash, per-region deltas, flags, predicted class, confidence. (A7, A13)
- [x] **11.4 Offline guarantee.** Test that the app makes no network calls (socket patched to fail) through a full fake scan.

## Phase 12 — Operator UI (touchscreen)

- [x] **12.1 Framework.** Full-screen app suited to a 7-inch touchscreen on Pi OS (choose PyQt5 from apt or another option; record in DECISIONS.md). Runs in fake mode on a laptop.
- [x] **12.2 Screens.** Reference-code entry → acclimatisation countdown with ambient status → live previews → capture → left/right confirmation → results (thermal heatmap with region deltas and flags, colour image, predicted class) → next patient.
- [x] **12.3 Errors.** Clear, non-technical messages for every refusal (room too warm, acclimatisation not done, foot out of frame, sensor fault).
- [x] **12.4 Button parity.** The physical capture button does the same as the on-screen button. (A6)
- [~] **12.5 [HW] Autostart.** systemd service starting the app on boot, restart on crash, logs to journal.

## Phase 13 — Documentation

- [x] **13.1 Methodology document.** `docs/methodology.md`: system-level development and testing methodology for the research team's paper. Covers hardware, capture protocol, calibration, registration, asymmetry method, classifier, patient-level validation, limitations. No accuracy claims. (A14)
- [x] **13.2 Operator manual.** `docs/operator_manual.md`: room preparation, patient positioning (supine and seated), acclimatisation, scanning, shutdown, cleaning.
- [x] **13.3 Calibration manual.** `docs/calibration.md`: thermal reference check, registration target, focus lock, how often to repeat.
- [x] **13.4 README refresh.** Update README with any decisions made during the build.

## Phase 14 — Acceptance readiness

- [x] **14.1 Acceptance runbook.** `docs/acceptance_test.md`: for each Annex A line (A1–A14), the exact step, the expected result, and which test or tool demonstrates it.
- [x] **14.2 Fake end-to-end test.** One pytest that runs the whole pipeline on fixtures and checks every software-testable Annex A line.
- [!] **14.3 [HW] On-device dry run.** Full scan on the station with a warm object and a reference thermometer; record results in PROGRESS.md.
- [x] **14.4 Final report.** Summary in PROGRESS.md: what is done, what is `[~]` waiting on hardware, every open item in BLOCKERS.md, every decision in DECISIONS.md that the Owner should review.

---

# Phase 2, Run A — first classifier on public colour photos

Goal: a real first classifier trained on public photos, exported to ONNX and
compiled to `.hef` for the Hailo-8L, so acceptance line A12 can be shown. To
be retrained later on station captures.

- [!] **A.1 Dataset intake.** Public DFU datasets in `data/public_raw/`; build `training/manifests/public_v1.csv`; map source labels to Wagner 0, 1, 2 with anything uncertain rejected; mapping table in DECISIONS.md.
- [~] **A.2 Patient grouping.** Documented subject ids where given, otherwise proxy groups from perceptual hash plus embedding similarity; never one id per image; limitation stated in training/README.md and docs/methodology.md.
- [~] **A.3 Data-quality report.** Class counts, group counts, images per group, duplicates removed, rejected labels. No silent rebalancing.
- [!] **A.4 Train.** Patient-grouped k-fold, then the `--final` model. Metrics reported as they are.
- [!] **A.5 Export.** ONNX with parity check; `models/model_meta.json`.
- [!] **A.6 Hailo compile (B10).** Dataflow Compiler on x86 Linux; quantise with held-out public images; `.hef` for Hailo-8L.
- [x] **A.7 Report.** PROGRESS.md: what was trained, on what data, metrics, the grouping limitation, what still needs the station.

---

# Phase 3, Run C — Pi bring-up without the thermal camera

A person is at the station. The Lepton and PureThermal are NOT connected:
every thermal check is skipped and no thermal item is marked passed. A
hardware result is recorded only if it was seen in command output or reported
by the person.

- [ ] **C.1 Versions.** Record in PROGRESS.md: Pi OS release, kernel, Python, `hailortcli --version`, Hailo firmware, picamera2 version.
- [ ] **C.2 Self-check (B6, partial).** `check_hardware`: Hailo-8L, Camera Module 3, GPIO and calibration-file lines correct; PureThermal and SHT31 expected to fail as not connected.
- [ ] **C.3 GPIO (B4).** Hardware test; person presses the button, reports each status LED state, confirms the interior LED switches.
- [ ] **C.4 Camera Module 3 (B3).** `color_lock` with shroud closed and LED on; sharpness at 420 mm; red object is red; hardware test.
- [ ] **C.5 Clock (B11).** If the RTC battery is fitted: set the clock, write it to the RTC, confirm it survives a power cycle.
- [ ] **C.6 Ambient sensor (B5).** If the SHT31 is fitted: `i2cdetect`, hardware test, compare with a room thermometer.
- [ ] **C.7 Autostart and panel (B12).** Install the service, reboot, kill-and-restart test; person goes through every screen on the 7-inch panel by finger in fully fake mode.
- [ ] **C.8 Run C report.** PROGRESS.md: what passed with evidence, what is still open and why.
- [x] **C.9 Screen ready for data gathering (laptop work).** Station can run with no classifier; fake scans kept apart from real ones; clock, storage and mode shown on the code screen; fake mode marked on every screen.