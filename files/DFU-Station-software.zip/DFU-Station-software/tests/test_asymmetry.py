"""Asymmetry: region map, delta T, and the inclusive 2.2 C flag (Annex A line 11)."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import numpy as np
import pytest

from src.asymmetry.compute import FLOAT_TOLERANCE_C, compute_asymmetry, is_flagged
from src.asymmetry.regions import points_in_polygon, region_masks
from src.config import REQUIRED_REGIONS, Config
from src.datamodel import AsymmetryResult, TempArray
from src.errors import AsymmetryError
from src.hardware.fakes import load_thermal_fixture
from src.segmentation.mask import segment_feet
from src.segmentation.sidedness import (
    OrientedFeet,
    confirm_sidedness,
    measure_feet,
    orient_feet,
    propose_sidedness,
)
from src.thermal.convert import y16_to_celsius
from tests.conftest import ROOT, make_config
from tools import synthetic
from tools.generate_fixtures import scenario_name

AMBIENT_C = 23.5
FIXTURES = ROOT / "tests" / "fixtures"


def orient(temps: TempArray, config: Config) -> OrientedFeet:
    masks = segment_feet(temps, AMBIENT_C, config.segmentation)
    feet = measure_feet(masks, config.segmentation)
    proposal = propose_sidedness(feet)
    assert proposal.left_is_image_left is not None
    return orient_feet(feet, confirm_sidedness(proposal, proposal.left_is_image_left))


def analyse(temps: TempArray, config: Config) -> AsymmetryResult:
    return compute_asymmetry(temps, orient(temps, config), config)


def fixture_temps(delta_c: float) -> TempArray:
    return y16_to_celsius(load_thermal_fixture(FIXTURES / scenario_name(delta_c)))


# --- The threshold itself -----------------------------------------------------


@pytest.mark.parametrize(
    ("delta_c", "expected"),
    [
        (0.0, False),
        (1.5, False),
        (2.19, False),
        (2.2, True),
        (2.21, True),
        (3.5, True),
        (-2.19, False),
        (-2.2, True),
        (-2.21, True),
    ],
)
def test_threshold_is_inclusive_at_2_2(delta_c: float, expected: bool) -> None:
    assert is_flagged(delta_c, 2.2) is expected


def test_float_error_does_not_lose_an_exact_2_2() -> None:
    # 32.20 C and 30.00 C as the sensor reports them, through the real conversion.
    raw = np.array([[30535, 30315]], dtype=np.uint16)
    temps = y16_to_celsius(raw)
    delta_c = float(temps[0, 0] - temps[0, 1])
    assert delta_c != 2.2  # binary floating point cannot hold it exactly
    assert is_flagged(delta_c, 2.2)
    # The tolerance is far below one sensor count, so 2.19 can never flag.
    assert FLOAT_TOLERANCE_C < 0.01 / 1000
    assert not is_flagged(2.2 - 0.01, 2.2)


# --- 8.1 regions ---------------------------------------------------------------


def test_region_map_covers_each_foot_once(config: Config) -> None:
    temps = fixture_temps(0.0)
    feet = orient(temps, config)
    polygons = config.regions.polygon_map()
    assert tuple(polygons) == REQUIRED_REGIONS
    for frame in (feet.left, feet.right):
        masks = region_masks(frame, polygons)
        total = np.zeros(temps.shape, dtype=int)
        for mask in masks.values():
            total += mask
        assert total.max() == 1  # no pixel is in two regions
        assert np.array_equal(total == 1, frame.shape.mask)  # every foot pixel is in one
        assert all(mask.sum() > 20 for mask in masks.values())


def test_regions_are_anatomical_on_both_feet(config: Config) -> None:
    temps = fixture_temps(0.0)
    feet = orient(temps, config)
    polygons = config.regions.polygon_map()
    left = region_masks(feet.left, polygons)
    right = region_masks(feet.right, polygons)

    def centre_x(mask: np.ndarray) -> float:
        return float(np.nonzero(mask)[1].mean())

    def centre_y(mask: np.ndarray) -> float:
        return float(np.nonzero(mask)[0].mean())

    # The patient's left foot is on the image right. Each hallux is on the
    # inner side, towards the other foot, and the lesser toes on the outer side.
    assert centre_x(left["hallux"]) < centre_x(left["lesser_toes"])
    assert centre_x(right["hallux"]) > centre_x(right["lesser_toes"])
    assert centre_x(left["metatarsal_head_1"]) < centre_x(left["metatarsal_head_5"])
    assert centre_x(right["metatarsal_head_1"]) > centre_x(right["metatarsal_head_5"])
    for masks in (left, right):
        assert (
            centre_y(masks["hallux"]) < centre_y(masks["medial_midfoot"]) < centre_y(masks["heel"])
        )
    # Matching regions are mirror images, so they hold the same number of pixels.
    for name in REQUIRED_REGIONS:
        assert left[name].sum() == pytest.approx(right[name].sum(), abs=3)


def test_shared_polygon_edges_are_not_double_counted() -> None:
    upper = ((0.0, 0.0), (1.0, 0.0), (1.0, 0.5), (0.0, 0.5))
    lower = ((0.0, 0.5), (1.0, 0.5), (1.0, 1.0), (0.0, 1.0))
    u = np.array([0.5, 0.5, 0.5])
    v = np.array([0.25, 0.5, 0.75])
    in_upper = points_in_polygon(upper, u, v)
    in_lower = points_in_polygon(lower, u, v)
    assert list(in_upper ^ in_lower) == [True, True, True]


# --- 8.2 / 8.3 delta T on fixtures -----------------------------------------------


@pytest.mark.parametrize(
    ("delta_c", "flagged"),
    [(0.0, False), (1.5, False), (2.19, False), (2.2, True), (2.21, True), (3.5, True)],
)
def test_fixture_heel_delta_and_flag(config: Config, delta_c: float, flagged: bool) -> None:
    result = analyse(fixture_temps(delta_c), config)
    heel = result.region("heel")
    assert heel.delta_c == pytest.approx(delta_c, abs=1e-9)
    assert heel.left_mean_c == pytest.approx(30.0 + delta_c, abs=1e-9)
    assert heel.right_mean_c == pytest.approx(30.0, abs=1e-9)
    assert heel.flagged is flagged
    assert result.flagged_regions == (("heel",) if flagged else ())
    assert result.threshold_c == 2.2
    assert result.max_abs_delta_c == pytest.approx(delta_c, abs=1e-9)


def test_symmetric_feet_raise_no_flags(config: Config) -> None:
    result = analyse(fixture_temps(0.0), config)
    assert result.flagged_regions == ()
    assert result.max_abs_delta_c == 0.0
    for region in result.regions:
        assert region.delta_c == 0.0
        assert region.flagged is False


def test_only_the_hot_region_is_flagged(config: Config) -> None:
    result = analyse(fixture_temps(3.5), config)
    for name in ("hallux", "lesser_toes", "metatarsal_head_1", "metatarsal_head_5"):
        assert result.region(name).delta_c == pytest.approx(0.0, abs=1e-9)
    # The synthetic hot zone starts above the heel region, so the midfoot
    # regions rise by a known part of the delta and stay below the threshold.
    for name in ("medial_midfoot", "lateral_midfoot"):
        midfoot = result.region(name).delta_c
        assert midfoot is not None
        assert 0.3 < midfoot < 1.5


def test_delta_is_left_minus_right(config: Config) -> None:
    hot_right = y16_to_celsius(
        synthetic.render_thermal_y16(synthetic.default_scene(2.5, hot_foot="right"))
    )
    heel = analyse(hot_right, config).region("heel")
    assert heel.delta_c == pytest.approx(-2.5, abs=1e-9)
    assert heel.flagged is True


def test_result_follows_anatomy_not_image_position(config: Config) -> None:
    # Same patient, feet swapped in the image: the left heel is still the hot one.
    swapped = y16_to_celsius(
        synthetic.render_thermal_y16(synthetic.default_scene(3.5, left_on_image_left=True))
    )
    assert analyse(swapped, config).region("heel").delta_c == pytest.approx(3.5, abs=1e-9)


def test_per_region_fixture_temperatures_are_measured(config: Config) -> None:
    polygons = config.regions.polygon_map()
    scene = synthetic.default_scene()
    left, right = scene.feet
    warmed = synthetic.with_feet(scene, replace(left, region_offsets_c={"hallux": 2.6}), right)
    result = analyse(y16_to_celsius(synthetic.render_thermal_y16(warmed, polygons)), config)
    hallux = result.region("hallux").delta_c
    assert hallux is not None
    # Region edges found by segmentation differ from the generator's by a pixel
    # or so, which dilutes a hot spot that exactly fills the region.
    assert hallux == pytest.approx(2.6, abs=0.45)
    assert result.region("heel").delta_c == pytest.approx(0.0, abs=1e-9)


def test_rotated_feet_give_the_same_answer(config: Config) -> None:
    rotated = y16_to_celsius(
        synthetic.render_thermal_y16(synthetic.default_scene(2.2, rotation_deg=6.0))
    )
    heel = analyse(rotated, config).region("heel")
    assert heel.delta_c == pytest.approx(2.2, abs=1e-9)
    assert heel.flagged is True


def test_difference_map_is_for_display(config: Config) -> None:
    result = analyse(fixture_temps(3.5), config)
    difference = result.difference_map_c
    assert difference.shape == (
        config.regions.difference_map_height_px,
        config.regions.difference_map_width_px,
    )
    values = difference[~np.isnan(difference)]
    assert set(np.round(np.unique(values), 6)) <= {-3.5, 0.0, 3.5}
    assert np.nanmax(difference[85:, :]) == pytest.approx(3.5)
    assert np.isnan(difference).any()  # outside the foot there is no value


def test_a_region_missing_on_one_foot_is_not_compared_and_not_invented(config: Config) -> None:
    temps = fixture_temps(3.5)
    feet = orient(temps, config)
    polygons = config.regions.polygon_map()
    # The left hallux is cold enough to drop out of the mask (or is absent).
    hallux_pixels = region_masks(feet.left, polygons)["hallux"]
    reduced_mask = feet.left.shape.mask & ~hallux_pixels
    left = replace(feet.left, shape=replace(feet.left.shape, mask=reduced_mask))
    result = compute_asymmetry(temps, replace(feet, left=left), config)
    hallux = result.region("hallux")
    assert hallux.delta_c is None
    assert hallux.left_mean_c is None
    assert hallux.right_mean_c == pytest.approx(30.0)
    assert hallux.flagged is False
    assert hallux.left_pixel_count == 0
    assert result.region("heel").flagged is True


def test_nothing_comparable_is_an_error(tmp_path: Path) -> None:
    config = make_config(tmp_path, regions__min_region_px=1000)
    with pytest.raises(AsymmetryError):
        analyse(fixture_temps(0.0), config)


def test_threshold_comes_from_config(tmp_path: Path) -> None:
    stricter = make_config(tmp_path, asymmetry_threshold_c=1.5)
    result = analyse(fixture_temps(1.5), stricter)
    assert result.flagged_regions == ("heel",)
    assert result.threshold_c == 1.5
