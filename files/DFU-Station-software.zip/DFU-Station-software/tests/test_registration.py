"""Registration: target detection, homography fit, applying it, and the check."""

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
import pytest
import yaml

from src.clock import ManualClock
from src.config import Config
from src.diagnostics import registration_calibrate as tool
from src.errors import RegistrationError
from src.hardware.fakes import load_color_fixture, load_thermal_fixture
from src.registration.apply import make_overlay, register_color, thermal_display_bgr
from src.registration.model import (
    Registration,
    load_registration,
    read_registration,
    save_registration,
)
from src.registration.target import (
    calibrate_from_target,
    find_color_holes,
    find_thermal_holes,
    fit_registration,
    order_grid,
    project,
)
from src.thermal.convert import y16_to_celsius
from tests.conftest import EXAMPLE_CONFIG, ROOT, make_config
from tools import synthetic

FIXTURES = ROOT / "tests" / "fixtures"
TARGET = FIXTURES / "registration_target"


def _target() -> tuple[np.ndarray, np.ndarray]:
    return load_color_fixture(TARGET), y16_to_celsius(load_thermal_fixture(TARGET))


def _calibrated(config: Config) -> Registration:
    color, temps = _target()
    return calibrate_from_target(color, temps, config, "test")


# --- 6.1 target detection and fit -------------------------------------------


def test_holes_are_found_in_both_frames(config: Config) -> None:
    color, temps = _target()
    spec = synthetic.TargetSpec()
    thermal_points = order_grid(find_thermal_holes(temps), spec.rows, spec.cols, "thermal")
    assert thermal_points.shape == (35, 2)
    assert np.abs(thermal_points - synthetic.target_centers_px(spec)).max() < 0.3
    color_points = order_grid(find_color_holes(color), spec.rows, spec.cols, "colour")
    mapped = project(synthetic.fixture_homography(), color_points)
    assert np.abs(mapped - synthetic.target_centers_px(spec)).max() < 0.3


def test_fitted_homography_matches_the_known_one(config: Config) -> None:
    registration = _calibrated(config)
    assert registration.point_count == 35
    assert registration.reprojection_error_px < 0.3
    corners = np.array([[0.0, 0.0], [1151.0, 0.0], [1151.0, 647.0], [0.0, 647.0], [576.0, 324.0]])
    fitted = project(registration.homography_color_to_thermal, corners)
    truth = project(synthetic.fixture_homography(), corners)
    assert np.abs(fitted - truth).max() < 0.5


def test_wrong_number_of_holes_fails(config: Config) -> None:
    color, temps = _target()
    blocked = temps.copy()
    blocked[:40, :] = 26.0  # the top rows of holes are covered
    with pytest.raises(RegistrationError, match="expected 35"):
        calibrate_from_target(color, blocked, config, "test")
    with pytest.raises(RegistrationError, match="flat"):
        calibrate_from_target(color, np.full_like(temps, 26.0), config, "test")


def test_a_target_turned_too_far_fails(config: Config) -> None:
    points = synthetic.target_centers_px(synthetic.TargetSpec())
    angle = np.deg2rad(30.0)
    rotation = np.array([[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]])
    turned = (points - points.mean(axis=0)) @ rotation.T + points.mean(axis=0)
    with pytest.raises(RegistrationError, match="rows overlap"):
        order_grid(turned, 5, 7, "thermal")


# --- 6.3 registration check ---------------------------------------------------


def test_calibration_fails_above_the_error_limit(config: Config) -> None:
    spec = synthetic.TargetSpec()
    thermal_points = synthetic.target_centers_px(spec)
    color_points = project(np.linalg.inv(synthetic.fixture_homography()), thermal_points)
    arguments = {
        "color_size_px": (1152, 648),
        "thermal_size_px": (160, 120),
        "max_error_px": config.registration.max_reprojection_error_px,
        "calibrated_at": "test",
    }
    good = fit_registration(color_points, thermal_points, **arguments)
    assert good.reprojection_error_px < 1e-4

    rng = np.random.default_rng(7)
    noisy = thermal_points + rng.normal(0.0, 4.0, thermal_points.shape)
    with pytest.raises(RegistrationError, match="above the limit"):
        fit_registration(color_points, noisy, **arguments)
    with pytest.raises(RegistrationError, match="at least 4"):
        fit_registration(color_points[:3], thermal_points[:3], **arguments)


def test_stored_registration_above_the_limit_is_refused(tmp_path: Path) -> None:
    path = tmp_path / "registration.yaml"
    config = make_config(tmp_path, registration__calibration_path=str(path))
    good = _calibrated(config)
    save_registration(good, path)
    assert load_registration(config).point_count == 35

    data = good.to_dict()
    data["reprojection_error_px"] = 3.0
    path.write_text(yaml.safe_dump(data), encoding="utf-8")
    with pytest.raises(RegistrationError, match="recalibrate"):
        load_registration(config)


def test_missing_registration_is_an_error_on_real_hardware(tmp_path: Path) -> None:
    path = tmp_path / "calibration" / "registration.yaml"
    real = make_config(tmp_path, hardware__mode="real", registration__calibration_path=str(path))
    with pytest.raises(RegistrationError, match="missing"):
        load_registration(real)
    fake = make_config(tmp_path, registration__calibration_path=str(path))
    assert load_registration(fake).calibrated_at == "synthetic"


@pytest.mark.parametrize(
    "change",
    [
        {"homography_color_to_thermal": [[1, 0], [0, 1]]},
        {"homography_color_to_thermal": [[0, 0, 0], [0, 0, 0], [0, 0, 0]]},
        {"color_width_px": "wide"},
        {"reprojection_error_px": -1.0},
    ],
)
def test_malformed_registration_file_is_refused(tmp_path: Path, change: dict[str, object]) -> None:
    data = read_registration(FIXTURES / "registration.yaml").to_dict()
    data.update(change)
    path = tmp_path / "registration.yaml"
    path.write_text(yaml.safe_dump(data), encoding="utf-8")
    with pytest.raises(RegistrationError):
        read_registration(path)


# --- 6.2 applying the registration ------------------------------------------


def test_colour_is_mapped_down_onto_the_thermal_grid(config: Config) -> None:
    registration = _calibrated(config)
    scenario = FIXTURES / "delta_3p50"
    color = load_color_fixture(scenario)
    raw = load_thermal_fixture(scenario)
    temps = y16_to_celsius(raw)
    before = temps.copy()

    registered = register_color(color, registration, config.registration)

    assert registered.thermal_grid_bgr.shape == (120, 160, 3)
    scale = config.registration.color_scale
    assert registered.crop_bgr.shape == (120 * scale, 160 * scale, 3)
    assert registered.coverage_fraction == 1.0
    # The thermal frame is untouched and keeps its native size.
    assert np.array_equal(temps, before)
    assert temps.shape == (120, 160)

    skin = registered.thermal_grid_bgr[:, :, 2] > 100
    feet = temps > 26.0
    intersection = np.logical_and(skin, feet).sum()
    union = np.logical_or(skin, feet).sum()
    assert intersection / union > 0.93


def test_crop_and_thermal_grid_agree(config: Config) -> None:
    registration = _calibrated(config)
    color = load_color_fixture(FIXTURES / "delta_0p00")
    registered = register_color(color, registration, config.registration)
    scale = config.registration.color_scale
    block_mean = registered.crop_bgr.reshape(120, scale, 160, scale, 3).mean(axis=(1, 3))
    assert np.abs(block_mean - registered.thermal_grid_bgr).max() <= 1.0


def test_uncovered_thermal_pixels_are_reported(config: Config) -> None:
    registration = _calibrated(config)
    shifted = registration.homography_color_to_thermal.copy()
    shifted[0, 2] += 60.0  # the colour camera no longer sees the left of the thermal field
    moved = Registration(
        homography_color_to_thermal=shifted,
        color_width_px=registration.color_width_px,
        color_height_px=registration.color_height_px,
        thermal_width_px=160,
        thermal_height_px=120,
        reprojection_error_px=0.1,
        point_count=35,
        calibrated_at="test",
    )
    registered = register_color(
        load_color_fixture(FIXTURES / "delta_0p00"), moved, config.registration
    )
    assert registered.coverage_fraction < 1.0
    assert not registered.covered[:, 0].any()
    assert registered.covered[:, -1].all()


def test_a_colour_frame_of_the_wrong_size_is_refused(config: Config) -> None:
    registration = _calibrated(config)
    with pytest.raises(RegistrationError, match="Recalibrate"):
        register_color(np.zeros((480, 640, 3), dtype=np.uint8), registration, config.registration)


def test_overlay_is_on_the_thermal_grid(config: Config) -> None:
    registration = _calibrated(config)
    scenario = FIXTURES / "delta_3p50"
    temps = y16_to_celsius(load_thermal_fixture(scenario))
    registered = register_color(load_color_fixture(scenario), registration, config.registration)
    overlay = make_overlay(temps, registered)
    assert overlay.shape == (120, 160, 3)
    assert overlay.dtype == np.uint8
    assert thermal_display_bgr(temps).shape == (120, 160, 3)
    with pytest.raises(RegistrationError):
        make_overlay(temps[:60], registered)


# --- The calibration tool ----------------------------------------------------


def _config_file(tmp_path: Path) -> Path:
    data = yaml.safe_load(EXAMPLE_CONFIG.read_text(encoding="utf-8"))
    data["fake"]["fixture_dir"] = str(FIXTURES)
    data["registration"]["calibration_path"] = str(tmp_path / "calibration" / "registration.yaml")
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(data), encoding="utf-8")
    return path


def test_tool_fake_run_passes_and_writes_nothing_by_default(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    assert tool.main(["--fake", "--config", str(_config_file(tmp_path))]) == 0
    output = capsys.readouterr().out
    assert "PASS" in output
    assert "nothing was written" in output
    assert not (tmp_path / "calibration").exists()


def test_tool_writes_registration_and_overlay_to_an_explicit_folder(tmp_path: Path) -> None:
    out = tmp_path / "out"
    code = tool.main(["--fake", "--config", str(_config_file(tmp_path)), "--output-dir", str(out)])
    assert code == 0
    stored = read_registration(out / "registration.yaml")
    assert stored.point_count == 35
    assert stored.reprojection_error_px < 0.3
    overlay = cv2.imread(str(out / tool.OVERLAY_NAME))
    assert overlay is not None
    assert overlay.shape == (120, 160, 3)


def test_tool_fails_and_writes_nothing_when_the_target_is_not_there(
    tmp_path: Path, config: Config
) -> None:
    from src.hardware.factory import build_fake_devices

    clock = ManualClock()
    devices = build_fake_devices(config, clock, None)  # feet, not the target
    with pytest.raises(RegistrationError):
        tool.calibrate(config, devices, clock, tmp_path / "out")
    assert not (tmp_path / "out").exists()
