"""Thermal calibration file: required on real hardware, identity in fake mode."""

from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pytest

from src.clock import ManualClock
from src.errors import CalibrationError
from src.station import build_station
from src.thermal.calibration import load_thermal_calibration
from tests.conftest import make_config


def _write(tmp_path: Path, text: str) -> Path:
    path = tmp_path / "thermal.yaml"
    path.write_text(text, encoding="utf-8")
    return path


def test_calibration_is_loaded_and_applied(tmp_path: Path) -> None:
    calibration = load_thermal_calibration(
        _write(tmp_path, "gain: 1.02\noffset_c: -0.35\n"), allow_missing=False
    )
    temps = np.array([[30.0, 32.0]])
    assert np.allclose(calibration.apply(temps), temps * 1.02 - 0.35)


def test_missing_file_is_an_error_on_real_hardware(tmp_path: Path) -> None:
    with pytest.raises(CalibrationError, match="missing"):
        load_thermal_calibration(tmp_path / "thermal.yaml", allow_missing=False)


def test_missing_file_is_identity_with_a_warning_in_fake_mode(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    with caplog.at_level(logging.WARNING):
        calibration = load_thermal_calibration(tmp_path / "thermal.yaml", allow_missing=True)
    assert (calibration.gain, calibration.offset_c) == (1.0, 0.0)
    assert "fake mode" in caplog.text


@pytest.mark.parametrize(
    "text",
    [
        "gain: 1.0\n",
        "offset_c: 0.0\n",
        "gain: fast\noffset_c: 0.0\n",
        "gain: 1.5\noffset_c: 0.0\n",
        "gain: 1.0\noffset_c: 25.0\n",
        "gain: .nan\noffset_c: 0.0\n",
        "- 1.0\n- 0.0\n",
        "gain: [1.0\n",
    ],
)
def test_bad_calibration_is_refused_in_both_modes(tmp_path: Path, text: str) -> None:
    path = _write(tmp_path, text)
    for allow_missing in (False, True):
        with pytest.raises(CalibrationError):
            load_thermal_calibration(path, allow_missing=allow_missing)


def test_real_station_will_not_start_without_thermal_calibration(tmp_path: Path) -> None:
    fake = make_config(tmp_path)
    real = make_config(
        tmp_path,
        hardware__mode="real",
        thermal__calibration_path=str(tmp_path / "calibration" / "thermal.yaml"),
        inference__metadata_path=str(fake.fake.fixture_dir / "model_meta.json"),
    )
    # Devices are injected so this test reaches the calibration check off-device.
    from src.hardware.factory import build_fake_devices
    from src.inference.metadata import load_model_metadata

    clock = ManualClock()
    metadata = load_model_metadata(real.inference.metadata_path)
    devices = build_fake_devices(fake, clock, metadata)
    with pytest.raises(CalibrationError):
        build_station(real, clock, devices)
