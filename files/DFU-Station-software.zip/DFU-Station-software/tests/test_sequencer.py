"""Capture sequence: order, delays, one paired record per trigger, timing log."""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path

import numpy as np
import pytest

from src.capture.sequencer import STEP_NAMES
from src.datamodel import FfcState, ScanRecord
from src.errors import (
    FfcTimeoutError,
    HardwareError,
    InvalidFrameError,
    RadiometryError,
    StorageError,
)
from src.storage import layout
from src.storage.writer import write_paired_record
from tests.conftest import REFERENCE_CODE, Rig


def _capture(rig: Rig) -> ScanRecord:
    rig.acclimatise()
    return rig.station.sequencer.capture(REFERENCE_CODE)


# --- 5.2 order and delays ---------------------------------------------------


def test_sequence_order(rig: Rig) -> None:
    _capture(rig)
    names = rig.events.names()
    # Thermal reads may repeat; the measurement frame is the last one.
    assert names[:5] == ["ambient_read", "ffc_trigger", "led_on", "color_capture", "led_off"]
    assert set(names[5:]) == {"thermal_read"}


def test_ffc_completes_before_anything_is_captured(rig: Rig) -> None:
    record = _capture(rig)
    ffc_done_s = rig.events.time_of("ffc_trigger") + 0.5
    assert rig.events.time_of("led_on") >= ffc_done_s
    assert record.thermal.ffc_state is FfcState.COMPLETE


def test_colour_frame_is_taken_with_the_light_on_after_it_settles(rig: Rig) -> None:
    _capture(rig)
    assert rig.color.light_was_on == [True]
    lit_for_s = rig.events.time_of("color_capture") - rig.events.time_of("led_on")
    assert lit_for_s == pytest.approx(rig.config.color.led_on_settle_s)


def test_thermal_frame_is_taken_with_the_light_off_after_the_settle_delay(rig: Rig) -> None:
    record = _capture(rig)
    assert rig.light.is_on is False
    dark_for_s = record.thermal.monotonic_s - rig.events.time_of("led_off")
    assert dark_for_s >= rig.config.settle_delay_s
    assert rig.config.settle_delay_s in rig.clock.sleeps


def test_a_longer_settle_delay_is_honoured(tmp_path: Path) -> None:
    from tests.conftest import make_rig

    rig = make_rig(tmp_path, settle_delay_s=7.5)
    record = _capture(rig)
    assert record.thermal.monotonic_s - rig.events.time_of("led_off") >= 7.5


def test_light_is_switched_off_even_if_the_colour_camera_fails(rig: Rig) -> None:
    rig.acclimatise()
    rig.color.fail = True
    with pytest.raises(HardwareError):
        rig.station.sequencer.capture(REFERENCE_CODE)
    assert rig.light.is_on is False
    assert rig.events.names()[-1] == "led_off"
    assert "thermal_read" not in rig.events.names()


def test_sequence_stops_without_radiometry(rig: Rig) -> None:
    rig.acclimatise()
    rig.thermal.radiometry = False
    with pytest.raises(RadiometryError):
        rig.station.sequencer.capture(REFERENCE_CODE)
    assert rig.events.names() == ["ambient_read"]


def test_sequence_stops_if_ffc_never_completes(rig: Rig) -> None:
    rig.acclimatise()
    rig.thermal.ffc_never_completes = True
    with pytest.raises(FfcTimeoutError):
        rig.station.sequencer.capture(REFERENCE_CODE)
    assert "led_on" not in rig.events.names()


# --- 5.3 one paired record, never half --------------------------------------


def test_one_trigger_gives_one_paired_record(rig: Rig) -> None:
    record = _capture(rig)
    assert record.reference_code == REFERENCE_CODE
    assert record.color.image_bgr.ndim == 3
    assert record.thermal.temps_c.shape == (120, 160)
    assert record.thermal.raw.shape == (120, 160)
    assert record.ambient.temp_c == rig.config.fake.ambient_temp_c
    assert record.config_hash == rig.config.config_hash()
    assert rig.events.names().count("color_capture") == 1
    assert rig.events.names().count("ffc_trigger") == 1


def test_button_press_triggers_exactly_one_capture(rig: Rig) -> None:
    rig.acclimatise()
    records: list[ScanRecord] = []
    rig.button.set_handler(lambda: records.append(rig.station.sequencer.capture(REFERENCE_CODE)))
    rig.button.press()
    assert len(records) == 1
    assert rig.events.names().count("color_capture") == 1


@pytest.mark.parametrize("fault", ["color", "thermal_missing", "thermal_invalid"])
def test_a_failed_capture_gives_no_record_and_no_files(rig: Rig, fault: str) -> None:
    rig.acclimatise()
    if fault == "color":
        rig.color.fail = True
    elif fault == "thermal_missing":
        rig.thermal.fail_reads = True
    else:
        rig.thermal.set_frame(np.zeros((120, 160), dtype=np.uint16))
    expected = InvalidFrameError if fault == "thermal_invalid" else HardwareError
    with pytest.raises(expected):
        record = rig.station.sequencer.capture(REFERENCE_CODE)
        write_paired_record(record, rig.config.storage.data_dir)
    assert not rig.config.storage.data_dir.exists()
    assert rig.light.is_on is False


def test_a_failed_write_leaves_no_half_record(rig: Rig, monkeypatch: pytest.MonkeyPatch) -> None:
    record = _capture(rig)
    data_dir = rig.config.storage.data_dir

    def refuse(source: object, target: object) -> None:
        raise OSError(28, "No space left on device")

    monkeypatch.setattr(os, "replace", refuse)
    with pytest.raises(StorageError):
        write_paired_record(record, data_dir)
    assert not list(data_dir.rglob("*.png"))
    assert not list(data_dir.rglob("*.npy"))
    assert not list(data_dir.rglob(".incomplete-*"))
    monkeypatch.undo()

    path = write_paired_record(record, data_dir)
    assert {item.name for item in path.iterdir()} == {
        layout.COLOR_FILE,
        layout.THERMAL_RAW_FILE,
        layout.THERMAL_TEMP_FILE,
        layout.META_FILE,
    }
    with pytest.raises(StorageError, match="already exists"):
        write_paired_record(record, data_dir)


# --- 5.4 timing log ----------------------------------------------------------


def test_every_step_is_timestamped_in_order(rig: Rig) -> None:
    record = _capture(rig)
    assert tuple(record.step_timestamps) == STEP_NAMES
    times = [datetime.fromisoformat(value) for value in record.step_timestamps.values()]
    assert times == sorted(times)
    assert all(time.tzinfo is not None for time in times)
    led_on = datetime.fromisoformat(record.step_timestamps["led_on"])
    led_off = datetime.fromisoformat(record.step_timestamps["led_off"])
    settled = datetime.fromisoformat(record.step_timestamps["settle_complete"])
    assert (led_off - led_on).total_seconds() == pytest.approx(rig.config.color.led_on_settle_s)
    assert (settled - led_off).total_seconds() == pytest.approx(rig.config.settle_delay_s)


def test_step_timestamps_are_stored_in_the_scan_metadata(rig: Rig) -> None:
    record = _capture(rig)
    path = write_paired_record(record, rig.config.storage.data_dir)
    meta = json.loads((path / layout.META_FILE).read_text(encoding="utf-8"))
    assert list(meta["step_timestamps_utc"]) == sorted(STEP_NAMES)
    assert meta["step_timestamps_utc"] == record.step_timestamps
