"""The photo capture app, run with the drawn test camera."""

from __future__ import annotations

import time
from collections.abc import Iterator
from datetime import datetime
from pathlib import Path

import pytest
from flask.testing import FlaskClient

from capture_app.camera import FakeCamera, light_level
from capture_app.exporter import Drive, Exporter, find_drives
from capture_app.library import Library, clean_participant
from capture_app.server import CaptureService, create_app
from capture_app.settings import Settings


@pytest.fixture
def library(tmp_path: Path) -> Library:
    return Library(tmp_path / "photos", thumbs=tmp_path / "thumbs", trash=tmp_path / "trash")


@pytest.fixture
def usb(tmp_path: Path) -> Path:
    path = tmp_path / "usb"
    path.mkdir()
    return path


@pytest.fixture
def service(tmp_path: Path, library: Library, usb: Path) -> Iterator[CaptureService]:
    camera = FakeCamera(delay_s=0.0)
    exporter = Exporter(library, drives=lambda: find_drives(Path("/nonexistent"), extra=usb))
    svc = CaptureService(camera, library, Settings(tmp_path / "settings.json"), exporter)
    yield svc
    camera.stop()


@pytest.fixture
def client(service: CaptureService) -> FlaskClient:
    return create_app(service).test_client()


def take(client: FlaskClient, service: CaptureService, n: int) -> list[str]:
    ids = []
    for _ in range(n):
        service._last_capture = 0.0  # the double-press guard is tested on its own
        response = client.post("/api/capture", json={})
        assert response.status_code == 200, response.json
        ids.append(response.json["id"])
    return ids


def test_participant_codes_are_cleaned() -> None:
    assert clean_participant(" p-014 ") == "P-014"
    assert clean_participant("../etc/passwd") == "ETCPASSWD"
    assert clean_participant("x" * 40) == "X" * 20


def test_file_names_carry_participant_foot_and_view(library: Library) -> None:
    library._now = lambda: datetime(2026, 10, 21, 14, 30, 12)
    first = library.new_path("p-014", "L", "plantar")
    assert first.parent.name == "2026-10-21"
    assert first.name == "P-014_L_plantar_20261021_143012.jpg"
    first.write_bytes(b"x")
    assert library.new_path("p-014", "L", "plantar").name == "P-014_L_plantar_20261021_143012_2.jpg"
    assert library.new_path("", "", "").name == "NOID_20261021_143012.jpg"


def test_capture_needs_the_camera_open(client: FlaskClient) -> None:
    assert client.post("/api/capture", json={}).status_code == 503


def test_capture_saves_a_jpeg_and_a_thumbnail(client: FlaskClient, service: CaptureService) -> None:
    client.post("/api/session", json={"participant": "p-7", "foot": "R", "view": "heel"})
    assert client.post("/api/camera/start", json={}).status_code == 200
    (photo_id,) = take(client, service, 1)
    assert "/P-7_R_heel_" in photo_id
    photo = client.get(f"/media/photo/{photo_id}")
    assert photo.status_code == 200 and photo.data[:2] == b"\xff\xd8"
    assert client.get(f"/media/thumb/{photo_id}").status_code == 200
    state = client.get("/api/state").json
    assert state["stats"]["total"] == 1
    assert state["last_photo"]["id"] == photo_id
    assert state["capture_count"] == 1


def test_both_feet_is_the_default(client: FlaskClient, service: CaptureService) -> None:
    client.post("/api/session", json={"participant": "p-8"})
    assert client.get("/api/state").json["session"]["foot"] == "B"
    client.post("/api/camera/start", json={})
    (photo_id,) = take(client, service, 1)
    assert "/P-8_B_" in photo_id
    assert client.get("/api/photos").json[0]["foot"] == "B"


def test_light_levels() -> None:
    assert light_level([20] * 100) == "dark"
    assert light_level([120] * 100) == "ok"
    assert light_level([230] * 100) == "bright"
    assert light_level([120] * 70 + [255] * 30) == "bright"  # a third blown out
    assert light_level([]) == "unknown"


def test_photo_checks_are_reported_while_the_camera_is_open(
    client: FlaskClient, service: CaptureService
) -> None:
    assert client.get("/api/camera/checks").json == {"focus": "unknown", "light": "unknown"}
    client.post("/api/camera/start", json={})
    for _ in range(50):
        checks = client.get("/api/camera/checks").json
        if checks["light"] != "unknown":
            break
        time.sleep(0.05)
    assert checks["focus"] == "ok"
    assert checks["light"] in {"ok", "dark", "bright"}
    assert client.get("/api/state").json["camera"]["checks"] == checks
    client.post("/api/camera/stop", json={})
    assert client.get("/api/camera/checks").json["light"] == "unknown"


def test_detection_boxes_are_mapped_back_to_the_frame() -> None:
    import numpy as np

    from capture_app.detector import letterbox, parse

    square, top = letterbox(np.zeros((360, 640, 3), dtype=np.uint8))
    assert square.shape == (640, 640, 3) and top == 140
    person = np.array([[140 / 640, 0.25, 320 / 640, 0.75, 0.9]])  # top half of the frame
    weak = np.array([[0.3, 0.3, 0.4, 0.4, 0.2]])
    output = [person] + [np.zeros((0, 5))] * 38 + [weak] + [np.zeros((0, 5))] * 40
    (box,) = parse(output, top, 360)
    assert box["label"] == "person" and box["score"] == 0.9
    assert (box["x"], box["w"]) == (0.25, 0.5)
    assert (box["y"], box["h"]) == (0.0, 0.5)


def test_detection_reports_unavailable_without_the_accelerator(client: FlaskClient) -> None:
    assert client.get("/api/camera/detections").json == {
        "available": False,
        "active": False,
        "boxes": [],
    }


def test_a_second_press_straight_away_is_ignored(
    client: FlaskClient, service: CaptureService
) -> None:
    client.post("/api/camera/start", json={})
    assert client.post("/api/capture", json={}).status_code == 200
    assert client.post("/api/capture", json={}).status_code == 409
    assert len(service.library.photos()) == 1


def test_delete_moves_photos_to_the_trash(
    client: FlaskClient, service: CaptureService, tmp_path: Path
) -> None:
    client.post("/api/camera/start", json={})
    ids = take(client, service, 3)
    response = client.post("/api/photos/delete", json={"ids": [ids[0], ids[2], "../x.jpg"]})
    assert response.json == {"deleted": 2}
    assert [p["id"] for p in client.get("/api/photos").json] == [ids[1]]
    assert len(list((tmp_path / "trash").rglob("*.jpg"))) == 2


def test_paths_outside_the_photo_folder_are_refused(client: FlaskClient) -> None:
    for bad in ("../settings.json", "2026-10-21/../../x.jpg", "x.jpg"):
        assert client.get(f"/media/photo/{bad}").status_code == 404


def test_export_copies_only_what_is_new(
    client: FlaskClient, service: CaptureService, usb: Path
) -> None:
    client.post("/api/camera/start", json={})
    ids = take(client, service, 2)
    mount = str(usb)
    assert client.post("/api/export/plan", json={"mount": mount}).json["pending"] == 2
    assert client.post("/api/export", json={"mount": mount}).status_code == 200
    _wait_for_export(service)
    assert sorted(p.name for p in (usb / "FootCaptures").rglob("*.jpg")) == sorted(
        i.split("/")[1] for i in ids
    )
    take(client, service, 1)
    plan = client.post("/api/export/plan", json={"mount": mount}).json
    assert (plan["total"], plan["pending"]) == (3, 1)


def test_export_of_selected_photos(client: FlaskClient, service: CaptureService, usb: Path) -> None:
    client.post("/api/camera/start", json={})
    ids = take(client, service, 3)
    client.post("/api/export", json={"mount": str(usb), "ids": [ids[1]]})
    _wait_for_export(service)
    assert [p.name for p in (usb / "FootCaptures").rglob("*.jpg")] == [ids[1].split("/")[1]]


def test_one_tap_export_ejects_when_done(
    client: FlaskClient, service: CaptureService, usb: Path
) -> None:
    client.post("/api/camera/start", json={})
    take(client, service, 2)
    response = client.post("/api/export", json={"mount": str(usb), "eject_after": True})
    assert response.status_code == 200 and response.json["ejected"] is False
    _wait_for_export(service)
    job = client.get("/api/state").json["export"]
    assert (job["copied"], job["ejected"]) == (2, True)


def test_unknown_drive_is_refused(client: FlaskClient) -> None:
    assert client.post("/api/export", json={"mount": "/media/gone"}).status_code == 404


def test_settings_are_checked_and_kept(tmp_path: Path, client: FlaskClient) -> None:
    assert client.post("/api/settings", json={"quality": "huge"}).status_code == 400
    assert client.post("/api/settings", json={"rotate180": "yes"}).status_code == 400
    assert client.post("/api/settings", json={"quality": "standard"}).json["quality"] == "standard"
    assert Settings(tmp_path / "settings.json")["quality"] == "standard"


def test_mounted_flash_drives_are_found(tmp_path: Path) -> None:
    media = tmp_path / "media" / "pi" / "MY USB"
    media.mkdir(parents=True)
    mounts = tmp_path / "mounts"
    mounts.write_text(
        "/dev/mmcblk0p2 / ext4 rw 0 0\n"
        "/dev/mmcblk0p1 /boot/firmware vfat rw 0 0\n"
        f"/dev/sda1 {str(media).replace(' ', chr(92) + '040')} vfat rw 0 0\n",
        encoding="utf-8",
    )
    import capture_app.exporter as exporter_module

    roots = exporter_module.MOUNT_ROOTS
    exporter_module.MOUNT_ROOTS = (str(tmp_path / "media"),)
    try:
        drives = find_drives(mounts)
    finally:
        exporter_module.MOUNT_ROOTS = roots
    assert [(d.device, d.label) for d in drives] == [("/dev/sda1", "MY USB")]
    assert isinstance(drives[0], Drive)


def test_usb_partitions_prefer_partitions_over_the_whole_disk(tmp_path: Path) -> None:
    from capture_app.exporter import usb_partitions

    devs = tmp_path / "dev"
    devs.mkdir()
    for name in ("sda", "sda1", "sdb"):
        (devs / name).write_text("", encoding="utf-8")
    by_id = tmp_path / "by-id"
    by_id.mkdir()
    links = {
        "usb-Kingston_DT_1-0:0": "sda",
        "usb-Kingston_DT_1-0:0-part1": "sda1",
        "usb-Generic_Stick_2-0:0": "sdb",  # no partition table: the disk itself
        "mmc-SD16G_0x1234": "sda",  # not USB
    }
    try:
        for link, target in links.items():
            (by_id / link).symlink_to(devs / target)
    except OSError:
        pytest.skip("symlinks need extra rights on this machine")
    found = usb_partitions(by_id)
    assert sorted(Path(p).name for p in found) == ["sda1", "sdb"]


def _wait_for_export(service: CaptureService) -> None:
    import time

    for _ in range(100):
        if service.exporter.status()["state"] != "running":
            break
        time.sleep(0.02)
    assert service.exporter.status()["state"] == "done", service.exporter.status()
