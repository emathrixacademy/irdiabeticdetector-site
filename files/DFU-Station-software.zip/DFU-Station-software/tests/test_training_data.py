"""Training data handling: manifest, data-quality report, patient-level splits.

These need no PyTorch and run everywhere.
"""

from __future__ import annotations

import inspect
from pathlib import Path

import pytest

from training import splits
from training.manifest import COLUMNS, ManifestError, ManifestRow, load_manifest
from training.quality import build_quality_report
from training.splits import SplitError, assert_patient_disjoint, patient_level_folds

HEADER = ",".join(COLUMNS)


def write_manifest(path: Path, lines: list[str], header: str = HEADER) -> Path:
    path.write_text("\n".join([header, *lines]) + "\n", encoding="utf-8")
    return path


def make_rows(patients_per_label: dict[str, int], images_per_patient: int = 3) -> list[ManifestRow]:
    rows: list[ManifestRow] = []
    line = 2
    for label, patient_count in patients_per_label.items():
        for patient in range(patient_count):
            for shot in range(images_per_patient):
                rows.append(
                    ManifestRow(
                        patient_id=f"P{label}-{patient:03d}",
                        image_path=f"{label}/{patient:03d}_{shot}.png",
                        label=label,
                        source="station-1",
                        capture_session=f"S{patient:03d}",
                        line_number=line,
                    )
                )
                line += 1
    return rows


# --- 10.1 manifest ---------------------------------------------------------------


def test_valid_manifest_loads(tmp_path: Path) -> None:
    path = write_manifest(
        tmp_path / "manifest.csv",
        ["DFU-0001,a/1.png,0,station-1,S1", "DFU-0002,a/2.png,1,,"],
    )
    rows = load_manifest(path)
    assert len(rows) == 2
    assert rows[0].patient_id == "DFU-0001"
    assert rows[0].line_number == 2
    assert rows[1].source == ""


def test_rows_missing_patient_id_reject_the_whole_manifest(tmp_path: Path) -> None:
    path = write_manifest(
        tmp_path / "manifest.csv",
        ["DFU-0001,a/1.png,0,s,S1", ",a/2.png,1,s,S1", "   ,a/3.png,1,s,S1"],
    )
    with pytest.raises(ManifestError) as info:
        load_manifest(path)
    message = str(info.value)
    assert "2 manifest row(s)" in message
    assert "line 3: missing patient_id" in message
    assert "line 4: missing patient_id" in message
    assert "never dropped" in message


@pytest.mark.parametrize("line", ["DFU-0001,,0,s,S1", "DFU-0001,a/1.png,,s,S1"])
def test_rows_missing_path_or_label_are_rejected(tmp_path: Path, line: str) -> None:
    with pytest.raises(ManifestError):
        load_manifest(write_manifest(tmp_path / "manifest.csv", [line]))


def test_wrong_columns_and_empty_manifest_are_rejected(tmp_path: Path) -> None:
    with pytest.raises(ManifestError, match="columns"):
        load_manifest(write_manifest(tmp_path / "a.csv", ["a/1.png,0"], header="image_path,label"))
    with pytest.raises(ManifestError, match="no rows"):
        load_manifest(write_manifest(tmp_path / "b.csv", []))
    with pytest.raises(ManifestError, match="cannot read"):
        load_manifest(tmp_path / "absent.csv")


# --- 10.2 data-quality report ----------------------------------------------------


def test_report_counts_images_and_patients_per_class() -> None:
    rows = make_rows({"0": 12, "1": 8, "2": 4})
    report = build_quality_report(rows)
    assert report.image_count == 72
    assert report.patient_count == 24
    assert [(c.label, c.images, c.patients) for c in report.classes] == [
        ("0", 36, 12),
        ("1", 24, 8),
        ("2", 12, 4),
    ]
    assert report.images_per_patient_min == report.images_per_patient_max == 3
    assert report.images_per_patient["P0-000"] == 3


def test_report_warns_about_imbalance_and_tiny_classes() -> None:
    report = build_quality_report(make_rows({"0": 12, "1": 8, "2": 4}))
    text = "\n".join(report.warnings)
    assert "Class '2' has only 4 patient(s)" in text
    assert "Class imbalance" in text
    assert "not rebalanced" in text
    balanced = build_quality_report(make_rows({"0": 10, "1": 10}))
    assert balanced.warnings == ()


def test_report_never_drops_or_changes_rows() -> None:
    rows = make_rows({"0": 12, "2": 4})
    before = list(rows)
    build_quality_report(rows)
    assert rows == before
    names = [name for name, _ in inspect.getmembers(inspect.getmodule(build_quality_report))]
    for word in ("drop", "impute", "rebalance", "resample", "oversample"):
        assert not any(word in name.lower() for name in names), word


def test_report_lists_missing_metadata_and_files(tmp_path: Path) -> None:
    rows = make_rows({"0": 6, "1": 6}, images_per_patient=1)
    rows[0] = ManifestRow("P0-000", rows[0].image_path, "0", "", "", 2)
    rows[1] = ManifestRow("P0-001", rows[0].image_path, "0", "station-1", "", 3)
    rows[2] = ManifestRow("P0-002", rows[2].image_path, "1", "station-1", "S2", 4)
    rows.append(ManifestRow("P0-002", "0/extra.png", "0", "station-1", "S9", 99))
    (tmp_path / "0").mkdir()
    (tmp_path / rows[2].image_path).write_bytes(b"x")

    report = build_quality_report(rows, tmp_path)
    assert report.missing_source_lines == (2,)
    assert report.missing_capture_session_lines == (2, 3)
    assert len(report.missing_image_lines) == len(rows) - 1
    assert report.duplicate_image_paths == (rows[0].image_path,)
    assert report.patients_with_several_labels == {"P0-002": ("0", "1")}

    markdown = report.to_markdown()
    assert "real sample size" in markdown
    assert "Nothing was dropped" in markdown
    assert "manifest lines 2, 3" in markdown


# --- 10.3 patient-level splits ---------------------------------------------------


@pytest.mark.parametrize("fold_count", [2, 3, 5])
@pytest.mark.parametrize("seed", [0, 1, 2026])
def test_no_patient_is_in_both_train_and_test_in_any_fold(fold_count: int, seed: int) -> None:
    rows = make_rows({"0": 13, "1": 9, "2": 6}, images_per_patient=4)
    plan = patient_level_folds(rows, fold_count, seed)
    assert len(plan.folds) == fold_count
    tested: list[int] = []
    for fold in plan.folds:
        train_patients = {rows[i].patient_id for i in fold.train_indices}
        test_patients = {rows[i].patient_id for i in fold.test_indices}
        assert train_patients.isdisjoint(test_patients)
        assert train_patients == set(fold.train_patients)
        assert test_patients == set(fold.test_patients)
        assert set(fold.train_indices).isdisjoint(fold.test_indices)
        assert len(fold.train_indices) + len(fold.test_indices) == len(rows)
        assert test_patients
        tested += list(fold.test_indices)
    # Every image is tested exactly once across the folds.
    assert sorted(tested) == list(range(len(rows)))


def test_every_image_of_a_patient_stays_together() -> None:
    rows = make_rows({"0": 10, "1": 10}, images_per_patient=7)
    for fold in patient_level_folds(rows, 5, 3).folds:
        for patient in fold.test_patients:
            in_test = sum(1 for i in fold.test_indices if rows[i].patient_id == patient)
            assert in_test == 7


def test_a_patient_with_two_labels_is_still_kept_on_one_side() -> None:
    rows = make_rows({"0": 6, "1": 6}, images_per_patient=2)
    rows.append(ManifestRow("P0-000", "1/later.png", "1", "station-1", "S99", 999))
    for fold in patient_level_folds(rows, 3, 0).folds:
        sides = {
            "train" if i in fold.train_indices else "test"
            for i, row in enumerate(rows)
            if row.patient_id == "P0-000"
        }
        assert len(sides) == 1


def test_splits_are_deterministic_and_spread_classes() -> None:
    rows = make_rows({"0": 10, "1": 10})
    first = patient_level_folds(rows, 5, 42)
    assert first == patient_level_folds(rows, 5, 42)
    assert first != patient_level_folds(rows, 5, 43)
    for fold in first.folds:
        labels = {patient[1] for patient in fold.test_patients}
        assert labels == {"0", "1"}
    assert first.warnings == ()


def test_too_few_patients_is_an_error_and_small_classes_are_warned() -> None:
    with pytest.raises(SplitError, match="real sample size"):
        patient_level_folds(make_rows({"0": 2, "1": 1}, images_per_patient=30), 5, 0)
    with pytest.raises(SplitError):
        patient_level_folds(make_rows({"0": 5, "1": 5}), 1, 0)
    plan = patient_level_folds(make_rows({"0": 10, "2": 3}), 5, 0)
    assert any("Class '2' has 3 patient(s)" in warning for warning in plan.warnings)


def test_the_guard_catches_a_leaked_patient() -> None:
    rows = make_rows({"0": 4, "1": 4}, images_per_patient=2)
    # An image-level split: the two images of patient P0-000 on opposite sides.
    with pytest.raises(SplitError, match="both training and testing"):
        assert_patient_disjoint(rows, (0, 2, 3), (1, 4, 5))
    with pytest.raises(SplitError):
        assert_patient_disjoint(rows, (0, 1, 2), (2, 3))
    assert_patient_disjoint(rows, (0, 1), (2, 3))


def test_split_module_has_no_image_level_shuffle() -> None:
    source = inspect.getsource(splits)
    assert "train_test_split" not in source
    # The only shuffle is of patients within a class.
    assert source.count(".shuffle(") == 1
    assert "rng.shuffle(group)" in source
