"""GPIO devices against gpiozero's mock pin factory (no Pi needed)."""

from __future__ import annotations

from collections.abc import Iterator

import pytest
from gpiozero.pins.mock import MockFactory

from src.clock import ManualClock
from src.config import Config
from src.hardware.gpio import (
    STATUS_PATTERNS,
    GpioCaptureButton,
    GpioInteriorLight,
    GpioStatusLed,
)
from src.hardware.interfaces import StatusState


@pytest.fixture
def factory() -> Iterator[MockFactory]:
    mock = MockFactory()
    yield mock
    mock.reset()


def test_interior_light_switches_its_pin(config: Config, factory: MockFactory) -> None:
    pin_number = config.gpio.interior_led_pin
    light = GpioInteriorLight(pin_number, factory)
    pin = factory.pin(pin_number)
    assert light.is_on is False
    assert pin.state == 0
    light.on()
    assert light.is_on is True
    assert pin.state == 1
    light.off()
    assert pin.state == 0
    light.on()
    light.close()
    assert pin.state == 0


def test_button_press_calls_the_handler_once(config: Config, factory: MockFactory) -> None:
    clock = ManualClock()
    button = GpioCaptureButton(config.gpio.capture_button_pin, 0.05, clock, factory)
    pin = factory.pin(config.gpio.capture_button_pin)
    presses: list[float] = []
    button.set_handler(lambda: presses.append(clock.monotonic()))

    pin.drive_low()
    pin.drive_high()
    assert len(presses) == 1

    # Contact bounce inside the debounce window is ignored.
    clock.advance(0.01)
    pin.drive_low()
    pin.drive_high()
    assert len(presses) == 1

    clock.advance(0.2)
    pin.drive_low()
    pin.drive_high()
    assert len(presses) == 2

    button.set_handler(None)
    clock.advance(0.2)
    pin.drive_low()
    pin.drive_high()
    assert len(presses) == 2
    button.close()


def test_status_led_states(config: Config, factory: MockFactory) -> None:
    led = GpioStatusLed(config.gpio.status_led_pin, factory)
    pin = factory.pin(config.gpio.status_led_pin)
    assert led.state is StatusState.IDLE

    led.set_state(StatusState.READY)
    assert pin.state == 1
    led.set_state(StatusState.IDLE)
    assert pin.state == 0
    for state in (StatusState.ACCLIMATISING, StatusState.CAPTURING, StatusState.ERROR):
        led.set_state(state)
        assert led.state is state
    led.close()
    assert pin.state == 0


def test_every_state_has_a_distinct_indication() -> None:
    assert set(STATUS_PATTERNS) == set(StatusState) - {StatusState.IDLE}
    assert len({repr(pattern) for pattern in STATUS_PATTERNS.values()}) == len(STATUS_PATTERNS)


@pytest.mark.hardware
def test_real_gpio_pins_can_be_claimed(config: Config) -> None:
    from src.hardware.gpio import real_pin_factory

    light = GpioInteriorLight(config.gpio.interior_led_pin, real_pin_factory())
    assert light.is_on is False
    light.close()
