"""SHT31 driver against a fake I2C bus."""

from __future__ import annotations

import pytest

from src.clock import ManualClock, RealClock
from src.config import Config
from src.errors import SensorFaultError
from src.hardware.sht31 import (
    COMMAND_MEASURE_HIGH,
    I2cBus,
    Sht31Sensor,
    crc8,
    decode_measurement,
)


def _response(raw_temp: int, raw_humidity: int) -> bytes:
    temp = raw_temp.to_bytes(2, "big")
    humidity = raw_humidity.to_bytes(2, "big")
    return temp + bytes([crc8(temp)]) + humidity + bytes([crc8(humidity)])


class FakeBus(I2cBus):
    def __init__(self, response: bytes) -> None:
        self.response = response
        self.writes: list[tuple[int, bytes]] = []
        self.fail = False

    def write(self, address: int, data: bytes) -> None:
        if self.fail:
            raise OSError(121, "Remote I/O error")
        self.writes.append((address, data))

    def read(self, address: int, length: int) -> bytes:
        return self.response[:length]


def test_crc_matches_the_datasheet_example() -> None:
    assert crc8(bytes([0xBE, 0xEF])) == 0x92


def test_decoding_follows_the_datasheet_formulas() -> None:
    temp_c, humidity_pct = decode_measurement(_response(0x6666, 0x8000))
    assert temp_c == pytest.approx(-45.0 + 175.0 * 0x6666 / 65535)
    assert temp_c == pytest.approx(25.0, abs=0.01)
    assert humidity_pct == pytest.approx(50.0, abs=0.01)


def test_sensor_reads_through_the_bus() -> None:
    clock = ManualClock()
    bus = FakeBus(_response(0x6666, 0x8000))
    reading = Sht31Sensor(bus, 0x44, clock).read()
    assert bus.writes == [(0x44, COMMAND_MEASURE_HIGH)]
    assert reading.temp_c == pytest.approx(25.0, abs=0.01)
    assert reading.humidity_pct == pytest.approx(50.0, abs=0.01)
    assert reading.monotonic_s == clock.monotonic() > 0


def test_checksum_error_raises_instead_of_returning_a_value() -> None:
    corrupted = bytearray(_response(0x6666, 0x8000))
    corrupted[0] ^= 0x01
    with pytest.raises(SensorFaultError, match="checksum"):
        Sht31Sensor(FakeBus(bytes(corrupted)), 0x44, ManualClock()).read()


def test_short_response_and_bus_error_raise() -> None:
    with pytest.raises(SensorFaultError):
        Sht31Sensor(FakeBus(b"\x66\x66"), 0x44, ManualClock()).read()
    bus = FakeBus(_response(0x6666, 0x8000))
    bus.fail = True
    with pytest.raises(SensorFaultError, match="did not respond"):
        Sht31Sensor(bus, 0x44, ManualClock()).read()


@pytest.mark.hardware
def test_real_sht31_gives_a_room_reading(config: Config) -> None:
    from src.hardware.sht31 import Smbus2Bus

    sensor = Sht31Sensor(Smbus2Bus(config.ambient.i2c_bus), config.ambient.i2c_address, RealClock())
    try:
        reading = sensor.read()
    finally:
        sensor.close()
    assert 0.0 < reading.temp_c < 50.0
    assert 0.0 <= reading.humidity_pct <= 100.0
