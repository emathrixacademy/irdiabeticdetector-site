"""Reference-thermometer check tool, run against the fake camera."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest
import yaml

from src.clock import ManualClock
from src.config import Config
from src.diagnostics import thermal_reference as tool
from src.errors import CalibrationError, RadiometryError
from src.hardware.fakes import FakeThermalCamera
from src.thermal.calibration import ThermalCalibration, load_thermal_calibration
from src.thermal.source import ThermalSource
from tests.conftest import EXAMPLE_CONFIG, ROOT

TARGET_C = 35.0


def _source(config: Config, target_c: float = TARGET_C) -> tuple[ThermalSource, ManualClock]:
    clock = ManualClock()
    raw = np.full((120, 160), round((target_c + 273.15) * 100), dtype=np.uint16)
    camera = FakeThermalCamera(raw, clock)
    return ThermalSource(camera, config.thermal, tool.UNCALIBRATED, clock), clock


def test_check_passes_when_the_sensor_agrees(config: Config) -> None:
    source, clock = _source(config)
    check = tool.run_reference_check(source, 35.3, config.thermal, tool.UNCALIBRATED, clock)
    assert check.measured_uncalibrated_c == pytest.approx(35.0)
    assert check.error_uncalibrated_c == pytest.approx(-0.3)
    assert check.passed
    assert check.frames == config.thermal.reference_frames


def test_check_fails_outside_tolerance(config: Config) -> None:
    source, clock = _source(config)
    check = tool.run_reference_check(source, 37.5, config.thermal, tool.UNCALIBRATED, clock)
    assert check.error_calibrated_c == pytest.approx(-2.5)
    assert not check.passed


def test_check_uses_the_calibration_in_use(config: Config) -> None:
    source, clock = _source(config)
    in_use = ThermalCalibration(gain=1.0, offset_c=2.5, source="test")
    check = tool.run_reference_check(source, 37.5, config.thermal, in_use, clock)
    assert check.error_uncalibrated_c == pytest.approx(-2.5)
    assert check.error_calibrated_c == pytest.approx(0.0)
    assert check.passed


@pytest.mark.parametrize("reference_c", [float("nan"), -5.0, 200.0])
def test_nonsense_reference_is_refused(config: Config, reference_c: float) -> None:
    source, clock = _source(config)
    with pytest.raises(CalibrationError):
        tool.run_reference_check(source, reference_c, config.thermal, tool.UNCALIBRATED, clock)


def test_check_refuses_without_radiometry(config: Config) -> None:
    clock = ManualClock()
    camera = FakeThermalCamera(np.full((120, 160), 30815, dtype=np.uint16), clock, radiometry=False)
    source = ThermalSource(camera, config.thermal, tool.UNCALIBRATED, clock)
    with pytest.raises(RadiometryError):
        tool.run_reference_check(source, 35.0, config.thermal, tool.UNCALIBRATED, clock)


def test_log_is_appended_and_offset_is_written(config: Config, tmp_path: Path) -> None:
    source, clock = _source(config)
    check = tool.run_reference_check(source, 36.5, config.thermal, tool.UNCALIBRATED, clock)
    tool.append_check_log(check, tmp_path)
    tool.append_check_log(check, tmp_path)
    entries = yaml.safe_load((tmp_path / tool.CHECK_LOG_NAME).read_text(encoding="utf-8"))
    assert len(entries) == 2
    assert entries[0]["reference_c"] == 36.5

    target = tmp_path / "thermal.yaml"
    tool.write_calibration(target, 1.0, -check.error_uncalibrated_c, check)
    calibration = load_thermal_calibration(target, allow_missing=False)
    assert calibration.offset_c == pytest.approx(1.5)


def test_huge_offset_is_not_written(config: Config, tmp_path: Path) -> None:
    source, clock = _source(config)
    check = tool.run_reference_check(source, 55.0, config.thermal, tool.UNCALIBRATED, clock)
    with pytest.raises(CalibrationError, match="too large"):
        tool.write_calibration(tmp_path / "thermal.yaml", 1.0, 20.0, check)
    assert not (tmp_path / "thermal.yaml").exists()


def _config_file(tmp_path: Path) -> Path:
    data = yaml.safe_load(EXAMPLE_CONFIG.read_text(encoding="utf-8"))
    data["fake"]["fixture_dir"] = str(ROOT / "tests" / "fixtures")
    data["thermal"]["calibration_path"] = str(tmp_path / "calibration" / "thermal.yaml")
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(data), encoding="utf-8")
    return path


def test_cli_fake_run_writes_nothing_by_default(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    # The centre of the fixture frame is the 23 C background between the feet.
    code = tool.main(["--fake", "--config", str(_config_file(tmp_path)), "--reference-c", "23.2"])
    assert code == 0
    output = capsys.readouterr().out
    assert "PASS" in output
    assert "nothing was written" in output
    assert not (tmp_path / "calibration").exists()


def test_cli_writes_to_an_explicit_folder(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    out = tmp_path / "out"
    args = ["--fake", "--config", str(_config_file(tmp_path)), "--output-dir", str(out)]
    assert tool.main([*args, "--reference-c", "25.0"]) == 1
    assert "FAIL" in capsys.readouterr().out
    assert not (out / "thermal.yaml").exists()
    assert tool.main([*args, "--reference-c", "25.0", "--apply-offset"]) == 1
    assert load_thermal_calibration(out / "thermal.yaml", allow_missing=False).offset_c == (
        pytest.approx(2.0)
    )
    assert len(yaml.safe_load((out / tool.CHECK_LOG_NAME).read_text(encoding="utf-8"))) == 2
