"""Ambient gate and acclimatisation timer. There is no bypass to test."""

from __future__ import annotations

import inspect
from datetime import UTC, datetime

import pytest

from src import app
from src.capture.gates import AcclimatisationTracker, AmbientGate
from src.capture.sequencer import CaptureSequencer
from src.clock import ManualClock
from src.datamodel import AmbientReading
from src.errors import (
    AcclimatisationNotMetError,
    AcclimatisationNotStartedError,
    AmbientOutOfRangeError,
    SensorFaultError,
)
from tests.conftest import REFERENCE_CODE, Rig

BYPASS_WORDS = ("force", "override", "bypass", "skip", "ignore", "unsafe", "no_gate", "no-gate")


def _reading(temp_c: float, monotonic_s: float = 0.0, humidity_pct: float = 50.0) -> AmbientReading:
    return AmbientReading(
        temp_c=temp_c,
        humidity_pct=humidity_pct,
        captured_at=datetime(2026, 10, 8, tzinfo=UTC),
        monotonic_s=monotonic_s,
    )


def _gate() -> AmbientGate:
    return AmbientGate(22.0, 25.0, max_reading_age_s=5.0)


@pytest.mark.parametrize("temp_c", [22.0, 22.01, 23.5, 24.99, 25.0])
def test_ambient_in_range_passes(temp_c: float) -> None:
    _gate().check(_reading(temp_c), now_monotonic_s=0.0)


@pytest.mark.parametrize("temp_c", [21.99, 20.0, 0.0, -5.0])
def test_ambient_below_range_is_refused(temp_c: float) -> None:
    with pytest.raises(AmbientOutOfRangeError) as info:
        _gate().check(_reading(temp_c), now_monotonic_s=0.0)
    assert info.value.too_warm is False


@pytest.mark.parametrize("temp_c", [25.01, 26.0, 31.0])
def test_ambient_above_range_is_refused(temp_c: float) -> None:
    with pytest.raises(AmbientOutOfRangeError) as info:
        _gate().check(_reading(temp_c), now_monotonic_s=0.0)
    assert info.value.too_warm is True


def test_stale_or_broken_ambient_reading_is_a_fault_not_a_pass() -> None:
    gate = _gate()
    with pytest.raises(SensorFaultError):
        gate.check(_reading(23.5, monotonic_s=0.0), now_monotonic_s=5.1)
    with pytest.raises(SensorFaultError):
        gate.check(_reading(float("nan")), now_monotonic_s=0.0)
    with pytest.raises(SensorFaultError):
        gate.check(_reading(23.5, humidity_pct=float("nan")), now_monotonic_s=0.0)
    with pytest.raises(SensorFaultError):
        gate.check(_reading(23.5, monotonic_s=10.0), now_monotonic_s=0.0)


def test_timer_must_be_started() -> None:
    tracker = AcclimatisationTracker(900.0, ManualClock())
    with pytest.raises(AcclimatisationNotStartedError):
        tracker.check(REFERENCE_CODE)


def test_timer_not_met_is_refused_until_the_full_period() -> None:
    clock = ManualClock()
    tracker = AcclimatisationTracker(900.0, clock)
    tracker.start(REFERENCE_CODE)
    with pytest.raises(AcclimatisationNotMetError) as info:
        tracker.check(REFERENCE_CODE)
    assert info.value.remaining_s == 900.0
    clock.advance(899.0)
    with pytest.raises(AcclimatisationNotMetError) as info:
        tracker.check(REFERENCE_CODE)
    assert info.value.remaining_s == pytest.approx(1.0)
    clock.advance(1.0)
    tracker.check(REFERENCE_CODE)


def test_timer_is_per_reference_code() -> None:
    clock = ManualClock()
    tracker = AcclimatisationTracker(900.0, clock)
    tracker.start("DFU-0001")
    clock.advance(900.0)
    tracker.start("DFU-0002")
    tracker.check("DFU-0001")
    with pytest.raises(AcclimatisationNotMetError):
        tracker.check("DFU-0002")


def test_starting_again_does_not_reset_a_running_timer_but_restart_does() -> None:
    clock = ManualClock()
    tracker = AcclimatisationTracker(900.0, clock)
    tracker.start(REFERENCE_CODE)
    clock.advance(600.0)
    tracker.start(REFERENCE_CODE)
    assert tracker.remaining_s(REFERENCE_CODE) == 300.0
    tracker.restart(REFERENCE_CODE)
    assert tracker.remaining_s(REFERENCE_CODE) == 900.0
    tracker.clear(REFERENCE_CODE)
    with pytest.raises(AcclimatisationNotStartedError):
        tracker.remaining_s(REFERENCE_CODE)


# --- The gates as the sequencer applies them -------------------------------


@pytest.mark.parametrize("temp_c", [21.9, 25.1])
def test_capture_is_refused_outside_the_ambient_range(rig: Rig, temp_c: float) -> None:
    rig.acclimatise()
    rig.ambient.temp_c = temp_c
    with pytest.raises(AmbientOutOfRangeError):
        rig.station.sequencer.capture(REFERENCE_CODE)
    assert rig.events.names() == ["ambient_read"]


def test_capture_is_refused_when_the_ambient_sensor_fails(rig: Rig) -> None:
    rig.acclimatise()
    rig.ambient.fail = True
    with pytest.raises(SensorFaultError):
        rig.station.sequencer.capture(REFERENCE_CODE)
    assert rig.events.names() == []


def test_capture_is_refused_before_acclimatisation(rig: Rig) -> None:
    rig.station.acclimatisation.start(REFERENCE_CODE)
    rig.clock.advance(rig.config.acclimatisation_s - 1.0)
    with pytest.raises(AcclimatisationNotMetError):
        rig.station.sequencer.capture(REFERENCE_CODE)
    assert rig.events.names() == ["ambient_read"]


def test_there_is_no_bypass_anywhere() -> None:
    assert list(inspect.signature(CaptureSequencer.capture).parameters) == [
        "self",
        "reference_code",
    ]
    for method in (AmbientGate.check, AcclimatisationTracker.check):
        for name in inspect.signature(method).parameters:
            assert not any(word in name for word in BYPASS_WORDS), name
    options = [option for action in app.build_parser()._actions for option in action.option_strings]
    assert options
    for option in options:
        assert not any(word in option for word in BYPASS_WORDS), option
