"""Version recording: values come from the system, and a missing one is not guessed."""

from __future__ import annotations

from pathlib import Path

from src.diagnostics import versions

IDENTIFY = """Executing on device: 0001:01:00.0
Identifying board
Control Protocol Version: 2
Firmware Version: 4.20.0 (release,app,extended context switch buffer)
Logger Version: 0
Board Name: Hailo-8
Device Architecture: HAILO8L
"""


def runner(responses: dict[str, tuple[int, str]]) -> versions.CommandRunner:
    def run(command: list[str]) -> tuple[int, str]:
        return responses.get(" ".join(command[:2]), (127, "command not found"))

    return run


def test_versions_are_parsed_from_tool_output() -> None:
    run = runner(
        {
            "hailortcli --version": (0, "HailoRT-CLI version 4.20.0\n"),
            "hailortcli fw-control": (0, IDENTIFY),
            "dpkg-query -W": (0, "0.3.25-1"),
        }
    )
    assert versions.hailort_version(run) == "4.20.0"
    assert versions.hailo_firmware(run) == (
        "4.20.0 (release,app,extended context switch buffer)",
        "HAILO8L",
    )
    assert versions.picamera2_version(run) == "0.3.25-1"


def test_missing_tools_are_reported_not_guessed(tmp_path: Path) -> None:
    run = runner({})
    assert versions.hailort_version(run) == versions.NOT_FOUND
    assert versions.hailo_firmware(run) == (versions.NOT_FOUND, versions.NOT_FOUND)
    assert versions.pi_model(tmp_path / "absent") == versions.NOT_FOUND
    assert versions.os_release(tmp_path / "absent") == versions.NOT_FOUND


def test_board_and_os_are_read_from_files(tmp_path: Path) -> None:
    model = tmp_path / "model"
    model.write_bytes(b"Raspberry Pi 5 Model B Rev 1.0\x00")
    release = tmp_path / "os-release"
    release.write_text(
        'PRETTY_NAME="Debian GNU/Linux 12 (bookworm)"\nNAME="Debian GNU/Linux"\n', encoding="utf-8"
    )
    assert versions.pi_model(model) == "Raspberry Pi 5 Model B Rev 1.0"
    assert versions.os_release(release) == "Debian GNU/Linux 12 (bookworm)"


def test_table_lists_every_item_asked_for() -> None:
    table = versions.format_table(versions.collect(runner({})))
    for item in ("OS release", "Kernel", "Python", "HailoRT", "Hailo firmware", "picamera2"):
        assert item in table
    assert table.splitlines()[0] == "| Item | Version |"
