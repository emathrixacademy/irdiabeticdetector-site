"""Fake drivers replay fixtures and can be told to misbehave."""

from __future__ import annotations

import numpy as np
import pytest

from src.clock import ManualClock
from src.datamodel import FfcState
from src.errors import HardwareError, SensorFaultError
from src.hardware.fakes import (
    FakeAccelerator,
    FakeAmbientSensor,
    FakeCaptureButton,
    FakeStatusLed,
    FakeThermalCamera,
)
from src.hardware.interfaces import StatusState
from tests.conftest import Rig


def test_thermal_fake_replays_the_fixture_unchanged(rig: Rig) -> None:
    stored = np.load(rig.config.fake.fixture_dir / rig.config.fake.scenario / "thermal_y16.npy")
    frame = rig.thermal.read_raw()
    assert np.array_equal(frame.raw, stored)
    assert frame.monotonic_s == rig.clock.monotonic()


def test_thermal_fake_ffc_states(rig: Rig) -> None:
    camera = rig.thermal
    assert camera.ffc_state() is FfcState.NEVER
    camera.trigger_ffc()
    assert camera.ffc_state() is FfcState.IN_PROGRESS
    assert camera.read_raw().ffc_state is FfcState.IN_PROGRESS
    rig.clock.advance(0.6)
    assert camera.ffc_state() is FfcState.COMPLETE


def test_thermal_fake_can_misbehave() -> None:
    clock = ManualClock()
    camera = FakeThermalCamera(np.full((120, 160), 30000, dtype=np.uint16), clock)
    clock.advance(10.0)
    camera.frame_age_s = 3.0
    assert camera.read_raw().monotonic_s == 7.0
    camera.fail_reads = True
    with pytest.raises(HardwareError):
        camera.read_raw()
    camera.radiometry = False
    assert camera.radiometry_confirmed() is False


def test_color_fake_records_the_light(rig: Rig) -> None:
    rig.color.capture()
    rig.light.on()
    frame = rig.color.capture()
    rig.light.off()
    assert rig.color.light_was_on == [False, True]
    assert frame.image_bgr.ndim == 3
    assert rig.events.names() == ["color_capture", "led_on", "color_capture", "led_off"]


@pytest.mark.parametrize("temp_c", [21.9, 23.5, 25.1])
def test_ambient_fake_values_in_and_out_of_range(temp_c: float) -> None:
    sensor = FakeAmbientSensor(ManualClock(), temp_c, 50.0)
    reading = sensor.read()
    assert reading.temp_c == temp_c
    assert reading.humidity_pct == 50.0
    sensor.fail = True
    with pytest.raises(SensorFaultError):
        sensor.read()


def test_button_fake_presses() -> None:
    button = FakeCaptureButton()
    presses: list[int] = []
    button.press()
    button.set_handler(lambda: presses.append(1))
    button.press()
    button.press()
    button.set_handler(None)
    button.press()
    assert len(presses) == 2


def test_status_led_fake_records_states() -> None:
    led = FakeStatusLed()
    assert led.state is None
    led.set_state(StatusState.ACCLIMATISING)
    led.set_state(StatusState.READY)
    assert led.states == [StatusState.ACCLIMATISING, StatusState.READY]


def test_accelerator_fake_is_deterministic() -> None:
    accelerator = FakeAccelerator(predicted_class=2, class_count=3)
    image = np.zeros((224, 224, 3), dtype=np.uint8)
    first = accelerator.infer(image)
    second = accelerator.infer(np.full_like(image, 200))
    assert int(np.argmax(first)) == 2
    assert np.array_equal(first, second)
    with pytest.raises(HardwareError):
        accelerator.infer(np.zeros((224, 224), dtype=np.uint8))
    with pytest.raises(HardwareError):
        FakeAccelerator(predicted_class=3, class_count=3)
