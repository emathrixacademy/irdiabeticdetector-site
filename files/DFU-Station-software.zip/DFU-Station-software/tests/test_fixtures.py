"""The synthetic fixtures are what they claim to be, and are reproducible."""

from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np
import pytest

from src.config import Config
from src.thermal.convert import y16_to_celsius
from tools import synthetic
from tools.generate_fixtures import DELTAS_C, scenario_name

FIXTURES = Path(__file__).resolve().parent / "fixtures"


def test_required_deltas_are_present() -> None:
    assert set(DELTAS_C) == {0.0, 1.5, 2.19, 2.2, 2.21, 3.5}
    for delta_c in DELTAS_C:
        folder = FIXTURES / scenario_name(delta_c)
        assert (folder / "thermal_y16.npy").is_file()
        assert (folder / "color.png").is_file()
        assert json.loads((folder / "truth.json").read_text(encoding="utf-8"))["synthetic"] is True


@pytest.mark.parametrize("delta_c", DELTAS_C)
def test_committed_fixture_matches_the_generator(delta_c: float) -> None:
    scene = synthetic.default_scene(delta_c)
    stored = np.load(FIXTURES / scenario_name(delta_c) / "thermal_y16.npy")
    assert stored.dtype == np.uint16
    assert stored.shape == (120, 160)
    assert np.array_equal(stored, synthetic.render_thermal_y16(scene))


@pytest.mark.parametrize("delta_c", DELTAS_C)
def test_thermal_fixture_has_exactly_the_stated_temperatures(delta_c: float) -> None:
    temps = y16_to_celsius(np.load(FIXTURES / scenario_name(delta_c) / "thermal_y16.npy"))
    values = sorted({round(float(v), 2) for v in np.unique(temps)})
    expected = sorted({23.0, 30.0, round(30.0 + delta_c, 2)})
    assert values == expected


def test_two_feet_on_a_cool_background() -> None:
    temps = y16_to_celsius(np.load(FIXTURES / "delta_0p00" / "thermal_y16.npy"))
    count, _ = cv2.connectedComponents((temps > 26.0).astype(np.uint8))
    assert count - 1 == 2
    border = np.concatenate([temps[0], temps[-1], temps[:, 0], temps[:, -1]])
    assert np.all(border == 23.0)


def test_per_region_temperatures_are_configurable(config: Config) -> None:
    polygons = config.regions.polygon_map()
    scene = synthetic.default_scene(0.0)
    left = scene.feet[0]
    warmed = synthetic.with_feet(
        scene,
        synthetic.FootSpec(
            "left", left.center_x_px, left.center_y_px, region_offsets_c={"hallux": 1.25}
        ),
        scene.feet[1],
    )
    temps = synthetic.render_temperature_c(warmed, polygons)
    assert sorted({round(float(v), 2) for v in np.unique(temps)}) == [23.0, 30.0, 31.25]


def test_color_fixture_matches_thermal_through_the_homography() -> None:
    color = cv2.imread(str(FIXTURES / "delta_0p00" / "color.png"))
    assert color is not None
    assert color.shape == (synthetic.COLOR_HEIGHT_PX, synthetic.COLOR_WIDTH_PX, 3)
    temps = y16_to_celsius(np.load(FIXTURES / "delta_0p00" / "thermal_y16.npy"))
    inverse = np.linalg.inv(synthetic.fixture_homography())
    # Foot centres in thermal pixels are skin in the colour frame; a corner is not.
    for thermal_xy, is_foot in (((45.0, 60.0), True), ((115.0, 60.0), True), ((5.0, 5.0), False)):
        x, y, w = inverse @ np.array([thermal_xy[0], thermal_xy[1], 1.0])
        pixel = color[round(y / w), round(x / w)]
        assert (int(pixel[2]) > 100) is is_foot
        assert bool(temps[round(thermal_xy[1]), round(thermal_xy[0])] > 26.0) is is_foot


def test_registration_target_fixture_exists() -> None:
    raw = np.load(FIXTURES / "registration_target" / "thermal_y16.npy")
    temps = y16_to_celsius(raw)
    count, _ = cv2.connectedComponents((temps > 30.0).astype(np.uint8))
    assert count - 1 == 35
