"""Config loader: valid file, missing key, bad types and out-of-range values."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
import yaml

from src.config import REQUIRED_REGIONS, load_config, parse_config
from src.errors import ConfigError


def test_example_config_is_valid(example_config_path: Path) -> None:
    config = load_config(example_config_path)
    assert config.asymmetry_threshold_c == 2.2
    assert config.ambient_min_c == 22.0
    assert config.ambient_max_c == 25.0
    assert config.acclimatisation_s == 900
    assert config.working_distance_mm == 420
    assert config.settle_delay_s == 2.0
    assert [name for name, _ in config.regions.polygons] == list(REQUIRED_REGIONS)


def test_missing_key_is_refused(config_data: dict[str, Any]) -> None:
    del config_data["asymmetry_threshold_c"]
    with pytest.raises(ConfigError, match="asymmetry_threshold_c"):
        parse_config(config_data)


def test_missing_nested_key_is_refused(config_data: dict[str, Any]) -> None:
    del config_data["thermal"]["max_frame_age_s"]
    with pytest.raises(ConfigError, match=r"thermal\.max_frame_age_s"):
        parse_config(config_data)


@pytest.mark.parametrize("value", [0.0, -2.2, 12.0])
def test_out_of_range_threshold_is_refused(config_data: dict[str, Any], value: float) -> None:
    config_data["asymmetry_threshold_c"] = value
    with pytest.raises(ConfigError, match="asymmetry_threshold_c"):
        parse_config(config_data)


@pytest.mark.parametrize("value", ["2.2", True, None, [2.2]])
def test_wrong_type_is_refused(config_data: dict[str, Any], value: object) -> None:
    config_data["asymmetry_threshold_c"] = value
    with pytest.raises(ConfigError, match="asymmetry_threshold_c"):
        parse_config(config_data)


def test_unknown_key_is_refused(config_data: dict[str, Any]) -> None:
    config_data["asymetry_threshold_c"] = 2.2
    with pytest.raises(ConfigError, match="unknown config key"):
        parse_config(config_data)


@pytest.mark.parametrize(
    ("key", "value"),
    [("ambient_min_c", 21.9), ("ambient_min_c", 0.0), ("ambient_max_c", 25.1)],
)
def test_ambient_gate_cannot_be_widened_by_config(
    config_data: dict[str, Any], key: str, value: float
) -> None:
    config_data[key] = value
    with pytest.raises(ConfigError, match=key):
        parse_config(config_data)


def test_ambient_gate_can_be_tightened(config_data: dict[str, Any]) -> None:
    config_data["ambient_min_c"] = 22.5
    config_data["ambient_max_c"] = 24.5
    config = parse_config(config_data)
    assert (config.ambient_min_c, config.ambient_max_c) == (22.5, 24.5)


def test_acclimatisation_cannot_be_shortened(config_data: dict[str, Any]) -> None:
    config_data["acclimatisation_s"] = 60
    with pytest.raises(ConfigError, match="acclimatisation_s"):
        parse_config(config_data)


def test_region_map_must_be_complete(config_data: dict[str, Any]) -> None:
    del config_data["regions"]["polygons"]["heel"]
    with pytest.raises(ConfigError, match="heel"):
        parse_config(config_data)


def test_region_points_must_be_normalised(config_data: dict[str, Any]) -> None:
    config_data["regions"]["polygons"]["heel"][0] = [0.0, 1.4]
    with pytest.raises(ConfigError, match="heel"):
        parse_config(config_data)


def test_reference_pattern_that_accepts_names_is_refused(config_data: dict[str, Any]) -> None:
    config_data["reference_code"]["pattern"] = ".+"
    with pytest.raises(ConfigError, match="name"):
        parse_config(config_data)


def test_bad_yaml_and_missing_file_are_refused(tmp_path: Path) -> None:
    with pytest.raises(ConfigError, match="cannot read"):
        load_config(tmp_path / "absent.yaml")
    bad = tmp_path / "bad.yaml"
    bad.write_text("a: [1, 2", encoding="utf-8")
    with pytest.raises(ConfigError, match="not valid YAML"):
        load_config(bad)


def test_force_fake_switches_drivers_only(example_config_path: Path) -> None:
    config = load_config(example_config_path, force_fake=True)
    assert config.is_fake
    assert config.inference.backend == "fake"
    assert (config.ambient_min_c, config.ambient_max_c) == (22.0, 25.0)
    assert config.acclimatisation_s == 900


def test_config_hash_is_stable_and_sensitive(
    config_data: dict[str, Any], tmp_path: Path, example_config_path: Path
) -> None:
    first = parse_config(config_data).config_hash()
    reordered = dict(reversed(list(config_data.items())))
    assert parse_config(reordered).config_hash() == first
    assert len(first) == 64

    copy_path = tmp_path / "config.yaml"
    copy_path.write_text(yaml.safe_dump(config_data), encoding="utf-8")
    assert load_config(copy_path).config_hash() == load_config(example_config_path).config_hash()

    config_data["settle_delay_s"] = 3.0
    assert parse_config(config_data).config_hash() != first
