"""Shared test fixtures. Nothing here needs hardware."""

from __future__ import annotations

import copy
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pytest
import yaml

from src.clock import ManualClock
from src.config import Config, load_config, parse_config
from src.hardware.factory import build_fake_devices
from src.hardware.fakes import (
    EventLog,
    FakeAmbientSensor,
    FakeCaptureButton,
    FakeColorCamera,
    FakeInteriorLight,
    FakeStatusLed,
    FakeThermalCamera,
)
from src.inference.metadata import load_model_metadata, metadata_path
from src.pipeline import AnalysedScan
from src.station import Station, build_station

ROOT = Path(__file__).resolve().parent.parent
EXAMPLE_CONFIG = ROOT / "config" / "config.example.yaml"
REFERENCE_CODE = "DFU-0001"


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    """Skip hardware tests unless running on the Raspberry Pi 5 station."""
    if _on_raspberry_pi():
        return
    skip = pytest.mark.skip(reason="needs the Raspberry Pi 5 station")
    for item in items:
        if item.get_closest_marker("hardware") is not None:
            item.add_marker(skip)


def _on_raspberry_pi() -> bool:
    if not sys.platform.startswith("linux"):
        return False
    try:
        model = Path("/proc/device-tree/model").read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return False
    return "Raspberry Pi 5" in model


@pytest.fixture
def example_config_path() -> Path:
    return EXAMPLE_CONFIG


@pytest.fixture
def config_data() -> dict[str, Any]:
    """The example config as a mutable mapping, for building bad variants."""
    data = yaml.safe_load(EXAMPLE_CONFIG.read_text(encoding="utf-8"))
    assert isinstance(data, dict)
    return copy.deepcopy(data)


@pytest.fixture
def config(tmp_path: Path) -> Config:
    """A valid fake-mode config whose outputs go to a temporary folder."""
    return make_config(tmp_path)


def make_config(tmp_path: Path, **overrides: Any) -> Config:
    data = yaml.safe_load(EXAMPLE_CONFIG.read_text(encoding="utf-8"))
    data["hardware"]["mode"] = "fake"
    data["inference"]["backend"] = "fake"
    data["storage"]["data_dir"] = str(tmp_path / "data")
    data["fake"]["fixture_dir"] = str(ROOT / "tests" / "fixtures")
    for key, value in overrides.items():
        target = data
        *parents, leaf = key.split("__")
        for parent in parents:
            target = target[parent]
        target[leaf] = value
    return parse_config(data)


__all__ = ["EXAMPLE_CONFIG", "REFERENCE_CODE", "ROOT", "load_config", "make_config"]


@dataclass
class Rig:
    """A complete fake station on a manual clock."""

    config: Config
    clock: ManualClock
    events: EventLog
    station: Station

    @property
    def thermal(self) -> FakeThermalCamera:
        assert isinstance(self.station.devices.thermal, FakeThermalCamera)
        return self.station.devices.thermal

    @property
    def color(self) -> FakeColorCamera:
        assert isinstance(self.station.devices.color, FakeColorCamera)
        return self.station.devices.color

    @property
    def light(self) -> FakeInteriorLight:
        assert isinstance(self.station.devices.light, FakeInteriorLight)
        return self.station.devices.light

    @property
    def ambient(self) -> FakeAmbientSensor:
        assert isinstance(self.station.devices.ambient, FakeAmbientSensor)
        return self.station.devices.ambient

    @property
    def button(self) -> FakeCaptureButton:
        assert isinstance(self.station.devices.button, FakeCaptureButton)
        return self.station.devices.button

    @property
    def status_led(self) -> FakeStatusLed:
        assert isinstance(self.station.devices.status_led, FakeStatusLed)
        return self.station.devices.status_led

    def acclimatise(self, reference_code: str = REFERENCE_CODE) -> None:
        """Start the rest timer and let the full period pass on the fake clock."""
        self.station.acclimatisation.start(reference_code)
        self.clock.advance(self.config.acclimatisation_s)

    def scan(
        self, reference_code: str = REFERENCE_CODE, left_is_image_left: bool = False
    ) -> AnalysedScan:
        """One full scan: capture, prepare, operator confirmation, analysis."""
        self.acclimatise(reference_code)
        record = self.station.sequencer.capture(reference_code)
        prepared = self.station.pipeline.prepare(record)
        return self.station.pipeline.analyse(prepared, left_is_image_left)


def make_rig(tmp_path: Path, **overrides: Any) -> Rig:
    config = make_config(tmp_path, **overrides)
    clock = ManualClock()
    events = EventLog()
    metadata = (
        load_model_metadata(metadata_path(config)) if config.inference.backend != "none" else None
    )
    devices = build_fake_devices(config, clock, metadata, events)
    return Rig(
        config=config, clock=clock, events=events, station=build_station(config, clock, devices)
    )


@pytest.fixture
def rig(tmp_path: Path) -> Rig:
    return make_rig(tmp_path)
