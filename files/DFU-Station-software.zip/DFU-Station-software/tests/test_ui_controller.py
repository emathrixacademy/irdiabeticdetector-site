"""Operator workflow, error messages and button parity, with no UI toolkit."""

from __future__ import annotations

import inspect
from pathlib import Path

import numpy as np
import pytest

from src import errors
from src.hardware.interfaces import StatusState
from src.storage import layout
from src.ui import render
from src.ui.controller import Screen, StationController
from src.ui.messages import friendly_message
from tests.conftest import REFERENCE_CODE, Rig, make_rig
from tools import synthetic

TECHNICAL_WORDS = (
    "exception",
    "traceback",
    "ffc",
    "y16",
    "tlinear",
    "radiometr",
    "homography",
    "none",
    "null",
    "segmentation",
    "errno",
    "i2c",
    "uvc",
    "hailo",
    "onnx",
)


def ready_controller(rig: Rig) -> StationController:
    controller = StationController(rig.station)
    assert controller.submit_reference_code(REFERENCE_CODE)
    rig.clock.advance(rig.config.acclimatisation_s)
    return controller


def scans_on_disk(rig: Rig) -> list[Path]:
    return list(rig.config.storage.data_dir.rglob(layout.META_FILE))


# --- 12.2 the workflow -------------------------------------------------------------


def test_full_workflow_from_code_to_next_patient(rig: Rig) -> None:
    controller = StationController(rig.station)
    assert controller.screen is Screen.REFERENCE
    assert rig.status_led.state is StatusState.IDLE

    assert controller.submit_reference_code(REFERENCE_CODE)
    assert controller.screen is Screen.PREPARE
    status = controller.prepare_status()
    assert status is not None
    assert status.remaining_s == rig.config.acclimatisation_s
    assert status.ambient_ok and not status.ready
    assert "OK to scan" in status.ambient_text
    assert rig.status_led.state is StatusState.ACCLIMATISING

    rig.clock.advance(rig.config.acclimatisation_s)
    status = controller.prepare_status()
    assert status is not None and status.ready and status.remaining_s == 0
    assert rig.status_led.state is StatusState.READY

    previews = controller.previews()
    assert previews.thermal_bgr is not None and previews.thermal_bgr.shape == (120, 160, 3)
    assert previews.color_bgr is not None

    assert controller.request_capture()
    assert controller.screen is Screen.CONFIRM_SIDES
    assert controller.prepared is not None
    assert controller.prepared.proposal.left_is_image_left is False
    assert scans_on_disk(rig) == []  # nothing is stored before left/right is confirmed
    assert StatusState.CAPTURING in rig.status_led.states

    assert controller.confirm_sides(False)
    assert controller.screen is Screen.RESULTS
    result = controller.result
    assert result is not None
    assert result.fused.flagged_regions == ("heel",)
    assert result.decision.source == "geometry_confirmed"
    assert len(scans_on_disk(rig)) == 1

    controller.next_patient()
    assert controller.screen is Screen.REFERENCE
    assert controller.reference_code is None
    assert controller.result is None
    assert rig.status_led.state is StatusState.IDLE


def test_next_patient_starts_a_fresh_rest_period(rig: Rig) -> None:
    controller = ready_controller(rig)
    controller.next_patient()
    assert controller.submit_reference_code(REFERENCE_CODE)
    status = controller.prepare_status()
    assert status is not None
    assert status.remaining_s == rig.config.acclimatisation_s


def test_operator_can_correct_left_and_right(rig: Rig) -> None:
    controller = ready_controller(rig)
    assert controller.request_capture()
    assert controller.confirm_sides(True)  # the operator disagrees with the foot shapes
    result = controller.result
    assert result is not None
    assert result.decision.source == "operator_override"
    assert result.asymmetry.region("heel").delta_c == pytest.approx(-3.5, abs=1e-9)


def test_retake_discards_the_scan(rig: Rig) -> None:
    controller = ready_controller(rig)
    assert controller.request_capture()
    controller.retake()
    assert controller.screen is Screen.PREPARE
    assert controller.prepared is None
    assert scans_on_disk(rig) == []


def test_scan_again_keeps_the_patient_and_the_timer(rig: Rig) -> None:
    controller = ready_controller(rig)
    assert controller.request_capture() and controller.confirm_sides(False)
    controller.scan_again()
    assert controller.screen is Screen.PREPARE
    rig.clock.advance(5.0)
    assert controller.request_capture() and controller.confirm_sides(False)
    assert len(scans_on_disk(rig)) == 2


def test_restarting_the_rest_period(rig: Rig) -> None:
    controller = ready_controller(rig)
    controller.restart_rest_period()
    status = controller.prepare_status()
    assert status is not None
    assert status.remaining_s == rig.config.acclimatisation_s
    assert not controller.request_capture()


def test_previews_and_status_are_only_given_on_the_prepare_screen(rig: Rig) -> None:
    controller = StationController(rig.station)
    assert controller.prepare_status() is None
    assert controller.previews().thermal_bgr is None


# --- 12.3 errors -------------------------------------------------------------------


def test_bad_reference_code_is_refused_with_a_message(rig: Rig) -> None:
    controller = StationController(rig.station)
    assert not controller.submit_reference_code("Juan Dela Cruz")
    assert controller.screen is Screen.REFERENCE
    message = controller.message
    assert message is not None
    assert message.title == "Reference code not accepted"
    assert "Juan" not in message.text
    assert rig.status_led.state is StatusState.ERROR
    controller.dismiss_message()
    assert controller.message is None


@pytest.mark.parametrize(("temp_c", "title"), [(26.4, "Room too warm"), (20.5, "Room too cold")])
def test_room_out_of_range_refuses_capture(rig: Rig, temp_c: float, title: str) -> None:
    controller = ready_controller(rig)
    rig.ambient.temp_c = temp_c
    status = controller.prepare_status()
    assert status is not None and not status.ready and not status.ambient_ok
    assert not controller.request_capture()
    assert controller.screen is Screen.PREPARE
    assert controller.message is not None
    assert controller.message.title == title
    assert f"{temp_c:.1f}" in controller.message.text
    assert scans_on_disk(rig) == []


def test_capture_before_the_rest_period_is_refused(rig: Rig) -> None:
    controller = StationController(rig.station)
    controller.submit_reference_code(REFERENCE_CODE)
    rig.clock.advance(rig.config.acclimatisation_s - 125)
    assert not controller.request_capture()
    assert controller.message is not None
    assert controller.message.title == "Rest period not finished"
    assert "2 min 5 s" in controller.message.text
    assert rig.events.names().count("color_capture") == 0


def test_foot_out_of_frame_is_refused(rig: Rig) -> None:
    controller = ready_controller(rig)
    scene = synthetic.default_scene()
    from dataclasses import replace

    cut = synthetic.with_feet(scene, replace(scene.feet[0], center_x_px=150.0), scene.feet[1])
    rig.thermal.set_frame(synthetic.render_thermal_y16(cut))
    assert not controller.request_capture()
    assert controller.message is not None
    assert controller.message.title == "Foot out of view"
    assert controller.screen is Screen.PREPARE
    assert rig.light.is_on is False


def test_sensor_fault_is_reported(rig: Rig) -> None:
    controller = ready_controller(rig)
    rig.ambient.fail = True
    status = controller.prepare_status()
    assert status is not None
    assert status.ambient_text == "Room sensor not responding."
    assert not status.ready
    assert not controller.request_capture()
    assert controller.message is not None
    assert controller.message.title == "Room sensor not responding"


def test_storage_failure_keeps_the_operator_on_the_confirm_screen(
    rig: Rig, monkeypatch: pytest.MonkeyPatch
) -> None:
    controller = ready_controller(rig)
    assert controller.request_capture()

    def refuse(scan: object) -> Path:
        raise errors.StorageError("disk full")

    monkeypatch.setattr(rig.station.store, "save", refuse)
    assert not controller.confirm_sides(False)
    assert controller.screen is Screen.CONFIRM_SIDES
    assert controller.message is not None
    assert controller.message.title == "Scan could not be saved"


def _all_error_classes() -> list[type[errors.StationError]]:
    return [
        cls
        for _, cls in inspect.getmembers(errors, inspect.isclass)
        if issubclass(cls, errors.StationError)
    ]


def _instance(cls: type[errors.StationError]) -> errors.StationError:
    if cls is errors.AmbientOutOfRangeError:
        return errors.AmbientOutOfRangeError(27.0, 22.0, 25.0)
    if cls is errors.AcclimatisationNotMetError:
        return errors.AcclimatisationNotMetError(310.0)
    if cls is errors.FootCountError:
        return errors.FootCountError(1)
    return cls("internal detail: errno 5 at 0x7f, /dev/video0")


@pytest.mark.parametrize("cls", _all_error_classes(), ids=lambda c: c.__name__)
def test_every_refusal_has_a_clear_non_technical_message(cls: type[errors.StationError]) -> None:
    message = friendly_message(_instance(cls))
    assert message.title and message.text
    assert message.text.endswith(".")
    combined = f"{message.title} {message.text}".lower()
    for word in TECHNICAL_WORDS:
        assert word not in combined, f"{cls.__name__}: {word!r}"
    # The internal error text is never shown to the operator.
    assert "errno" not in combined and "/dev/" not in combined
    # Every message tells the operator what to do next.
    assert any(
        phrase in combined
        for phrase in ("again", "technician", "enter", "confirm", "cool", "warm", "to go")
    )


def test_specific_errors_do_not_fall_through_to_the_generic_message() -> None:
    generic = friendly_message(RuntimeError("anything")).title
    assert generic == "Something went wrong"
    specific = [cls for cls in _all_error_classes() if cls is not errors.StationError]
    for cls in specific:
        assert friendly_message(_instance(cls)).title != generic, cls.__name__


def test_the_four_named_refusals() -> None:
    assert friendly_message(errors.AmbientOutOfRangeError(27, 22, 25)).title == "Room too warm"
    assert friendly_message(errors.AcclimatisationNotMetError(60)).title == (
        "Rest period not finished"
    )
    assert friendly_message(errors.FootOutOfFrameError("x")).title == "Foot out of view"
    assert friendly_message(errors.SensorFaultError("x")).title == "Room sensor not responding"


# --- 12.4 button parity ---------------------------------------------------------------


def test_physical_button_does_the_same_as_the_on_screen_button(tmp_path: Path) -> None:
    by_screen = make_rig(tmp_path / "screen")
    by_button = make_rig(tmp_path / "button")
    screen_controller = ready_controller(by_screen)
    button_controller = ready_controller(by_button)

    assert screen_controller.request_capture()
    by_button.button.press()

    assert button_controller.screen is screen_controller.screen is Screen.CONFIRM_SIDES
    assert by_button.events.names() == by_screen.events.names()
    first, second = screen_controller.prepared, button_controller.prepared
    assert first is not None and second is not None
    assert np.array_equal(first.record.thermal.raw, second.record.thermal.raw)
    assert first.proposal == second.proposal
    assert first.record.step_timestamps.keys() == second.record.step_timestamps.keys()


def test_physical_button_is_refused_by_the_same_gates(rig: Rig) -> None:
    controller = StationController(rig.station)
    rig.button.press()  # no patient yet: nothing happens
    assert controller.screen is Screen.REFERENCE
    assert rig.events.names() == []

    controller.submit_reference_code(REFERENCE_CODE)
    rig.button.press()  # rest period not finished
    assert controller.screen is Screen.PREPARE
    assert controller.message is not None
    assert controller.message.title == "Rest period not finished"
    assert rig.events.names().count("color_capture") == 0


def test_physical_button_does_nothing_on_other_screens(rig: Rig) -> None:
    controller = ready_controller(rig)
    rig.button.press()
    assert controller.screen is Screen.CONFIRM_SIDES
    captures = rig.events.names().count("color_capture")
    rig.button.press()
    assert controller.screen is Screen.CONFIRM_SIDES
    assert rig.events.names().count("color_capture") == captures


def test_button_press_goes_through_the_ui_hook_when_one_is_set(rig: Rig) -> None:
    controller = ready_controller(rig)
    calls: list[str] = []
    controller.set_capture_hook(lambda: calls.append("hook"))
    rig.button.press()
    assert calls == ["hook"]
    assert controller.screen is Screen.PREPARE  # the hook decides when to capture
    controller.set_capture_hook(None)
    rig.button.press()
    assert controller.screen is Screen.CONFIRM_SIDES


# --- Pictures and table ------------------------------------------------------------------


def test_results_pictures_and_table(rig: Rig) -> None:
    controller = ready_controller(rig)
    assert controller.request_capture()
    prepared = controller.prepared
    assert prepared is not None
    assert render.confirm_picture(prepared).shape == (480, 640, 3)
    assert controller.confirm_sides(False)
    scan = controller.result
    assert scan is not None

    heatmap = render.results_heatmap(scan, rig.config)
    assert heatmap.shape == (480, 640, 3)
    assert heatmap.dtype == np.uint8
    # Drawing on the picture never touches the measurement.
    assert scan.record.thermal.temps_c.shape == (120, 160)

    rows = render.region_rows(scan)
    assert [row.name for row in rows][-1] == "heel"
    heel = rows[-1]
    assert (heel.left, heel.right, heel.delta, heel.flagged) == ("33.5", "30.0", "+3.50", True)
    assert sum(row.flagged for row in rows) == 1


def test_table_shows_na_for_a_region_that_could_not_be_compared(rig: Rig) -> None:
    import dataclasses

    scan = rig.scan()
    regions = tuple(
        dataclasses.replace(region, delta_c=None, left_mean_c=None)
        if region.name == "hallux"
        else region
        for region in scan.asymmetry.regions
    )
    partial = dataclasses.replace(
        scan, asymmetry=dataclasses.replace(scan.asymmetry, regions=regions)
    )
    hallux = render.region_rows(partial)[0]
    assert (hallux.left, hallux.delta) == ("n/a", "n/a")


def test_countdown_text() -> None:
    assert render.countdown_text(900) == "15:00"
    assert render.countdown_text(59.2) == "01:00"
    assert render.countdown_text(0.4) == "00:01"
    assert render.countdown_text(0) == "00:00"
    assert render.countdown_text(-3) == "00:00"
