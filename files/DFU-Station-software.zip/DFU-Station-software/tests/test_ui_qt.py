"""The touchscreen app, run off-screen against the fake station."""

from __future__ import annotations

import os
import sys
from collections.abc import Iterator
from pathlib import Path

import pytest

# On a Linux machine with no display, use Qt's off-screen platform. Elsewhere
# the normal platform is used with windows that are never put on the screen,
# so fonts and sizes are the real ones.
if (
    sys.platform.startswith("linux")
    and not os.environ.get("DISPLAY")
    and not os.environ.get("WAYLAND_DISPLAY")
):
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

QtWidgets = pytest.importorskip("PyQt5.QtWidgets", reason="PyQt5 is needed for the UI tests")
from PyQt5 import QtCore  # noqa: E402

from src.ui.controller import Screen  # noqa: E402
from src.ui.qt_app import SCREEN_HEIGHT_PX, SCREEN_WIDTH_PX, MainWindow  # noqa: E402
from tests.conftest import REFERENCE_CODE, Rig, make_rig  # noqa: E402

SCREENSHOT_DIR_ENV = "DFU_UI_SCREENSHOTS"


@pytest.fixture(scope="module")
def application() -> Iterator[object]:
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    yield app


@pytest.fixture
def window(application: object, tmp_path: Path) -> Iterator[tuple[MainWindow, Rig]]:
    rig = make_rig(tmp_path)
    main = MainWindow(rig.station, synchronous=True)
    main.timer.stop()  # the tests drive the clock themselves
    main.setAttribute(QtCore.Qt.WA_DontShowOnScreen, True)
    main.resize(SCREEN_WIDTH_PX, SCREEN_HEIGHT_PX)
    main.show()
    yield main, rig
    main.close()


def snapshot(main: MainWindow, name: str) -> None:
    """Save a picture of the window when DFU_UI_SCREENSHOTS names a folder."""
    folder = os.environ.get(SCREENSHOT_DIR_ENV)
    if folder:
        QtWidgets.QApplication.processEvents()
        main.grab().save(str(Path(folder) / f"{name}.png"))


def enter_code(main: MainWindow, code: str) -> None:
    for character in code:
        main.key_buttons[character].click()


def test_window_fits_a_7_inch_touchscreen(window: tuple[MainWindow, Rig]) -> None:
    main, _ = window
    QtWidgets.QApplication.processEvents()
    assert main.width() <= SCREEN_WIDTH_PX
    assert main.height() <= SCREEN_HEIGHT_PX
    for page in main._pages.values():
        hint = page.minimumSizeHint()
        assert hint.width() <= SCREEN_WIDTH_PX, hint.width()
        assert hint.height() <= SCREEN_HEIGHT_PX, hint.height()


def test_on_screen_keys_cover_a_reference_code(window: tuple[MainWindow, Rig]) -> None:
    main, _ = window
    for character in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_":
        assert character in main.key_buttons
    enter_code(main, "DFU-0001X")
    main.delete_character()
    assert main.code_label.text() == "DFU-0001"
    main.clear_code()
    assert main.code_label.text() == ""


def test_whole_workflow_through_the_widgets(window: tuple[MainWindow, Rig]) -> None:
    main, rig = window
    assert main.controller.screen is Screen.REFERENCE
    snapshot(main, "1_reference")

    enter_code(main, REFERENCE_CODE)
    main.start_button.click()
    assert main.controller.screen is Screen.PREPARE
    assert main.stack.currentWidget() is main._pages[Screen.PREPARE]
    main.tick()
    assert main.countdown_label.text() == "15:00"
    assert not main.capture_button.isEnabled()
    assert "Resting" in main.state_label.text()
    assert "23.5" in main.ambient_label.text()
    assert main.thermal_preview.pixmap() is not None
    snapshot(main, "2_resting")

    rig.clock.advance(rig.config.acclimatisation_s)
    main.tick()
    assert main.countdown_label.text() == "00:00"
    assert main.capture_button.isEnabled()
    assert main.state_label.text() == "Ready to scan."
    snapshot(main, "3_ready")

    main.capture_button.click()
    assert main.controller.screen is Screen.CONFIRM_SIDES
    assert "foot B is the left foot" in main.proposal_label.text()
    assert main.confirm_picture.pixmap() is not None
    snapshot(main, "4_confirm")

    main.left_is_b_button.click()
    assert main.controller.screen is Screen.RESULTS
    assert REFERENCE_CODE in main.result_title.text()
    assert main.table.rowCount() == 8
    assert main.table.item(7, 0).text() == "heel"
    assert "FLAG" in main.table.item(7, 3).text()
    assert "FLAG" not in main.table.item(0, 3).text()
    summary = main.summary_label.text()
    assert "predicted class" in summary
    assert "not a clinical assessment" in summary
    for word in ("grade", "wagner", "diagnos"):
        assert word not in summary.lower()
        assert word not in main.result_title.text().lower()
    snapshot(main, "5_results")

    assert len(list(rig.config.storage.data_dir.rglob("meta.json"))) == 1


def test_physical_button_and_screen_button_take_the_same_path(
    window: tuple[MainWindow, Rig],
) -> None:
    main, rig = window
    enter_code(main, REFERENCE_CODE)
    main.start_button.click()
    rig.clock.advance(rig.config.acclimatisation_s)
    main.tick()
    rig.button.press()  # the GPIO button, through the Qt signal
    QtWidgets.QApplication.processEvents()
    assert main.controller.screen is Screen.CONFIRM_SIDES
    assert rig.events.names().count("ffc_trigger") == 1


def test_refusal_is_shown_as_a_plain_message(window: tuple[MainWindow, Rig]) -> None:
    main, rig = window
    enter_code(main, REFERENCE_CODE)
    main.start_button.click()
    rig.clock.advance(rig.config.acclimatisation_s)
    rig.ambient.temp_c = 27.3
    main.tick()
    assert not main.capture_button.isEnabled()
    assert "too warm" in main.ambient_label.text()
    rig.button.press()  # the physical button cannot get round the gate either
    QtWidgets.QApplication.processEvents()
    assert main.controller.screen is Screen.PREPARE
    assert main.last_message_text.startswith("Room too warm: The room is 27.3")
    snapshot(main, "6_too_warm")


def test_a_name_typed_as_a_code_is_refused(window: tuple[MainWindow, Rig]) -> None:
    main, _ = window
    enter_code(main, "MARIA")
    main.start_button.click()
    assert main.controller.screen is Screen.REFERENCE
    assert main.last_message_text.startswith("Reference code not accepted")
