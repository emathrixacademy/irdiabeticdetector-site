"""Readiness for data gathering: no-classifier mode, fake data kept apart, station info."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path
from typing import Any

import pytest
import yaml

from src.config import FAKE_DATA_SUBDIR, load_config, parse_config
from src.fusion.fuse import NO_CLASSIFIER_LINE, RESEARCH_NOTICE, summary_lines
from src.storage import layout
from src.storage.store import CSV_COLUMNS
from src.ui.controller import Screen, StationController
from tests.conftest import EXAMPLE_CONFIG, REFERENCE_CODE, ROOT, Rig, make_rig


def collection_rig(tmp_path: Path, **overrides: Any) -> Rig:
    return make_rig(tmp_path, inference__backend="none", **overrides)


# --- Collecting data with no classifier -------------------------------------------


def test_station_runs_with_no_classifier_and_no_model_files(tmp_path: Path) -> None:
    import shutil

    fixtures = tmp_path / "fixtures_without_model"
    shutil.copytree(ROOT / "tests" / "fixtures" / "delta_3p50", fixtures / "delta_3p50")
    shutil.copy(ROOT / "tests" / "fixtures" / "registration.yaml", fixtures)
    assert not (fixtures / "model_meta.json").exists()
    rig = collection_rig(tmp_path, fake__fixture_dir=str(fixtures))
    assert rig.station.metadata is None  # no model_meta.json was needed
    assert rig.scan().classifier is None


def test_scan_is_measured_and_stored_in_full_without_a_classifier(tmp_path: Path) -> None:
    # Fixtures come from the usual folder; only the classifier is absent.
    rig = collection_rig(tmp_path)
    scan = rig.scan()
    assert scan.classifier is None
    assert scan.asymmetry.flagged_regions == ("heel",)
    assert scan.asymmetry.region("heel").delta_c == pytest.approx(3.5, abs=1e-9)
    assert scan.fused.any_region_flagged is True
    assert scan.fused.predicted_class is None
    assert scan.fused.predicted_label is None
    assert scan.fused.confidence is None

    folder = rig.station.store.save(scan)
    assert {item.name for item in folder.iterdir()} == set(layout.SCAN_FILES)
    meta = json.loads((folder / layout.META_FILE).read_text(encoding="utf-8"))
    assert meta["classifier"]["ran"] is False
    assert meta["classifier"]["predicted_class"] is None
    assert meta["asymmetry"]["flagged_regions"] == ["heel"]

    with rig.station.store.csv_path.open(newline="", encoding="utf-8") as handle:
        row = next(csv.DictReader(handle))
    assert tuple(row) == CSV_COLUMNS
    # Empty, not zero and not a made-up class.
    assert row["predicted_class"] == ""
    assert row["predicted_label"] == ""
    assert row["confidence"] == ""
    assert row["model_id"] == ""
    assert row["heel_delta_c"] == "3.5000"
    assert row["heel_flagged"] == "1"
    assert row["ambient_temp_c"] == "23.50"


def test_summary_says_plainly_there_is_no_colour_model(tmp_path: Path) -> None:
    lines = summary_lines(collection_rig(tmp_path).scan().fused)
    assert lines[2] == NO_CLASSIFIER_LINE
    assert lines[-1] == RESEARCH_NOTICE
    assert "predicted class" not in " ".join(lines).lower()


def test_with_a_classifier_the_fields_are_filled(rig: Rig) -> None:
    scan = rig.scan()
    assert scan.classifier is not None
    folder = rig.station.store.save(scan)
    meta = json.loads((folder / layout.META_FILE).read_text(encoding="utf-8"))
    assert meta["classifier"]["ran"] is True
    assert meta["classifier"]["predicted_label"] == "class_0"


def test_whole_workflow_without_a_classifier(tmp_path: Path) -> None:
    rig = collection_rig(tmp_path)
    controller = StationController(rig.station)
    assert controller.submit_reference_code(REFERENCE_CODE)
    rig.clock.advance(rig.config.acclimatisation_s)
    assert controller.request_capture()
    assert controller.confirm_sides(False)
    assert controller.screen is Screen.RESULTS
    assert controller.message is None
    assert not controller.station_info().classifier_installed


# --- Fake-mode scans never mix with real ones ---------------------------------------


def _config_data() -> dict[str, Any]:
    data = yaml.safe_load(EXAMPLE_CONFIG.read_text(encoding="utf-8"))
    assert isinstance(data, dict)
    return data


def test_real_mode_writes_to_the_data_folder() -> None:
    config = parse_config(_config_data())
    assert not config.is_fake
    assert config.storage.data_dir == Path("data")


def test_fake_mode_writes_to_its_own_folder_however_it_is_switched_on(tmp_path: Path) -> None:
    data = _config_data()
    data["hardware"]["mode"] = "fake"
    assert parse_config(data).storage.data_dir == Path("data") / FAKE_DATA_SUBDIR

    forced = load_config(EXAMPLE_CONFIG, force_fake=True)
    assert forced.storage.data_dir == Path("data") / FAKE_DATA_SUBDIR

    # A config already in fake mode, forced again, does not nest the folder.
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(data), encoding="utf-8")
    assert load_config(path, force_fake=True).storage.data_dir == Path("data") / FAKE_DATA_SUBDIR


def test_fake_scans_are_marked_and_kept_out_of_the_real_folder(rig: Rig) -> None:
    folder = rig.station.store.save(rig.scan())
    data_dir = rig.config.storage.data_dir
    assert data_dir.name == FAKE_DATA_SUBDIR
    assert data_dir in folder.parents
    assert json.loads((folder / layout.META_FILE).read_text("utf-8"))["fake_mode"] is True
    real_dir = data_dir.parent
    assert [item.name for item in real_dir.iterdir()] == [FAKE_DATA_SUBDIR]


# --- What the operator sees about the station ----------------------------------------


def test_station_info_shows_the_clock_storage_and_scan_count(rig: Rig) -> None:
    controller = StationController(rig.station)
    info = controller.station_info()
    # The test clock starts at 2026-10-08 01:00 UTC.
    assert info.utc_time_text == "01:00 UTC"
    assert "2026" in info.local_time_text
    assert info.free_mb is not None and info.free_mb > 0
    assert info.scans_today == 0
    assert info.fake_mode is True
    assert info.classifier_installed is True

    rig.station.store.save(rig.scan())
    rig.clock.advance(60.0)
    rig.station.store.save(rig.scan("DFU-0002"))
    assert controller.station_info().scans_today == 2

    lines = controller.station_info().lines()
    assert lines[0].startswith("Station clock: ")
    assert "call the technician" in lines[0]
    assert "Scans stored today: 2" in lines[1]
    assert any("DEMO MODE" in line for line in lines)


def test_scans_from_another_day_are_not_counted_as_today(rig: Rig) -> None:
    controller = StationController(rig.station)
    rig.station.store.save(rig.scan())
    rig.clock.advance(24 * 3600.0)
    assert controller.station_info().scans_today == 0


def test_low_storage_is_called_out(tmp_path: Path) -> None:
    plenty = StationController(make_rig(tmp_path / "a").station).station_info()
    assert plenty.low_space is False
    assert not any("NEARLY FULL" in line for line in plenty.lines())

    tight = StationController(
        make_rig(tmp_path / "b", storage__low_space_warning_mb=10**9).station
    ).station_info()
    assert tight.low_space is True
    assert any("NEARLY FULL" in line for line in tight.lines())


def test_data_collection_mode_is_stated_on_the_screen(tmp_path: Path) -> None:
    lines = StationController(collection_rig(tmp_path).station).station_info().lines()
    assert any("Data collection:" in line for line in lines)


# --- On the real widgets ---------------------------------------------------------------


def test_touchscreen_shows_station_info_and_marks_demo_mode(tmp_path: Path) -> None:
    import os

    if sys.platform.startswith("linux") and not os.environ.get("DISPLAY"):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    widgets = pytest.importorskip("PyQt5.QtWidgets")
    from PyQt5 import QtCore

    from src.ui.qt_app import SCREEN_HEIGHT_PX, SCREEN_WIDTH_PX, MainWindow

    application = widgets.QApplication.instance() or widgets.QApplication([])
    rig = collection_rig(tmp_path)
    window = MainWindow(rig.station, synchronous=True)
    window.timer.stop()
    window.setAttribute(QtCore.Qt.WA_DontShowOnScreen, True)
    window.resize(SCREEN_WIDTH_PX, SCREEN_HEIGHT_PX)
    window.show()
    application.processEvents()
    try:
        info = window.info_label.text()
        assert "Station clock:" in info and "01:00 UTC" in info
        assert "Storage free:" in info
        assert "Data collection:" in info
        assert "DEMO MODE" in info
        for page in window._pages.values():
            hint = page.minimumSizeHint()
            assert hint.width() <= SCREEN_WIDTH_PX and hint.height() <= SCREEN_HEIGHT_PX

        for character in REFERENCE_CODE:
            window.key_buttons[character].click()
        window.start_button.click()
        assert window.patient_label.text() == f"DEMO: Patient {REFERENCE_CODE}"
        rig.clock.advance(rig.config.acclimatisation_s)
        window.tick()
        window.capture_button.click()
        window.left_is_b_button.click()
        assert window.result_title.text().startswith("DEMO: Patient")
        assert "Colour model: not installed" in window.summary_label.text()
        folder = os.environ.get("DFU_UI_SCREENSHOTS")
        if folder:
            application.processEvents()
            window.grab().save(str(Path(folder) / "7_results_no_model.png"))
            window.next_patient()
            application.processEvents()
            window.grab().save(str(Path(folder) / "8_reference_info.png"))
    finally:
        window.close()
