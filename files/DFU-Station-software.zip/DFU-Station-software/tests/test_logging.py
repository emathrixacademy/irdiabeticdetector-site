"""No log line carries a reference code or image data."""

from __future__ import annotations

import io
import logging

import numpy as np

from src.config import Config
from src.logging_setup import REDACTED_CODE, attach_redaction, setup_logging


def _capture(config: Config) -> tuple[logging.Logger, io.StringIO]:
    logger = setup_logging("DEBUG", config.reference_code.pattern)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    attach_redaction(handler, config.reference_code.pattern)
    logger.addHandler(handler)
    return logger, stream


def test_reference_code_is_redacted(config: Config) -> None:
    logger, stream = _capture(config)
    logger.info("scan started for DFU-0001")
    logger.info("scan started for %s", "DFU-0042")
    logging.getLogger("src.storage.writer").warning("wrote data/20261008_AB-123/scan")
    output = stream.getvalue()
    assert "DFU-0001" not in output
    assert "DFU-0042" not in output
    assert "AB-123" not in output
    assert output.count(REDACTED_CODE) == 3


def test_image_data_is_not_logged(config: Config) -> None:
    logger, stream = _capture(config)
    frame = np.full((120, 160), 30515, dtype=np.uint16)
    logger.info("frame %s", frame)
    logger.info("png %s", b"\x89PNG\r\n" + bytes(2000))
    output = stream.getvalue()
    assert "30515" not in output
    assert "PNG" not in output
    assert "<array shape=(120, 160) dtype=uint16>" in output
    assert "bytes>" in output


def test_ordinary_messages_pass_through(config: Config) -> None:
    logger, stream = _capture(config)
    logger.info("ambient %.1f C in range", 23.5)
    assert "ambient 23.5 C in range" in stream.getvalue()
