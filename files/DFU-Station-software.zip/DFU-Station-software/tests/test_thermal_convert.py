"""Y16 to Celsius: the formula, and rejection of implausible frames."""

from __future__ import annotations

import numpy as np
import pytest

from src.errors import InvalidFrameError
from src.thermal.convert import check_plausible, y16_to_celsius


@pytest.mark.parametrize(
    ("raw", "expected_c"),
    [(27315, 0.0), (29815, 25.0), (30515, 32.0), (31015, 37.0), (33315, 60.0)],
)
def test_formula_is_raw_over_100_minus_273_15(raw: int, expected_c: float) -> None:
    temps = y16_to_celsius(np.array([[raw]], dtype=np.uint16))
    assert temps[0, 0] == pytest.approx(expected_c, abs=1e-9)
    assert temps[0, 0] == pytest.approx(raw / 100 - 273.15, abs=1e-12)


def test_conversion_is_vectorised_and_keeps_shape() -> None:
    raw = np.arange(29000, 29000 + 120 * 160, dtype=np.uint16).reshape(120, 160)
    temps = y16_to_celsius(raw)
    assert temps.shape == (120, 160)
    assert temps.dtype == np.float64
    assert np.allclose(temps, raw / 100.0 - 273.15)
    # One count is one hundredth of a degree.
    assert np.allclose(np.diff(temps, axis=1), 0.01)


@pytest.mark.parametrize("dtype", [np.uint8, np.int16, np.float32])
def test_non_y16_data_is_refused(dtype: type) -> None:
    with pytest.raises(InvalidFrameError):
        y16_to_celsius(np.zeros((120, 160), dtype=dtype))


def test_plausible_frame_passes() -> None:
    temps = np.full((120, 160), 30.0)
    temps[0, 0] = 0.0
    temps[1, 1] = 60.0
    check_plausible(temps, 0.0, 60.0)


@pytest.mark.parametrize("bad_value", [-0.01, 60.01, -273.15, 382.2, float("nan"), float("inf")])
def test_frame_with_any_implausible_pixel_is_rejected(bad_value: float) -> None:
    temps = np.full((120, 160), 30.0)
    temps[60, 80] = bad_value
    with pytest.raises(InvalidFrameError):
        check_plausible(temps, 0.0, 60.0)
