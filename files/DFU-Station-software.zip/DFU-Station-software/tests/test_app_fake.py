"""`python -m src.app --fake` runs a complete scan with no hardware."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest
import yaml

from src import app
from src.storage import layout
from tests.conftest import EXAMPLE_CONFIG, REFERENCE_CODE, ROOT


def _fake_config_file(tmp_path: Path) -> Path:
    data = yaml.safe_load(EXAMPLE_CONFIG.read_text(encoding="utf-8"))
    data["storage"]["data_dir"] = str(tmp_path / "data")
    data["fake"]["fixture_dir"] = str(ROOT / "tests" / "fixtures")
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(data), encoding="utf-8")
    return path


def _scan_dirs(tmp_path: Path) -> list[Path]:
    return [path.parent for path in (tmp_path / "data").rglob(layout.META_FILE)]


def test_one_fake_scan_writes_one_record(tmp_path: Path) -> None:
    config_path = _fake_config_file(tmp_path)
    code = app.main(
        [
            "--fake", "--headless", "--config", str(config_path),
            "--reference-code", REFERENCE_CODE, "--left-foot", "image-right",
        ]
    )  # fmt: skip
    assert code == 0
    scans = _scan_dirs(tmp_path)
    assert len(scans) == 1
    scan = scans[0]
    assert (scan / layout.COLOR_FILE).is_file()
    raw = np.load(scan / layout.THERMAL_RAW_FILE)
    temps = np.load(scan / layout.THERMAL_TEMP_FILE)
    assert raw.dtype == np.uint16
    assert temps.shape == raw.shape == (120, 160)
    meta = json.loads((scan / layout.META_FILE).read_text(encoding="utf-8"))
    assert meta["reference_code"] == REFERENCE_CODE
    assert len(meta["config_hash"]) == 64
    assert meta["ambient"]["temp_c"] == 23.5
    assert not list((tmp_path / "data").rglob(".incomplete-*"))
    assert {item.name for item in scan.iterdir()} == set(layout.SCAN_FILES)
    assert meta["asymmetry"]["flagged_regions"] == ["heel"]
    assert meta["sidedness"]["source"] == "geometry_confirmed"
    # Fake-mode scans are synthetic: they go in their own folder, never among real scans.
    fake_dir = tmp_path / "data" / "_fake_mode"
    assert scan.parent.parent == fake_dir
    assert len((fake_dir / "scans.csv").read_text(encoding="utf-8").splitlines()) == 2
    assert not (tmp_path / "data" / "scans.csv").exists()
    assert meta["fake_mode"] is True


def test_headless_scan_needs_the_operator_to_state_left_and_right(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    config_path = _fake_config_file(tmp_path)
    code = app.main(
        ["--fake", "--headless", "--config", str(config_path), "--reference-code", REFERENCE_CODE]
    )
    assert code == 2
    assert "--left-foot" in capsys.readouterr().err
    assert _scan_dirs(tmp_path) == []


def test_fake_scan_with_a_bad_reference_code_writes_nothing(tmp_path: Path) -> None:
    config_path = _fake_config_file(tmp_path)
    code = app.main(
        [
            "--fake", "--headless", "--config", str(config_path),
            "--reference-code", "Juan Dela Cruz", "--left-foot", "image-right",
        ]
    )  # fmt: skip
    assert code == 1
    assert _scan_dirs(tmp_path) == []


def test_without_headless_the_touchscreen_app_is_started(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    pytest.importorskip("PyQt5.QtWidgets")
    from src.ui import qt_app

    started: list[bool] = []

    def fake_run_ui(station: object) -> int:
        started.append(True)
        station.close()  # type: ignore[attr-defined]
        return 0

    monkeypatch.setattr(qt_app, "run_ui", fake_run_ui)
    assert app.main(["--fake", "--config", str(_fake_config_file(tmp_path))]) == 0
    assert started == [True]


def test_bad_config_stops_the_app(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    bad = tmp_path / "config.yaml"
    bad.write_text("asymmetry_threshold_c: 2.2\n", encoding="utf-8")
    arguments = ["--fake", "--headless", "--config", str(bad), "--reference-code", "X"]
    assert app.main([*arguments, "--left-foot", "image-left"]) == 2
    assert "Cannot start" in capsys.readouterr().err
