"""Segmentation: plantar mask, foot count, frame edge, left/right, normalisation."""

from __future__ import annotations

from dataclasses import replace

import numpy as np
import pytest

from src.config import Config
from src.datamodel import TempArray
from src.errors import FootCountError, FootOutOfFrameError, SidednessError
from src.segmentation.geometry import canonical_frame, measure_foot, warp_to_canonical
from src.segmentation.mask import segment_feet
from src.segmentation.sidedness import (
    confirm_sidedness,
    measure_feet,
    orient_feet,
    propose_sidedness,
)
from src.thermal.convert import y16_to_celsius
from tools import synthetic

AMBIENT_C = 23.5


def temps_of(scene: synthetic.SceneSpec) -> TempArray:
    return y16_to_celsius(synthetic.render_thermal_y16(scene))


def _moved(foot: synthetic.FootSpec, **changes: float) -> synthetic.FootSpec:
    return replace(foot, **changes)


# --- 7.1 plantar mask --------------------------------------------------------


def test_two_feet_are_found(config: Config) -> None:
    temps = temps_of(synthetic.default_scene())
    masks = segment_feet(temps, AMBIENT_C, config.segmentation)
    assert masks.threshold_c == pytest.approx(AMBIENT_C + config.segmentation.min_above_reference_c)
    assert masks.background_c == 23.0
    truth = temps > 26.0
    found = masks.image_left | masks.image_right
    # Every masked pixel is foot, and all but a few one-pixel spurs are found.
    assert not (found & ~truth).any()
    assert found.sum() / truth.sum() > 0.99
    assert not (masks.image_left & masks.image_right).any()
    left_columns = np.nonzero(masks.image_left)[1]
    right_columns = np.nonzero(masks.image_right)[1]
    assert left_columns.max() < right_columns.min()


def test_mask_does_not_change_any_temperature(config: Config) -> None:
    temps = temps_of(synthetic.default_scene(3.5))
    before = temps.copy()
    segment_feet(temps, AMBIENT_C, config.segmentation)
    assert np.array_equal(temps, before)


def test_one_foot_is_refused(config: Config) -> None:
    scene = synthetic.default_scene()
    with pytest.raises(FootCountError) as info:
        segment_feet(
            temps_of(synthetic.with_feet(scene, scene.feet[0])), AMBIENT_C, config.segmentation
        )
    assert info.value.found == 1


def test_no_feet_is_refused(config: Config) -> None:
    with pytest.raises(FootCountError) as info:
        segment_feet(np.full((120, 160), 23.0), AMBIENT_C, config.segmentation)
    assert info.value.found == 0


def test_three_warm_objects_are_refused(config: Config) -> None:
    scene = synthetic.default_scene()
    narrow = [_moved(foot, width_px=30.0) for foot in scene.feet]
    extra = synthetic.FootSpec("left", 80.0, 60.0, width_px=30.0)
    feet = (_moved(narrow[0], center_x_px=132.0), _moved(narrow[1], center_x_px=28.0), extra)
    with pytest.raises(FootCountError) as info:
        segment_feet(temps_of(synthetic.with_feet(scene, *feet)), AMBIENT_C, config.segmentation)
    assert info.value.found == 3


def test_touching_feet_are_refused(config: Config) -> None:
    scene = synthetic.default_scene()
    left, right = scene.feet
    together = synthetic.with_feet(
        scene, _moved(left, center_x_px=98.0), _moved(right, center_x_px=62.0)
    )
    with pytest.raises(FootCountError) as info:
        segment_feet(temps_of(together), AMBIENT_C, config.segmentation)
    assert info.value.found == 1


def test_small_warm_speck_is_ignored(config: Config) -> None:
    temps = temps_of(synthetic.default_scene())
    temps[5:9, 76:80] = 31.0  # a 16-pixel warm speck, far below a foot's area
    masks = segment_feet(temps, AMBIENT_C, config.segmentation)
    assert not (masks.image_left | masks.image_right)[5:9, 76:80].any()


def test_warm_cabinet_background_is_not_foot(config: Config) -> None:
    # Room sensor reads 23.5 C but the cabinet interior has warmed to 26 C.
    scene = synthetic.default_scene(background_c=26.0)
    masks = segment_feet(temps_of(scene), AMBIENT_C, config.segmentation)
    assert masks.reference_c == 26.0
    found = masks.image_left | masks.image_right
    truth = temps_of(scene) > 28.0
    assert not (found & ~truth).any()
    assert found.sum() / truth.sum() > 0.99


def test_cool_feet_just_above_the_threshold_are_still_found(config: Config) -> None:
    scene = synthetic.default_scene(base_c=25.8)
    masks = segment_feet(temps_of(scene), AMBIENT_C, config.segmentation)
    assert masks.image_left.sum() > config.segmentation.min_foot_area_px


# --- 7.4 both feet in frame ---------------------------------------------------


@pytest.mark.parametrize(
    "change",
    [
        {"center_x_px": 150.0},  # off the right edge
        {"center_y_px": 80.0},  # heel off the bottom
        {"center_y_px": 40.0},  # toes off the top
    ],
)
def test_a_foot_cut_off_at_the_frame_edge_is_refused(
    config: Config, change: dict[str, float]
) -> None:
    scene = synthetic.default_scene()
    cut = synthetic.with_feet(scene, _moved(scene.feet[0], **change), scene.feet[1])
    with pytest.raises(FootOutOfFrameError):
        segment_feet(temps_of(cut), AMBIENT_C, config.segmentation)


def test_a_foot_off_the_left_edge_is_refused(config: Config) -> None:
    scene = synthetic.default_scene()
    cut = synthetic.with_feet(scene, scene.feet[0], _moved(scene.feet[1], center_x_px=10.0))
    with pytest.raises(FootOutOfFrameError):
        segment_feet(temps_of(cut), AMBIENT_C, config.segmentation)


def test_a_foot_one_pixel_inside_the_frame_is_accepted(config: Config) -> None:
    scene = synthetic.default_scene()
    near = synthetic.with_feet(scene, scene.feet[0], _moved(scene.feet[1], center_x_px=21.0))
    masks = segment_feet(temps_of(near), AMBIENT_C, config.segmentation)
    assert np.nonzero(masks.image_left)[1].min() >= 1


# --- 7.3 normalisation --------------------------------------------------------


@pytest.mark.parametrize("rotation_deg", [0.0, 6.0, -9.0])
def test_foot_axis_length_and_toe_end(config: Config, rotation_deg: float) -> None:
    scene = synthetic.default_scene(rotation_deg=rotation_deg)
    masks = segment_feet(temps_of(scene), AMBIENT_C, config.segmentation)
    left_spec = scene.feet[0]  # anatomical left, on the image right
    shape = measure_foot(masks.image_right, config.segmentation)
    assert shape.length_px == pytest.approx(left_spec.length_px, abs=3.0)
    assert shape.width_px == pytest.approx(left_spec.width_px, abs=3.0)
    assert shape.angle_deg == pytest.approx(-left_spec.rotation_deg, abs=3.0)
    # Toes are up in these scenes, so toe-to-heel points down the image.
    assert shape.toe_to_heel[1] > 0.95


def test_upside_down_feet_are_still_oriented_toe_to_heel(config: Config) -> None:
    scene = synthetic.default_scene()
    flipped = synthetic.with_feet(scene, *[_moved(foot, rotation_deg=180.0) for foot in scene.feet])
    masks = segment_feet(temps_of(flipped), AMBIENT_C, config.segmentation)
    shape = measure_foot(masks.image_left, config.segmentation)
    assert shape.toe_to_heel[1] < -0.95


def test_both_feet_land_in_the_same_canonical_frame(config: Config) -> None:
    scene = synthetic.default_scene(rotation_deg=5.0)
    masks = segment_feet(temps_of(scene), AMBIENT_C, config.segmentation)
    feet = measure_feet(masks, config.segmentation)
    oriented = orient_feet(feet, confirm_sidedness(propose_sidedness(feet), False))
    assert oriented.left.mirrored is False
    assert oriented.right.mirrored is True
    for frame, spec in ((oriented.left, scene.feet[0]), (oriented.right, scene.feet[1])):
        angle = np.deg2rad(spec.rotation_deg)
        for u, v in ((0.16, 0.085), (0.50, 0.86), (0.89, 0.16)):
            # Where the generator put this canonical point in the image.
            local_x = (u - 0.5 if spec.side == "left" else 0.5 - u) * spec.width_px
            local_y = (v - 0.5) * spec.length_px
            x = spec.center_x_px + np.cos(angle) * local_x - np.sin(angle) * local_y
            y = spec.center_y_px + np.sin(angle) * local_x + np.cos(angle) * local_y
            got_u, got_v = frame.canonical_uv(np.array([x]), np.array([y]))
            # The principal axis of a foot leans a couple of degrees towards
            # the hallux, the same way on both feet, so u is looser than v.
            assert got_u[0] == pytest.approx(u, abs=0.08)
            assert got_v[0] == pytest.approx(v, abs=0.03)
            back_x, back_y = frame.image_xy(got_u, got_v)
            assert back_x[0] == pytest.approx(x, abs=1e-9)
            assert back_y[0] == pytest.approx(y, abs=1e-9)


def test_canonical_warp_lines_the_feet_up_without_inventing_values(config: Config) -> None:
    scene = synthetic.default_scene(3.5)
    temps = temps_of(scene)
    masks = segment_feet(temps, AMBIENT_C, config.segmentation)
    feet = measure_feet(masks, config.segmentation)
    oriented = orient_feet(feet, confirm_sidedness(propose_sidedness(feet), False))
    left = warp_to_canonical(temps, oriented.left, 40, 100)
    right = warp_to_canonical(temps, oriented.right, 40, 100)
    assert left.shape == right.shape == (100, 40)
    # Only temperatures that exist in the frame appear.
    assert set(np.unique(left[~np.isnan(left)])) <= {30.0, 33.5}
    assert set(np.unique(right[~np.isnan(right)])) == {30.0}
    both = ~np.isnan(left) & ~np.isnan(right)
    assert both.mean() > 0.6
    difference = left - right
    assert np.nanmax(difference[80:, :]) == pytest.approx(3.5)
    assert np.nanmax(np.abs(difference[:55, :])) == pytest.approx(0.0)


# --- 7.2 left / right ---------------------------------------------------------


@pytest.mark.parametrize("left_on_image_left", [False, True])
@pytest.mark.parametrize("rotation_deg", [0.0, 8.0, -8.0])
def test_geometry_finds_the_left_foot_wherever_it_is(
    config: Config, left_on_image_left: bool, rotation_deg: float
) -> None:
    scene = synthetic.default_scene(
        left_on_image_left=left_on_image_left, rotation_deg=rotation_deg
    )
    masks = segment_feet(temps_of(scene), AMBIENT_C, config.segmentation)
    proposal = propose_sidedness(measure_feet(masks, config.segmentation))
    assert proposal.confident
    assert proposal.left_is_image_left is left_on_image_left


def test_left_is_not_assumed_from_position(config: Config) -> None:
    normal = synthetic.default_scene()
    crossed = synthetic.default_scene(left_on_image_left=True)
    results = []
    for scene in (normal, crossed):
        masks = segment_feet(temps_of(scene), AMBIENT_C, config.segmentation)
        results.append(
            propose_sidedness(measure_feet(masks, config.segmentation)).left_is_image_left
        )
    assert results == [False, True]


def test_two_feet_of_the_same_side_give_no_proposal(config: Config) -> None:
    scene = synthetic.default_scene()
    left, right = scene.feet
    two_lefts = synthetic.with_feet(scene, left, replace(left, center_x_px=right.center_x_px))
    masks = segment_feet(temps_of(two_lefts), AMBIENT_C, config.segmentation)
    proposal = propose_sidedness(measure_feet(masks, config.segmentation))
    assert proposal.left_is_image_left is None
    assert not proposal.confident
    assert "same side" in proposal.detail


def test_operator_confirmation_is_required_and_recorded(config: Config) -> None:
    masks = segment_feet(temps_of(synthetic.default_scene()), AMBIENT_C, config.segmentation)
    feet = measure_feet(masks, config.segmentation)
    proposal = propose_sidedness(feet)

    with pytest.raises(SidednessError, match="not confirmed"):
        confirm_sidedness(proposal, None)

    confirmed = confirm_sidedness(proposal, False)
    assert confirmed.source == "geometry_confirmed"
    assert confirmed.left_is_image_left is False
    assert confirmed.geometry_left_is_image_left is False

    overridden = confirm_sidedness(proposal, True)
    assert overridden.source == "operator_override"
    assert overridden.left_is_image_left is True
    assert overridden.geometry_left_is_image_left is False


def test_operator_decides_when_geometry_cannot(config: Config) -> None:
    scene = synthetic.default_scene()
    left, right = scene.feet
    two_lefts = synthetic.with_feet(scene, left, replace(left, center_x_px=right.center_x_px))
    masks = segment_feet(temps_of(two_lefts), AMBIENT_C, config.segmentation)
    feet = measure_feet(masks, config.segmentation)
    decision = confirm_sidedness(propose_sidedness(feet), True)
    assert decision.source == "operator_override"
    assert decision.geometry_left_is_image_left is None
    oriented = orient_feet(feet, decision)
    assert oriented.left.shape is feet.image_left
    assert oriented.right.shape is feet.image_right


def test_unclear_hallux_side_falls_back_to_the_confirmed_side(config: Config) -> None:
    masks = segment_feet(temps_of(synthetic.default_scene()), AMBIENT_C, config.segmentation)
    shape = replace(measure_foot(masks.image_right, config.segmentation), hallux_on_low_side=None)
    assert canonical_frame(shape, is_left_foot=True).mirrored is False
    assert canonical_frame(shape, is_left_foot=False).mirrored is True
