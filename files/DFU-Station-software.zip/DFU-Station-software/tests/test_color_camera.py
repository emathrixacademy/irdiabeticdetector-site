"""Camera Module 3 driver logic with an injected stand-in for picamera2."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pytest

from src.capture import color_calibration as cc
from src.capture.picamera import PICAMERA_BGR_FORMAT, PiCamera3, fixed_controls
from src.clock import ManualClock, RealClock
from src.config import Config
from src.diagnostics.color_lock import settled_calibration
from src.errors import CalibrationError, HardwareError
from src.hardware.fakes import FakeInteriorLight

CALIBRATION = cc.ColorCalibration(
    lens_position_dioptres=2.38,
    exposure_time_us=12000,
    analogue_gain=1.5,
    colour_gain_red=1.9,
    colour_gain_blue=1.6,
)


class StandInPicamera2:
    """Records what the driver asks of picamera2."""

    def __init__(self, shape: tuple[int, ...], dtype: type = np.uint8) -> None:
        self.shape = shape
        self.dtype = dtype
        self.configuration: dict[str, Any] | None = None
        self.controls: list[dict[str, Any]] = []
        self.calls: list[str] = []
        self.metadata: dict[str, Any] = {
            "ExposureTime": 14000,
            "AnalogueGain": 2.0,
            "ColourGains": (2.1, 1.4),
        }

    def create_still_configuration(self, main: dict[str, Any]) -> dict[str, Any]:
        return {"main": main}

    def configure(self, configuration: dict[str, Any]) -> None:
        self.configuration = configuration

    def set_controls(self, controls: dict[str, Any]) -> None:
        self.controls.append(controls)

    def start(self) -> None:
        self.calls.append("start")

    def stop(self) -> None:
        self.calls.append("stop")

    def close(self) -> None:
        self.calls.append("close")

    def capture_array(self, name: str) -> np.ndarray:
        return np.zeros(self.shape, dtype=self.dtype)

    def capture_metadata(self) -> dict[str, Any]:
        return self.metadata


def test_nominal_focus_for_420_mm(config: Config) -> None:
    assert cc.nominal_lens_position_dioptres(config.working_distance_mm) == pytest.approx(
        2.381, abs=0.001
    )


def test_driver_pins_focus_exposure_and_white_balance(config: Config) -> None:
    stand_in = StandInPicamera2((config.color.height_px, config.color.width_px, 3))
    camera = PiCamera3(stand_in, config.color, CALIBRATION, ManualClock())
    assert stand_in.configuration == {
        "main": {
            "size": (config.color.width_px, config.color.height_px),
            "format": PICAMERA_BGR_FORMAT,
        }
    }
    controls = stand_in.controls[0]
    assert controls["LensPosition"] == 2.38
    assert controls["AeEnable"] is False
    assert controls["AwbEnable"] is False
    assert controls["ExposureTime"] == 12000
    assert controls["AnalogueGain"] == 1.5
    assert controls["ColourGains"] == (1.9, 1.6)
    assert controls == fixed_controls(CALIBRATION)

    frame = camera.capture()
    assert frame.image_bgr.shape == (config.color.height_px, config.color.width_px, 3)
    camera.close()
    assert stand_in.calls == ["start", "stop", "close"]


@pytest.mark.parametrize("shape", [(100, 100, 3), (1296, 2304), (1296, 2304, 4)])
def test_wrong_frame_shape_is_an_error(config: Config, shape: tuple[int, ...]) -> None:
    camera = PiCamera3(StandInPicamera2(shape), config.color, CALIBRATION, ManualClock())
    with pytest.raises(HardwareError):
        camera.capture()


def test_calibration_round_trip_and_missing_file(tmp_path: Path) -> None:
    path = tmp_path / "calibration" / "color.yaml"
    with pytest.raises(CalibrationError, match="missing"):
        cc.load_color_calibration(path)
    cc.save_color_calibration(CALIBRATION, path)
    assert cc.load_color_calibration(path) == CALIBRATION


@pytest.mark.parametrize(
    "change",
    [
        {"analogue_gain": 40.0},
        {"exposure_time_us": 0},
        {"colour_gain_red": "auto"},
        {"lens_position_dioptres": None},
    ],
)
def test_bad_calibration_values_are_refused(change: dict[str, Any]) -> None:
    data = {
        "lens_position_dioptres": 2.38,
        "exposure_time_us": 12000,
        "analogue_gain": 1.5,
        "colour_gain_red": 1.9,
        "colour_gain_blue": 1.6,
    }
    data.update(change)
    with pytest.raises(CalibrationError):
        cc.parse_color_calibration(data, "test")


def test_color_lock_reads_settled_values_with_the_led_on(config: Config) -> None:
    clock = ManualClock()
    light = FakeInteriorLight(clock)
    stand_in = StandInPicamera2((config.color.height_px, config.color.width_px, 3))
    calibration = settled_calibration(stand_in, light, config, clock)
    assert calibration.exposure_time_us == 14000
    assert calibration.analogue_gain == 2.0
    assert (calibration.colour_gain_red, calibration.colour_gain_blue) == (2.1, 1.4)
    assert calibration.lens_position_dioptres == pytest.approx(1000 / 420)
    assert stand_in.controls[0]["AeEnable"] is True
    assert light.is_on is False
    assert clock.monotonic() > 0


@pytest.mark.hardware
def test_real_camera_module_3_captures_a_frame(config: Config) -> None:
    camera = PiCamera3.open(config.color, RealClock())
    try:
        frame = camera.capture()
        assert frame.image_bgr.shape == (config.color.height_px, config.color.width_px, 3)
    finally:
        camera.close()
