"""The Railway documents page: home page, manual rendering and downloads. No network."""

from __future__ import annotations

import importlib.util
import threading
import urllib.error
import urllib.request
from collections.abc import Iterator
from http.server import ThreadingHTTPServer
from pathlib import Path
from types import ModuleType

import pytest

pytest.importorskip("markdown")

APP_PATH = Path(__file__).resolve().parents[1] / "deploy" / "downloads" / "app.py"

MANUAL = (
    "---\nlayout: doc\ntitle: Operator manual\n---\n\n"
    "# Operator manual\n\n| A | B |\n|---|---|\n| 1 | 2 |\n"
)


@pytest.fixture
def app(monkeypatch: pytest.MonkeyPatch) -> ModuleType:
    spec = importlib.util.spec_from_file_location("dfu_docs_app", APP_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    files = {
        "docs/operator_manual.md": MANUAL.encode(),
        "cad.html": b"<!doctype html><title>DFU Station 3D Model</title>",
    }
    monkeypatch.setattr(module, "_fetch", lambda path: files.get(path))
    monkeypatch.setattr(module, "file_sizes", lambda: {})
    return module


@pytest.fixture
def server(app: ModuleType) -> Iterator[str]:
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), app.Handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{httpd.server_address[1]}"
    httpd.shutdown()


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[no-untyped-def]
        return None


def _get(url: str) -> tuple[int, str, dict[str, str]]:
    opener = urllib.request.build_opener(_NoRedirect)
    try:
        with opener.open(url, timeout=5) as r:
            return r.status, r.read().decode(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode(), dict(e.headers)


def test_health(server: str) -> None:
    assert _get(f"{server}/health")[:2] == (200, "ok")


def test_home_is_public_and_lists_every_manual(server: str, app: ModuleType) -> None:
    status, body, _ = _get(f"{server}/")
    assert status == 200
    assert 'name="code"' not in body  # no access code
    for slug in app.DOCS:
        assert f'href="/doc/{slug}"' in body


def test_manual_renders_without_front_matter(server: str) -> None:
    status, body, _ = _get(f"{server}/doc/operator_manual")
    assert status == 200
    assert "<h1>Operator manual</h1>" in body
    assert "<table>" in body
    assert "layout: doc" not in body


@pytest.mark.parametrize("path", ["/doc/missing", "/doc/../secrets", "/download/other.zip"])
def test_unknown_paths_are_404(server: str, path: str) -> None:
    assert _get(server + path)[0] == 404


def test_download_redirects_to_the_site_repo(server: str, app: ModuleType) -> None:
    status, _, headers = _get(f"{server}/download/{app.SOFTWARE}")
    assert status == 302
    assert headers["Location"] == f"{app.SITE_RAW}/files/{app.SOFTWARE}"


def test_big_buttons_follow_the_files(app: ModuleType) -> None:
    empty = app.home_page({})
    assert "Download the station software (coming soon)" in empty
    assert f'href="/download/{app.SOFTWARE}"' not in empty

    full = app.home_page(dict.fromkeys(app.FILES, 55_000) | {app.SOFTWARE: 2_500_000})
    assert f'href="/download/{app.SOFTWARE}"' in full
    assert f'href="/download/{app.SCHEMATIC}"' in full
    for name in app.FILES:
        assert f'href="/download/{name}"' in full
    assert "coming soon" not in full
    assert "2.5 MB" in full


def test_page_offers_no_upload(app: ModuleType) -> None:
    page = app.home_page({}).lower()
    assert "<form" not in page
    assert "upload to" not in page.replace("never upload", "")


def test_front_matter_is_only_stripped_at_the_top(app: ModuleType) -> None:
    assert app.strip_front_matter("---\na: 1\n---\n\nbody") == "body"
    assert app.strip_front_matter("body\n---\nmore") == "body\n---\nmore"


def test_3d_model_page_is_served_and_linked(server: str, app: ModuleType) -> None:
    status, body, _ = _get(f"{server}/cad")
    assert status == 200
    assert "DFU Station 3D Model" in body
    assert 'href="/cad"' in app.home_page({})
    status, _, headers = _get(f"{server}/index.html")
    assert (status, headers["Location"]) == (302, "/")
