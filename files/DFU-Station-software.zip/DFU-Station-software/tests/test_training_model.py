"""Training, export and the Hailo compile script, on a tiny synthetic dataset.

These tests check that the pipeline runs and keeps its promises. They do not
assert a classification accuracy: accuracy belongs to the dataset, which the
client supplies and which will change.
"""

from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np
import pytest

from src.inference.classifier import Classifier
from src.inference.metadata import load_model_metadata
from src.inference.onnx_runner import OnnxAccelerator
from src.inference.preprocess import preprocess
from training import hailo_compile
from training.manifest import ManifestRow

torch = pytest.importorskip("torch", reason="PyTorch is only installed for off-device training")
pytest.importorskip("torchvision")
pytest.importorskip("onnx")

from training import export as export_module  # noqa: E402
from training import train as train_module  # noqa: E402

pytestmark = pytest.mark.training

SETTINGS = train_module.TrainSettings(
    epochs=1, batch_size=4, fold_count=2, seed=5, pretrained=False, freeze_backbone=True
)
CLASS_COLOURS = {"0": (60, 90, 200), "1": (60, 200, 90)}


def make_dataset(root: Path, patients_per_label: int = 3, shots: int = 2) -> list[ManifestRow]:
    """SYNTHETIC images: flat colours with noise, one colour per label."""
    rng = np.random.default_rng(11)
    rows: list[ManifestRow] = []
    line = 2
    for label, colour in CLASS_COLOURS.items():
        (root / label).mkdir(parents=True, exist_ok=True)
        for patient in range(patients_per_label):
            for shot in range(shots):
                image = np.clip(np.array(colour) + rng.normal(0, 12, (96, 128, 3)), 0, 255).astype(
                    np.uint8
                )
                relative = f"{label}/p{patient}_{shot}.png"
                cv2.imwrite(str(root / relative), image)
                rows.append(
                    ManifestRow(f"T{label}-{patient:02d}", relative, label, "synthetic", "S1", line)
                )
                line += 1
    return rows


def test_dataset_uses_the_station_preprocessing(tmp_path: Path) -> None:
    rows = make_dataset(tmp_path)
    names = train_module.class_names(rows)
    metadata = train_module.make_metadata(len(names), "test")
    dataset = train_module.ManifestDataset(
        rows, tuple(range(len(rows))), tmp_path, names, metadata, augment=False, seed=0
    )
    tensor, target = dataset[0]
    image = cv2.imread(str(tmp_path / rows[0].image_path))
    assert np.array_equal(tensor.numpy(), preprocess(image, metadata)[0])
    assert target == 0
    assert tensor.shape == (3, 224, 224)


def test_metadata_for_the_station_uses_neutral_class_names() -> None:
    metadata = train_module.make_metadata(4, "m")
    assert metadata.labels == ("class_0", "class_1", "class_2", "class_3")
    assert metadata.scores_are_logits is True


def test_class_weights_come_from_the_training_side_only(tmp_path: Path) -> None:
    rows = make_dataset(tmp_path)
    names = train_module.class_names(rows)
    train_indices = (
        tuple(i for i, row in enumerate(rows) if row.label == "0")[:4]
        + tuple(i for i, row in enumerate(rows) if row.label == "1")[:2]
    )
    weights = train_module.class_weights(rows, train_indices, names)
    assert weights[1] > weights[0]
    assert weights.tolist() == pytest.approx([6 / (2 * 4), 6 / (2 * 2)])


def test_cross_validation_runs_and_reports_patient_counts(tmp_path: Path) -> None:
    rows = make_dataset(tmp_path)
    report = train_module.run_cross_validation(rows, tmp_path, SETTINGS)
    assert report["patient_count"] == 6
    assert report["image_count"] == 12
    assert "patient_id" in report["split"]
    assert len(report["folds"]) == 2
    for fold in report["folds"]:
        assert fold["train_patients"] + fold["test_patients"] == 6
        assert fold["test_images"] == sum(sum(row) for row in fold["confusion_matrix"])
        assert set(fold["recall_per_class"]) == {"0", "1"}
        assert len(fold["loss_per_epoch"]) == SETTINGS.epochs
    markdown = train_module.report_markdown(report)
    assert "Patients: **6**" in markdown
    json.dumps(report)


def test_training_is_deterministic(tmp_path: Path) -> None:
    rows = make_dataset(tmp_path)
    first = train_module.run_cross_validation(rows, tmp_path, SETTINGS)
    second = train_module.run_cross_validation(rows, tmp_path, SETTINGS)
    assert first["folds"][0]["loss_per_epoch"] == pytest.approx(
        second["folds"][0]["loss_per_epoch"], rel=1e-6
    )
    assert first["folds"][0]["confusion_matrix"] == second["folds"][0]["confusion_matrix"]


def test_training_cli_writes_reports_and_final_model(tmp_path: Path) -> None:
    images = tmp_path / "images"
    rows = make_dataset(images)
    manifest = tmp_path / "manifest.csv"
    lines = ["patient_id,image_path,label,source,capture_session"]
    lines += [
        f"{r.patient_id},{r.image_path},{r.label},{r.source},{r.capture_session}" for r in rows
    ]
    manifest.write_text("\n".join(lines) + "\n", encoding="utf-8")
    out = tmp_path / "run"
    code = train_module.main(
        [
            "--manifest", str(manifest), "--image-root", str(images), "--out", str(out),
            "--epochs", "1", "--folds", "2", "--batch-size", "4", "--no-pretrained", "--final",
        ]
    )  # fmt: skip
    assert code == 0
    for name in ("data_quality.md", "cv_report.md", "cv_report.json", "final_model.pt"):
        assert (out / name).is_file()
    assert json.loads((out / "label_map.json").read_text("utf-8")) == {
        "class_0": "0",
        "class_1": "1",
    }

    # 10.5: export from that run, with the parity check.
    models = tmp_path / "models"
    assert export_module.main(["--run", str(out), "--out", str(models)]) == 0
    metadata = load_model_metadata(models / export_module.METADATA_NAME)
    assert metadata.labels == ("class_0", "class_1")
    runner = OnnxAccelerator(models / export_module.ONNX_NAME, metadata)
    result = Classifier(runner, metadata).classify(cv2.imread(str(images / rows[0].image_path)))
    assert result.predicted_label in metadata.labels
    assert 0.0 <= result.confidence <= 1.0


def test_export_has_a_fixed_input_shape_and_matches_pytorch(tmp_path: Path) -> None:
    import onnxruntime

    torch.manual_seed(0)
    model = train_module.build_model(3, pretrained=False, freeze_backbone=False)
    error = export_module.export_and_check(model, 3, tmp_path, seed=1)
    assert error <= export_module.PARITY_TOLERANCE
    session = onnxruntime.InferenceSession(
        str(tmp_path / export_module.ONNX_NAME), providers=["CPUExecutionProvider"]
    )
    assert list(session.get_inputs()[0].shape) == [1, 3, 224, 224]
    assert list(session.get_outputs()[0].shape) == [1, 3]


def test_export_is_rejected_when_it_does_not_match(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    model = train_module.build_model(2, pretrained=False, freeze_backbone=False)
    monkeypatch.setattr(export_module, "parity_error", lambda *args, **kwargs: 0.5)
    with pytest.raises(export_module.ExportError, match="deleted"):
        export_module.export_and_check(model, 2, tmp_path, seed=1)
    assert not (tmp_path / export_module.ONNX_NAME).exists()
    assert not (tmp_path / export_module.METADATA_NAME).exists()


# --- 10.6 Hailo compile script (logic only; the compiler is not installed) -------


def test_normalisation_script_matches_the_training_normalisation() -> None:
    metadata = train_module.make_metadata(3, "m")
    script = hailo_compile.normalisation_script(metadata)
    assert script == (
        "normalization1 = normalization([123.675, 116.28, 103.53], [58.395, 57.12, 57.375])\n"
    )


def test_calibration_set_is_station_preprocessed_uint8(tmp_path: Path) -> None:
    metadata = train_module.make_metadata(2, "m")
    rng = np.random.default_rng(2)
    for index in range(hailo_compile.MIN_CALIBRATION_IMAGES):
        frame = rng.integers(0, 256, (48, 64, 3), dtype=np.uint8)
        cv2.imwrite(str(tmp_path / f"capture_{index:03d}.png"), frame)
    paths = hailo_compile.find_calibration_images(tmp_path)
    calibration = hailo_compile.build_calibration_set(paths, metadata)
    assert calibration.shape == (64, 224, 224, 3)
    assert calibration.dtype == np.uint8
    with pytest.raises(hailo_compile.CompileError, match="at least 64"):
        hailo_compile.build_calibration_set(paths[:10], metadata)


def test_compile_reports_a_missing_compiler_clearly(tmp_path: Path) -> None:
    try:
        import hailo_sdk_client  # noqa: F401
    except ImportError:
        metadata = train_module.make_metadata(2, "m")
        with pytest.raises(hailo_compile.CompileError, match="Dataflow Compiler"):
            hailo_compile.compile_hef(
                tmp_path / "m.onnx", metadata, np.zeros((64, 224, 224, 3), np.uint8)
            )


def test_public_holdout_calibration_is_recorded_as_interim(tmp_path: Path) -> None:
    record = hailo_compile.build_record(
        tmp_path / "m.onnx", hailo_compile.CALIBRATION_PUBLIC_HOLDOUT, 64, "3.x"
    )
    assert record["calibration_kind"] == "public_holdout"
    assert "INTERIM" in str(record["calibration_note"])
    assert "Recompile" in str(record["calibration_note"])
    station = hailo_compile.build_record(
        tmp_path / "m.onnx", hailo_compile.CALIBRATION_STATION, 80, "3.x"
    )
    assert "INTERIM" not in str(station["calibration_note"])


def test_calibration_images_come_from_the_holdout_manifest(tmp_path: Path) -> None:
    manifest = tmp_path / "holdout.csv"
    manifest.write_text(
        "patient_id,image_path,label,source,capture_session\n"
        "public_v1-g00001,set/a.png,0,set,\n"
        "public_v1-g00002,set/b.png,1,set,\n",
        encoding="utf-8",
    )
    paths = hailo_compile.calibration_images_from_manifest(manifest, tmp_path / "raw")
    assert paths == [tmp_path / "raw" / "set" / "a.png", tmp_path / "raw" / "set" / "b.png"]
    with pytest.raises(hailo_compile.CompileError, match="calibration manifest"):
        hailo_compile.calibration_images_from_manifest(tmp_path / "absent.csv", tmp_path)


def test_compile_cli_needs_one_calibration_source(tmp_path: Path) -> None:
    arguments = ["--onnx", "m.onnx", "--metadata", "meta.json", "--out", str(tmp_path / "m.hef")]
    with pytest.raises(SystemExit):
        hailo_compile.main(arguments)
    assert hailo_compile.main([*arguments, "--calibration-manifest", "h.csv"]) == 1
    assert not (tmp_path / "m.hef").exists()
    assert not (tmp_path / "m.build.json").exists()
