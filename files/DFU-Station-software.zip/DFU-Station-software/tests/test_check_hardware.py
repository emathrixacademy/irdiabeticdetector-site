"""Hardware self-check: clear pass or fail per item, and no item hides another."""

from __future__ import annotations

from pathlib import Path

import pytest

from src.config import Config
from src.diagnostics import check_hardware as ch
from src.errors import HardwareError
from tests.conftest import _on_raspberry_pi, make_config

HAILO_OK = """Executing on device: 0001:01:00.0
Identifying board
Control Protocol Version: 2
Firmware Version: 4.20.0 (release,app,extended context switch buffer)
Board Name: Hailo-8
Device Architecture: HAILO8L
"""

CAMERAS_OK = """Available cameras
-----------------
0 : imx708 [4608x2592 10-bit RGGB] (/base/axi/pcie@120000/rp1/i2c@88000/imx708@1a)
"""


def _runner(code: int, output: str) -> ch.CommandRunner:
    return lambda command: (code, output)


def test_hailo_check() -> None:
    assert ch.check_hailo(_runner(0, HAILO_OK)).passed
    wrong = ch.check_hailo(_runner(0, HAILO_OK.replace("HAILO8L", "HAILO8")))
    assert not wrong.passed
    assert "not a Hailo-8L" in wrong.detail
    missing = ch.check_hailo(_runner(127, "hailortcli: command not found"))
    assert not missing.passed
    assert "command not found" in missing.detail


def test_camera_module_check() -> None:
    assert ch.check_camera_module(_runner(0, CAMERAS_OK)).passed
    assert not ch.check_camera_module(_runner(0, "No cameras available!")).passed
    assert not ch.check_camera_module(_runner(1, "error")).passed


def test_calibration_file_check(tmp_path: Path) -> None:
    folder = tmp_path / "calibration"
    config = make_config(
        tmp_path,
        thermal__calibration_path=str(folder / "thermal.yaml"),
        color__calibration_path=str(folder / "color.yaml"),
        registration__calibration_path=str(folder / "registration.yaml"),
    )
    result = ch.check_calibration_files(config)
    assert not result.passed
    assert "thermal.yaml" in result.detail
    folder.mkdir()
    for name in ("thermal.yaml", "color.yaml", "registration.yaml"):
        (folder / name).write_text("x: 1\n", encoding="utf-8")
    assert ch.check_calibration_files(config).passed


def test_one_failing_check_does_not_hide_the_others() -> None:
    def broken() -> ch.CheckResult:
        raise HardwareError("no PureThermal board found")

    def crashed() -> ch.CheckResult:
        raise RuntimeError("driver bug")

    results = ch.run_checks(
        [
            ("first", lambda: ch.CheckResult("first", True, "ok")),
            ("thermal", broken),
            ("gpio", crashed),
            ("last", lambda: ch.CheckResult("last", True, "ok")),
        ]
    )
    assert [result.passed for result in results] == [True, False, False, True]
    assert results[1].detail == "no PureThermal board found"
    assert "RuntimeError" in results[2].detail

    report = ch.format_results(results)
    assert report.count("[PASS]") == 2
    assert report.count("[FAIL]") == 2
    assert "2 check(s) FAILED." in report


def test_all_items_are_covered(config: Config) -> None:
    from src.clock import ManualClock

    names = [name for name, _ in ch.station_checks(config, ManualClock(), _runner(0, ""))]
    for word in ("Hailo", "Camera Module 3", "PureThermal", "Y16", "GPIO", "Ambient"):
        assert any(word in name for name in names), word


@pytest.mark.skipif(_on_raspberry_pi(), reason="on the station these checks should pass")
def test_off_device_the_station_checks_fail_cleanly(config: Config) -> None:
    from src.clock import ManualClock

    checks = ch.station_checks(config, ManualClock(), ch.run_command)
    results = ch.run_checks(checks[:4])
    assert all(not result.passed for result in results)
    assert "FAILED" in ch.format_results(results)


def test_fake_mode_is_not_a_hardware_check(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    import yaml

    from tests.conftest import EXAMPLE_CONFIG

    data = yaml.safe_load(EXAMPLE_CONFIG.read_text(encoding="utf-8"))
    data["hardware"]["mode"] = "fake"
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(data), encoding="utf-8")
    assert ch.main(["--config", str(path)]) == 2
    assert "no hardware to check" in capsys.readouterr().err


@pytest.mark.hardware
def test_real_station_self_check_passes(config: Config) -> None:
    assert ch.main([]) == 0
