"""Fusion, storage layout, CSV log and the offline guarantee (Annex A 7, 13)."""

from __future__ import annotations

import ast
import csv
import json
import os
import socket
from pathlib import Path

import cv2
import numpy as np
import pytest

from src.config import REQUIRED_REGIONS
from src.errors import StorageError
from src.fusion.fuse import RESEARCH_NOTICE, fuse, summary_lines
from src.storage import layout
from src.storage.store import CSV_COLUMNS, append_csv_row, csv_row
from tests.conftest import REFERENCE_CODE, ROOT, Rig, make_rig

DIAGNOSIS_WORDS = (
    "diagnos",
    "ulcer",
    "infect",
    "disease",
    "positive",
    "negative",
    "abnormal",
    "at risk",
    "wagner",
    "grade",
    "refer",
    "treat",
)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


# --- 11.1 fusion ----------------------------------------------------------------


def test_fused_result_carries_both_outputs_side_by_side(rig: Rig) -> None:
    scan = rig.scan()
    fused = scan.fused
    assert fused == fuse(scan.asymmetry, scan.classifier)
    assert fused.any_region_flagged is True
    assert fused.flagged_regions == ("heel",)
    assert fused.max_abs_delta_c == pytest.approx(3.5, abs=1e-9)
    assert set(fused.region_deltas_c) == set(REQUIRED_REGIONS)
    assert fused.region_deltas_c["heel"] == pytest.approx(3.5, abs=1e-9)
    assert fused.asymmetry_threshold_c == 2.2
    assert fused.predicted_class == rig.config.fake.predicted_class
    assert fused.predicted_label == "class_0"
    assert 0.0 <= fused.confidence <= 1.0


def test_no_flags_when_feet_are_symmetric(tmp_path: Path) -> None:
    scan = make_rig(tmp_path, fake__scenario="delta_0p00").scan()
    assert scan.fused.any_region_flagged is False
    assert scan.fused.flagged_regions == ()
    assert "No region reached" in summary_lines(scan.fused)[0]


@pytest.mark.parametrize("scenario", ["delta_0p00", "delta_2p20", "delta_3p50"])
def test_summary_has_no_diagnosis_wording(tmp_path: Path, scenario: str) -> None:
    scan = make_rig(tmp_path, fake__scenario=scenario).scan()
    lines = summary_lines(scan.fused)
    assert lines[-1] == RESEARCH_NOTICE
    assert "not a clinical assessment" in RESEARCH_NOTICE
    findings = " ".join(lines[:-1]).lower()
    for word in DIAGNOSIS_WORDS:
        assert word not in findings, word
    assert "predicted class" in findings


def test_the_classifier_does_not_change_the_flags(tmp_path: Path) -> None:
    flags = []
    for predicted_class in (0, 1, 2):
        scan = make_rig(
            tmp_path / str(predicted_class), fake__predicted_class=predicted_class
        ).scan()
        assert scan.fused.predicted_class == predicted_class
        flags.append((scan.fused.flagged_regions, scan.fused.max_abs_delta_c))
    assert len(set(flags)) == 1


# --- 11.2 storage layout ----------------------------------------------------------


def test_scan_folder_layout(rig: Rig) -> None:
    scan = rig.scan()
    folder = rig.station.store.save(scan)
    data_dir = rig.config.storage.data_dir
    assert folder == data_dir / scan.record.session_id / scan.record.scan_id
    assert scan.record.session_id.endswith(REFERENCE_CODE)
    assert {item.name for item in folder.iterdir()} == set(layout.SCAN_FILES)

    color = cv2.imread(str(folder / layout.COLOR_FILE))
    assert np.array_equal(color, scan.record.color.image_bgr)
    registered = cv2.imread(str(folder / layout.COLOR_REGISTERED_FILE))
    assert registered.shape == (480, 640, 3)
    overlay = cv2.imread(str(folder / layout.OVERLAY_FILE))
    assert overlay.shape == (120, 160, 3)

    raw = np.load(folder / layout.THERMAL_RAW_FILE)
    temps = np.load(folder / layout.THERMAL_TEMP_FILE)
    assert raw.dtype == np.uint16
    assert np.array_equal(raw, scan.record.thermal.raw)
    assert temps.dtype == np.float64
    assert np.array_equal(temps, scan.record.thermal.temps_c)
    assert np.allclose(temps, raw / 100.0 - 273.15)


def test_meta_json_holds_everything(rig: Rig) -> None:
    scan = rig.scan()
    folder = rig.station.store.save(scan)
    meta = json.loads((folder / layout.META_FILE).read_text(encoding="utf-8"))
    assert meta["reference_code"] == REFERENCE_CODE
    assert meta["config_hash"] == rig.config.config_hash()
    assert meta["ambient"] == {
        "temp_c": 23.5,
        "humidity_pct": 55.0,
        "captured_at_utc": scan.record.ambient.captured_at.isoformat(),
    }
    assert meta["sidedness"]["left_foot_position"] == "image_right"
    assert meta["sidedness"]["source"] == "geometry_confirmed"
    assert meta["asymmetry"]["flagged_regions"] == ["heel"]
    assert [region["name"] for region in meta["asymmetry"]["regions"]] == list(REQUIRED_REGIONS)
    assert meta["classifier"]["predicted_label"] == "class_0"
    assert meta["registration"]["color_coverage_fraction"] == 1.0
    assert meta["notice"] == RESEARCH_NOTICE
    assert "thermal_captured" in meta["step_timestamps_utc"]
    text = json.dumps(meta).lower()
    assert "wagner" not in text
    assert '"grade' not in text


def test_only_the_reference_code_identifies_the_patient(rig: Rig) -> None:
    scan = rig.scan()
    folder = rig.station.store.save(scan)
    meta = json.loads((folder / layout.META_FILE).read_text(encoding="utf-8"))

    def keys(value: object) -> set[str]:
        if isinstance(value, dict):
            found = set(value)
            for item in value.values():
                found |= keys(item)
            return found
        if isinstance(value, list):
            return set().union(*[keys(item) for item in value]) if value else set()
        return set()

    identifying = (
        "patient_name",
        "first_name",
        "last_name",
        "surname",
        "birth",
        "dob",
        "address",
        "phone",
        "email",
        "mrn",
        "hospital",
    )
    for key in keys(meta) | set(CSV_COLUMNS):
        assert not any(word in key.lower() for word in identifying), key
    # "name" appears only as the name of a plantar region, never of a person.
    assert "name" not in meta
    assert {region["name"] for region in meta["asymmetry"]["regions"]} == set(REQUIRED_REGIONS)


# --- 11.3 CSV log -----------------------------------------------------------------


def test_one_row_per_scan_with_every_column(rig: Rig) -> None:
    scan = rig.scan()
    rig.station.store.save(scan)
    rows = read_csv(rig.station.store.csv_path)
    assert len(rows) == 1
    row = rows[0]
    assert tuple(row) == CSV_COLUMNS
    assert row["reference_code"] == REFERENCE_CODE
    assert row["ambient_temp_c"] == "23.50"
    assert row["ambient_humidity_pct"] == "55.0"
    assert row["config_hash"] == rig.config.config_hash()
    assert row["triggered_at_utc"] == scan.record.step_timestamps["trigger"]
    assert row["thermal_captured_at_utc"]
    assert row["heel_delta_c"] == "3.5000"
    assert row["heel_flagged"] == "1"
    assert row["hallux_delta_c"] == "0.0000"
    assert row["hallux_flagged"] == "0"
    assert row["flagged_regions"] == "heel"
    assert row["any_region_flagged"] == "1"
    assert row["predicted_class"] == "0"
    assert row["predicted_label"] == "class_0"
    assert 0.0 <= float(row["confidence"]) <= 1.0
    assert row["sidedness_source"] == "geometry_confirmed"
    assert row["left_foot_position"] == "image_right"
    assert row["scan_folder"] == f"{scan.record.session_id}/{scan.record.scan_id}"
    for region in REQUIRED_REGIONS:
        for name in ("left_mean_c", "right_mean_c", "delta_c", "flagged"):
            assert f"{region}_{name}" in row


def test_csv_has_no_grade_column() -> None:
    for column in CSV_COLUMNS:
        assert "grade" not in column
        assert "wagner" not in column
        assert "diagnos" not in column
    assert "predicted_class" in CSV_COLUMNS


def test_csv_is_append_only(rig: Rig) -> None:
    store = rig.station.store
    store.save(rig.scan("DFU-0001"))
    first = store.csv_path.read_bytes()
    rig.clock.advance(60.0)
    store.save(rig.scan("DFU-0002"))
    second = store.csv_path.read_bytes()
    assert second.startswith(first)  # earlier bytes are untouched
    rows = read_csv(store.csv_path)
    assert [row["reference_code"] for row in rows] == ["DFU-0001", "DFU-0002"]
    assert second.count(b"\n") == 3  # header and two rows, each complete


def test_a_missing_delta_is_written_empty_not_zero(rig: Rig) -> None:
    import dataclasses

    scan = rig.scan()
    regions = tuple(
        dataclasses.replace(region, delta_c=None, left_mean_c=None, flagged=False)
        if region.name == "hallux"
        else region
        for region in scan.asymmetry.regions
    )
    partial = dataclasses.replace(
        scan, asymmetry=dataclasses.replace(scan.asymmetry, regions=regions)
    )
    row = csv_row(partial, "session/scan")
    assert row["hallux_delta_c"] == ""
    assert row["hallux_left_mean_c"] == ""
    assert row["hallux_right_mean_c"] == "30.0000"
    assert row["hallux_flagged"] == "0"


def test_csv_with_other_columns_is_never_rewritten(rig: Rig) -> None:
    scan = rig.scan()
    path = rig.station.store.csv_path
    path.parent.mkdir(parents=True, exist_ok=True)
    old = "reference_code,something_else\nDFU-0009,1\n"
    path.write_text(old, encoding="utf-8")
    with pytest.raises(StorageError, match="different columns"):
        rig.station.store.save(scan)
    assert path.read_text(encoding="utf-8") == old
    # And the scan folder was undone, so nothing is half stored.
    assert not list(rig.config.storage.data_dir.rglob(layout.META_FILE))


def test_failed_csv_write_leaves_no_scan_folder(rig: Rig, monkeypatch: pytest.MonkeyPatch) -> None:
    scan = rig.scan()

    def refuse(descriptor: int, payload: bytes) -> int:
        raise OSError(28, "No space left on device")

    monkeypatch.setattr(os, "write", refuse)
    with pytest.raises(StorageError):
        rig.station.store.save(scan)
    monkeypatch.undo()
    data_dir = rig.config.storage.data_dir
    assert not list(data_dir.rglob(layout.META_FILE))
    assert not list(data_dir.rglob("*.npy"))
    # The same scan can then be stored once the disk is healthy again.
    rig.station.store.save(scan)
    assert len(read_csv(rig.station.store.csv_path)) == 1


def test_row_is_written_in_one_write_call(rig: Rig, monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[bytes] = []
    real_write = os.write

    def record(descriptor: int, payload: bytes) -> int:
        calls.append(bytes(payload))
        return real_write(descriptor, payload)

    row = csv_row(rig.scan(), "session/scan")
    path = rig.config.storage.data_dir / "scans.csv"
    monkeypatch.setattr(os, "write", record)
    append_csv_row(path, row)
    append_csv_row(path, row)
    assert len(calls) == 2
    assert calls[0].count(b"\n") == 2  # header and row together
    assert calls[1].count(b"\n") == 1


# --- 11.4 offline guarantee ---------------------------------------------------------


def test_full_fake_scan_makes_no_network_calls(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    attempts: list[str] = []

    def blocked(*args: object, **kwargs: object) -> None:
        attempts.append("network")
        raise AssertionError("the station tried to open a network connection")

    monkeypatch.setattr(socket, "socket", blocked)
    monkeypatch.setattr(socket, "create_connection", blocked)
    monkeypatch.setattr(socket, "getaddrinfo", blocked)

    rig = make_rig(tmp_path)
    scan = rig.scan()
    folder = rig.station.store.save(scan)
    rig.station.close()

    assert attempts == []
    assert (folder / layout.META_FILE).is_file()
    assert len(read_csv(rig.station.store.csv_path)) == 1


NETWORK_MODULES = {
    "socket",
    "ssl",
    "http",
    "urllib",
    "urllib3",
    "requests",
    "httpx",
    "aiohttp",
    "ftplib",
    "smtplib",
    "paramiko",
    "boto3",
    "sentry_sdk",
    "websocket",
    "websockets",
    "grpc",
    "telnetlib",
    "xmlrpc",
}


def _imports(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    found: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found |= {alias.name.split(".")[0] for alias in node.names}
        elif isinstance(node, ast.ImportFrom) and node.module:
            found.add(node.module.split(".")[0])
    return found


def test_station_code_imports_no_network_library() -> None:
    files = sorted((ROOT / "src").rglob("*.py"))
    assert files
    for path in files:
        used = _imports(path) & NETWORK_MODULES
        assert not used, f"{path.relative_to(ROOT)} imports {sorted(used)}"


def test_logging_goes_nowhere_but_stderr(rig: Rig) -> None:
    import logging
    import logging.handlers

    from src.logging_setup import setup_logging

    logger = setup_logging("INFO", rig.config.reference_code.pattern)
    remote = (
        logging.handlers.SocketHandler,
        logging.handlers.DatagramHandler,
        logging.handlers.SysLogHandler,
        logging.handlers.HTTPHandler,
        logging.handlers.SMTPHandler,
    )
    assert logger.handlers
    for handler in logger.handlers:
        assert not isinstance(handler, remote)
        assert type(handler) is logging.StreamHandler
