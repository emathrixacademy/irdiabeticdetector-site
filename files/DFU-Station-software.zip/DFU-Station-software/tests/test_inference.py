"""Shared preprocessing, the classifier wrapper and the two runners."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pytest

from src.clock import ManualClock
from src.config import Config
from src.datamodel import ImageArray
from src.errors import HardwareError, InferenceError
from src.hardware.factory import build_accelerator
from src.hardware.fakes import FakeAccelerator
from src.hardware.interfaces import Accelerator
from src.inference.classifier import Classifier
from src.inference.hailo_runner import HailoAccelerator
from src.inference.metadata import ModelMetadata, load_model_metadata, parse_model_metadata
from src.inference.onnx_runner import OnnxAccelerator
from src.inference.preprocess import normalise, preprocess, softmax, to_model_input_rgb
from tests.conftest import ROOT, make_config

METADATA_FILE = ROOT / "tests" / "fixtures" / "model_meta.json"


@pytest.fixture
def metadata() -> ModelMetadata:
    return load_model_metadata(METADATA_FILE)


# --- 9.1 preprocessing --------------------------------------------------------


def test_resize_and_colour_order(metadata: ModelMetadata) -> None:
    crop = np.zeros((480, 640, 3), dtype=np.uint8)
    crop[:, :, 0] = 200  # blue in BGR
    model_input = to_model_input_rgb(crop, metadata)
    assert model_input.shape == (224, 224, 3)
    assert model_input.dtype == np.uint8
    assert model_input[0, 0].tolist() == [0, 0, 200]  # blue is last in RGB


def test_the_whole_image_is_kept_not_cropped(metadata: ModelMetadata) -> None:
    crop = np.zeros((480, 640, 3), dtype=np.uint8)
    crop[:, :20] = 255  # a stripe at the far left
    crop[:, -20:] = 255  # and the far right
    model_input = to_model_input_rgb(crop, metadata)
    assert model_input[:, 0].min() > 200
    assert model_input[:, -1].min() > 200
    assert model_input[:, 112].max() == 0


def test_normalisation_matches_the_metadata(metadata: ModelMetadata) -> None:
    rgb = np.zeros((224, 224, 3), dtype=np.uint8)
    rgb[:, :] = (255, 128, 0)
    tensor = normalise(rgb, metadata)
    assert tensor.shape == (1, 3, 224, 224)
    assert tensor.dtype == np.float32
    for channel, value in enumerate((255, 128, 0)):
        expected = (value / 255.0 - metadata.mean_rgb[channel]) / metadata.std_rgb[channel]
        assert tensor[0, channel, 5, 7] == pytest.approx(expected, abs=1e-6)


def test_preprocess_is_both_steps(metadata: ModelMetadata) -> None:
    rng = np.random.default_rng(3)
    crop = rng.integers(0, 256, (480, 640, 3), dtype=np.uint8)
    assert np.array_equal(
        preprocess(crop, metadata), normalise(to_model_input_rgb(crop, metadata), metadata)
    )


def test_bad_images_are_refused(metadata: ModelMetadata) -> None:
    with pytest.raises(InferenceError):
        to_model_input_rgb(np.zeros((480, 640), dtype=np.uint8), metadata)
    with pytest.raises(InferenceError):
        to_model_input_rgb(np.zeros((480, 640, 3), dtype=np.float32), metadata)
    with pytest.raises(InferenceError):
        normalise(np.zeros((100, 100, 3), dtype=np.uint8), metadata)


def test_softmax() -> None:
    probabilities = softmax(np.array([4.0, 0.0, 0.0], dtype=np.float32))
    assert probabilities.sum() == pytest.approx(1.0)
    assert probabilities[0] == pytest.approx(np.exp(4) / (np.exp(4) + 2), rel=1e-5)
    big = softmax(np.array([1000.0, 999.0], dtype=np.float32))
    assert np.all(np.isfinite(big))


# --- Classifier wrapper ---------------------------------------------------------


class ScriptedAccelerator(Accelerator):
    def __init__(self, scores: list[float]) -> None:
        self.scores = scores
        self.seen: list[ImageArray] = []

    @property
    def model_id(self) -> str:
        return "scripted"

    def infer(self, input_rgb: ImageArray) -> np.ndarray:
        self.seen.append(input_rgb)
        return np.array(self.scores, dtype=np.float32)


def test_classifier_returns_class_label_and_confidence(metadata: ModelMetadata) -> None:
    accelerator = ScriptedAccelerator([0.5, 3.0, 1.0])
    result = Classifier(accelerator, metadata).classify(np.zeros((480, 640, 3), dtype=np.uint8))
    assert result.predicted_class == 1
    assert result.predicted_label == "class_1"
    assert result.confidence == pytest.approx(float(softmax(np.array([0.5, 3.0, 1.0]))[1]))
    assert result.model_id == "scripted"
    assert accelerator.seen[0].shape == (224, 224, 3)


def test_classifier_with_the_fake_accelerator(metadata: ModelMetadata) -> None:
    classifier = Classifier(FakeAccelerator(2, metadata.class_count), metadata)
    result = classifier.classify(np.zeros((480, 640, 3), dtype=np.uint8))
    assert (result.predicted_class, result.predicted_label) == (2, "class_2")
    assert 0.9 < result.confidence <= 1.0


def test_classifier_accepts_probabilities_when_the_metadata_says_so(
    metadata: ModelMetadata,
) -> None:
    import dataclasses

    as_probabilities = dataclasses.replace(metadata, scores_are_logits=False)
    result = Classifier(ScriptedAccelerator([0.1, 0.2, 0.7]), as_probabilities).classify(
        np.zeros((480, 640, 3), dtype=np.uint8)
    )
    assert result.predicted_class == 2
    assert result.confidence == pytest.approx(0.7)


@pytest.mark.parametrize("scores", [[1.0, 2.0], [1.0, 2.0, 3.0, 4.0], [float("nan"), 0.0, 0.0]])
def test_classifier_refuses_wrong_or_broken_scores(
    metadata: ModelMetadata, scores: list[float]
) -> None:
    with pytest.raises(InferenceError):
        Classifier(ScriptedAccelerator(scores), metadata).classify(
            np.zeros((480, 640, 3), dtype=np.uint8)
        )


# --- Metadata -------------------------------------------------------------------


def _metadata_dict() -> dict[str, Any]:
    data = json.loads(METADATA_FILE.read_text(encoding="utf-8"))
    assert isinstance(data, dict)
    return data


def test_metadata_loads(metadata: ModelMetadata) -> None:
    assert metadata.labels == ("class_0", "class_1", "class_2")
    assert metadata.class_count == 3
    assert (metadata.input_width_px, metadata.input_height_px) == (224, 224)


@pytest.mark.parametrize(
    "change",
    [
        {"labels": ["only_one"]},
        {"labels": ["a", "a"]},
        {"labels": "class_0,class_1"},
        {"input_width_px": 0},
        {"std_rgb": [0.2, 0.0, 0.2]},
        {"mean_rgb": [0.5, 0.5]},
        {"scores_are_logits": "yes"},
        {"model_id": ""},
    ],
)
def test_bad_metadata_is_refused(change: dict[str, Any]) -> None:
    data = _metadata_dict()
    data.update(change)
    with pytest.raises(InferenceError):
        parse_model_metadata(data)


def test_missing_metadata_key_and_file_are_refused(tmp_path: Path) -> None:
    data = _metadata_dict()
    del data["labels"]
    with pytest.raises(InferenceError, match="labels"):
        parse_model_metadata(data)
    with pytest.raises(InferenceError, match="cannot read"):
        load_model_metadata(tmp_path / "absent.json")


# --- 9.3 ONNX dev runner ----------------------------------------------------------


def _tiny_onnx_model(path: Path, bias: list[float]) -> None:
    """Global average pool then a linear layer: logits = mean_rgb @ W + b."""
    onnx = pytest.importorskip("onnx")
    helper, tensor_proto = onnx.helper, onnx.TensorProto
    weights = np.array([[1.0, 0.0, -1.0], [0.0, 2.0, 0.0], [0.5, 0.5, 0.5]], dtype=np.float32)
    graph = helper.make_graph(
        [
            helper.make_node("GlobalAveragePool", ["input"], ["pooled"]),
            helper.make_node("Flatten", ["pooled"], ["flat"]),
            helper.make_node("Gemm", ["flat", "weights", "bias"], ["logits"], transB=1),
        ],
        "tiny",
        [helper.make_tensor_value_info("input", tensor_proto.FLOAT, [1, 3, 224, 224])],
        [helper.make_tensor_value_info("logits", tensor_proto.FLOAT, [1, 3])],
        [
            helper.make_tensor("weights", tensor_proto.FLOAT, [3, 3], weights.flatten().tolist()),
            helper.make_tensor("bias", tensor_proto.FLOAT, [3], bias),
        ],
    )
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 13)])
    model.ir_version = 8
    onnx.save(model, str(path))


def test_onnx_runner_matches_numpy(tmp_path: Path, metadata: ModelMetadata) -> None:
    path = tmp_path / "tiny.onnx"
    _tiny_onnx_model(path, [0.1, -0.2, 0.3])
    runner = OnnxAccelerator(path, metadata)
    rgb = np.zeros((224, 224, 3), dtype=np.uint8)
    rgb[:, :] = (200, 100, 50)
    scores = runner.infer(rgb)

    mean = normalise(rgb, metadata)[0].mean(axis=(1, 2))
    weights = np.array([[1.0, 0.0, -1.0], [0.0, 2.0, 0.0], [0.5, 0.5, 0.5]], dtype=np.float32)
    expected = weights @ mean + np.array([0.1, -0.2, 0.3], dtype=np.float32)
    assert scores.shape == (3,)
    assert scores == pytest.approx(expected, abs=1e-3)
    assert runner.model_id == "onnx:tiny.onnx"

    result = Classifier(runner, metadata).classify(np.full((480, 640, 3), 90, dtype=np.uint8))
    assert result.predicted_label in metadata.labels
    assert isinstance(runner, Accelerator)


def test_onnx_runner_refuses_a_missing_or_mismatched_model(
    tmp_path: Path, metadata: ModelMetadata
) -> None:
    import dataclasses

    with pytest.raises(InferenceError, match="not found"):
        OnnxAccelerator(tmp_path / "absent.onnx", metadata)
    path = tmp_path / "tiny.onnx"
    _tiny_onnx_model(path, [0.0, 0.0, 0.0])
    smaller = dataclasses.replace(metadata, input_width_px=160, input_height_px=160)
    with pytest.raises(InferenceError, match="input"):
        OnnxAccelerator(path, smaller)
    garbage = tmp_path / "garbage.onnx"
    garbage.write_bytes(b"not a model")
    with pytest.raises(InferenceError, match="cannot load"):
        OnnxAccelerator(garbage, metadata)


def test_factory_builds_the_configured_runner(tmp_path: Path, metadata: ModelMetadata) -> None:
    path = tmp_path / "tiny.onnx"
    _tiny_onnx_model(path, [0.0, 0.0, 0.0])
    config = make_config(tmp_path, inference__backend="onnx", inference__model_path=str(path))
    assert isinstance(build_accelerator(config, metadata), OnnxAccelerator)

    fake = make_config(tmp_path)
    assert isinstance(build_accelerator(fake, metadata), FakeAccelerator)

    real_with_fake_backend = make_config(tmp_path, hardware__mode="real")
    with pytest.raises(HardwareError, match="only allowed in fake mode"):
        build_accelerator(real_with_fake_backend, metadata)


# --- 9.2 Hailo runner (logic only; the device test needs the station) ----------


class StandInHailo:
    """Mimics the parts of hailo_platform the runner uses."""

    class HailoStreamInterface:
        PCIe = "pcie"

    class FormatType:
        UINT8 = "uint8"
        FLOAT32 = "float32"

    def __init__(self, input_shape: tuple[int, ...] = (224, 224, 3)) -> None:
        outer = self
        self.events: list[str] = []
        self.batches: list[np.ndarray] = []

        class Info:
            def __init__(self, name: str, shape: tuple[int, ...]) -> None:
                self.name = name
                self.shape = shape

        class Hef:
            def __init__(self, path: str) -> None:
                outer.events.append("hef")

            def get_input_vstream_infos(self) -> list[Info]:
                return [Info("net/input_layer1", input_shape)]

            def get_output_vstream_infos(self) -> list[Info]:
                return [Info("net/fc1", (3,))]

        class Context:
            def __init__(self, name: str) -> None:
                self.name = name

            def __enter__(self) -> Any:
                outer.events.append(f"enter:{self.name}")
                return self

            def __exit__(self, *args: object) -> None:
                outer.events.append(f"exit:{self.name}")

        class NetworkGroup:
            def create_params(self) -> str:
                return "params"

            def activate(self, params: str) -> Context:
                return Context("activate")

        class Device(Context):
            def __init__(self) -> None:
                super().__init__("device")

            def configure(self, hef: Hef, params: object) -> list[NetworkGroup]:
                return [NetworkGroup()]

        class Pipeline(Context):
            def __init__(self, *args: object) -> None:
                super().__init__("pipeline")

            def infer(self, feed: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
                outer.batches.append(feed["net/input_layer1"])
                return {"net/fc1": np.array([[0.1, 2.5, 0.3]], dtype=np.float32)}

        class Params:
            @staticmethod
            def create_from_hef(hef: Hef, interface: str) -> str:
                return "configure"

            @staticmethod
            def make(network_group: NetworkGroup, format_type: str) -> str:
                outer.events.append(f"vstream:{format_type}")
                return "vstream"

        self.HEF = Hef
        self.VDevice = Device
        self.ConfigureParams = Params
        self.InputVStreamParams = Params
        self.OutputVStreamParams = Params
        self.InferVStreams = Pipeline


def _hef(tmp_path: Path) -> Path:
    path = tmp_path / "dfu_mobilenetv2.hef"
    path.write_bytes(b"stand-in")
    return path


def test_hailo_runner_feeds_uint8_rgb_and_returns_scores(
    tmp_path: Path, metadata: ModelMetadata
) -> None:
    hailo = StandInHailo()
    runner = HailoAccelerator(_hef(tmp_path), metadata, hailo=hailo)
    rgb = np.full((224, 224, 3), 7, dtype=np.uint8)
    scores = runner.infer(rgb)
    assert scores.tolist() == pytest.approx([0.1, 2.5, 0.3])
    assert hailo.batches[0].shape == (1, 224, 224, 3)
    assert hailo.batches[0].dtype == np.uint8
    assert "vstream:uint8" in hailo.events
    assert "vstream:float32" in hailo.events
    assert runner.model_id == "hailo:dfu_mobilenetv2.hef"

    result = Classifier(runner, metadata).classify(np.zeros((480, 640, 3), dtype=np.uint8))
    assert result.predicted_class == 1
    runner.close()
    assert hailo.events[-3:] == ["exit:activate", "exit:pipeline", "exit:device"]


def test_hailo_runner_refusals(tmp_path: Path, metadata: ModelMetadata) -> None:
    with pytest.raises(InferenceError, match="not found"):
        HailoAccelerator(tmp_path / "absent.hef", metadata, hailo=StandInHailo())
    onnx_file = tmp_path / "model.onnx"
    onnx_file.write_bytes(b"x")
    with pytest.raises(InferenceError, match="compiled off-device"):
        HailoAccelerator(onnx_file, metadata, hailo=StandInHailo())
    with pytest.raises(InferenceError, match="input"):
        HailoAccelerator(_hef(tmp_path), metadata, hailo=StandInHailo((160, 160, 3)))
    runner = HailoAccelerator(_hef(tmp_path), metadata, hailo=StandInHailo())
    with pytest.raises(InferenceError):
        runner.infer(np.zeros((224, 224, 3), dtype=np.float32))


def test_hailo_runner_off_device_fails_cleanly(tmp_path: Path, metadata: ModelMetadata) -> None:
    pytest.importorskip("numpy")
    try:
        import hailo_platform  # noqa: F401
    except ImportError:
        with pytest.raises(InferenceError, match="hailo_platform is not available"):
            HailoAccelerator(_hef(tmp_path), metadata)


@pytest.mark.hardware
def test_real_hailo_runs_the_compiled_model(config: Config) -> None:
    from src.config import load_config

    real = load_config(Path("config/config.yaml"))
    metadata = load_model_metadata(real.inference.metadata_path)
    runner = HailoAccelerator(real.inference.model_path, metadata)
    try:
        scores = runner.infer(
            np.zeros((metadata.input_height_px, metadata.input_width_px, 3), dtype=np.uint8)
        )
        assert scores.shape == (metadata.class_count,)
    finally:
        runner.close()
    assert ManualClock() is not None
