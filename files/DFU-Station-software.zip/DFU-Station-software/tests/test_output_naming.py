"""The classifier output is a predicted class, never a grade (Annex A line 12).

Non-negotiable 3: the system never assigns a Wagner grade. These tests fail
if a grade-like name appears as an identifier anywhere in the station or
training code, or if a model label reads like a grade.
"""

from __future__ import annotations

import dataclasses
import io
import json
import tokenize
from pathlib import Path

import pytest

from src.datamodel import ClassifierResult, FusedResult
from src.errors import InferenceError
from src.inference.metadata import parse_model_metadata
from tests.conftest import ROOT

FORBIDDEN_IN_NAMES = ("grade", "wagner", "diagnosis", "diagnose")


def _python_files() -> list[Path]:
    files = sorted((ROOT / "src").rglob("*.py")) + sorted((ROOT / "training").rglob("*.py"))
    assert files
    return files


def test_classifier_result_fields() -> None:
    names = [field.name for field in dataclasses.fields(ClassifierResult)]
    assert names == ["predicted_class", "predicted_label", "confidence", "model_id"]
    fused = {field.name for field in dataclasses.fields(FusedResult)}
    assert {"predicted_class", "predicted_label", "confidence"} <= fused


@pytest.mark.parametrize("path", _python_files(), ids=lambda p: p.relative_to(ROOT).as_posix())
def test_no_identifier_is_named_like_a_grade(path: Path) -> None:
    source = path.read_text(encoding="utf-8")
    for token in tokenize.generate_tokens(io.StringIO(source).readline):
        if token.type != tokenize.NAME:
            continue
        lowered = token.string.lower()
        for word in FORBIDDEN_IN_NAMES:
            assert word not in lowered, f"{path.name}:{token.start[0]} names {token.string!r}"


@pytest.mark.parametrize(
    "label", ["Grade 2", "wagner_1", "WAGNER-3", "grade0", "diagnosis_positive"]
)
def test_grade_like_labels_are_refused(label: str) -> None:
    data = json.loads((ROOT / "tests" / "fixtures" / "model_meta.json").read_text("utf-8"))
    data["labels"] = ["class_0", label]
    with pytest.raises(InferenceError, match="clinical grade"):
        parse_model_metadata(data)
