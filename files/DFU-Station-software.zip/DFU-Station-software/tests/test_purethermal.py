"""PureThermal driver logic, tested with a fake control channel and grabber.

These tests cover the rules the driver enforces. They do not prove the
extension-unit numbers are right for the real board; that is the hardware
test at the bottom, which only runs on the station.
"""

from __future__ import annotations

import struct
from pathlib import Path

import numpy as np
import pytest

from src.capture import purethermal as pt
from src.clock import ManualClock
from src.config import Config
from src.datamodel import FfcState
from src.errors import HardwareError


class FakeControl(pt.LeptonControl):
    def __init__(self) -> None:
        self.tlinear_enabled = 1
        self.tlinear_resolution = 1
        self.ffc_status = pt.LEP_SYS_FFC_STATUS_READY
        self.fail = False
        self.sets: list[tuple[int, int, bytes]] = []

    def get(self, unit: int, selector: int, size: int) -> bytes:
        if self.fail:
            raise HardwareError("control channel down")
        values = {
            (pt.XU_UNIT_RAD, pt.xu_selector(pt.LEP_CID_RAD_TLINEAR_ENABLE_STATE)): (
                self.tlinear_enabled
            ),
            (pt.XU_UNIT_RAD, pt.xu_selector(pt.LEP_CID_RAD_TLINEAR_RESOLUTION)): (
                self.tlinear_resolution
            ),
            (pt.XU_UNIT_SYS, pt.xu_selector(pt.LEP_CID_SYS_FFC_STATUS)): self.ffc_status,
        }
        return struct.pack("<i", values[(unit, selector)])

    def set(self, unit: int, selector: int, data: bytes) -> None:
        self.sets.append((unit, selector, data))


class FakeGrabber(pt.Y16Grabber):
    def __init__(self, frame: np.ndarray | None) -> None:
        self.frame = frame

    def read(self) -> np.ndarray | None:
        return self.frame


def _camera(
    config: Config, frame: np.ndarray | None = None
) -> tuple[pt.PureThermalCamera, FakeControl, FakeGrabber, ManualClock]:
    control = FakeControl()
    data = np.full((120, 160), 30315, dtype=np.uint16) if frame is None else frame
    grabber = FakeGrabber(data)
    clock = ManualClock()
    camera = pt.PureThermalCamera(grabber, control, config.thermal, clock, start_reader=False)
    return camera, control, grabber, clock


def test_selector_mapping() -> None:
    assert pt.xu_selector(pt.LEP_CID_SYS_RUN_FFC) == 17
    assert pt.xu_selector(pt.LEP_CID_SYS_FFC_STATUS) == 18
    assert pt.xu_selector(pt.LEP_CID_RAD_TLINEAR_ENABLE_STATE) == 49
    assert pt.xu_selector(pt.LEP_CID_RAD_TLINEAR_RESOLUTION) == 50


def test_radiometry_is_confirmed_only_when_the_unit_says_so(config: Config) -> None:
    camera, control, _, _ = _camera(config)
    assert camera.radiometry_confirmed() is True
    control.tlinear_enabled = 0
    assert camera.radiometry_confirmed() is False
    control.tlinear_enabled = 1
    control.tlinear_resolution = 0  # 0.1 K per count: raw / 100 would be wrong
    assert camera.radiometry_confirmed() is False
    control.tlinear_resolution = 1
    control.fail = True
    assert camera.radiometry_confirmed() is False


def test_ffc_state_follows_the_unit(config: Config) -> None:
    camera, control, _, _ = _camera(config)
    assert camera.ffc_state() is FfcState.NEVER
    camera.trigger_ffc()
    assert control.sets == [(pt.XU_UNIT_SYS, 17, bytes([17]))]
    control.ffc_status = pt.LEP_SYS_FFC_STATUS_BUSY
    assert camera.ffc_state() is FfcState.IN_PROGRESS
    control.ffc_status = pt.LEP_SYS_FFC_STATUS_READY
    assert camera.ffc_state() is FfcState.COMPLETE
    # An automatic FFC later shows up as in progress again.
    control.ffc_status = pt.LEP_SYS_FFC_STATUS_FRAME_AVERAGE
    assert camera.ffc_state() is FfcState.IN_PROGRESS


def test_ffc_is_not_called_complete_just_because_status_reads_ready(config: Config) -> None:
    camera, _, _, clock = _camera(config)
    camera.trigger_ffc()
    assert camera.ffc_state() is FfcState.IN_PROGRESS
    clock.advance(pt.FFC_ASSUMED_DURATION_S - 0.1)
    assert camera.ffc_state() is FfcState.IN_PROGRESS
    clock.advance(0.2)
    assert camera.ffc_state() is FfcState.COMPLETE


def test_ffc_error_status_raises(config: Config) -> None:
    camera, control, _, _ = _camera(config)
    control.ffc_status = -1
    with pytest.raises(HardwareError):
        camera.ffc_state()


def test_frame_is_stamped_when_it_arrives_not_when_it_is_read(config: Config) -> None:
    camera, _, _, clock = _camera(config)
    with pytest.raises(HardwareError):
        camera.read_raw()
    clock.advance(5.0)
    camera.poll()
    clock.advance(2.0)
    frame = camera.read_raw()
    assert frame.monotonic_s == 5.0
    assert frame.raw.shape == (120, 160)
    assert frame.raw.dtype == np.uint16


def test_frame_read_during_ffc_is_flagged(config: Config) -> None:
    camera, control, _, _ = _camera(config)
    control.ffc_status = pt.LEP_SYS_FFC_STATUS_BUSY
    camera.poll()
    assert camera.read_raw().ffc_state is FfcState.IN_PROGRESS


def test_colour_stream_is_refused(config: Config) -> None:
    colour = np.zeros((120, 160, 3), dtype=np.uint8)
    camera, _, _, _ = _camera(config, colour)
    with pytest.raises(HardwareError, match="colour stream"):
        camera.poll()


def test_wrong_size_and_missing_frames_are_refused(config: Config) -> None:
    camera, _, grabber, _ = _camera(config, np.zeros((60, 80), dtype=np.uint16))
    with pytest.raises(HardwareError):
        camera.poll()
    grabber.frame = None
    with pytest.raises(HardwareError, match="no frame"):
        camera.poll()


def test_flat_y16_buffer_is_reshaped(config: Config) -> None:
    flat = np.arange(120 * 160, dtype=np.uint16).reshape(1, -1) + 1
    camera, _, _, _ = _camera(config, flat)
    camera.poll()
    assert camera.read_raw().raw.shape == (120, 160)


def test_device_discovery(tmp_path: Path) -> None:
    def node(name: str, label: str, index: int) -> None:
        folder = tmp_path / name
        folder.mkdir()
        (folder / "name").write_text(label + "\n", encoding="utf-8")
        (folder / "index").write_text(f"{index}\n", encoding="utf-8")

    node("video0", "rp1-cfe", 0)
    with pytest.raises(HardwareError, match="PureThermal"):
        pt.find_purethermal_device(tmp_path)
    node("video9", "PureThermal (fw:v1.3.0): PureThermal", 1)
    node("video8", "PureThermal (fw:v1.3.0): PureThermal", 0)
    assert pt.find_purethermal_device(tmp_path) == "/dev/video8"


@pytest.mark.hardware
def test_real_purethermal_delivers_radiometric_y16(config: Config) -> None:
    from src.clock import RealClock

    camera = pt.PureThermalCamera.open(config.thermal, RealClock())
    try:
        assert camera.radiometry_confirmed()
        frame = camera.read_raw()
        assert frame.raw.shape == (config.thermal.height_px, config.thermal.width_px)
        assert frame.raw.dtype == np.uint16
    finally:
        camera.close()
