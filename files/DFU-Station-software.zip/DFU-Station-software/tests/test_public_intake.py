"""Public dataset intake, proxy grouping and the manifest they produce.

All images here are SYNTHETIC patterns generated in the test. No public
dataset is used, and nothing here is a result about real data.
"""

from __future__ import annotations

import copy
import inspect
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import pytest
import yaml

from tests.conftest import ROOT
from training import grouping, public_pipeline
from training.grouping import difference_hash, group_images
from training.intake import (
    REASON_CONFLICT,
    REASON_NO_LABEL,
    REASON_UNMAPPED,
    REASON_UNREADABLE,
    IntakeConfig,
    IntakeError,
    load_intake_config,
    parse_intake_config,
    run_intake,
)
from training.manifest import load_manifest
from training.public_pipeline import GROUPING_LIMITATION, choose_holdout, run_pipeline
from training.splits import patient_level_folds

CONFIG_FILE = ROOT / "training" / "configs" / "public_v1.yaml"


def pattern(seed: int, size: tuple[int, int] = (120, 160)) -> np.ndarray:
    """A smooth random picture; different seeds give clearly different pictures."""
    rng = np.random.default_rng(seed)
    coarse = rng.integers(0, 256, (6, 8, 3), dtype=np.uint8)
    return cv2.resize(coarse, (size[1], size[0]), interpolation=cv2.INTER_CUBIC)


def save(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    assert cv2.imwrite(str(path), image)


def config_data(tmp_path: Path, **source: Any) -> dict[str, Any]:
    data = yaml.safe_load(CONFIG_FILE.read_text(encoding="utf-8"))
    data["raw_dir"] = str(tmp_path / "raw")
    data["manifest_path"] = str(tmp_path / "out" / "public_v1.csv")
    data["calibration_manifest_path"] = str(tmp_path / "out" / "public_v1_calibration.csv")
    data["report_dir"] = str(tmp_path / "out" / "report")
    rule: dict[str, Any] = {
        "url": "https://example.org/synthetic",
        "licence": "synthetic test data",
        "retrieved": "2026-10-08",
        "label_from": "folder",
        "label_map": {"Stage A": "0", "Stage B": "1", "Stage C": "2"},
    }
    rule.update(source)
    data["sources"] = {"setone": rule}
    return data


def make_config(tmp_path: Path, **source: Any) -> IntakeConfig:
    return parse_intake_config(config_data(tmp_path, **source))


def flat_embedder(paths: list[Path]) -> np.ndarray:
    """Every image unlike every other: only the hash and documented ids can link."""
    return np.eye(len(paths), dtype=np.float32)


# --- Step 1: intake -------------------------------------------------------------


def test_committed_config_is_valid_and_has_no_sources_yet() -> None:
    config = load_intake_config(CONFIG_FILE)
    assert config.target_labels == ("0", "1", "2")
    assert config.sources == {}
    assert config.raw_dir == Path("data/public_raw")


def test_empty_or_missing_raw_folder_stops_with_instructions(tmp_path: Path) -> None:
    config = make_config(tmp_path)
    with pytest.raises(IntakeError, match="B14"):
        run_intake(config)
    (tmp_path / "raw").mkdir()
    with pytest.raises(IntakeError, match="no dataset folders"):
        run_intake(config)


def test_an_undescribed_dataset_folder_is_never_ingested(tmp_path: Path) -> None:
    save(tmp_path / "raw" / "setone" / "Stage A" / "a.png", pattern(1))
    save(tmp_path / "raw" / "mystery" / "ulcer" / "b.png", pattern(2))
    with pytest.raises(IntakeError, match="mystery"):
        run_intake(make_config(tmp_path))


def test_labels_are_mapped_only_by_exact_entries(tmp_path: Path) -> None:
    raw = tmp_path / "raw" / "setone"
    save(raw / "Stage A" / "a.png", pattern(1))
    save(raw / "Stage B" / "b.png", pattern(2))
    save(raw / "Stage C" / "c.png", pattern(3))
    save(raw / "Stage D" / "d.png", pattern(4))  # not in the map
    save(raw / "StageA" / "e.png", pattern(5))  # near miss: still not mapped
    save(raw / "loose.png", pattern(6))  # no label folder
    (raw / "Stage A" / "broken.png").write_bytes(b"not an image")

    result = run_intake(make_config(tmp_path))
    assert [(r.image_path, r.label) for r in result.accepted] == [
        ("setone/Stage A/a.png", "0"),
        ("setone/Stage B/b.png", "1"),
        ("setone/Stage C/c.png", "2"),
    ]
    reasons = {r.image_path: r.reason for r in result.rejected}
    assert reasons == {
        "setone/Stage D/d.png": REASON_UNMAPPED,
        "setone/StageA/e.png": REASON_UNMAPPED,
        "setone/loose.png": REASON_NO_LABEL,
        "setone/Stage A/broken.png": REASON_UNREADABLE,
    }


def test_exact_duplicates_are_removed_and_listed(tmp_path: Path) -> None:
    raw = tmp_path / "raw" / "setone"
    save(raw / "Stage A" / "a.png", pattern(1))
    (raw / "Stage A" / "copy.png").write_bytes((raw / "Stage A" / "a.png").read_bytes())
    result = run_intake(make_config(tmp_path))
    assert [r.image_path for r in result.accepted] == ["setone/Stage A/a.png"]
    assert [(d.removed_path, d.kept_path) for d in result.duplicates] == [
        ("setone/Stage A/copy.png", "setone/Stage A/a.png")
    ]


def test_identical_image_with_two_labels_is_rejected_entirely(tmp_path: Path) -> None:
    raw = tmp_path / "raw" / "setone"
    save(raw / "Stage A" / "a.png", pattern(1))
    save(raw / "Stage B" / "b.png", pattern(9))
    (raw / "Stage B" / "same.png").write_bytes((raw / "Stage A" / "a.png").read_bytes())
    result = run_intake(make_config(tmp_path))
    assert [r.image_path for r in result.accepted] == ["setone/Stage B/b.png"]
    assert {r.image_path for r in result.rejected if r.reason == REASON_CONFLICT} == {
        "setone/Stage A/a.png",
        "setone/Stage B/same.png",
    }


def test_labels_and_documented_ids_from_a_csv(tmp_path: Path) -> None:
    raw = tmp_path / "raw" / "setone"
    for name, seed in (("p1_a.png", 1), ("p1_b.png", 2), ("p2_a.png", 3), ("nolabel.png", 4)):
        save(raw / "images" / name, pattern(seed))
    (raw / "labels.csv").write_text(
        "file,stage,subject\np1_a.png,Stage A,S01\np1_b.png,Stage A,S01\np2_a.png,Stage C,S02\n",
        encoding="utf-8",
    )
    config = make_config(
        tmp_path,
        label_from="csv",
        csv={
            "path": "labels.csv",
            "image_column": "file",
            "label_column": "stage",
            "patient_column": "subject",
        },
    )
    result = run_intake(config)
    assert [(r.documented_patient, r.label) for r in result.accepted] == [
        ("S01", "0"),
        ("S01", "0"),
        ("S02", "2"),
    ]
    assert [r.reason for r in result.rejected] == [REASON_NO_LABEL]


@pytest.mark.parametrize(
    "change",
    [
        {"label_map": {"Stage A": "3"}},  # not a target label
        {"label_map": {}},
        {"label_from": "guess"},
        {"url": ""},
        {"licence": ""},
        {"patient_id_regex": "no_group"},
        {"label_from": "csv"},  # csv settings missing
    ],
)
def test_bad_source_rules_are_refused(tmp_path: Path, change: dict[str, Any]) -> None:
    with pytest.raises(IntakeError):
        make_config(tmp_path, **change)


# --- Step 2: grouping -------------------------------------------------------------


def test_near_duplicates_share_a_group_and_different_pictures_do_not(tmp_path: Path) -> None:
    raw = tmp_path / "raw" / "setone" / "Stage A"
    base = pattern(1, (240, 320))
    save(raw / "foot.png", base)
    save(raw / "foot_small.png", cv2.resize(base, (160, 120), interpolation=cv2.INTER_AREA))
    save(raw / "foot_bright.png", np.clip(base.astype(np.int16) + 12, 0, 255).astype(np.uint8))
    save(raw / "foot_crop.png", base[4:-4, 4:-4])
    save(raw / "other1.png", pattern(2))
    save(raw / "other2.png", pattern(3))
    config = make_config(tmp_path)
    records = run_intake(config).accepted
    result = group_images(records, config.raw_dir, config.grouping, flat_embedder, "public_v1")

    def group(name: str) -> str:
        return result.group_of[f"setone/Stage A/{name}"]

    assert group("foot.png") == group("foot_small.png") == group("foot_bright.png")
    assert group("foot.png") == group("foot_crop.png")
    assert len({group("foot.png"), group("other1.png"), group("other2.png")}) == 3
    assert result.group_count == 3
    assert result.hash_links == 3
    assert group("foot.png").startswith("public_v1-g")


def test_embedding_similarity_links_other_shots_of_the_same_foot(tmp_path: Path) -> None:
    raw = tmp_path / "raw" / "setone" / "Stage A"
    for index in range(4):
        save(raw / f"{index}.png", pattern(10 + index))
    config = make_config(tmp_path)
    records = run_intake(config).accepted

    def embedder(paths: list[Path]) -> np.ndarray:
        # Images 0 and 2 look alike to the network; 1 and 3 are unlike anything.
        vectors = np.eye(len(paths), dtype=np.float32)
        vectors[2] = vectors[0] * 0.98 + vectors[2] * 0.02
        return vectors

    result = group_images(records, config.raw_dir, config.grouping, embedder, "public_v1")
    groups = [result.group_of[f"setone/Stage A/{index}.png"] for index in range(4)]
    assert groups[0] == groups[2]
    assert len(set(groups)) == 3
    assert result.embedding_links == 1
    assert result.hash_links == 0


def test_links_are_closed_transitively(tmp_path: Path) -> None:
    raw = tmp_path / "raw" / "setone" / "Stage A"
    names = ["S01_a.png", "S01_b.png", "X_c.png", "X_d.png", "X_e.png", "X_f.png"]
    for index, name in enumerate(names):
        save(raw / name, pattern(20 + index))
    config = make_config(tmp_path, patient_id_regex=r"(S\d+)_")
    records = run_intake(config).accepted

    def embedder(paths: list[Path]) -> np.ndarray:
        # S01_b looks like X_c. S01_a is tied to S01_b only by the documented id.
        vectors = np.eye(len(paths), dtype=np.float32)
        vectors[2] = vectors[1] * 0.98 + vectors[2] * 0.02
        return vectors

    result = group_images(records, config.raw_dir, config.grouping, embedder, "public_v1")
    groups = [result.group_of[f"setone/Stage A/{name}"] for name in names]
    assert groups[0] == groups[1] == groups[2]  # a -(id)- b -(looks alike)- c
    assert len(set(groups)) == 4


def test_unrelated_pictures_are_not_linked_by_the_network_baseline(tmp_path: Path) -> None:
    """Real network features are all positive, so unrelated pictures have a raw
    cosine near 0.9. The grouping must not take that for similarity."""
    raw = tmp_path / "raw" / "setone" / "Stage A"
    for index in range(12):
        save(raw / f"{index:02d}.png", pattern(40 + index))
    config = make_config(tmp_path)
    records = run_intake(config).accepted
    rng = np.random.default_rng(5)

    def embedder(paths: list[Path]) -> np.ndarray:
        shared = np.full((len(paths), 64), 5.0, dtype=np.float32)  # what every image has
        vectors = shared + rng.random((len(paths), 64), dtype=np.float32)
        vectors[7] = vectors[3] + 0.01  # one true near-copy
        return vectors

    vectors = embedder([Path("x")] * 12)
    unit = vectors / np.linalg.norm(vectors, axis=1, keepdims=True)
    assert (unit @ unit.T).min() > config.grouping.embedding_min_cosine  # raw: all "similar"

    result = group_images(records, config.raw_dir, config.grouping, embedder, "public_v1")
    assert result.group_count == 11
    assert result.group_of["setone/Stage A/03.png"] == result.group_of["setone/Stage A/07.png"]
    low, middle, high = result.nearest_cosine_quantiles
    assert low <= middle <= high <= 1.0


def test_report_warns_when_grouping_collapses_or_links_nothing(tmp_path: Path) -> None:
    build_dataset(tmp_path, feet_per_label=6, shots=2)

    def everything_alike(paths: list[Path]) -> np.ndarray:
        vectors = np.zeros((len(paths), 4), dtype=np.float32)
        vectors[: len(paths) // 2, 0] = 1.0  # two big look-alike clusters
        vectors[len(paths) // 2 :, 1] = 1.0
        return vectors

    collapsed = run_pipeline(make_config(tmp_path), everything_alike)
    assert collapsed.grouping.group_count == 2
    assert "WARNING: one group holds" in collapsed.report_markdown

    strict = config_data(tmp_path)
    strict["grouping"]["hash_max_distance"] = 0
    strict["manifest_path"] = str(tmp_path / "out2" / "m.csv")
    strict["calibration_manifest_path"] = str(tmp_path / "out2" / "c.csv")
    strict["report_dir"] = str(tmp_path / "out2" / "report")
    for folder in ("Stage A", "Stage B", "Stage C"):
        for path in (tmp_path / "raw" / "setone" / folder).glob("*_1.png"):
            path.unlink()  # leave one shot per synthetic foot
    alone = run_pipeline(parse_intake_config(strict), flat_embedder)
    assert "WARNING: every group holds a single image" in alone.report_markdown


def test_documented_subject_ids_are_used(tmp_path: Path) -> None:
    raw = tmp_path / "raw" / "setone" / "Stage B"
    for name, seed in (("S01_v1.png", 1), ("S01_v2.png", 2), ("S02_v1.png", 3)):
        save(raw / name, pattern(30 + seed))
    config = make_config(tmp_path, patient_id_regex=r"(S\d+)_")
    records = run_intake(config).accepted
    assert [r.documented_patient for r in records] == ["S01", "S01", "S02"]
    result = group_images(records, config.raw_dir, config.grouping, flat_embedder, "public_v1")
    assert (
        result.group_of["setone/Stage B/S01_v1.png"] == result.group_of["setone/Stage B/S01_v2.png"]
    )
    assert result.group_count == 2
    assert result.documented_links == 1


def test_there_is_no_one_id_per_image_shortcut() -> None:
    # Grouping always computes both similarity tests; there is no option to skip them.
    parameters = set(inspect.signature(group_images).parameters)
    assert parameters == {"records", "raw_dir", "settings", "embedder", "version"}
    source = inspect.getsource(grouping) + inspect.getsource(public_pipeline)
    for word in ("per_image", "one_per_image", "skip_grouping", "no_grouping"):
        assert word not in source
    assert "cannot be guaranteed" in GROUPING_LIMITATION


def test_hash_is_stable_for_the_same_picture(tmp_path: Path) -> None:
    save(tmp_path / "a.png", pattern(1))
    save(tmp_path / "b.png", pattern(1))
    assert np.array_equal(difference_hash(tmp_path / "a.png"), difference_hash(tmp_path / "b.png"))
    with pytest.raises(grouping.GroupingError):
        difference_hash(tmp_path / "absent.png")


# --- Steps 1 to 3 together ---------------------------------------------------------


def build_dataset(tmp_path: Path, feet_per_label: int = 30, shots: int = 4) -> None:
    """SYNTHETIC: each 'foot' is one pattern photographed several times."""
    for label_index, folder in enumerate(("Stage A", "Stage B", "Stage C")):
        for foot in range(feet_per_label):
            base = pattern(1000 * label_index + foot, (240, 320))
            for shot in range(shots):
                picture = np.clip(base.astype(np.int16) + 3 * shot, 0, 255).astype(np.uint8)
                save(tmp_path / "raw" / "setone" / folder / f"f{foot:02d}_{shot}.png", picture)
    save(tmp_path / "raw" / "setone" / "Stage D" / "x.png", pattern(99999))


def test_pipeline_writes_a_manifest_that_keeps_each_foot_together(tmp_path: Path) -> None:
    build_dataset(tmp_path)
    config = make_config(tmp_path)
    output = run_pipeline(config, flat_embedder)

    assert len(output.intake.accepted) == 360
    assert output.grouping.group_count == 90  # one group per synthetic foot, not per image
    assert len(output.intake.rejected) == 1

    # The quantisation hold-out is whole groups and shares none with training.
    group_of = output.grouping.group_of
    held = {group_of[r.image_path] for r in output.holdout_records}
    kept = {group_of[r.image_path] for r in output.training_records}
    assert len(output.holdout_records) >= config.holdout_min_images
    assert held and not held & kept
    assert {r.label for r in output.holdout_records} == {"0", "1", "2"}

    rows = load_manifest(config.manifest_path)
    assert len(rows) == len(output.training_records)
    assert {row.label for row in rows} == {"0", "1", "2"}
    assert all(row.patient_id.startswith("public_v1-g") for row in rows)
    for fold in patient_level_folds(rows, 5, 2026).folds:
        train_feet = {rows[i].image_path.rsplit("_", 1)[0] for i in fold.train_indices}
        test_feet = {rows[i].image_path.rsplit("_", 1)[0] for i in fold.test_indices}
        assert not train_feet & test_feet  # no synthetic foot on both sides

    report_dir = config.report_dir
    for name in (
        "intake_report.md",
        "data_quality.md",
        "rejected.csv",
        "duplicates_removed.csv",
        "groups.csv",
    ):
        assert (report_dir / name).is_file()
    report = (report_dir / "intake_report.md").read_text(encoding="utf-8")
    assert GROUPING_LIMITATION in report
    assert "NOT YET CONFIRMED" in report
    assert "Nothing was rebalanced" in report
    assert "| Stage A | 0 |" in report.replace("setone | ", "")
    assert "Stage D" in report


def test_small_dataset_gets_no_holdout_and_says_so(tmp_path: Path) -> None:
    build_dataset(tmp_path, feet_per_label=4, shots=2)
    output = run_pipeline(make_config(tmp_path), flat_embedder)
    assert output.holdout_records == ()
    assert "No quantisation hold-out was reserved" in output.holdout_note
    assert len(output.training_records) == 24


def test_missing_target_label_is_reported_not_filled(tmp_path: Path) -> None:
    build_dataset(tmp_path, feet_per_label=6, shots=2)
    config = make_config(tmp_path, label_map={"Stage B": "1", "Stage C": "2"})
    output = run_pipeline(config, flat_embedder)
    assert {r.label for r in output.intake.accepted} == {"1", "2"}
    assert "No images at all for target label(s) ['0']" in output.report_markdown


def test_holdout_choice_is_deterministic() -> None:
    from training.intake import ImageRecord

    records = [
        ImageRecord("s", f"{label}/{foot}_{shot}.png", "x", label, "", f"{label}{foot}{shot}")
        for label in ("0", "1")
        for foot in range(60)
        for shot in range(3)
    ]
    group_of = {r.image_path: r.image_path.rsplit("_", 1)[0] for r in records}
    first = choose_holdout(records, group_of, 64, 7)
    assert first == choose_holdout(copy.deepcopy(records), group_of, 64, 7)
    assert first[0] != choose_holdout(records, group_of, 64, 8)[0]


def test_cli_stops_cleanly_when_the_raw_folder_is_absent(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(config_data(tmp_path)), encoding="utf-8")
    assert public_pipeline.main(["--config", str(path)]) == 1
    assert "Intake stopped" in capsys.readouterr().err
    assert not (tmp_path / "out").exists()
