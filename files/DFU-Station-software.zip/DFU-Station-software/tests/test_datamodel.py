"""The data model never names a model output as a grade."""

from __future__ import annotations

import dataclasses
import inspect

from src import datamodel

FORBIDDEN = ("grade", "wagner", "diagnos")


def _dataclasses() -> list[type]:
    return [
        obj
        for _, obj in inspect.getmembers(datamodel, inspect.isclass)
        if dataclasses.is_dataclass(obj) and obj.__module__ == datamodel.__name__
    ]


def test_expected_dataclasses_exist() -> None:
    names = {cls.__name__ for cls in _dataclasses()}
    assert {
        "ThermalFrame",
        "ColorFrame",
        "AmbientReading",
        "ScanRecord",
        "RegionResult",
        "AsymmetryResult",
        "ClassifierResult",
        "FusedResult",
    } <= names


def test_no_field_is_named_as_a_grade() -> None:
    for cls in _dataclasses():
        for field in dataclasses.fields(cls):
            lowered = field.name.lower()
            assert not any(word in lowered for word in FORBIDDEN), f"{cls.__name__}.{field.name}"


def test_thermal_frame_fields() -> None:
    names = {field.name for field in dataclasses.fields(datamodel.ThermalFrame)}
    assert {"temps_c", "raw", "captured_at", "ffc_state"} <= names


def test_classifier_output_is_a_predicted_class() -> None:
    names = {field.name for field in dataclasses.fields(datamodel.ClassifierResult)}
    assert "predicted_class" in names
