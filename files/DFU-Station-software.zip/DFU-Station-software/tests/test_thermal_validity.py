"""A bad thermal frame raises. It is never repaired or substituted."""

from __future__ import annotations

from datetime import UTC, datetime

import numpy as np
import pytest

from src.config import Config
from src.datamodel import FfcState, RawThermalFrame
from src.errors import (
    FfcInProgressError,
    FfcTimeoutError,
    HardwareError,
    InvalidFrameError,
    RadiometryError,
    StaleFrameError,
)
from src.thermal.convert import y16_to_celsius
from src.thermal.validity import validate_raw_frame
from tests.conftest import Rig

NOW_S = 100.0


def _frame(
    raw: np.ndarray | None = None,
    *,
    monotonic_s: float = NOW_S,
    ffc_state: FfcState = FfcState.COMPLETE,
) -> RawThermalFrame:
    data = np.full((120, 160), 30315, dtype=np.uint16) if raw is None else raw
    return RawThermalFrame(
        raw=data,
        monotonic_s=monotonic_s,
        captured_at=datetime(2026, 10, 8, tzinfo=UTC),
        ffc_state=ffc_state,
    )


def _validate(frame: RawThermalFrame, config: Config, last_ffc_s: float | None = 90.0) -> None:
    validate_raw_frame(frame, config.thermal, now_monotonic_s=NOW_S, last_ffc_activity_s=last_ffc_s)


def test_good_frame_passes(config: Config) -> None:
    _validate(_frame(), config)


def test_stale_frame_is_rejected(config: Config) -> None:
    limit_s = config.thermal.max_frame_age_s
    _validate(_frame(monotonic_s=NOW_S - limit_s), config)
    with pytest.raises(StaleFrameError):
        _validate(_frame(monotonic_s=NOW_S - limit_s - 0.01), config)
    with pytest.raises(StaleFrameError):
        _validate(_frame(monotonic_s=NOW_S + 1.0), config)


def test_frame_during_ffc_is_rejected(config: Config) -> None:
    with pytest.raises(FfcInProgressError):
        _validate(_frame(ffc_state=FfcState.IN_PROGRESS), config)


def test_frame_before_any_ffc_is_rejected(config: Config) -> None:
    with pytest.raises(FfcInProgressError):
        _validate(_frame(ffc_state=FfcState.NEVER), config)


def test_frame_right_after_ffc_is_rejected(config: Config) -> None:
    discard_s = config.thermal.post_ffc_discard_s
    with pytest.raises(FfcInProgressError):
        _validate(_frame(), config, last_ffc_s=NOW_S - discard_s + 0.01)
    _validate(_frame(), config, last_ffc_s=NOW_S - discard_s)


def test_all_zero_frame_is_rejected(config: Config) -> None:
    with pytest.raises(InvalidFrameError, match="all zero"):
        _validate(_frame(np.zeros((120, 160), dtype=np.uint16)), config)


def test_saturated_frame_is_rejected(config: Config) -> None:
    raw = np.full((120, 160), 30315, dtype=np.uint16)
    raw[10, 10] = 65535
    with pytest.raises(InvalidFrameError, match="saturated"):
        _validate(_frame(raw), config)


def test_frame_with_dead_zero_pixels_is_rejected(config: Config) -> None:
    raw = np.full((120, 160), 30315, dtype=np.uint16)
    raw[5, 5] = 0
    with pytest.raises(InvalidFrameError, match="zero-valued"):
        _validate(_frame(raw), config)


@pytest.mark.parametrize("shape", [(60, 80), (160, 120), (120, 160, 3)])
def test_wrong_shape_is_rejected(config: Config, shape: tuple[int, ...]) -> None:
    with pytest.raises(InvalidFrameError):
        _validate(_frame(np.full(shape, 30315, dtype=np.uint16)), config)


# --- ThermalSource ---------------------------------------------------------


def _ready(rig: Rig) -> None:
    rig.station.thermal_source.run_ffc()
    rig.clock.advance(rig.config.thermal.post_ffc_discard_s + 0.01)


def test_source_returns_exactly_what_the_sensor_gave(rig: Rig) -> None:
    _ready(rig)
    stored = np.load(rig.config.fake.fixture_dir / rig.config.fake.scenario / "thermal_y16.npy")
    frame = rig.station.thermal_source.capture()
    assert np.array_equal(frame.raw, stored)
    assert np.array_equal(frame.temps_c, y16_to_celsius(stored))
    assert frame.ffc_state is FfcState.COMPLETE


def test_source_refuses_without_radiometry(rig: Rig) -> None:
    _ready(rig)
    rig.thermal.radiometry = False
    with pytest.raises(RadiometryError):
        rig.station.thermal_source.capture()


def test_source_never_measures_before_ffc(rig: Rig) -> None:
    with pytest.raises(FfcInProgressError):
        rig.station.thermal_source.capture()
    assert rig.thermal.reads == rig.config.thermal.max_capture_attempts


def test_source_discards_frames_too_soon_after_ffc_then_reads_a_real_one(rig: Rig) -> None:
    rig.station.thermal_source.run_ffc()
    rig.clock.advance(rig.config.thermal.post_ffc_discard_s - 0.2)
    frame = rig.station.thermal_source.capture()
    assert 1 < rig.thermal.reads <= rig.config.thermal.max_capture_attempts
    assert frame.monotonic_s == rig.clock.monotonic()


def test_source_raises_when_every_frame_is_stale(rig: Rig) -> None:
    _ready(rig)
    rig.thermal.frame_age_s = 5.0
    with pytest.raises(StaleFrameError):
        rig.station.thermal_source.capture()
    assert rig.thermal.reads == rig.config.thermal.max_capture_attempts


def test_source_raises_on_ffc_timeout(rig: Rig) -> None:
    rig.thermal.ffc_never_completes = True
    with pytest.raises(FfcTimeoutError):
        rig.station.thermal_source.run_ffc()


def test_source_raises_on_a_missing_frame(rig: Rig) -> None:
    _ready(rig)
    rig.thermal.fail_reads = True
    with pytest.raises(HardwareError):
        rig.station.thermal_source.capture()


def test_source_raises_on_an_implausible_scene(rig: Rig) -> None:
    _ready(rig)
    rig.thermal.set_frame(np.full((120, 160), 40000, dtype=np.uint16))  # 126.85 C
    with pytest.raises(InvalidFrameError, match="plausible"):
        rig.station.thermal_source.capture()
    assert rig.thermal.reads == 1


def test_source_raises_on_an_all_zero_frame_without_retrying(rig: Rig) -> None:
    _ready(rig)
    rig.thermal.set_frame(np.zeros((120, 160), dtype=np.uint16))
    with pytest.raises(InvalidFrameError):
        rig.station.thermal_source.capture()
    assert rig.thermal.reads == 1
