"""The package layout from README section 5 exists and imports cleanly."""

import importlib

import pytest

PACKAGES = [
    "capture",
    "thermal",
    "registration",
    "segmentation",
    "asymmetry",
    "inference",
    "fusion",
    "storage",
    "ui",
    "hardware",
    "diagnostics",
]


@pytest.mark.parametrize("name", PACKAGES)
def test_package_imports(name: str) -> None:
    importlib.import_module(f"src.{name}")
