"""Fake end-to-end run of the whole station against Annex A (README section 8).

One test drives the complete pipeline on synthetic fixtures and checks every
acceptance line that software alone can check. Lines about the physical build
and about real hardware being present are listed at the bottom as not
testable here; they are demonstrated on the station (docs/acceptance_test.md).

This test shows the software does what it should. It is not evidence about
the hardware, and it asserts no classification accuracy.
"""

from __future__ import annotations

import csv
import json
import socket
from pathlib import Path

import cv2
import numpy as np
import pytest

from src.clock import ManualClock
from src.config import REQUIRED_REGIONS
from src.diagnostics import thermal_reference
from src.errors import (
    AcclimatisationNotMetError,
    AmbientOutOfRangeError,
)
from src.hardware.fakes import FakeThermalCamera, load_color_fixture, load_thermal_fixture
from src.hardware.interfaces import StatusState
from src.registration.target import calibrate_from_target
from src.storage import layout
from src.storage.store import CSV_COLUMNS
from src.thermal.convert import y16_to_celsius
from src.thermal.source import ThermalSource
from src.ui.controller import Screen, StationController
from tests.conftest import REFERENCE_CODE, ROOT, make_rig
from tools import synthetic
from tools.generate_fixtures import scenario_name

FIXTURES = ROOT / "tests" / "fixtures"

SOFTWARE_TESTABLE = {"A2", "A6", "A7", "A8", "A9", "A10", "A11", "A12", "A13", "A14"}
# Physical build and hardware presence: shown on the station, not here.
NOT_SOFTWARE_TESTABLE = {
    "A1": "cabinet, matte interior, blackout shroud: inspection",
    "A3": "camera head at a fixed 420 mm: tape measure",
    "A4": "Pi 5 with Hailo-8L, cooling, storage, power: check_hardware on the station",
    "A5": "Lepton 3.5 and Camera Module 3 integrated: check_hardware on the station",
}


def test_fake_end_to_end_covers_every_software_testable_annex_a_line(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    checked: dict[str, str] = {}

    # A13 (offline): from here on, any attempt to use the network fails the test.
    def no_network(*args: object, **kwargs: object) -> None:
        raise AssertionError("the station tried to use the network")

    monkeypatch.setattr(socket, "socket", no_network)
    monkeypatch.setattr(socket, "create_connection", no_network)
    monkeypatch.setattr(socket, "getaddrinfo", no_network)

    rig = make_rig(tmp_path, fake__scenario=scenario_name(3.5))
    config = rig.config
    controller = StationController(rig.station)
    data_dir = config.storage.data_dir

    # --- A6: touchscreen workflow, capture control, status indication -------
    assert rig.status_led.state is StatusState.IDLE
    assert controller.submit_reference_code(REFERENCE_CODE)
    assert rig.status_led.state is StatusState.ACCLIMATISING

    # The gates hold: too early, and then a room that is too warm.
    with pytest.raises(AcclimatisationNotMetError):
        rig.station.sequencer.capture(REFERENCE_CODE)
    rig.clock.advance(config.acclimatisation_s)
    rig.ambient.temp_c = 25.1
    with pytest.raises(AmbientOutOfRangeError):
        rig.station.sequencer.capture(REFERENCE_CODE)
    rig.ambient.temp_c = config.fake.ambient_temp_c
    assert not data_dir.exists()

    status = controller.prepare_status()
    assert status is not None and status.ready
    assert rig.status_led.state is StatusState.READY

    # --- A2: both soles in one thermal frame ---------------------------------
    previews = controller.previews()
    assert previews.thermal_bgr is not None
    scene = synthetic.default_scene(3.5)
    from dataclasses import replace

    cut_off = synthetic.with_feet(scene, replace(scene.feet[0], center_x_px=150.0), scene.feet[1])
    good_frame = load_thermal_fixture(FIXTURES / scenario_name(3.5))
    rig.thermal.set_frame(synthetic.render_thermal_y16(cut_off))
    assert not controller.request_capture()
    assert controller.message is not None and controller.message.title == "Foot out of view"
    assert rig.status_led.state is StatusState.ERROR
    assert not data_dir.exists()
    rig.thermal.set_frame(good_frame)
    controller.dismiss_message()

    # --- A8: one trigger, one paired colour and thermal frame -----------------
    events_before = len(rig.events.events)
    rig.button.press()  # A6: the physical button, same path as the screen button
    assert controller.screen is Screen.CONFIRM_SIDES
    assert StatusState.CAPTURING in rig.status_led.states
    new_events = rig.events.names()[events_before:]
    assert new_events[:5] == ["ambient_read", "ffc_trigger", "led_on", "color_capture", "led_off"]
    assert new_events.count("color_capture") == 1
    assert new_events.count("led_on") == 1
    # After the colour frame only thermal reads follow, with the light off.
    # (The controller switches the light off once more at the end, to be sure.)
    assert "thermal_read" in new_events[5:]
    assert set(new_events[5:]) <= {"thermal_read", "led_off"}
    assert rig.light.is_on is False
    prepared = controller.prepared
    assert prepared is not None
    assert prepared.masks.image_left.any() and prepared.masks.image_right.any()
    checked["A2"] = "two whole soles segmented from one thermal frame; cut-off foot refused"
    checked["A6"] = "workflow by controller, physical button parity, five status states"

    # Left and right must be confirmed before anything is analysed or stored.
    assert not data_dir.exists()
    assert prepared.proposal.left_is_image_left is False
    assert controller.confirm_sides(False)
    assert controller.screen is Screen.RESULTS
    scan = controller.result
    assert scan is not None

    scan_dirs = [path.parent for path in data_dir.rglob(layout.META_FILE)]
    assert len(scan_dirs) == 1
    folder = scan_dirs[0]
    assert {item.name for item in folder.iterdir()} == set(layout.SCAN_FILES)
    color = cv2.imread(str(folder / layout.COLOR_FILE))
    raw = np.load(folder / layout.THERMAL_RAW_FILE)
    temps = np.load(folder / layout.THERMAL_TEMP_FILE)
    assert color is not None and color.ndim == 3
    assert raw.shape == temps.shape == (config.thermal.height_px, config.thermal.width_px)
    meta = json.loads((folder / layout.META_FILE).read_text(encoding="utf-8"))
    steps = meta["step_timestamps_utc"]
    assert steps["trigger"] <= steps["color_captured"] <= steps["thermal_captured"]
    checked["A8"] = "one button press gave one folder holding both frames and step times"

    # --- A9: thermal values are real temperatures -----------------------------
    assert np.array_equal(raw, good_frame)  # exactly what the sensor gave
    assert np.allclose(temps, raw / 100.0 - 273.15)
    clock = ManualClock()
    target = np.full((120, 160), round((35.0 + 273.15) * 100), dtype=np.uint16)
    source = ThermalSource(
        FakeThermalCamera(target, clock), config.thermal, thermal_reference.UNCALIBRATED, clock
    )
    check = thermal_reference.run_reference_check(
        source, 35.0, config.thermal, thermal_reference.UNCALIBRATED, clock
    )
    assert check.passed and abs(check.error_calibrated_c) < 1e-9
    off = thermal_reference.run_reference_check(
        source, 37.0, config.thermal, thermal_reference.UNCALIBRATED, clock
    )
    assert not off.passed
    checked["A9"] = "conversion formula holds; reference check passes and fails correctly"

    # --- A10: thermal frame registered to the colour frame --------------------
    target_dir = FIXTURES / "registration_target"
    registration = calibrate_from_target(
        load_color_fixture(target_dir),
        y16_to_celsius(load_thermal_fixture(target_dir)),
        config,
        "test",
    )
    assert registration.reprojection_error_px <= config.registration.max_reprojection_error_px
    overlay = cv2.imread(str(folder / layout.OVERLAY_FILE))
    assert overlay is not None and overlay.shape[:2] == temps.shape
    assert scan.registered.thermal_grid_bgr.shape[:2] == temps.shape
    skin = scan.registered.thermal_grid_bgr[:, :, 2] > 100
    feet = temps > 26.0
    assert np.logical_and(skin, feet).sum() / np.logical_or(skin, feet).sum() > 0.93
    assert meta["registration"]["reprojection_error_px"] <= 1.0
    checked["A10"] = "homography fitted within the limit; colour lies on the thermal feet"

    # --- A11: left-right matching with the 2.2 C flag --------------------------
    assert scan.asymmetry.threshold_c == 2.2
    heel = scan.asymmetry.region("heel")
    assert heel.delta_c == pytest.approx(3.5, abs=1e-9)
    assert scan.asymmetry.flagged_regions == ("heel",)
    assert scan.decision.source == "geometry_confirmed"
    for delta_c, flagged in ((0.0, False), (2.19, False), (2.2, True), (2.21, True)):
        other = make_rig(tmp_path / scenario_name(delta_c), fake__scenario=scenario_name(delta_c))
        result = other.scan()
        assert result.asymmetry.region("heel").delta_c == pytest.approx(delta_c, abs=1e-9)
        assert result.asymmetry.region("heel").flagged is flagged, delta_c
        assert result.fused.any_region_flagged is flagged
    checked["A11"] = "2.19 not flagged; 2.2 and 2.21 flagged; symmetric feet not flagged"

    # --- A12: classifier output (software side) ---------------------------------
    assert scan.classifier.predicted_label in rig.station.metadata.labels
    assert 0.0 <= scan.classifier.confidence <= 1.0
    assert meta["classifier"]["predicted_class"] == scan.classifier.predicted_class
    text = json.dumps(meta).lower()
    assert "wagner" not in text and '"grade' not in text
    checked["A12"] = "classifier ran behind the accelerator interface; output is a predicted class"

    # --- A7 and A13: logged with every scan, offline, to CSV ---------------------
    with (data_dir / config.storage.csv_name).open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 1
    row = rows[0]
    assert tuple(row) == CSV_COLUMNS
    assert row["ambient_temp_c"] == "23.50" and row["ambient_humidity_pct"] == "55.0"
    assert meta["ambient"]["temp_c"] == 23.5 and meta["ambient"]["humidity_pct"] == 55.0
    checked["A7"] = "ambient temperature and humidity are in the CSV row and meta.json"

    assert row["reference_code"] == REFERENCE_CODE
    assert row["config_hash"] == config.config_hash()
    assert row["heel_delta_c"] == "3.5000" and row["heel_flagged"] == "1"
    assert row["predicted_label"] == scan.classifier.predicted_label
    for region in REQUIRED_REGIONS:
        assert row[f"{region}_delta_c"] != ""
    assert row["scan_folder"] == folder.relative_to(data_dir).as_posix()
    checked["A13"] = "images, arrays, metadata and a CSV row written with the network blocked"

    # --- A14: methodology document -----------------------------------------------
    methodology = (ROOT / "docs" / "methodology.md").read_text(encoding="utf-8")
    assert "makes no claim about" in methodology
    assert "patient-level cross-validation" in methodology.lower()
    checked["A14"] = "methodology document present with no accuracy claim"

    # --- Back to the start for the next patient ------------------------------------
    controller.next_patient()
    assert controller.screen is Screen.REFERENCE
    assert rig.status_led.state is StatusState.IDLE
    assert set(rig.status_led.states) == set(StatusState)

    # Every software-testable line was checked, and the rest are accounted for.
    assert set(checked) == SOFTWARE_TESTABLE
    all_lines = {f"A{number}" for number in range(1, 15)}
    assert set(checked) | set(NOT_SOFTWARE_TESTABLE) == all_lines
    assert not set(checked) & set(NOT_SOFTWARE_TESTABLE)
