"""Interfaces are abstract, and the factory picks real or fake from config."""

from __future__ import annotations

import dataclasses
from pathlib import Path

import pytest

from src.clock import ManualClock, RealClock, ScaledClock
from src.errors import HardwareError
from src.hardware import fakes, interfaces
from src.hardware.factory import build_clock, build_devices
from src.inference.metadata import load_model_metadata, metadata_path
from tests.conftest import make_config

INTERFACES = [
    interfaces.ThermalCamera,
    interfaces.ColorCamera,
    interfaces.InteriorLight,
    interfaces.CaptureButton,
    interfaces.StatusLed,
    interfaces.AmbientSensor,
    interfaces.Accelerator,
]


@pytest.mark.parametrize("interface", INTERFACES)
def test_interfaces_cannot_be_instantiated(interface: type) -> None:
    with pytest.raises(TypeError):
        interface()


def test_fake_mode_builds_fakes(tmp_path: Path) -> None:
    config = make_config(tmp_path)
    metadata = load_model_metadata(metadata_path(config))
    devices = build_devices(config, ManualClock(), metadata)
    assert isinstance(devices.thermal, fakes.FakeThermalCamera)
    assert isinstance(devices.color, fakes.FakeColorCamera)
    assert isinstance(devices.light, fakes.FakeInteriorLight)
    assert isinstance(devices.button, fakes.FakeCaptureButton)
    assert isinstance(devices.status_led, fakes.FakeStatusLed)
    assert isinstance(devices.ambient, fakes.FakeAmbientSensor)
    assert isinstance(devices.accelerator, fakes.FakeAccelerator)
    for field in dataclasses.fields(devices):
        assert isinstance(getattr(devices, field.name), tuple(INTERFACES))


def test_real_mode_never_builds_fakes_off_device(tmp_path: Path) -> None:
    config = make_config(tmp_path, hardware__mode="real")
    metadata = load_model_metadata(make_config(tmp_path).fake.fixture_dir / "model_meta.json")
    with pytest.raises(HardwareError):
        build_devices(config, ManualClock(), metadata)


def test_sped_up_clock_exists_only_in_fake_mode(tmp_path: Path) -> None:
    assert isinstance(build_clock(make_config(tmp_path)), ScaledClock)
    assert isinstance(build_clock(make_config(tmp_path, hardware__mode="real")), RealClock)


def test_missing_fixture_is_an_error(tmp_path: Path) -> None:
    config = make_config(tmp_path, fake__scenario="no_such_scenario")
    metadata = load_model_metadata(metadata_path(config))
    with pytest.raises(HardwareError, match="fixture"):
        build_devices(config, ManualClock(), metadata)
