"""The handover documents exist, cover what they must, and claim no accuracy."""

from __future__ import annotations

import re

import pytest

from src.config import REQUIRED_REGIONS, load_config
from tests.conftest import EXAMPLE_CONFIG, ROOT

DOCS = ROOT / "docs"


def read(name: str) -> str:
    return (DOCS / name).read_text(encoding="utf-8")


def test_methodology_covers_every_required_topic() -> None:
    text = read("methodology.md").lower()
    for topic in (
        "hardware",
        "capture protocol",
        "calibration",
        "registration",
        "asymmetry method",
        "classifier",
        "patient-level cross-validation",
        "limitations",
    ):
        assert topic in text, topic


def test_methodology_makes_no_accuracy_claim() -> None:
    text = read("methodology.md")
    assert "makes no claim about" in text
    # No performance figure: no "NN % accuracy", "accuracy of NN", "F1 of", AUC values.
    patterns = (
        r"\d+(\.\d+)?\s*%\s*(accuracy|sensitivity|specificity|precision|recall)",
        r"(accuracy|sensitivity|specificity|f1|auc)\s*(of|was|is|=|:)\s*\d",
        r"achiev\w+\s+\d",
    )
    for pattern in patterns:
        assert not re.search(pattern, text, flags=re.IGNORECASE), pattern


def test_methodology_matches_the_configured_protocol() -> None:
    config = load_config(EXAMPLE_CONFIG)
    text = read("methodology.md")
    assert f"{config.asymmetry_threshold_c} °C" in text
    assert f"{config.ambient_min_c}–{config.ambient_max_c} °C" in text
    assert f"{config.acclimatisation_s:.0f} s" in text
    assert f"{config.settle_delay_s} s" in text
    assert f"{config.color.led_on_settle_s} s" in text
    assert f"{config.segmentation.min_above_reference_c} °C" in text
    assert f"{config.segmentation.min_foot_area_px} pixels" in text
    assert f"fewer than {config.regions.min_region_px} pixels" in text
    assert f"{config.registration.max_reprojection_error_px} thermal pixel" in text
    lowered = text.lower()
    for region in REQUIRED_REGIONS:
        words = region.replace("metatarsal_head_1", "1st metatarsal head")
        words = words.replace("metatarsal_head_5", "5th metatarsal head")
        words = words.replace("metatarsal_heads_central", "central metatarsal heads")
        assert words.replace("_", " ") in lowered, region


def test_methodology_states_the_region_map_in_use() -> None:
    config = load_config(EXAMPLE_CONFIG)
    text = read("methodology.md")
    heel = config.regions.polygon_map()["heel"]
    assert min(v for _, v in heel) == 0.70
    assert "| Heel | 0.70–1.00 | 0.00–1.00 |" in text
    hallux = config.regions.polygon_map()["hallux"]
    assert max(u for u, _ in hallux) == 0.35
    assert "| Hallux | 0.00–0.18 | 0.00–0.35 |" in text


def test_operator_manual_covers_every_required_topic() -> None:
    text = read("operator_manual.md").lower()
    for topic in (
        "prepare the room",
        "supine",
        "seated",
        "rest period",
        "scan",
        "shutting down",
        "cleaning",
        "never type a patient's name",
    ):
        assert topic in text, topic
    assert "not a diagnosis" in text


def test_calibration_manual_covers_every_required_topic() -> None:
    text = read("calibration.md").lower()
    for topic in (
        "thermal reference check",
        "registration",
        "focus",
        "how often to repeat",
        "reference thermometer",
    ):
        assert topic in text, topic


@pytest.mark.parametrize(
    "command",
    [
        "src.diagnostics.thermal_reference",
        "src.diagnostics.color_lock",
        "src.diagnostics.registration_calibrate",
        "src.diagnostics.check_hardware",
    ],
)
def test_documented_tools_exist(command: str) -> None:
    assert command in read("calibration.md")
    assert (ROOT / (command.replace(".", "/") + ".py")).is_file()
