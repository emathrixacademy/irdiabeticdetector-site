"""Reference codes: anonymised codes pass, anything like a name is refused."""

from __future__ import annotations

import pytest

from src.config import Config
from src.errors import ReferenceCodeError
from src.reference_code import validate_reference_code


@pytest.mark.parametrize("code", ["DFU-0001", "AB-123", "STUDY-999999"])
def test_valid_codes_pass(config: Config, code: str) -> None:
    assert validate_reference_code(code, config.reference_code) == code


@pytest.mark.parametrize(
    "code",
    [
        "",
        "Juan Dela Cruz",
        "Maria",
        "SANTOS",
        "Santos, Ana",
        "juan.delacruz",
        "DelaCruz-001",
        " DFU-0001",
        "DFU-0001 ",
        "dfu-0001",
        "DFU-0001-EXTRA-LONG-CODE",
        "DFU/0001",
        "../DFU-0001",
        "0001",
    ],
)
def test_names_and_malformed_codes_are_refused(config: Config, code: str) -> None:
    with pytest.raises(ReferenceCodeError):
        validate_reference_code(code, config.reference_code)


def test_error_does_not_repeat_the_rejected_text(config: Config) -> None:
    with pytest.raises(ReferenceCodeError) as info:
        validate_reference_code("Juan Dela Cruz", config.reference_code)
    assert "Juan" not in str(info.value)
