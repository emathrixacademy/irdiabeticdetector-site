# Test fixtures

Everything in this folder is **synthetic**, written by
`python -m tools.generate_fixtures`. No file here was captured from a
person or from the station.
