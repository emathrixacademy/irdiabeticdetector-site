"""The autostart service file says what it should. Running it needs the Pi."""

from __future__ import annotations

import configparser
import subprocess
import sys

import pytest

from src import app
from tests.conftest import ROOT

UNIT = ROOT / "deploy" / "dfu-station.service"
INSTALLER = ROOT / "deploy" / "install_service.sh"


def _unit() -> configparser.ConfigParser:
    parser = configparser.ConfigParser(interpolation=None)
    parser.optionxform = str  # type: ignore[assignment,method-assign]
    parser.read_string(UNIT.read_text(encoding="utf-8"))
    return parser


def test_service_starts_the_real_app_and_restarts_on_crash() -> None:
    unit = _unit()
    command = unit["Service"]["ExecStart"]
    assert "-m src.app" in command
    assert "--fake" not in command
    assert "--headless" not in command
    assert unit["Service"]["Restart"] == "on-failure"
    assert unit["Service"]["RestartPreventExitStatus"] == "2"
    assert unit["Install"]["WantedBy"] == "graphical-session.target"


def test_service_logs_to_the_journal() -> None:
    unit = _unit()
    assert unit["Service"]["StandardOutput"] == "journal"
    assert unit["Service"]["StandardError"] == "journal"


def test_service_does_not_depend_on_the_network() -> None:
    text = UNIT.read_text(encoding="utf-8")
    settings = "\n".join(line for line in text.splitlines() if not line.startswith("#"))
    assert "network" not in settings.lower()


def test_service_arguments_are_ones_the_app_accepts() -> None:
    command = _unit()["Service"]["ExecStart"].split(" -m src.app ", 1)[1]
    arguments = command.replace("@INSTALL_DIR@", "/home/pi/dfu").split()
    parsed = app.parse_args(arguments)
    assert str(parsed.config).replace("\\", "/") == "/home/pi/dfu/config/config.yaml"
    assert parsed.fake is False
    assert parsed.headless is False


def test_installer_fills_in_the_folder_and_refuses_root() -> None:
    text = INSTALLER.read_text(encoding="utf-8")
    assert text.startswith("#!/bin/sh")
    assert "@INSTALL_DIR@" in text
    assert "systemctl --user enable --now" in text
    assert "not as root" in text
    assert "\r\n" not in text


def test_fake_panel_test_is_an_explicit_option_and_says_what_it_is() -> None:
    text = INSTALLER.read_text(encoding="utf-8")
    assert '"--fake-panel-test"' in text
    assert "nothing it shows is a measurement" in text
    assert "install the real service before the station is used" in text
    # The committed unit itself never starts the app in fake mode.
    assert "--fake" not in UNIT.read_text(encoding="utf-8")
    # An unknown option is refused instead of silently installing something.
    assert "Unknown option" in text


@pytest.mark.hardware
def test_service_is_running_on_the_station() -> None:
    assert sys.platform.startswith("linux")
    result = subprocess.run(
        ["systemctl", "--user", "is-active", "dfu-station.service"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.stdout.strip() == "active"
