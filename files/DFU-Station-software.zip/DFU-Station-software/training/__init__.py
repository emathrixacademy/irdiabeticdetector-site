"""Off-device training pipeline. Runs on an x86 machine, never on the Pi.

The research team supplies the dataset and the clinician-assigned labels.
Two rules are fixed: every split is grouped by patient, and data problems are
reported, never silently corrected.
"""
