"""Intake of public image datasets into a labelled, de-duplicated image list.

Rules:
- Every dataset folder must be described in the intake config. A folder that
  is not described stops the intake; nothing is ingested on a guess.
- A source label is mapped to a target label only by an exact entry in that
  source's `label_map`. Anything else is rejected and listed, never guessed.
- Byte-identical files are removed, keeping one, and listed. If identical
  files carry different labels, all of them are rejected: the label is not
  certain.
- Nothing is rebalanced.
"""

from __future__ import annotations

import csv
import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import yaml

REASON_UNMAPPED = "source label has no certain mapping to a target label"
REASON_NO_LABEL = "no source label found for this image"
REASON_UNREADABLE = "image file could not be read"
REASON_CONFLICT = "identical image appears with different labels"


class IntakeError(Exception):
    """The intake cannot proceed as configured."""


@dataclass(frozen=True)
class SourceRule:
    name: str
    url: str
    licence: str
    retrieved: str
    label_from: str
    label_map: dict[str, str]
    csv_path: str
    csv_image_column: str
    csv_label_column: str
    csv_patient_column: str
    patient_id_regex: str
    confirmed_by: str


@dataclass(frozen=True)
class GroupingSettings:
    hash_max_distance: int
    embedding_min_cosine: float
    embedding_batch_size: int


@dataclass(frozen=True)
class IntakeConfig:
    version: str
    raw_dir: Path
    manifest_path: Path
    calibration_manifest_path: Path
    report_dir: Path
    target_labels: tuple[str, ...]
    image_suffixes: tuple[str, ...]
    grouping: GroupingSettings
    holdout_min_images: int
    holdout_seed: int
    sources: dict[str, SourceRule]


@dataclass(frozen=True)
class ImageRecord:
    source: str
    image_path: str  # relative to raw_dir, forward slashes
    source_label: str
    label: str
    documented_patient: str  # "" unless the dataset documents an id
    sha256: str


@dataclass(frozen=True)
class Rejected:
    source: str
    image_path: str
    source_label: str
    reason: str


@dataclass(frozen=True)
class Duplicate:
    removed_path: str
    kept_path: str


@dataclass
class IntakeResult:
    accepted: list[ImageRecord] = field(default_factory=list)
    rejected: list[Rejected] = field(default_factory=list)
    duplicates: list[Duplicate] = field(default_factory=list)


def _text(data: dict[str, Any], key: str, where: str, *, required: bool = True) -> str:
    value = data.get(key, "")
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise IntakeError(f"{where}.{key}: expected text")
    if required and not value.strip():
        raise IntakeError(f"{where}.{key}: required and empty")
    return value.strip()


def _source_rule(name: str, data: object, targets: tuple[str, ...]) -> SourceRule:
    where = f"sources.{name}"
    if not isinstance(data, dict):
        raise IntakeError(f"{where}: expected a mapping")
    label_from = _text(data, "label_from", where)
    if label_from not in ("folder", "csv"):
        raise IntakeError(f"{where}.label_from: must be 'folder' or 'csv'")
    raw_map = data.get("label_map")
    if not isinstance(raw_map, dict) or not raw_map:
        raise IntakeError(f"{where}.label_map: required; map each certain source label")
    label_map = {str(key): str(value) for key, value in raw_map.items()}
    for source_label, target in label_map.items():
        if target not in targets:
            raise IntakeError(
                f"{where}.label_map: {source_label!r} maps to {target!r}, "
                f"which is not one of the target labels {list(targets)}"
            )
    csv_data = data.get("csv") or {}
    if not isinstance(csv_data, dict):
        raise IntakeError(f"{where}.csv: expected a mapping")
    if label_from == "csv":
        for key in ("path", "image_column", "label_column"):
            _text(csv_data, key, f"{where}.csv")
    regex = _text(data, "patient_id_regex", where, required=False)
    if regex:
        try:
            if re.compile(regex).groups < 1:
                raise IntakeError(f"{where}.patient_id_regex: needs one capture group")
        except re.error as exc:
            raise IntakeError(f"{where}.patient_id_regex: {exc}") from exc
    return SourceRule(
        name=name,
        url=_text(data, "url", where),
        licence=_text(data, "licence", where),
        retrieved=_text(data, "retrieved", where),
        label_from=label_from,
        label_map=label_map,
        csv_path=_text(csv_data, "path", f"{where}.csv", required=False),
        csv_image_column=_text(csv_data, "image_column", f"{where}.csv", required=False),
        csv_label_column=_text(csv_data, "label_column", f"{where}.csv", required=False),
        csv_patient_column=_text(csv_data, "patient_column", f"{where}.csv", required=False),
        patient_id_regex=regex,
        confirmed_by=_text(data, "confirmed_by", where, required=False),
    )


def parse_intake_config(data: object) -> IntakeConfig:
    if not isinstance(data, dict):
        raise IntakeError("intake config: expected a mapping")
    try:
        targets = tuple(str(label) for label in data["target_labels"])
        grouping = data["grouping"]
        holdout = data["calibration_holdout"]
        sources_raw = data.get("sources") or {}
        if not isinstance(sources_raw, dict):
            raise IntakeError("sources: expected a mapping")
        hash_distance = int(grouping["hash_max_distance"])
        cosine = float(grouping["embedding_min_cosine"])
        if not 0 <= hash_distance <= 64:
            raise IntakeError("grouping.hash_max_distance: must be 0 to 64")
        if not 0.0 < cosine <= 1.0:
            raise IntakeError("grouping.embedding_min_cosine: must be above 0 and at most 1")
        return IntakeConfig(
            version=str(data["version"]),
            raw_dir=Path(str(data["raw_dir"])),
            manifest_path=Path(str(data["manifest_path"])),
            calibration_manifest_path=Path(str(data["calibration_manifest_path"])),
            report_dir=Path(str(data["report_dir"])),
            target_labels=targets,
            image_suffixes=tuple(str(s).lower() for s in data["image_suffixes"]),
            grouping=GroupingSettings(
                hash_max_distance=hash_distance,
                embedding_min_cosine=cosine,
                embedding_batch_size=int(grouping["embedding_batch_size"]),
            ),
            holdout_min_images=int(holdout["min_images"]),
            holdout_seed=int(holdout["seed"]),
            sources={
                str(name): _source_rule(str(name), rule, targets)
                for name, rule in sources_raw.items()
            },
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise IntakeError(f"intake config: missing or malformed value: {exc}") from exc


def load_intake_config(path: Path) -> IntakeConfig:
    try:
        return parse_intake_config(yaml.safe_load(path.read_text(encoding="utf-8")))
    except (OSError, yaml.YAMLError) as exc:
        raise IntakeError(f"cannot read intake config {path}: {exc}") from exc


def dataset_folders(raw_dir: Path) -> list[str]:
    if not raw_dir.is_dir():
        return []
    return sorted(entry.name for entry in raw_dir.iterdir() if entry.is_dir())


def check_sources(config: IntakeConfig) -> list[str]:
    """Dataset folders present. Raises unless each one is described in the config."""
    folders = dataset_folders(config.raw_dir)
    if not folders:
        raise IntakeError(
            f"no dataset folders found in {config.raw_dir.as_posix()}. "
            "See BLOCKERS.md B14 for what to download and where to put it."
        )
    unknown = [name for name in folders if name not in config.sources]
    if unknown:
        raise IntakeError(
            f"dataset folder(s) {unknown} are not described under `sources` in the intake "
            "config. Describe each one (url, licence, label_map) before it is ingested."
        )
    return folders


def _csv_labels(rule: SourceRule, folder: Path) -> dict[str, tuple[str, str]]:
    """image name or relative path -> (source label, documented patient id)."""
    path = folder / rule.csv_path
    try:
        handle = path.open(newline="", encoding="utf-8-sig")
    except OSError as exc:
        raise IntakeError(f"sources.{rule.name}.csv.path: cannot read {path.name}: {exc}") from exc
    labels: dict[str, tuple[str, str]] = {}
    with handle:
        reader = csv.DictReader(handle)
        columns = set(reader.fieldnames or ())
        needed = {rule.csv_image_column, rule.csv_label_column}
        if rule.csv_patient_column:
            needed.add(rule.csv_patient_column)
        if not needed <= columns:
            raise IntakeError(
                f"sources.{rule.name}.csv: columns {sorted(needed - columns)} not in {path.name}"
            )
        for row in reader:
            key = (row.get(rule.csv_image_column) or "").strip().replace("\\", "/")
            patient = (
                (row.get(rule.csv_patient_column) or "").strip()
                if (rule.csv_patient_column)
                else ""
            )
            if key:
                labels[key] = ((row.get(rule.csv_label_column) or "").strip(), patient)
    return labels


def _readable(path: Path) -> bool:
    data = np.fromfile(path, dtype=np.uint8)
    return data.size > 0 and cv2.imdecode(data, cv2.IMREAD_COLOR) is not None


def _scan_source(
    rule: SourceRule, config: IntakeConfig
) -> tuple[list[ImageRecord], list[Rejected]]:
    folder = config.raw_dir / rule.name
    csv_labels = _csv_labels(rule, folder) if rule.label_from == "csv" else {}
    pattern = re.compile(rule.patient_id_regex) if rule.patient_id_regex else None
    accepted: list[ImageRecord] = []
    rejected: list[Rejected] = []
    files = sorted(
        path
        for path in folder.rglob("*")
        if path.is_file() and path.suffix.lower() in config.image_suffixes
    )
    for path in files:
        relative = path.relative_to(config.raw_dir).as_posix()
        in_source = path.relative_to(folder).as_posix()
        documented = ""
        if rule.label_from == "folder":
            source_label = path.parent.name if path.parent != folder else ""
        else:
            found = csv_labels.get(in_source) or csv_labels.get(path.name)
            source_label, documented = found if found else ("", "")
        if pattern is not None and not documented:
            match = pattern.search(in_source)
            documented = match.group(1) if match else ""
        if not source_label:
            rejected.append(Rejected(rule.name, relative, "", REASON_NO_LABEL))
            continue
        label = rule.label_map.get(source_label)
        if label is None:
            rejected.append(Rejected(rule.name, relative, source_label, REASON_UNMAPPED))
            continue
        if not _readable(path):
            rejected.append(Rejected(rule.name, relative, source_label, REASON_UNREADABLE))
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        accepted.append(ImageRecord(rule.name, relative, source_label, label, documented, digest))
    return accepted, rejected


def run_intake(config: IntakeConfig) -> IntakeResult:
    """Scan every dataset folder, map labels, and remove exact duplicates."""
    result = IntakeResult()
    candidates: list[ImageRecord] = []
    for name in check_sources(config):
        accepted, rejected = _scan_source(config.sources[name], config)
        candidates += accepted
        result.rejected += rejected

    by_digest: dict[str, list[ImageRecord]] = {}
    for record in sorted(candidates, key=lambda item: item.image_path):
        by_digest.setdefault(record.sha256, []).append(record)
    for copies in by_digest.values():
        if len({copy.label for copy in copies}) > 1:
            result.rejected += [
                Rejected(copy.source, copy.image_path, copy.source_label, REASON_CONFLICT)
                for copy in copies
            ]
            continue
        kept = copies[0]
        result.accepted.append(kept)
        result.duplicates += [Duplicate(copy.image_path, kept.image_path) for copy in copies[1:]]
    result.accepted.sort(key=lambda item: item.image_path)
    result.rejected.sort(key=lambda item: item.image_path)
    return result
