"""Proxy patient grouping for datasets that document no patient ids.

Public image sets usually carry no patient id, and one person's foot often
appears in many images (repeat visits, several angles, crops, augmented
copies). Giving each image its own id and calling the split "patient-level"
would leak the same foot across the split. This module never does that.

Where a dataset documents a patient or subject id, that id is used. Otherwise
images are linked into proxy groups by two tests, and a group is everything
connected through such links:

- perceptual hash: near-duplicate pictures (resized, recompressed, slightly
  cropped or brightened copies);
- embedding similarity: pictures a pretrained network sees as nearly the
  same, which catches other shots of the same foot.

LIMITATION, stated wherever these groups are used: grouping is a proxy. True
patient separation cannot be guaranteed on public data without real ids. Two
photographs of one patient that look different (another day, another angle)
can still land in different groups.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np
from numpy.typing import NDArray

from training.intake import GroupingSettings, ImageRecord

HASH_BITS = 64
NEAREST_QUANTILES = (0.1, 0.5, 0.9)
Embedder = Callable[[list[Path]], NDArray[np.float32]]


class GroupingError(Exception):
    """Images could not be grouped."""


@dataclass(frozen=True)
class GroupingResult:
    group_of: dict[str, str]  # image_path -> group id (used as patient_id)
    hash_links: int
    embedding_links: int
    documented_links: int
    # Each image's similarity to its most similar other image, at the
    # NEAREST_QUANTILES of the dataset. Used to judge the threshold.
    nearest_cosine_quantiles: tuple[float, ...] = ()

    @property
    def group_count(self) -> int:
        return len(set(self.group_of.values()))


def difference_hash(path: Path) -> NDArray[np.bool_]:
    """64-bit difference hash: is each pixel brighter than its right neighbour."""
    try:
        data = np.fromfile(path, dtype=np.uint8)
    except OSError as exc:
        raise GroupingError(f"cannot read {path.name}: {exc}") from exc
    gray = cv2.imdecode(data, cv2.IMREAD_GRAYSCALE) if data.size else None
    if gray is None:
        raise GroupingError(f"cannot read {path.name}")
    small = cv2.resize(gray, (9, 8), interpolation=cv2.INTER_AREA).astype(np.int16)
    return np.asarray((small[:, 1:] > small[:, :-1]).reshape(HASH_BITS), dtype=np.bool_)


class _DisjointSets:
    def __init__(self, count: int) -> None:
        self._parent = list(range(count))

    def find(self, item: int) -> int:
        while self._parent[item] != item:
            self._parent[item] = self._parent[self._parent[item]]
            item = self._parent[item]
        return item

    def union(self, first: int, second: int) -> bool:
        root_a, root_b = self.find(first), self.find(second)
        if root_a == root_b:
            return False
        self._parent[max(root_a, root_b)] = min(root_a, root_b)
        return True


def mobilenet_embedder(batch_size: int) -> Embedder:
    """MobileNetV2 (ImageNet) pooled features, unit length. Needs PyTorch."""
    import torch
    from torchvision.models import MobileNet_V2_Weights, mobilenet_v2

    from src.inference.preprocess import preprocess
    from training.train import make_metadata

    model = mobilenet_v2(weights=MobileNet_V2_Weights.IMAGENET1K_V1).features.eval()
    metadata = make_metadata(2, "embedder")

    def embed(paths: list[Path]) -> NDArray[np.float32]:
        rows: list[NDArray[np.float32]] = []
        with torch.no_grad():
            for start in range(0, len(paths), batch_size):
                batch = []
                for path in paths[start : start + batch_size]:
                    image = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
                    if image is None:
                        raise GroupingError(f"cannot read {path.name}")
                    batch.append(preprocess(image, metadata)[0])
                features = model(torch.from_numpy(np.stack(batch))).mean(dim=(2, 3))
                rows.append(features.numpy().astype(np.float32))
        return np.concatenate(rows) if rows else np.zeros((0, 1280), dtype=np.float32)

    return embed


def _unit_rows(matrix: NDArray[np.float32]) -> NDArray[np.float32]:
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    return np.asarray(matrix / np.maximum(norms, 1e-12), dtype=np.float32)


def group_images(
    records: list[ImageRecord],
    raw_dir: Path,
    settings: GroupingSettings,
    embedder: Embedder,
    version: str,
) -> GroupingResult:
    """Assign every image a group id. Each id stands in for a patient id."""
    ordered = sorted(records, key=lambda record: record.image_path)
    count = len(ordered)
    if count == 0:
        raise GroupingError("there are no images to group")
    paths = [raw_dir / record.image_path for record in ordered]
    sets = _DisjointSets(count)

    documented_links = 0
    first_with_id: dict[tuple[str, str], int] = {}
    for index, record in enumerate(ordered):
        if record.documented_patient:
            key = (record.source, record.documented_patient)
            if key in first_with_id:
                documented_links += sets.union(first_with_id[key], index)
            else:
                first_with_id[key] = index

    hashes = np.stack([difference_hash(path) for path in paths])
    hash_links = 0
    for index in range(count - 1):
        distances = np.count_nonzero(hashes[index + 1 :] != hashes[index], axis=1)
        for offset in np.nonzero(distances <= settings.hash_max_distance)[0]:
            hash_links += sets.union(index, index + 1 + int(offset))

    raw_embeddings = np.asarray(embedder(paths), dtype=np.float32)
    if raw_embeddings.shape[0] != count:
        raise GroupingError("the embedder returned the wrong number of rows")
    # Network features are all positive, so any two pictures have a high raw
    # cosine (about 0.9 even when unrelated). Subtracting the dataset mean
    # first makes unrelated pictures score near zero and leaves near-identical
    # ones near one, which is what the threshold is meant to separate.
    embeddings = _unit_rows(raw_embeddings - raw_embeddings.mean(axis=0, keepdims=True))
    embedding_links = 0
    nearest = np.full(count, -1.0, dtype=np.float64)
    for index in range(count - 1):
        similarity = embeddings[index + 1 :] @ embeddings[index]
        nearest[index] = max(nearest[index], float(np.max(similarity)))
        nearest[index + 1 :] = np.maximum(nearest[index + 1 :], similarity)
        for offset in np.nonzero(similarity >= settings.embedding_min_cosine)[0]:
            embedding_links += sets.union(index, index + 1 + int(offset))

    roots = sorted({sets.find(index) for index in range(count)})
    name_of = {root: f"{version}-g{number:05d}" for number, root in enumerate(roots, start=1)}
    return GroupingResult(
        group_of={
            record.image_path: name_of[sets.find(index)] for index, record in enumerate(ordered)
        },
        hash_links=hash_links,
        embedding_links=embedding_links,
        documented_links=documented_links,
        nearest_cosine_quantiles=(
            tuple(float(value) for value in np.quantile(nearest, NEAREST_QUANTILES))
            if count > 1
            else ()
        ),
    )
