# Training pipeline (off-device)

Everything here runs on an x86 machine. Nothing here runs on the Pi, and the
Pi never compiles a model.

```
dataset + manifest.csv
   -> training.train        data-quality report, patient-level cross-validation, final model
   -> training.export       ONNX (fixed 1 x 3 x 224 x 224 input) + model_meta.json, parity checked
   -> training.hailo_compile   .hef for the Hailo-8L (needs the Hailo Dataflow Compiler)
   -> copy the .hef and model_meta.json into models/ on the station
```

## Two fixed rules

1. **Split by patient, never by image.** Every fold is grouped by
   `patient_id`. The split code checks this when it builds the folds and again
   when each fold is used. Do not add an image-level shuffle of the dataset.
2. **The dataset is reported as it is.** The data-quality report counts images
   and patients per class and warns about imbalance, tiny classes and missing
   metadata. Nothing is dropped, imputed or rebalanced. The patient count is
   the real sample size.

## 1. The manifest

A CSV with exactly these columns:

| Column | Meaning |
|---|---|
| `patient_id` | The anonymised reference code. Required. Never a name. |
| `image_path` | Path to the image, relative to `--image-root`. Required. |
| `label` | The label assigned by the clinician. Required. |
| `source` | Where the image came from (for example the station id). |
| `capture_session` | The session the image belongs to. |

A manifest with any row missing `patient_id`, `image_path` or `label` is
rejected as a whole, with the line numbers listed. Fix the file; rows are not
dropped for you.

Use the station's registered colour crops (`color_registered.png` in each scan
folder) as the images, so training sees what the station's classifier sees.

Manifests, images and reports contain session data. Keep them out of git.

## 1a. A first model from public photographs (`public_v1`)

Until the station has collected its own images, a first model can be trained
on public colour photographs so the classifier path can be shown working. It
is a stand-in, to be retrained on station captures. Public photographs are not
what the station sees: other cameras, other light, close-ups of wounds
instead of a fixed view of both soles.

```bash
python -m training.public_pipeline --config training/configs/public_v1.yaml
```

Put each dataset in its own folder under `data/public_raw/` and describe it
under `sources:` in the config first (`BLOCKERS.md` B14 has the steps). The
command then:

1. **Maps labels** using the exact table you gave for each dataset. A label
   that is not in the table is rejected and listed, never guessed. Wagner
   grades 3 to 5, "normal" or "healthy", ungraded "ulcer", and any other
   grading system are rejected (`DECISIONS.md` D49).
2. **Removes byte-identical files**, keeping one, and lists what it removed.
3. **Groups the images** so that pictures of the same foot stay on one side of
   every split. It uses the dataset's own subject ids where it documents them.
   Where it does not, it links near-duplicate pictures (perceptual hash) and
   visually similar ones (network features) and treats each connected set as
   one "patient". It never gives each image its own id.
4. **Sets aside whole groups** (64 or more images) for Hailo quantisation.
5. **Writes** `training/manifests/public_v1.csv`, the hold-out manifest, and a
   report folder with `intake_report.md`, `data_quality.md`, `rejected.csv`,
   `duplicates_removed.csv` and `groups.csv`.

> **Limitation, to be stated wherever results from this model are reported:**
> grouping is a proxy, true patient separation cannot be guaranteed on this
> public data. Two different-looking photographs of one patient can fall in
> different groups, so cross-validation figures on public data may be
> optimistic. Only a dataset with real patient ids removes this.

Read `intake_report.md` before training. It prints the label map with who
confirmed it, the counts per label, the group sizes and how similar the images
are to each other. It warns if one group has swallowed a large share of the
images (thresholds too loose) or if nothing was linked at all (too strict). In
either case look at `groups.csv` and adjust `grouping:` in the config.

Nothing is rebalanced. If a target label has no images, the report says so and
the model simply has fewer classes.

Then train and export as below, with
`--manifest training/manifests/public_v1.csv --image-root data/public_raw`.

## 2. Train

```bash
pip install -r requirements.txt -r training/requirements.txt
python -m training.train --manifest manifest.csv --image-root images/ --out runs/run1 --final
```

Outputs in `runs/run1/`:

- `data_quality.md` — read this first.
- `cv_report.md`, `cv_report.json` — per-fold accuracy, per-class recall and
  confusion matrix, with the number of patients behind each fold.
- `final_model.pt` and `label_map.json` (with `--final`) — a model trained on
  all data, for export. `label_map.json` maps the neutral class names
  (`class_0`, ...) back to the manifest labels. It stays off the station.

Useful options: `--folds`, `--epochs`, `--seed`, `--no-class-weighting`,
`--no-augment`, `--train-backbone`, `--no-pretrained`.

No accuracy target is built in. Accuracy belongs to the dataset.

## 3. Export

```bash
python -m training.export --run runs/run1 --out models/
```

Writes `models/dfu_mobilenetv2.onnx` and `models/model_meta.json`. The export
is kept only if ONNX Runtime and PyTorch agree to within 1e-4 on random
inputs. To try it on a laptop, set `inference.backend: onnx` and
`inference.model_path: models/dfu_mobilenetv2.onnx`.

The class names written for the station are `class_0`, `class_1`, ... The
station refuses any model whose labels read like a clinical grade.

## 4. Compile for the Hailo-8L

Needs an x86 Linux machine with the Hailo Dataflow Compiler from the Hailo
Developer Zone (`hailo_sdk_client`).

```bash
python -m training.hailo_compile \
    --onnx models/dfu_mobilenetv2.onnx \
    --metadata models/model_meta.json \
    --calibration-images path/to/station/captures \
    --out models/dfu_mobilenetv2.hef
```

- The calibration set must be at least 64 **colour frames from this station**
  (`color_registered.png` files), not images from elsewhere. Quantisation is
  tuned to them.
- **Interim only:** before any station frames exist, the public hold-out can
  be used instead, with `--calibration-manifest
  training/manifests/public_v1_calibration.csv --image-root data/public_raw`
  in place of `--calibration-images`. The script writes a `.build.json` file
  beside the `.hef` recording that it was quantised on public images.
  Recompile with station frames before the model is relied on.
- The compiler needs an x86-64 Linux machine with at least 16 GB of RAM.
  `BLOCKERS.md` B15 has the installation steps.
- The script builds the training normalisation into the `.hef`, so the station
  feeds it plain RGB bytes.
- After copying the `.hef` to the station, confirm the device with
  `hailortcli fw-control identify` and run
  `pytest -m hardware tests/test_inference.py`.
