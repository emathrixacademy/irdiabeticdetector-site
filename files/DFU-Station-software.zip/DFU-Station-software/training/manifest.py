"""Dataset manifest: one CSV row per image.

Columns: patient_id, image_path, label, source, capture_session

`patient_id` is the anonymised reference code. It is what every split is
grouped by, so a row without it cannot be used and the whole manifest is
rejected. `label` is the label assigned by the clinician; this code only
carries it.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

COLUMNS: tuple[str, ...] = ("patient_id", "image_path", "label", "source", "capture_session")
REQUIRED_VALUES: tuple[str, ...] = ("patient_id", "image_path", "label")
MAX_ERRORS_SHOWN = 20


class ManifestError(Exception):
    """The manifest cannot be used as it stands."""


@dataclass(frozen=True)
class ManifestRow:
    patient_id: str
    image_path: str
    label: str
    source: str
    capture_session: str
    line_number: int


def load_manifest(path: Path) -> list[ManifestRow]:
    """Read and validate the manifest. Raises ManifestError listing every bad row.

    Nothing is dropped or repaired. A manifest with any row missing
    `patient_id`, `image_path` or `label` is rejected as a whole, so a patient
    can never slip into a split ungrouped.
    """
    try:
        handle = path.open(newline="", encoding="utf-8-sig")
    except OSError as exc:
        raise ManifestError(f"cannot read manifest {path}: {exc}") from exc
    with handle:
        reader = csv.DictReader(handle)
        header = tuple(reader.fieldnames or ())
        if set(header) != set(COLUMNS) or len(header) != len(COLUMNS):
            raise ManifestError(
                f"manifest columns must be exactly {list(COLUMNS)}, found {list(header)}"
            )
        rows: list[ManifestRow] = []
        problems: list[str] = []
        for line_number, record in enumerate(reader, start=2):
            values = {column: (record.get(column) or "").strip() for column in COLUMNS}
            missing = [column for column in REQUIRED_VALUES if not values[column]]
            if missing:
                problems.append(f"line {line_number}: missing {', '.join(missing)}")
                continue
            rows.append(ManifestRow(line_number=line_number, **values))
    if problems:
        shown = "; ".join(problems[:MAX_ERRORS_SHOWN])
        more = len(problems) - MAX_ERRORS_SHOWN
        suffix = f"; and {more} more" if more > 0 else ""
        raise ManifestError(
            f"{len(problems)} manifest row(s) cannot be used: {shown}{suffix}. "
            "Fix the manifest; rows are never dropped automatically."
        )
    if not rows:
        raise ManifestError("the manifest has no rows")
    return rows
