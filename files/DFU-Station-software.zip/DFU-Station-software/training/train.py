"""MobileNetV2 transfer learning with patient-level cross-validation.

    python -m training.train --manifest manifest.csv --image-root images/ --out runs/run1

Runs off the Pi. Writes a data-quality report, per-fold metrics and, with
`--final`, a model trained on all data ready for `training.export`.

No accuracy target is asserted anywhere. Accuracy belongs to the dataset. The
report states the patient counts behind every number.
"""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

from src.inference.metadata import ModelMetadata
from src.inference.preprocess import normalise, to_model_input_rgb
from training.manifest import ManifestRow, load_manifest
from training.quality import build_quality_report
from training.splits import Fold, assert_patient_disjoint, patient_level_folds

IMAGENET_MEAN_RGB = (0.485, 0.456, 0.406)
IMAGENET_STD_RGB = (0.229, 0.224, 0.225)
INPUT_SIZE_PX = 224

BRIGHTNESS_JITTER = 0.10
CONTRAST_JITTER = 0.10


@dataclass(frozen=True)
class TrainSettings:
    epochs: int = 20
    batch_size: int = 16
    learning_rate: float = 1e-3
    fold_count: int = 5
    seed: int = 2026
    class_weighting: bool = True
    pretrained: bool = True
    augment: bool = True
    freeze_backbone: bool = True


def set_seeds(seed: int) -> None:
    """Make a run repeatable on the same machine and library versions."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(True, warn_only=True)


def class_names(rows: list[ManifestRow]) -> tuple[str, ...]:
    """The distinct manifest labels, sorted. Their order defines class indices."""
    return tuple(sorted({row.label for row in rows}))


def make_metadata(class_count: int, model_id: str) -> ModelMetadata:
    """Metadata the station will load. Classes get neutral names, never grades."""
    return ModelMetadata(
        model_id=model_id,
        labels=tuple(f"class_{index}" for index in range(class_count)),
        input_width_px=INPUT_SIZE_PX,
        input_height_px=INPUT_SIZE_PX,
        mean_rgb=IMAGENET_MEAN_RGB,
        std_rgb=IMAGENET_STD_RGB,
        scores_are_logits=True,
    )


def augment_rgb(image_rgb: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Light augmentation on the uint8 model-input image."""
    image = image_rgb
    if rng.random() < 0.5:
        image = image[:, ::-1]
    contrast = 1.0 + rng.uniform(-CONTRAST_JITTER, CONTRAST_JITTER)
    brightness = rng.uniform(-BRIGHTNESS_JITTER, BRIGHTNESS_JITTER) * 255.0
    adjusted = image.astype(np.float32) * contrast + brightness
    return np.ascontiguousarray(np.clip(adjusted, 0, 255).astype(np.uint8))


class ManifestDataset(Dataset[tuple[torch.Tensor, int]]):
    """Images from the manifest, preprocessed exactly as on the station."""

    def __init__(
        self,
        rows: list[ManifestRow],
        indices: tuple[int, ...],
        image_root: Path,
        names: tuple[str, ...],
        metadata: ModelMetadata,
        *,
        augment: bool,
        seed: int,
    ) -> None:
        self._rows = [rows[index] for index in indices]
        self._image_root = image_root
        self._class_of = {name: index for index, name in enumerate(names)}
        self._metadata = metadata
        self._augment = augment
        self._rng = np.random.default_rng(seed)

    def __len__(self) -> int:
        return len(self._rows)

    def __getitem__(self, index: int) -> tuple[torch.Tensor, int]:
        row = self._rows[index]
        path = self._image_root / row.image_path
        data = np.fromfile(path, dtype=np.uint8) if path.is_file() else None
        image_bgr = cv2.imdecode(data, cv2.IMREAD_COLOR) if data is not None else None
        if image_bgr is None:
            raise FileNotFoundError(f"cannot read image for manifest line {row.line_number}")
        image_rgb = to_model_input_rgb(image_bgr, self._metadata)
        if self._augment:
            image_rgb = augment_rgb(image_rgb, self._rng)
        tensor = torch.from_numpy(normalise(image_rgb, self._metadata)[0])
        return tensor, self._class_of[row.label]


def build_model(class_count: int, *, pretrained: bool, freeze_backbone: bool) -> nn.Module:
    """MobileNetV2 with a new final layer for this dataset's classes."""
    from torchvision.models import MobileNet_V2_Weights, mobilenet_v2

    weights = MobileNet_V2_Weights.IMAGENET1K_V1 if pretrained else None
    model = mobilenet_v2(weights=weights)
    if freeze_backbone:
        for parameter in model.features.parameters():
            parameter.requires_grad = False
    in_features = model.classifier[1].in_features
    model.classifier[1] = nn.Linear(in_features, class_count)
    return model


def class_weights(
    rows: list[ManifestRow], indices: tuple[int, ...], names: tuple[str, ...]
) -> torch.Tensor:
    """Inverse-frequency loss weights from the training side of a fold only."""
    counts = np.array(
        [sum(1 for index in indices if rows[index].label == name) for name in names],
        dtype=np.float64,
    )
    weights = np.where(counts > 0, counts.sum() / (len(names) * np.maximum(counts, 1)), 0.0)
    return torch.tensor(weights, dtype=torch.float32)


def fit(
    model: nn.Module,
    loader: DataLoader[tuple[torch.Tensor, int]],
    settings: TrainSettings,
    weights: torch.Tensor | None,
) -> list[float]:
    """Train in place. Returns the mean loss of each epoch."""
    criterion = nn.CrossEntropyLoss(weight=weights)
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimiser = torch.optim.Adam(trainable, lr=settings.learning_rate)
    history: list[float] = []
    model.train()
    for _ in range(settings.epochs):
        total, batches = 0.0, 0
        for images, targets in loader:
            optimiser.zero_grad()
            loss = criterion(model(images), targets)
            loss.backward()
            optimiser.step()
            total += float(loss.item())
            batches += 1
        history.append(total / max(batches, 1))
    return history


def evaluate(
    model: nn.Module, loader: DataLoader[tuple[torch.Tensor, int]], class_count: int
) -> np.ndarray:
    """Confusion matrix: rows are true classes, columns are predicted classes."""
    confusion = np.zeros((class_count, class_count), dtype=np.int64)
    model.eval()
    with torch.no_grad():
        for images, targets in loader:
            predictions = model(images).argmax(dim=1)
            for target, prediction in zip(targets.tolist(), predictions.tolist(), strict=True):
                confusion[target, prediction] += 1
    return confusion


def _loader(
    dataset: ManifestDataset, settings: TrainSettings, *, shuffle: bool, seed: int
) -> DataLoader[tuple[torch.Tensor, int]]:
    generator = torch.Generator()
    generator.manual_seed(seed)
    # This shuffles the order of batches inside one side of a fold. Which
    # images are in training and which in testing was fixed by patient above.
    return DataLoader(
        dataset,
        batch_size=settings.batch_size,
        shuffle=shuffle,
        num_workers=0,
        generator=generator,
    )


def fold_metrics(
    confusion: np.ndarray, fold: Fold, names: tuple[str, ...], history: list[float]
) -> dict[str, Any]:
    total = int(confusion.sum())
    correct = int(np.trace(confusion))
    recall: dict[str, float | None] = {}
    for index, name in enumerate(names):
        support = int(confusion[index].sum())
        recall[name] = float(confusion[index, index] / support) if support else None
    return {
        "fold": fold.index,
        "train_patients": len(fold.train_patients),
        "test_patients": len(fold.test_patients),
        "train_images": len(fold.train_indices),
        "test_images": total,
        "accuracy": correct / total if total else None,
        "recall_per_class": recall,
        "confusion_matrix": confusion.tolist(),
        "confusion_matrix_axes": "rows = true label, columns = predicted",
        "labels": list(names),
        "loss_per_epoch": history,
    }


def run_cross_validation(
    rows: list[ManifestRow], image_root: Path, settings: TrainSettings
) -> dict[str, Any]:
    """Patient-level k-fold. Returns the report as plain data."""
    names = class_names(rows)
    metadata = make_metadata(len(names), "cross-validation")
    plan = patient_level_folds(rows, settings.fold_count, settings.seed)
    results: list[dict[str, Any]] = []
    for fold in plan.folds:
        # Checked again here, at the point of use, so no later change to the
        # split code can leak a patient across the split unnoticed.
        assert_patient_disjoint(rows, fold.train_indices, fold.test_indices)
        set_seeds(settings.seed + fold.index)
        train_set = ManifestDataset(
            rows,
            fold.train_indices,
            image_root,
            names,
            metadata,
            augment=settings.augment,
            seed=settings.seed + fold.index,
        )
        test_set = ManifestDataset(
            rows, fold.test_indices, image_root, names, metadata, augment=False, seed=0
        )
        model = build_model(
            len(names), pretrained=settings.pretrained, freeze_backbone=settings.freeze_backbone
        )
        weights = (
            class_weights(rows, fold.train_indices, names) if settings.class_weighting else None
        )
        history = fit(
            model,
            _loader(train_set, settings, shuffle=True, seed=settings.seed + fold.index),
            settings,
            weights,
        )
        confusion = evaluate(model, _loader(test_set, settings, shuffle=False, seed=0), len(names))
        results.append(fold_metrics(confusion, fold, names, history))
    return {
        "settings": asdict(settings),
        "split": "grouped k-fold by patient_id; no patient is in both sides of any fold",
        "patient_count": len({row.patient_id for row in rows}),
        "image_count": len(rows),
        "labels": list(names),
        "split_warnings": list(plan.warnings),
        "folds": results,
    }


def train_final_model(
    rows: list[ManifestRow], image_root: Path, settings: TrainSettings
) -> tuple[nn.Module, tuple[str, ...]]:
    """Train on every image, for export. Cross-validation gives the metrics."""
    names = class_names(rows)
    metadata = make_metadata(len(names), "final")
    set_seeds(settings.seed)
    indices = tuple(range(len(rows)))
    dataset = ManifestDataset(
        rows, indices, image_root, names, metadata, augment=settings.augment, seed=settings.seed
    )
    model = build_model(
        len(names), pretrained=settings.pretrained, freeze_backbone=settings.freeze_backbone
    )
    weights = class_weights(rows, indices, names) if settings.class_weighting else None
    fit(model, _loader(dataset, settings, shuffle=True, seed=settings.seed), settings, weights)
    return model, names


def report_markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Cross-validation report",
        "",
        f"- Split: {report['split']}",
        f"- Patients: **{report['patient_count']}**, images: {report['image_count']}",
        f"- Labels: {', '.join(report['labels'])}",
        "",
        "These figures describe this dataset only. With few patients per class they",
        "can move a great deal from fold to fold; read them with the patient counts.",
        "",
        "| Fold | Train patients | Test patients | Test images | Accuracy |",
        "|---|---|---|---|---|",
    ]
    for fold in report["folds"]:
        accuracy = "n/a" if fold["accuracy"] is None else f"{fold['accuracy']:.3f}"
        lines.append(
            f"| {fold['fold']} | {fold['train_patients']} | {fold['test_patients']} "
            f"| {fold['test_images']} | {accuracy} |"
        )
    if report["split_warnings"]:
        lines += ["", "## Split warnings", ""]
        lines += [f"- {warning}" for warning in report["split_warnings"]]
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Train the colour classifier (off-device)")
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=TrainSettings.epochs)
    parser.add_argument("--batch-size", type=int, default=TrainSettings.batch_size)
    parser.add_argument("--learning-rate", type=float, default=TrainSettings.learning_rate)
    parser.add_argument("--folds", type=int, default=TrainSettings.fold_count)
    parser.add_argument("--seed", type=int, default=TrainSettings.seed)
    parser.add_argument("--no-class-weighting", action="store_true")
    parser.add_argument("--no-pretrained", action="store_true")
    parser.add_argument("--no-augment", action="store_true")
    parser.add_argument("--train-backbone", action="store_true")
    parser.add_argument("--final", action="store_true", help="also train on all data and save it")
    args = parser.parse_args(argv)

    settings = TrainSettings(
        epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        fold_count=args.folds,
        seed=args.seed,
        class_weighting=not args.no_class_weighting,
        pretrained=not args.no_pretrained,
        augment=not args.no_augment,
        freeze_backbone=not args.train_backbone,
    )
    rows = load_manifest(args.manifest)
    args.out.mkdir(parents=True, exist_ok=True)
    quality = build_quality_report(rows, args.image_root)
    (args.out / "data_quality.md").write_text(quality.to_markdown(), encoding="utf-8")
    print(quality.to_markdown())

    report = run_cross_validation(rows, args.image_root, settings)
    (args.out / "cv_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (args.out / "cv_report.md").write_text(report_markdown(report), encoding="utf-8")
    print(report_markdown(report))

    if args.final:
        model, names = train_final_model(rows, args.image_root, settings)
        torch.save(model.state_dict(), args.out / "final_model.pt")
        label_map = {f"class_{index}": name for index, name in enumerate(names)}
        (args.out / "label_map.json").write_text(json.dumps(label_map, indent=2), encoding="utf-8")
        print(f"final model saved to {args.out / 'final_model.pt'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
