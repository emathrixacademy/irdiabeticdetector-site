"""Public-data intake: labelled images -> proxy groups -> manifest and reports.

    python -m training.public_pipeline --config training/configs/public_v1.yaml

Writes the training manifest, a separate manifest of whole groups held out for
Hailo quantisation, and a report folder: what was accepted, what was rejected
and why, which duplicates were removed, and how images were grouped.

Nothing is rebalanced and nothing is guessed. Training and export are then run
with `training.train` and `training.export` (see training/README.md).
"""

from __future__ import annotations

import argparse
import csv
import random
import statistics
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path

from training.grouping import Embedder, GroupingError, GroupingResult, group_images
from training.intake import (
    ImageRecord,
    IntakeConfig,
    IntakeError,
    IntakeResult,
    load_intake_config,
    run_intake,
)
from training.manifest import COLUMNS, ManifestRow
from training.quality import build_quality_report

# The quantisation hold-out may take at most this share of the images.
MAX_HOLDOUT_FRACTION = 0.2
# One group holding more than this share of the images means the grouping
# thresholds have chained unrelated images together.
COLLAPSE_WARNING_SHARE = 0.2

GROUPING_LIMITATION = (
    "Grouping is a proxy, true patient separation cannot be guaranteed on this public data. "
    "Images were grouped by documented subject ids where the dataset gives them, and "
    "otherwise by near-duplicate and visual similarity. Two different-looking photographs "
    "of one patient can still be in different groups, so cross-validation figures on this "
    "data may be optimistic."
)


@dataclass(frozen=True)
class PipelineOutput:
    intake: IntakeResult
    grouping: GroupingResult
    training_records: tuple[ImageRecord, ...]
    holdout_records: tuple[ImageRecord, ...]
    holdout_note: str
    report_markdown: str


def choose_holdout(
    records: list[ImageRecord], group_of: dict[str, str], min_images: int, seed: int
) -> tuple[set[str], str]:
    """Whole groups to keep out of training for quantisation, spread over the labels."""
    if len(records) * MAX_HOLDOUT_FRACTION < min_images:
        return set(), (
            f"No quantisation hold-out was reserved: {min_images} images would be more than "
            f"{MAX_HOLDOUT_FRACTION:.0%} of the {len(records)} accepted images."
        )
    members: dict[str, list[ImageRecord]] = defaultdict(list)
    for record in records:
        members[group_of[record.image_path]].append(record)
    by_label: dict[str, list[str]] = defaultdict(list)
    for group in sorted(members):
        labels = Counter(record.label for record in members[group])
        by_label[sorted(labels.items(), key=lambda item: (-item[1], item[0]))[0][0]].append(group)
    rng = random.Random(seed)
    for groups in by_label.values():
        rng.shuffle(groups)
    chosen: set[str] = set()
    total = 0
    limit = len(records) * MAX_HOLDOUT_FRACTION
    while total < min_images and any(by_label.values()):
        for label in sorted(by_label):
            if not by_label[label] or total >= min_images:
                continue
            group = by_label[label].pop()
            if total + len(members[group]) > limit:
                continue  # a very large group; leave it in training
            chosen.add(group)
            total += len(members[group])
    if total < min_images:
        return set(), (
            "No quantisation hold-out was reserved: whole groups could not make up "
            f"{min_images} images within {MAX_HOLDOUT_FRACTION:.0%} of the data."
        )
    return chosen, f"{len(chosen)} whole groups ({total} images) are held out for quantisation."


def _write_csv(path: Path, header: tuple[str, ...], rows: list[tuple[str, ...]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)


def write_manifest(path: Path, records: tuple[ImageRecord, ...], group_of: dict[str, str]) -> None:
    """Manifest rows. `patient_id` is the group id; `capture_session` is unknown."""
    _write_csv(
        path,
        COLUMNS,
        [(group_of[r.image_path], r.image_path, r.label, r.source, "") for r in records],
    )


def _grouping_checks(grouping: GroupingResult, sizes: list[int], image_count: int) -> list[str]:
    """Lines that let a person judge whether the thresholds suit this dataset."""
    lines: list[str] = []
    if grouping.nearest_cosine_quantiles:
        low, middle, high = grouping.nearest_cosine_quantiles
        lines.append(
            "- Similarity of each image to its most similar other image: "
            f"10th percentile {low:.2f}, median {middle:.2f}, 90th percentile {high:.2f}"
        )
    largest_share = max(sizes) / image_count
    if largest_share > COLLAPSE_WARNING_SHARE:
        lines.append(
            f"- **WARNING: one group holds {largest_share:.0%} of all images.** The grouping "
            "thresholds are probably too loose for this dataset and have chained unrelated "
            "images together. Inspect groups.csv and tighten them before training."
        )
    if all(size == 1 for size in sizes) and image_count > 1:
        lines.append(
            "- **WARNING: every group holds a single image.** No two images were linked. On a "
            "public photo set that is unlikely to be true; the thresholds are probably too "
            "strict. Inspect the images before trusting any cross-validation figure."
        )
    return lines


def _count_table(title: str, counts: Counter[str]) -> list[str]:
    lines = [f"| {title} | Images |", "|---|---|"]
    lines += [f"| {key} | {count} |" for key, count in sorted(counts.items())]
    return lines or ["None."]


def build_report(
    config: IntakeConfig,
    intake: IntakeResult,
    grouping: GroupingResult,
    training: tuple[ImageRecord, ...],
    holdout: tuple[ImageRecord, ...],
    holdout_note: str,
) -> str:
    group_of = grouping.group_of
    sizes = Counter(group_of[record.image_path] for record in intake.accepted)
    size_values = list(sizes.values())
    groups_per_label: dict[str, set[str]] = defaultdict(set)
    for record in intake.accepted:
        groups_per_label[record.label].add(group_of[record.image_path])
    documented = sum(1 for record in intake.accepted if record.documented_patient)

    lines = [
        f"# Intake report: {config.version}",
        "",
        "PUBLIC colour photographs, not station captures. Nothing was rebalanced.",
        "",
        "## Sources",
        "",
        "| Source | URL | Licence | Retrieved | Label map confirmed by |",
        "|---|---|---|---|---|",
    ]
    for name in sorted({record.source for record in intake.accepted} | set(config.sources)):
        rule = config.sources[name]
        confirmed = rule.confirmed_by or "**NOT YET CONFIRMED**"
        lines.append(f"| {name} | {rule.url} | {rule.licence} | {rule.retrieved} | {confirmed} |")
    lines += [
        "",
        "## Label mapping used",
        "",
        "| Source | Source label | Target label |",
        "|---|---|---|",
    ]
    for name in sorted(config.sources):
        for source_label, target in sorted(config.sources[name].label_map.items()):
            lines.append(f"| {name} | {source_label} | {target} |")

    lines += [
        "",
        "## Accepted images",
        "",
        f"- Accepted: **{len(intake.accepted)}** images in **{grouping.group_count}** groups",
        f"- Exact duplicates removed: **{len(intake.duplicates)}**",
        f"- Rejected: **{len(intake.rejected)}**",
        "",
        "| Target label | Images | Groups |",
        "|---|---|---|",
    ]
    images_per_label = Counter(record.label for record in intake.accepted)
    for label in config.target_labels:
        group_total = len(groups_per_label.get(label, ()))
        lines.append(f"| {label} | {images_per_label.get(label, 0)} | {group_total} |")
    missing = [label for label in config.target_labels if images_per_label.get(label, 0) == 0]
    if missing:
        lines += ["", f"**No images at all for target label(s) {missing}.**"]

    lines += [
        "",
        "## Grouping (stands in for patient ids)",
        "",
        GROUPING_LIMITATION,
        "",
        f"- Images with a documented subject id: {documented} of {len(intake.accepted)}",
        f"- Links from documented ids: {grouping.documented_links}",
        f"- Links from perceptual hash (difference of at most "
        f"{config.grouping.hash_max_distance} of 64 bits): {grouping.hash_links}",
        f"- Links from embedding similarity (cosine at least "
        f"{config.grouping.embedding_min_cosine}): {grouping.embedding_links}",
        f"- Images per group: min {min(size_values)}, median "
        f"{statistics.median(size_values):g}, max {max(size_values)}",
        f"- Groups holding a single image: {sum(1 for size in size_values if size == 1)}",
        *_grouping_checks(grouping, size_values, len(intake.accepted)),
        "",
        "## Quantisation hold-out",
        "",
        holdout_note,
        f"Training manifest: {len(training)} images. Hold-out manifest: {len(holdout)} images.",
        "",
        "## Rejected, by reason",
        "",
    ]
    reasons = Counter(
        f"{item.source} / {item.source_label or '(none)'} / {item.reason}"
        for item in intake.rejected
    )
    lines += _count_table("Source / source label / reason", reasons) if reasons else ["None."]
    return "\n".join(lines) + "\n"


def run_pipeline(config: IntakeConfig, embedder: Embedder) -> PipelineOutput:
    """Steps 1 to 3: intake, grouping, hold-out, manifests and reports."""
    intake = run_intake(config)
    if not intake.accepted:
        raise IntakeError(
            "no image was accepted: every label was rejected. Check the label_map entries."
        )
    grouping = group_images(
        intake.accepted, config.raw_dir, config.grouping, embedder, config.version
    )
    held_groups, holdout_note = choose_holdout(
        intake.accepted, grouping.group_of, config.holdout_min_images, config.holdout_seed
    )
    training = tuple(
        r for r in intake.accepted if grouping.group_of[r.image_path] not in held_groups
    )
    holdout = tuple(r for r in intake.accepted if grouping.group_of[r.image_path] in held_groups)
    if {grouping.group_of[r.image_path] for r in training} & held_groups:
        raise GroupingError("a held-out group also appears in the training manifest")

    write_manifest(config.manifest_path, training, grouping.group_of)
    write_manifest(config.calibration_manifest_path, holdout, grouping.group_of)
    report_dir = config.report_dir
    _write_csv(
        report_dir / "rejected.csv",
        ("source", "image_path", "source_label", "reason"),
        [(r.source, r.image_path, r.source_label, r.reason) for r in intake.rejected],
    )
    _write_csv(
        report_dir / "duplicates_removed.csv",
        ("removed_path", "kept_path"),
        [(d.removed_path, d.kept_path) for d in intake.duplicates],
    )
    _write_csv(
        report_dir / "groups.csv",
        ("group", "image_path", "label", "source", "documented_subject", "held_out"),
        [
            (
                grouping.group_of[r.image_path],
                r.image_path,
                r.label,
                r.source,
                r.documented_patient,
                "1" if grouping.group_of[r.image_path] in held_groups else "0",
            )
            for r in intake.accepted
        ],
    )
    report = build_report(config, intake, grouping, training, holdout, holdout_note)
    rows = [
        ManifestRow(grouping.group_of[r.image_path], r.image_path, r.label, r.source, "", index)
        for index, r in enumerate(training, start=2)
    ]
    quality = build_quality_report(rows, config.raw_dir).to_markdown()
    quality = quality.replace("Patients", "Groups (proxy for patients)")
    (report_dir / "intake_report.md").write_text(report, encoding="utf-8")
    (report_dir / "data_quality.md").write_text(quality, encoding="utf-8")
    return PipelineOutput(
        intake, grouping, training, holdout, holdout_note, report + "\n" + quality
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Public dataset intake and proxy grouping")
    parser.add_argument("--config", type=Path, default=Path("training/configs/public_v1.yaml"))
    args = parser.parse_args(argv)
    try:
        config = load_intake_config(args.config)
        from training.grouping import mobilenet_embedder

        # Check the folders before loading the network, so an empty folder fails fast.
        from training.intake import check_sources

        check_sources(config)
        output = run_pipeline(config, mobilenet_embedder(config.grouping.embedding_batch_size))
    except (IntakeError, GroupingError) as exc:
        print(f"Intake stopped: {exc}", file=sys.stderr)
        return 1
    print(output.report_markdown)
    print(f"Manifest: {config.manifest_path.as_posix()}")
    print("Next: python -m training.train --manifest", config.manifest_path.as_posix(),
          "--image-root", config.raw_dir.as_posix(), "--out runs/public_v1 --final")  # fmt: skip
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
