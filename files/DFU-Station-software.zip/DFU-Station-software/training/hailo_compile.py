"""Compile the ONNX model to a `.hef` for the Hailo-8L.

    python -m training.hailo_compile --onnx models/dfu_mobilenetv2.onnx \
        --metadata models/model_meta.json --calibration-images captures/ \
        --out models/dfu_mobilenetv2.hef

Runs on an x86 Linux machine with the Hailo Dataflow Compiler installed
(`hailo_sdk_client`). It never runs on the Pi.

Steps: parse the ONNX, add input normalisation from the same mean and
standard deviation the training code used, optimise (quantise) with a
calibration set of real colour frames from this station, and compile for
`hailo8l`.

Until station captures exist, `--calibration-manifest` with `--image-root`
quantises with held-out public images instead. That is an interim measure and
is recorded as such in `<name>.build.json` beside the `.hef`.

NOT YET RUN: the Dataflow Compiler was not installed on the build machine.
See BLOCKERS.md (B10).
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from src.inference.metadata import ModelMetadata, load_model_metadata
from src.inference.preprocess import PIXEL_MAX, to_model_input_rgb
from training.manifest import ManifestError, load_manifest

HAILO_ARCHITECTURE = "hailo8l"
NETWORK_NAME = "dfu_mobilenetv2"
# Hailo recommends at least this many calibration images for quantisation.
MIN_CALIBRATION_IMAGES = 64
IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg")

CALIBRATION_STATION = "station_captures"
CALIBRATION_PUBLIC_HOLDOUT = "public_holdout"
CALIBRATION_NOTES = {
    CALIBRATION_STATION: "Quantised with colour frames captured by this station.",
    CALIBRATION_PUBLIC_HOLDOUT: (
        "INTERIM: quantised with held-out PUBLIC images because no station captures existed. "
        "Public photos do not match what the station's camera sees. Recompile with at least "
        f"{MIN_CALIBRATION_IMAGES} station frames before the model is relied on."
    ),
}


class CompileError(Exception):
    """The model could not be compiled."""


def normalisation_script(metadata: ModelMetadata) -> str:
    """Model-script line that builds the training normalisation into the `.hef`.

    The station feeds the Hailo runner RGB uint8 in 0..255, so the mean and
    standard deviation are scaled to that range.
    """
    mean = [round(value * PIXEL_MAX, 4) for value in metadata.mean_rgb]
    std = [round(value * PIXEL_MAX, 4) for value in metadata.std_rgb]
    return f"normalization1 = normalization({mean}, {std})\n"


def find_calibration_images(folder: Path) -> list[Path]:
    """Every image under the folder, in a stable order."""
    return sorted(path for path in folder.rglob("*") if path.suffix.lower() in IMAGE_SUFFIXES)


def build_calibration_set(image_paths: list[Path], metadata: ModelMetadata) -> np.ndarray:
    """N x H x W x 3 uint8 RGB, preprocessed exactly as on the station.

    The images must be colour frames captured by this station (the registered
    colour crops), not images from elsewhere: quantisation is tuned to them.
    """
    if len(image_paths) < MIN_CALIBRATION_IMAGES:
        raise CompileError(
            f"{len(image_paths)} calibration image(s) found; at least "
            f"{MIN_CALIBRATION_IMAGES} station captures are needed for quantisation"
        )
    frames = []
    for path in image_paths:
        image_bgr = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
        if image_bgr is None:
            raise CompileError(f"cannot read calibration image {path.name}")
        frames.append(to_model_input_rgb(image_bgr, metadata))
    return np.stack(frames).astype(np.uint8)


def compile_hef(onnx_path: Path, metadata: ModelMetadata, calibration: np.ndarray) -> bytes:
    """Parse, optimise and compile. Needs the Hailo Dataflow Compiler."""
    try:
        from hailo_sdk_client import ClientRunner
    except ImportError as exc:
        raise CompileError(
            "hailo_sdk_client is not installed. Install the Hailo Dataflow Compiler on an "
            "x86 Linux machine (Hailo Developer Zone) and run this script there."
        ) from exc
    runner: Any = ClientRunner(hw_arch=HAILO_ARCHITECTURE)
    runner.translate_onnx_model(
        str(onnx_path),
        NETWORK_NAME,
        net_input_shapes={"input": [1, 3, metadata.input_height_px, metadata.input_width_px]},
    )
    runner.load_model_script(normalisation_script(metadata))
    runner.optimize(calibration)
    return bytes(runner.compile())


def calibration_images_from_manifest(manifest: Path, image_root: Path) -> list[Path]:
    """Images listed in a hold-out manifest written by `training.public_pipeline`."""
    try:
        rows = load_manifest(manifest)
    except ManifestError as exc:
        raise CompileError(f"calibration manifest: {exc}") from exc
    return [image_root / row.image_path for row in rows]


def compiler_version() -> str:
    try:
        import hailo_sdk_client
    except ImportError:
        return "not installed"
    return str(getattr(hailo_sdk_client, "__version__", "unknown"))


def build_record(
    onnx_path: Path, kind: str, image_count: int, compiler: str
) -> dict[str, str | int]:
    """What a `.hef` was built from. Written beside it as `<name>.build.json`."""
    return {
        "onnx": onnx_path.name,
        "architecture": HAILO_ARCHITECTURE,
        "dataflow_compiler_version": compiler,
        "calibration_kind": kind,
        "calibration_images": image_count,
        "calibration_note": CALIBRATION_NOTES[kind],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Compile the classifier for the Hailo-8L")
    parser.add_argument("--onnx", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument(
        "--calibration-images", type=Path, help="folder of colour frames captured by this station"
    )
    source.add_argument(
        "--calibration-manifest",
        type=Path,
        help="hold-out manifest of public images (interim only; recompile with station frames)",
    )
    parser.add_argument("--image-root", type=Path, help="needed with --calibration-manifest")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        if args.out.suffix != ".hef":
            raise CompileError("the output file must end in .hef")
        metadata = load_model_metadata(args.metadata)
        if args.calibration_manifest is not None:
            if args.image_root is None:
                raise CompileError("--calibration-manifest needs --image-root")
            kind = CALIBRATION_PUBLIC_HOLDOUT
            images = calibration_images_from_manifest(args.calibration_manifest, args.image_root)
        else:
            kind = CALIBRATION_STATION
            images = find_calibration_images(args.calibration_images)
        calibration = build_calibration_set(images, metadata)
        hef = compile_hef(args.onnx, metadata, calibration)
    except Exception as exc:
        print(f"Compile failed: {exc}")
        return 1
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_bytes(hef)
    record = build_record(args.onnx, kind, len(images), compiler_version())
    args.out.with_suffix(".build.json").write_text(
        json.dumps(record, indent=2) + "\n", encoding="utf-8"
    )
    print(f"wrote {args.out} for {HAILO_ARCHITECTURE} from {len(images)} calibration images")
    print(record["calibration_note"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
