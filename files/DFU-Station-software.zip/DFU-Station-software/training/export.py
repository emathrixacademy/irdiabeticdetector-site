"""Export the trained model to ONNX and check it against PyTorch.

    python -m training.export --run runs/run1 --out models/

Writes `dfu_mobilenetv2.onnx` with a fixed 1 x 3 x 224 x 224 input (the shape
the shared preprocessing produces) and `model_meta.json` for the station.
The export is accepted only if ONNX Runtime and PyTorch agree on random
inputs.
"""

from __future__ import annotations

import argparse
import dataclasses
import json
from pathlib import Path

import numpy as np
import torch
from torch import nn

from src.inference.metadata import ModelMetadata, parse_model_metadata
from training.train import build_model, make_metadata

ONNX_NAME = "dfu_mobilenetv2.onnx"
METADATA_NAME = "model_meta.json"
ONNX_OPSET = 13
PARITY_TOLERANCE = 1e-4
PARITY_SAMPLES = 4


class ExportError(Exception):
    """The export failed or does not match the PyTorch model."""


def export_onnx(model: nn.Module, metadata: ModelMetadata, path: Path) -> None:
    """Write the model with a fixed input shape and no dynamic axes."""
    model.eval()
    example = torch.zeros(1, 3, metadata.input_height_px, metadata.input_width_px)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.onnx.export(
        model,
        (example,),
        str(path),
        input_names=["input"],
        output_names=["logits"],
        opset_version=ONNX_OPSET,
        dynamo=False,
    )


def parity_error(model: nn.Module, onnx_path: Path, metadata: ModelMetadata, seed: int) -> float:
    """Largest absolute difference between PyTorch and ONNX Runtime outputs."""
    import onnxruntime

    session = onnxruntime.InferenceSession(str(onnx_path), providers=["CPUExecutionProvider"])
    input_info = session.get_inputs()[0]
    expected = [1, 3, metadata.input_height_px, metadata.input_width_px]
    if list(input_info.shape) != expected:
        raise ExportError(f"exported input shape is {input_info.shape}, expected {expected}")
    rng = np.random.default_rng(seed)
    model.eval()
    worst = 0.0
    for _ in range(PARITY_SAMPLES):
        sample = rng.normal(0.0, 1.0, expected).astype(np.float32)
        with torch.no_grad():
            reference = model(torch.from_numpy(sample)).numpy()
        exported = session.run(None, {input_info.name: sample})[0]
        worst = max(worst, float(np.max(np.abs(reference - exported))))
    return worst


def write_metadata(metadata: ModelMetadata, path: Path) -> None:
    data = dataclasses.asdict(metadata)
    data["labels"] = list(metadata.labels)
    data["mean_rgb"] = list(metadata.mean_rgb)
    data["std_rgb"] = list(metadata.std_rgb)
    # Round-trip through the station's own parser so a bad file is never written.
    parse_model_metadata(data)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def export_and_check(model: nn.Module, class_count: int, out_dir: Path, seed: int) -> float:
    """Export, verify parity and write the metadata. Returns the parity error."""
    metadata = make_metadata(class_count, ONNX_NAME)
    onnx_path = out_dir / ONNX_NAME
    export_onnx(model, metadata, onnx_path)
    error = parity_error(model, onnx_path, metadata, seed)
    if error > PARITY_TOLERANCE:
        onnx_path.unlink(missing_ok=True)
        raise ExportError(
            f"ONNX Runtime differs from PyTorch by {error:.2e}, above {PARITY_TOLERANCE:.0e}. "
            "The export was deleted."
        )
    write_metadata(metadata, out_dir / METADATA_NAME)
    return error


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Export the trained classifier to ONNX")
    parser.add_argument("--run", type=Path, required=True, help="folder from training.train")
    parser.add_argument("--out", type=Path, default=Path("models"))
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args(argv)

    label_map = json.loads((args.run / "label_map.json").read_text(encoding="utf-8"))
    model = build_model(len(label_map), pretrained=False, freeze_backbone=False)
    model.load_state_dict(torch.load(args.run / "final_model.pt", map_location="cpu"))
    error = export_and_check(model, len(label_map), args.out, args.seed)
    print(f"exported {args.out / ONNX_NAME}; PyTorch vs ONNX Runtime max difference {error:.2e}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
