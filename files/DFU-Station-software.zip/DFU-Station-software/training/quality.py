"""Data-quality report for a dataset manifest.

Read-only. It counts and warns; it never imputes, drops, rebalances or
corrects anything. A model trained on four patients of one class is a real
result that has to be stated, and this report is where it is stated.
"""

from __future__ import annotations

import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from training.manifest import ManifestRow

# A class with fewer patients than this gets a warning.
FEW_PATIENTS_WARNING = 5
# Largest class has this many times the patients of the smallest: warn.
IMBALANCE_RATIO_WARNING = 3.0


@dataclass(frozen=True)
class ClassCount:
    label: str
    images: int
    patients: int


@dataclass(frozen=True)
class QualityReport:
    image_count: int
    patient_count: int
    classes: tuple[ClassCount, ...]
    images_per_patient: dict[str, int]
    images_per_patient_min: int
    images_per_patient_median: float
    images_per_patient_max: int
    missing_source_lines: tuple[int, ...]
    missing_capture_session_lines: tuple[int, ...]
    missing_image_lines: tuple[int, ...]
    duplicate_image_paths: tuple[str, ...]
    patients_with_several_labels: dict[str, tuple[str, ...]]
    warnings: tuple[str, ...] = field(default=())

    def to_markdown(self) -> str:
        lines = [
            "# Data-quality report",
            "",
            "This report describes the dataset as supplied. Nothing was dropped,",
            "imputed, rebalanced or corrected.",
            "",
            f"- Images: **{self.image_count}**",
            f"- Patients: **{self.patient_count}** (this is the real sample size)",
            f"- Images per patient: min {self.images_per_patient_min}, "
            f"median {self.images_per_patient_median:g}, max {self.images_per_patient_max}",
            "",
            "## Per class",
            "",
            "| Label | Images | Patients |",
            "|---|---|---|",
        ]
        lines += [f"| {c.label} | {c.images} | {c.patients} |" for c in self.classes]
        lines += [
            "",
            "## Missing metadata",
            "",
            f"- Rows with no `source`: {len(self.missing_source_lines)}"
            f"{_line_list(self.missing_source_lines)}",
            f"- Rows with no `capture_session`: {len(self.missing_capture_session_lines)}"
            f"{_line_list(self.missing_capture_session_lines)}",
            f"- Rows whose image file was not found: {len(self.missing_image_lines)}"
            f"{_line_list(self.missing_image_lines)}",
            f"- Image paths listed more than once: {len(self.duplicate_image_paths)}",
            f"- Patients with more than one label: {len(self.patients_with_several_labels)}",
            "",
            "## Warnings",
            "",
        ]
        lines += [f"- {warning}" for warning in self.warnings] or ["- None."]
        return "\n".join(lines) + "\n"


def _line_list(lines: tuple[int, ...]) -> str:
    if not lines:
        return ""
    shown = ", ".join(str(line) for line in lines[:15])
    return f" (manifest lines {shown}{', ...' if len(lines) > 15 else ''})"


def build_quality_report(rows: list[ManifestRow], image_root: Path | None = None) -> QualityReport:
    """Summarise the dataset. Pass `image_root` to also check the files exist."""
    images_per_class: Counter[str] = Counter(row.label for row in rows)
    patients_per_class: dict[str, set[str]] = defaultdict(set)
    labels_per_patient: dict[str, set[str]] = defaultdict(set)
    images_per_patient: Counter[str] = Counter()
    for row in rows:
        patients_per_class[row.label].add(row.patient_id)
        labels_per_patient[row.patient_id].add(row.label)
        images_per_patient[row.patient_id] += 1

    classes = tuple(
        ClassCount(label, images_per_class[label], len(patients_per_class[label]))
        for label in sorted(images_per_class)
    )
    path_counts = Counter(row.image_path for row in rows)
    duplicates = tuple(sorted(path for path, count in path_counts.items() if count > 1))
    several_labels = {
        patient: tuple(sorted(labels))
        for patient, labels in sorted(labels_per_patient.items())
        if len(labels) > 1
    }
    missing_images: tuple[int, ...] = ()
    if image_root is not None:
        missing_images = tuple(
            row.line_number for row in rows if not (image_root / row.image_path).is_file()
        )

    warnings: list[str] = []
    for item in classes:
        if item.patients < FEW_PATIENTS_WARNING:
            warnings.append(
                f"Class {item.label!r} has only {item.patients} patient(s) "
                f"({item.images} images). Results for this class rest on very few people."
            )
    patient_counts = [item.patients for item in classes]
    if len(classes) < 2:
        warnings.append("Only one class is present; a classifier cannot be trained.")
    elif min(patient_counts) > 0 and max(patient_counts) / min(patient_counts) >= (
        IMBALANCE_RATIO_WARNING
    ):
        warnings.append(
            f"Class imbalance: the largest class has {max(patient_counts)} patients and the "
            f"smallest has {min(patient_counts)}. This was not rebalanced."
        )
    if several_labels:
        warnings.append(
            f"{len(several_labels)} patient(s) carry more than one label. Each patient is "
            "still kept on one side of every split."
        )
    if duplicates:
        warnings.append(f"{len(duplicates)} image path(s) appear more than once.")
    if missing_images:
        warnings.append(f"{len(missing_images)} image file(s) listed in the manifest are missing.")
    missing_source = tuple(row.line_number for row in rows if not row.source)
    missing_session = tuple(row.line_number for row in rows if not row.capture_session)
    if missing_source:
        warnings.append(f"{len(missing_source)} row(s) have no `source`.")
    if missing_session:
        warnings.append(f"{len(missing_session)} row(s) have no `capture_session`.")

    counts = list(images_per_patient.values())
    return QualityReport(
        image_count=len(rows),
        patient_count=len(images_per_patient),
        classes=classes,
        images_per_patient=dict(sorted(images_per_patient.items())),
        images_per_patient_min=min(counts),
        images_per_patient_median=float(statistics.median(counts)),
        images_per_patient_max=max(counts),
        missing_source_lines=missing_source,
        missing_capture_session_lines=missing_session,
        missing_image_lines=missing_images,
        duplicate_image_paths=duplicates,
        patients_with_several_labels=several_labels,
        warnings=tuple(warnings),
    )
