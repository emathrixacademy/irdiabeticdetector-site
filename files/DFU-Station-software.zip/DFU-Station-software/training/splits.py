"""Patient-level cross-validation splits.

THE CORE CONTRACT: every split is grouped by `patient_id` first. All images
of one patient are in training or in testing for a given fold, never both.
Near-identical shots of the same foot on both sides of a split inflate
accuracy into a meaningless number.

There is no image-level shuffle in this module and none may be added.
"""

from __future__ import annotations

import random
from collections import Counter, defaultdict
from dataclasses import dataclass

from training.manifest import ManifestRow


class SplitError(Exception):
    """The requested split cannot be made, or a split broke the patient rule."""


@dataclass(frozen=True)
class Fold:
    index: int
    train_indices: tuple[int, ...]
    test_indices: tuple[int, ...]
    train_patients: tuple[str, ...]
    test_patients: tuple[str, ...]


@dataclass(frozen=True)
class FoldPlan:
    folds: tuple[Fold, ...]
    warnings: tuple[str, ...]


def patient_label(rows: list[ManifestRow]) -> dict[str, str]:
    """One label per patient, used only to spread classes across folds.

    A patient with several labels is placed by their most common one. The
    patient still goes entirely into one side of each split.
    """
    labels: dict[str, Counter[str]] = defaultdict(Counter)
    for row in rows:
        labels[row.patient_id][row.label] += 1
    return {
        patient: sorted(counts.items(), key=lambda item: (-item[1], item[0]))[0][0]
        for patient, counts in labels.items()
    }


def assert_patient_disjoint(
    rows: list[ManifestRow], train_indices: tuple[int, ...], test_indices: tuple[int, ...]
) -> None:
    """Raise if any patient appears on both sides. Called before every fold is used."""
    train_patients = {rows[index].patient_id for index in train_indices}
    test_patients = {rows[index].patient_id for index in test_indices}
    shared = train_patients & test_patients
    if shared:
        raise SplitError(
            f"{len(shared)} patient(s) appear in both training and testing. "
            "Splits must be grouped by patient_id."
        )
    if set(train_indices) & set(test_indices):
        raise SplitError("an image appears in both training and testing")


def patient_level_folds(rows: list[ManifestRow], fold_count: int, seed: int) -> FoldPlan:
    """Grouped k-fold by patient, spreading each class's patients across folds.

    Deterministic for a given manifest order, fold count and seed.
    """
    if fold_count < 2:
        raise SplitError("cross-validation needs at least 2 folds")
    labels = patient_label(rows)
    patients = sorted(labels)
    if len(patients) < fold_count:
        raise SplitError(
            f"{len(patients)} patient(s) cannot be split into {fold_count} folds. "
            "The patient count is the real sample size."
        )

    by_label: dict[str, list[str]] = defaultdict(list)
    for patient in patients:
        by_label[labels[patient]].append(patient)

    rng = random.Random(seed)
    fold_of: dict[str, int] = {}
    next_fold = 0
    warnings: list[str] = []
    for label in sorted(by_label):
        group = by_label[label]
        rng.shuffle(group)
        if len(group) < fold_count:
            warnings.append(
                f"Class {label!r} has {len(group)} patient(s), fewer than the {fold_count} "
                "folds, so some folds have no test patient of this class."
            )
        for patient in group:
            fold_of[patient] = next_fold
            next_fold = (next_fold + 1) % fold_count

    folds: list[Fold] = []
    for index in range(fold_count):
        test = tuple(i for i, row in enumerate(rows) if fold_of[row.patient_id] == index)
        train = tuple(i for i, row in enumerate(rows) if fold_of[row.patient_id] != index)
        assert_patient_disjoint(rows, train, test)
        folds.append(
            Fold(
                index=index,
                train_indices=train,
                test_indices=test,
                train_patients=tuple(sorted(p for p in patients if fold_of[p] != index)),
                test_patients=tuple(sorted(p for p in patients if fold_of[p] == index)),
            )
        )
    return FoldPlan(folds=tuple(folds), warnings=tuple(warnings))
