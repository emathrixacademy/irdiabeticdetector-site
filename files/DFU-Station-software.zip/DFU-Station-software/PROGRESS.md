# PROGRESS.md

One line per completed task: task id, what was done, files touched.
Build machine for this run: Windows 11, Python 3.13 (not a Raspberry Pi), so
every [HW] task is built against the fakes and marked `[~]`.

| Task | What was done | Files touched |
|---|---|---|
| 0.1 | Initialised git on `main`, added ignore rules for calibration, local config, captured data and model binaries, and a proprietary licence stating eMathrix background IP. | `.gitignore`, `LICENSE`, `TASKS.md`, `PROGRESS.md` |
| 0.2 | Added pyproject (ruff, mypy, pytest settings), runtime and dev requirements with Pi-only packages left to apt, and LF line endings. pip install -r requirements-dev.txt succeeded on Windows / Python 3.13. | `pyproject.toml`, `requirements.txt`, `requirements-dev.txt`, `.gitattributes` |
| 0.3 [x] | Created every folder from README section 5 with package markers, plus models/, config/, docs/, tests/fixtures/ and training/. | src/**/__init__.py, tests/__init__.py, models/README.md, docs/README.md |
| 0.4 [x] | Added tasks.py (lint, test, check, format, run, run-fake) and a skeleton import test. ruff check, ruff format --check, mypy src and pytest all pass (11 tests). mypy type-checks for Linux because the target is Pi OS. | tasks.py, pyproject.toml, tests/test_skeleton.py |
| 0.5 [x] | Created DECISIONS.md and BLOCKERS.md templates (PROGRESS.md already existed from 0.1). | DECISIONS.md, BLOCKERS.md |
| 1.1 [x] | Added config.example.yaml with every protocol value and a strict loader: all keys required, unknown keys refused, types and ranges checked, ambient gate and acclimatisation can only be tightened. Tests cover a valid file, missing keys, wrong types and out-of-range thresholds. | config/config.example.yaml, src/config.py, src/errors.py, tests/conftest.py, tests/test_config.py, DECISIONS.md |
| 1.2 [x] | Config.config_hash() gives a stable SHA-256 of the effective config (key order does not matter, any value change does). Test covers stability and sensitivity. | src/config.py, tests/test_config.py |
| 1.3 [x] | Added the pipeline dataclasses (ThermalFrame, ColorFrame, AmbientReading, ScanRecord, RegionResult, AsymmetryResult, ClassifierResult, FusedResult, plus RawThermalFrame and SidednessDecision). A test fails if any field is named grade, wagner or diagnosis. | src/datamodel.py, tests/test_datamodel.py |
| 1.4 [x] | Added the reference-code validator: configurable pattern plus fixed guards (digits required, no spaces, no long letter runs, file-name safe). Error text never repeats the rejected input. | src/reference_code.py, tests/test_reference_code.py |
| 1.5 [x] | Added central logging to stderr with a redacting filter that strips reference codes and replaces arrays and byte blobs with a short description. Tests prove neither reaches a log line. | src/logging_setup.py, tests/test_logging.py |
| 2.1 [x] | Added abstract interfaces for all seven devices, a Clock interface (real, sped-up fake, manual), the Devices bundle and a factory that picks fake drivers from config. Real mode refuses to start until the real drivers land in Phases 3, 4 and 9. | src/hardware/interfaces.py, src/hardware/factory.py, src/clock.py, src/inference/metadata.py, tests/test_hardware_interfaces.py, tests/conftest.py, DECISIONS.md |
| 2.2 [x] | Added the synthetic scene generator and committed fixtures: two plantar-shaped feet on a 23 C background with heel deltas of 0.0, 1.5, 2.19, 2.2, 2.21 and 3.5 C, matching colour frames through a known homography, a registration target pair and fake model metadata. All marked synthetic. | tools/synthetic.py, tools/generate_fixtures.py, tests/fixtures/**, tests/test_fixtures.py |
| 2.3 [x] | Added fake drivers that replay fixtures unchanged: thermal camera with FFC states and stale/failed-read controls, colour camera that records whether the light was on, ambient sensor with in and out of range values and faults, button presses, status LED history and a deterministic accelerator. | src/hardware/fakes.py, tests/test_fakes.py |
| 2.4 [x] | python -m src.app --fake --headless --reference-code DFU-0001 runs a full scan on a laptop and writes one paired record (colour PNG, raw Y16, temperature array, meta.json) atomically. This brought in the thermal conversion, validity and calibration modules, the two gates, the capture sequencer and the scan-folder writer, which Phases 3, 5 and 11 test in depth. | src/app.py, src/station.py, src/capture/gates.py, src/capture/sequencer.py, src/thermal/*.py, src/storage/layout.py, src/storage/writer.py, tests/test_app_fake.py |
| 3.1 [x] | Y16 to Celsius is raw / 100 - 273.15, vectorised in float64, in src/thermal/convert.py only. A frame with any pixel outside the configured plausible range (0-60 C) or any non-finite value is rejected. Tests cover the formula, shape, dtype and range. | src/thermal/convert.py, tests/test_thermal_convert.py |
| 3.2 [x] | Frame validity: stale frames, frames during FFC, before any FFC or within post_ffc_discard_s of one, all-zero, saturated, dead-zero and wrong-shape frames all raise. ThermalSource re-reads a real frame for FFC or staleness (up to max_capture_attempts) and raises at once for anything else. Tests prove the returned frame is exactly what the sensor gave. | src/thermal/validity.py, src/thermal/source.py, tests/test_thermal_validity.py |
| 3.3 [x] | Per-unit gain and offset load from calibration/thermal.yaml with sanity limits (gain 0.8-1.2, offset within 10 C). A missing file is an error on real hardware and the identity with a warning in fake mode. A malformed file is refused in both modes. | src/thermal/calibration.py, tests/test_thermal_calibration.py |
| 3.4 [~] | Wrote the PureThermal 3 driver: V4L2 Y16 capture with RGB conversion off, FFC trigger and status and TLinear state over the UVC extension units, frames stamped on arrival by a reader thread. It refuses a colour stream and refuses to confirm radiometry unless TLinear is on at 0.01 K. Logic tested with a fake control channel. NEEDS HARDWARE VERIFICATION (B1): extension-unit numbers were not observed on a board. | src/capture/purethermal.py, src/hardware/factory.py, tests/test_purethermal.py, BLOCKERS.md, DECISIONS.md |
| 3.5 [~] | Wrote the reference-thermometer check tool: asks for the reference reading, averages the centre of several validated frames, reports uncalibrated and calibrated error against the tolerance, logs every check to calibration/ and writes thermal.yaml (identity if within tolerance, offset only with --apply-offset). Tested against the fake camera. NEEDS HARDWARE VERIFICATION (B2): no real check has been done. | src/diagnostics/thermal_reference.py, tests/test_thermal_reference.py |
| 4.1 [~] | Wrote the Camera Module 3 driver on picamera2: manual focus at the calibrated lens position, auto-exposure and auto white balance off with fixed values from calibration/color.yaml, fixed resolution from config, B-G-R frames. Added the color_lock tool that finds those values with the LED on. Tested with a stand-in for picamera2. NEEDS HARDWARE VERIFICATION (B3). | src/capture/picamera.py, src/capture/color_calibration.py, src/diagnostics/color_lock.py, src/hardware/factory.py, tests/test_color_camera.py, BLOCKERS.md, DECISIONS.md |
| 4.2 [~] | Wrote the GPIO devices on gpiozero with the lgpio pin factory (no RPi.GPIO): interior LED that is off at start and on close, debounced capture button, and a status LED with distinct idle, acclimatising, ready, capturing and error indications. Tested against the gpiozero mock pin factory. NEEDS HARDWARE VERIFICATION (B4). | src/hardware/gpio.py, tests/test_gpio.py |
| 4.3 [~] | Wrote the SHT31 I2C driver behind AmbientSensor: single-shot measurement, CRC-8 check on both words, datasheet conversion formulas. Bus errors, short responses and checksum mismatches raise SensorFaultError. Tested against a fake bus with the datasheet checksum example. NEEDS HARDWARE VERIFICATION (B5): the sensor model is still TBD. | src/hardware/sht31.py, tests/test_sht31.py |
| 4.4 [~] | Wrote the hardware self-check: Hailo-8L (hailortcli fw-control identify), Camera Module 3, PureThermal enumeration, Y16 and TLinear, GPIO, ambient sensor and calibration files, each with its own PASS or FAIL line. A failure or crash in one check does not stop the others. Parsing and reporting tested off-device. NEEDS HARDWARE VERIFICATION (B6). | src/diagnostics/check_hardware.py, tests/test_check_hardware.py |
| 5.1 [x] | Ambient gate (22-25 C inclusive; stale, non-finite or failed readings are sensor faults, not passes) and a 900 s acclimatisation timer per reference code. Refusals carry a clear reason. No bypass exists: a test checks the capture signature, the gate methods and every command-line option. Tests cover in range, below, above, sensor fault and timer not met. | src/capture/gates.py, src/app.py, tests/test_gates.py, tasks.py |
| 5.2 [x] | Sequence enforced and tested with fakes: ambient check, acclimatisation check, FFC and wait, LED on, settle, colour frame, LED off, settle delay, thermal frame. Tests check the event order, that the colour frame is lit, that the thermal frame is taken dark at least settle_delay_s after LED off, and that the LED goes off even when the colour camera fails. | src/capture/sequencer.py, tests/test_sequencer.py |
| 5.3 [x] | One trigger gives exactly one paired colour and thermal record or an exception. A colour fault, missing thermal frame, invalid thermal frame or failed disk write leaves no files at all (scan folders are written to a temporary folder and moved into place in one rename). Covers Annex A line 8. | src/storage/writer.py, tests/test_sequencer.py |
| 5.4 [x] | Every step of the sequence (trigger, ambient_checked, acclimatisation_checked, ffc_triggered, ffc_complete, led_on, color_captured, led_off, settle_complete, thermal_captured) is timestamped in UTC and stored in the scan metadata. | src/capture/sequencer.py, src/storage/writer.py, tests/test_sequencer.py |
| 6.1 [x] | Documented the calibration target and procedure in docs/calibration.md (perforated plate over a warm backing, in the sole plane) and wrote the tool that finds matching hole centres in both frames and fits a homography (python -m src.diagnostics.registration_calibrate). Tested on a synthetic target with a known homography. Real per-unit calibration is waiting on hardware and a physical target (B7). | docs/calibration.md, src/registration/target.py, src/registration/model.py, src/diagnostics/registration_calibrate.py, src/hardware/factory.py, tests/test_registration.py, DECISIONS.md, BLOCKERS.md |
| 6.2 [x] | Applying registration maps the colour frame onto the thermal field of view: one image on the thermal grid and one crop at 4x that grid for the classifier. The thermal frame is never resampled. The homography is stored in calibration/registration.yaml; a missing file is an error on real hardware. The covered fraction of the thermal frame is reported. | src/registration/apply.py, src/registration/model.py, tests/test_registration.py |
| 6.3 [x] | Registration check: an overlay image (thermal false colour blended with registered colour, on the thermal grid) and a numeric RMS reprojection error in thermal pixels. Calibration fails and writes nothing above registration.max_reprojection_error_px, and a stored registration above the limit is refused at start-up. Covers Annex A line 10 in software. | src/registration/apply.py, src/registration/target.py, tests/test_registration.py |
| 7.1 [x] | Plantar mask on the temperature frame: threshold above the warmer of ambient and the frame background, 3x3 open and close to group pixels, components under min_foot_area_px ignored, and FootCountError unless exactly two feet remain. Masks contain only pixels that are themselves above the threshold. Tests cover one, none, three and touching feet, specks, a warm cabinet and cool feet. | src/segmentation/mask.py, tests/test_segmentation.py, DECISIONS.md |
| 7.2 [x] | Left and right: geometry proposes from each foot's hallux side, the operator must confirm or correct, and the record stores which was used (geometry_confirmed or operator_override) plus the geometry proposal. No proposal is made when both feet look like the same side or a hallux side is unclear. Tests include feet swapped in the image and rotated feet. | src/segmentation/sidedness.py, src/segmentation/geometry.py, tests/test_segmentation.py |
| 7.3 [x] | Normalisation: each foot's long axis from principal axes, toe end from the wider end, scale from its own length and width, right foot mirrored into a canonical left-foot frame (u medial to lateral, v toe to heel). Includes the inverse mapping and a nearest-pixel canonical warp for the display-only difference map. Tested with rotated and upside-down feet. | src/segmentation/geometry.py, tests/test_segmentation.py |
| 7.4 [x] | A foot within edge_margin_px of any frame edge raises FootOutOfFrameError and the scan is refused. Tested on all four edges and with a foot one pixel inside the frame. Covers Annex A line 2 in software. | src/segmentation/mask.py, tests/test_segmentation.py |
| 8.1 [x] | Fixed plantar region map of eight regions (hallux, lesser toes, first, central and fifth metatarsal heads, medial and lateral midfoot, heel) as normalised polygons in the config. Each thermal pixel of a foot belongs to exactly one region; tests check full coverage, no double counting and that medial and lateral land correctly on both feet. | src/asymmetry/regions.py, config/config.example.yaml, src/config.py, tools/synthetic.py, tests/test_asymmetry.py, DECISIONS.md |
| 8.2 [x] | Delta T: mean temperature per region per foot, delta = left minus right, flagged when abs(delta) >= 2.2 inclusive (with a 1e-6 C tolerance for floating-point error only). A region with too few pixels on either foot is reported as not comparable instead of being filled in. Also computes a pixel-wise left-minus-mirrored-right difference map for display only. | src/asymmetry/compute.py, src/datamodel.py |
| 8.3 [x] | Asymmetry tests on fixtures: 2.19 gives no flag, 2.2 flags, 2.21 flags, a symmetric pair gives no flags and zero deltas. Also covers a hot right foot (negative delta), feet swapped in the image, rotated feet, a region missing on one foot and a threshold changed in config. Covers Annex A line 11. | tests/test_asymmetry.py |
| 9.1 [x] | Shared preprocessing in src/inference/preprocess.py: BGR to RGB, whole-image resize to the model input size, scale, mean and standard deviation normalisation, NCHW layout. Training imports the same functions, and a test checks a training sample equals the station's preprocessing of the same image. Added the Classifier wrapper that turns scores into class index, label and confidence. | src/inference/preprocess.py, src/inference/classifier.py, tests/test_inference.py, DECISIONS.md, BLOCKERS.md |
| 9.2 [~] | Wrote the HailoRT runner: loads a .hef (never compiles), feeds RGB uint8, returns class scores, checks the input shape against the model metadata, labels come from model_meta.json. Call flow tested against a stand-in for hailo_platform. NEEDS HARDWARE VERIFICATION (B8) and a trained, compiled model (B9, B10). | src/inference/hailo_runner.py, src/hardware/factory.py, tests/test_inference.py |
| 9.3 [x] | Wrote the ONNX Runtime CPU runner behind the same Accelerator interface, selected with inference.backend: onnx. It applies the shared normalisation and checks the model input shape against the metadata. Tested against a small ONNX graph with a known answer. | src/inference/onnx_runner.py, requirements-dev.txt, tests/test_inference.py |
| 9.4 [x] | Classifier output is stored as predicted_class, never a grade. Tests enforce it three ways: the result fields, a scan of every identifier in src/ and training/ for grade-like names, and the metadata loader refusing labels that read like a clinical grade. Covers Annex A line 12 in software. | tests/test_output_naming.py, src/inference/metadata.py |
| 10.1 [x] | Dataset manifest CSV with columns patient_id, image_path, label, source, capture_session. The loader rejects the whole manifest, listing line numbers, if any row is missing patient_id, image_path or label. Rows are never dropped. | training/__init__.py, training/manifest.py, tests/test_training_data.py |
| 10.2 [x] | Data-quality report: images and patients per class, images per patient, missing source or capture_session, missing image files, duplicate paths, patients with several labels, and warnings for tiny classes and class imbalance. Read-only: a test checks it changes nothing and has no drop, impute or rebalance function. | training/quality.py, tests/test_training_data.py |
| 10.3 [x] | Grouped k-fold by patient_id, spreading each class across folds, deterministic by seed. Tests prove no patient is in both train and test in any fold for several fold counts and seeds, that every image is tested exactly once, and that the guard catches a deliberately leaked patient. No image-level shuffle exists in the split module. | training/splits.py, tests/test_training_data.py |
| 10.4 [x] | MobileNetV2 transfer learning in PyTorch with a class weighting option, augmentation, fixed seeds and per-fold metrics (accuracy, per-class recall, confusion matrix, patient counts) written to JSON and Markdown. No accuracy target is asserted. Run end to end on small synthetic images only; no real model exists because no dataset was supplied (B9). | training/train.py, training/requirements.txt, training/README.md, tests/test_training_model.py |
| 10.5 [x] | ONNX export with a fixed 1 x 3 x 224 x 224 input matching the shared preprocessing, plus model_meta.json written through the station's own parser. The export is deleted unless ONNX Runtime matches PyTorch within 1e-4. Tested on an untrained MobileNetV2 and through the station's ONNX runner. | training/export.py, tests/test_training_model.py |
| 10.6 [~] | Wrote the Hailo Dataflow Compiler script and instructions (parse, add normalisation, optimise with a calibration set of station captures, compile for hailo8l). The normalisation line and calibration-set builder are tested. The compiler is not installed here, so the compile itself has never run (B10), and there is no trained model to compile (B9). | training/hailo_compile.py, training/README.md, tests/test_training_model.py |
| 11.1 [x] | FusedResult puts region flags, maximum delta, the flagged-region list and the classifier class and confidence side by side, with no combined verdict. Added ScanPipeline (prepare, operator confirmation, analyse) that runs registration, segmentation, asymmetry and the classifier. A test checks the on-screen summary for diagnosis wording and that the classifier cannot change the flags. | src/fusion/fuse.py, src/pipeline.py, src/station.py, src/app.py, tests/test_fusion_storage.py, tests/conftest.py, tests/test_app_fake.py, DECISIONS.md, BLOCKERS.md |
| 11.2 [x] | Storage layout data/<session_id>/<scan_id>/ with the colour PNG, registered colour PNG, raw Y16 .npy, temperature .npy, overlay PNG and meta.json (capture metadata, sidedness, segmentation, registration, every region result, classifier output). Written to a temporary folder and moved into place in one rename. Covers Annex A line 13. | src/storage/store.py, src/storage/layout.py, tests/test_fusion_storage.py |
| 11.3 [x] | CSV log, one row per scan: reference code, timestamps, ambient temperature and humidity, config hash, per-region means, deltas and flags, predicted class and confidence. Append-only with a single write and fsync per row; a CSV with other columns is never rewritten; a failed CSV write removes the scan folder so nothing is half stored. Covers Annex A lines 7 and 13. | src/storage/store.py, tests/test_fusion_storage.py |
| 11.4 [x] | Offline guarantee: a full fake scan including storage runs with socket creation, connection and name lookup patched to fail, and none is attempted. Further tests check that no file under src/ imports a network library and that logging has only a stderr handler. | tests/test_fusion_storage.py |
| 12.1 [x] | Chose PyQt5 (apt on the Pi, pip on a laptop; recorded as D40). Full-screen app laid out for a 7-inch 800 x 480 touchscreen with an on-screen keypad. `python -m src.app --fake` runs it on a laptop against the fake drivers. The workflow lives in a toolkit-free controller so it is tested without a display. | src/ui/qt_app.py, src/ui/controller.py, src/app.py, pyproject.toml, tests/test_ui_qt.py, tests/test_app_fake.py, DECISIONS.md, BLOCKERS.md |
| 12.2 [x] | Screens: reference-code entry, acclimatisation countdown with ambient status and live previews, capture, left/right confirmation (feet marked A and B), results (thermal heatmap with region map, deltas and flags, colour image, region table, predicted class), next patient. Nothing is stored until left and right are confirmed. Tested through the controller and through the real widgets. | src/ui/controller.py, src/ui/render.py, src/ui/qt_app.py, src/thermal/source.py, src/pipeline.py, tests/test_ui_controller.py, tests/test_ui_qt.py |
| 12.3 [x] | Clear, non-technical messages for every refusal: room too warm, room too cold, rest period not finished, foot out of view, both soles needed, room sensor not responding, and one for every other station error. A test walks every error class, checks each has its own message that tells the operator what to do next, and that no internal detail or jargon is shown. | src/ui/messages.py, tests/test_ui_controller.py |
| 12.4 [x] | The physical capture button and the on-screen button both end in StationController.request_capture. Tests show identical device events and results from either, that the physical button is refused by the same gates, and that it does nothing on other screens. In the Qt app the button press is carried to the UI thread by a signal and then takes the same path as a tap. Covers Annex A line 6 in software. | src/ui/controller.py, src/ui/qt_app.py, tests/test_ui_controller.py, tests/test_ui_qt.py |
| 12.5 [~] | Wrote the systemd user service and installer: starts the app with the desktop session, restarts on crash, logs to the journal, no network dependency, and no restart loop when the station cannot start as configured. The file contents are tested. NEEDS HARDWARE VERIFICATION (B12): systemd was never run. | deploy/dfu-station.service, deploy/install_service.sh, tests/test_deploy.py, .gitattributes |
| 13.1 [x] | Wrote docs/methodology.md for the research team: rationale, hardware, capture protocol, thermal measurement and calibration, registration, segmentation and left/right, the asymmetry method, the classifier, patient-level validation, data recorded, software verification, limitations and status. It makes no accuracy claim and leaves boxed notes where a number must come from the finished station. Tests check the quoted protocol values match the config. Covers Annex A line 14. | docs/methodology.md, tests/test_docs.py, pyproject.toml, DECISIONS.md |
| 13.2 [x] | Wrote docs/operator_manual.md: room preparation, patient positioning (supine and seated), acclimatisation, scanning, confirming left and right, reading the results screen without interpreting it, what to do for each refusal, the status light, cleaning and shutdown. Added an Exit button to the code screen so the station can be shut down by touch. | docs/operator_manual.md, src/ui/qt_app.py |
| 13.3 [x] | Completed docs/calibration.md: thermal reference check (what is needed, procedure, reading the result, limits), colour camera focus and exposure lock, registration target and procedure, how often to repeat each, and which records to keep. | docs/calibration.md |
| 13.4 [x] | Refreshed README.md with the decisions made during the build: the full scan flow including flat-field correction and operator confirmation, the software stack, the real repository layout, laptop and Pi setup with the three calibration steps, the training rules, a document index and an honest build status. | README.md, docs/README.md (removed) |
| 14.1 [x] | Wrote docs/acceptance_test.md: for each Annex A line (A1 to A14) the exact step, the expected result and the test or tool that demonstrates it, plus a preparation checklist and a summary table saying which lines need the station and which blocker applies. A12 is marked blocked (no dataset, no model). | docs/acceptance_test.md |
| 14.2 [x] | One pytest (tests/test_acceptance_e2e.py) runs the whole station on fixtures with the network blocked and checks every software-testable Annex A line: A2, A6, A7, A8, A9, A10, A11, A12, A13, A14. It asserts that exactly those lines were checked and that A1, A3, A4 and A5 are accounted for as physical or hardware-presence lines. | tests/test_acceptance_e2e.py |
| 14.3 [!] | BLOCKED (B13): the on-device dry run needs the assembled station, a warm object, a reference thermometer and a person. Not done and not faked. The same scan was run end to end on the fake drivers only, which is not a hardware result. An empty results table for the real run is at the end of this file. | BLOCKERS.md, src/app.py |
| 14.4 [x] | Final report written below: what is done, what is waiting on hardware, every open blocker and every decision for the Owner to review. | PROGRESS.md |

---

# On-device dry run (task 14.3) — NOT YET PERFORMED

Nothing has been entered here because nothing has been measured. The build ran
on a Windows laptop with no station attached. Fill this in on the station; see
BLOCKERS.md B13 for the steps.

| Item | Result | Date | By |
|---|---|---|---|
| `check_hardware` output (all lines) | | | |
| Reference thermometer make, model, stated accuracy | | | |
| Warm object: reference thermometer reading (°C) | | | |
| Warm object: Lepton reading in `thermal_temp_c.npy` (°C) | | | |
| Difference (°C) | | | |
| Registration reprojection error (thermal px) | | | |
| Colour frame covers the full thermal frame? (`color_coverage_fraction`) | | | |
| One press gave one scan folder with both frames? | | | |
| Ambient reading in the CSV agrees with a room thermometer? | | | |
| Classifier ran on the Hailo-8L? (`model_id` in `meta.json`) | | | |

---

# Final report (task 14.4)

Build finished October 8, 2026. Client acceptance is October 30, 2026.

## In one paragraph

The station's software is written, tested and committed: 64 of 64 tasks are
closed out, 54 complete, 9 complete in code and waiting to be verified on the
real hardware, and 1 blocked because it is purely physical. The whole pipeline
runs on a laptop against stand-in drivers, including the touchscreen app. It
has **not** been run on the station, because the build machine was a Windows
laptop, and **no model has been trained**, because no dataset was supplied.
Nothing was faked to get past either gap: there are no invented temperatures,
calibration values, weights or results anywhere in the repository.

## Verification at the end of the build

Run with `python tasks.py check`:

| Check | Result |
|---|---|
| `ruff check .` | Passed |
| `ruff format --check .` | Passed |
| `mypy src` (strict, 60 files) | No issues |
| `pytest` | 540 passed, 7 skipped |

The 7 skipped tests are the hardware tests (`@pytest.mark.hardware`), which
only run on the Pi 5: PureThermal, Camera Module 3, GPIO, SHT31, Hailo, the
self-check and the autostart service. They have never been run.

63 commits before this one, one or more per task, each named by task id.

## What is done `[x]` (54 tasks)

| Phase | Done |
|---|---|
| 0 Scaffold | 0.1–0.5: repo, project files, package skeleton, task runner, working files |
| 1 Config and data model | 1.1–1.5: strict config loader, config hash, data model, reference-code validator, redacting logs |
| 2 Interfaces and fakes | 2.1–2.4: seven device interfaces, synthetic fixtures, fake drivers, fake app run |
| 3 Thermal path | 3.1–3.3: Y16 conversion, frame validity, calibration file |
| 5 Capture sequencer | 5.1–5.4: gates, sequence, paired record, timing log |
| 6 Registration | 6.1–6.3: target procedure and tool, applying it, error check |
| 7 Segmentation | 7.1–7.4: plantar mask, left/right, normalisation, frame-edge refusal |
| 8 Asymmetry | 8.1–8.3: region map, delta T and flag, threshold tests |
| 9 Inference | 9.1, 9.3, 9.4: shared preprocessing, ONNX runner, output naming |
| 10 Training | 10.1–10.5: manifest, data-quality report, patient-level splits, training, export |
| 11 Fusion and storage | 11.1–11.4: fusion, scan folders, CSV log, offline guarantee |
| 12 Operator UI | 12.1–12.4: PyQt5 app, screens, error messages, button parity |
| 13 Documentation | 13.1–13.4: methodology, operator manual, calibration manual, README |
| 14 Acceptance | 14.1, 14.2, 14.4: runbook, end-to-end test, this report |

"Done" for Phases 6 and 10 means the software is done. The registration of the
real unit (B7) and a model trained on real data (B9) are still to come.

## What is waiting on hardware `[~]` (9 tasks)

Each is fully written and tested against a stand-in. None has run on a device.

| Task | What | Blocker |
|---|---|---|
| 3.4 | PureThermal Y16 driver | B1 |
| 3.5 | Reference-thermometer check tool | B2 |
| 4.1 | Camera Module 3 driver and colour lock tool | B3 |
| 4.2 | GPIO: interior LED, button, status LED | B4 |
| 4.3 | Ambient sensor (SHT31) | B5 |
| 4.4 | Hardware self-check | B6 |
| 9.2 | HailoRT runner | B8 |
| 10.6 | Hailo compile script (compiler not installed) | B10 |
| 12.5 | Autostart service | B12 |

## What is blocked `[!]` (1 task)

| Task | What | Blocker |
|---|---|---|
| 14.3 | On-device dry run with a warm object and reference thermometer | B13 |

## Every open blocker (BLOCKERS.md)

| # | Blocker | Who can clear it |
|---|---|---|
| B1 | PureThermal driver never run on the board. The UVC extension-unit numbers were written from documentation, not observed. | Technician on the station |
| B2 | Reference-thermometer check not performed. No `calibration/thermal.yaml` exists; the station will not scan without it. | Technician, with a reference thermometer |
| B3 | Camera Module 3 driver never run on the Pi. No `calibration/color.yaml`. | Technician on the station |
| B4 | GPIO never run on the Pi. Pin numbers are assumed (D5). | Technician; needs the wiring diagram |
| B5 | Ambient sensor model is still TBD. Software assumes an SHT31. | **Owner decision**, then technician |
| B6 | Hardware self-check never run on the station. | Technician on the station |
| B7 | Registration not calibrated on the real unit. No physical target exists yet. | Fabrication (make the target), then technician |
| B8 | Hailo runner never run on the Hailo-8L. | Technician, once a `.hef` exists |
| B9 | **No dataset, so no trained model.** No weights, no accuracy figure, nothing in `models/`. | **Research team** must supply the dataset |
| B10 | Hailo Dataflow Compiler not installed. Compile script never executed. | Developer with an x86 Linux machine and a Hailo account |
| B11 | Station clock: offline, so it needs an RTC battery or a daily check. | **Owner decision** (fit a battery) |
| B12 | Autostart never installed or tried. UI never seen on the real 7-inch panel. | Technician on the station |
| B13 | On-device dry run not done. | Technician, after B1–B8 and B12 |

### Critical path to October 30

Acceptance line A12 (MobileNetV2 compiled to Hailo, running on-device) depends
on a chain that has not started: dataset from the client (B9) → training →
export → Dataflow Compiler on x86 Linux (B10) → run on the Hailo-8L (B8). It
is the longest item and the one outside eMathrix's control. Raise it with the
client now. Everything else on the list is a few days of bench work once the
station is assembled.

## Every decision for the Owner to review (DECISIONS.md)

All 48 are written up in DECISIONS.md with the question, the choice and the
reason. The ones most worth reading first are marked.

**Clinical and scientific. Please review these first.**

| # | Decision |
|---|---|
| **D26** | Where the eight plantar regions are. Proportional defaults, not a published standard. **Needs a clinician.** |
| **D25** | `delta >= 2.2` is implemented with a 1e-6 C tolerance so an exact 2.20 is not lost to floating-point rounding. Does not change the rule. |
| **D21** | A pixel is foot if it is 2.0 C above the room or background. Very cold toes may fall outside the mask and go unmeasured. |
| **D27** | A region with too few pixels on one foot is reported as not comparable, not estimated. |
| **D22** | Left/right: geometry proposes, the operator must always confirm. |
| **D23** | How the two feet are lined up (principal axes, own length and width). |
| **D28** | Delta T is left minus right. |
| **D36** | Fusion gives no combined verdict; the two results sit side by side. |
| **D30** | The station only sees neutral class names (`class_0`, ...), never grade labels. |
| **D13** | Thermal calibration is a single-point offset, written only on request; 1.0 C tolerance is a placeholder. |
| **D12** | One implausible, zero or saturated pixel rejects the whole thermal frame. |
| **D11** | A mid-FFC or stale frame is discarded and a new real frame read, up to 5. |
| **D14** | The Lepton's automatic FFC is left on; affected frames are flagged and discarded. |

**Protocol gates.**

| # | Decision |
|---|---|
| **D2** | The config can narrow the 22–25 C gate but cannot widen it. |
| **D3** | The config can lengthen the 900 s rest but cannot shorten it. |
| D10 | Fake mode passes the rest period by faking the clock, never by skipping the gate. |
| D24 | A refused scan is not stored. |

**Hardware assumptions. Check against the real build.**

| # | Decision |
|---|---|
| **D5** | GPIO pins: LED 18, button 17, status LED 27. No wiring diagram was supplied. |
| **D15** | Ambient sensor assumed to be an SHT31 at I2C address 0x44. |
| D16 | One status LED shows five states by blink pattern. |
| D17 | Button debounce, wired to ground with the internal pull-up. |
| D7 | Colour camera focus, exposure and white balance are fixed values, found once under the LED. |
| **D19** | The colour camera may not cover the full height of the thermal frame; coverage is recorded, not filled in. |
| D20 | Calibration target: 5 x 7 holes, about 18 mm on a 50 mm pitch. |
| D41 | UI laid out for 800 x 480 with an on-screen keypad. |
| D45 | Autostart is a systemd user service; needs Desktop Autologin. |

**Data, storage and privacy.**

| # | Decision |
|---|---|
| **D6** | Reference code format assumed to be like `DFU-0001`. The research team has not given theirs. |
| D37 | Scan folder contents; a session is one code on one UTC date; `color_registered.png` added. |
| D38 | A CSV with different columns is never rewritten; the station refuses and the old file is moved aside. |
| D39 | A missing delta is an empty cell, never zero. |
| D8 | Synthetic test data lives outside the station package and is marked synthetic. |
| D1 | All model files are kept out of git, whatever their size. |
| D4 | Every config key is required; unknown keys are refused. |

**Classifier and training.**

| # | Decision |
|---|---|
| D18 | The classifier sees a 640 x 480 colour crop of the thermal field of view, not a 160 x 120 image. |
| D29 | Whole crop resized to 224 x 224, ImageNet normalisation, one shared module. |
| D31 | Normalisation is built into the `.hef`; the ONNX runner does it in Python. |
| D32 | Folds: grouped k-fold by patient, classes spread across folds, checked twice. |
| D33 | Training defaults, including a horizontal flip that swaps left and right. |
| D34 | ONNX export uses the TorchScript exporter, opset 13, fixed shape. |

**Operator interface and documents.**

| # | Decision |
|---|---|
| D40 | PyQt5, with the workflow in a toolkit-free controller. |
| D42 | Live colour preview is unlit; the light only comes on for the capture. |
| D43 | Left/right is confirmed by tapping "Foot A" or "Foot B". |
| D44 | What the results screen shows. |
| D48 | An Exit button on the code screen, for shutdown by touch. |
| **D46** | The methodology leaves boxed gaps for results that do not exist yet. Pass to the research team. |
| D47 | Cleaning guidance defers to the facility's infection-control policy. |

**Build housekeeping.**

| # | Decision |
|---|---|
| D9 | Size of the synthetic hot spot in the test fixtures. |
| D35 | The build environment was at `C:\tmp\dfu-venv` because of Windows path-length limits. Safe to delete. |

## Annex A readiness

| Line | State |
|---|---|
| A1, A3 | Fabrication. No software involved. |
| A2, A6, A7, A8, A11, A13 | Software ready and tested. Needs demonstrating on the station. |
| A4, A5 | Self-check written. Needs the station (B6). |
| A9 | Tool written. Needs the reference check on the unit (B2). |
| A10 | Tool written. Needs the target and a calibration on the unit (B7). |
| **A12** | **Blocked.** No dataset, no model, no compiler (B9, B10, B8). |
| A14 | Methodology written, with gaps for the team to fill from the unit and their data. |

The step-by-step runbook is `docs/acceptance_test.md`.

## Three things worth knowing

1. **The non-negotiables held.** No temperature was invented; every split is
   grouped by patient; the classifier output is never a grade; nothing touches
   the network; the ambient gate has no bypass; only the reference code is
   stored. Each has tests that fail if it is broken.
2. **The laptop tests are about the software, not the station.** They prove
   the arithmetic, the rules and the workflow on idealised synthetic feet.
   They do not prove the Lepton reads true temperatures or that real feet
   segment cleanly. Expect to adjust the segmentation settings once real
   thermal frames are available.
3. **The first day on the station should be B1.** The PureThermal control
   numbers are the single most likely thing to need fixing, and until the
   Lepton delivers a confirmed radiometric frame nothing else on the thermal
   path can be checked.

---

# Phase 2, Run A (first classifier on public colour photos)

Started October 8, 2026, on the same Windows laptop.

| Task | What was done | Files touched |
|---|---|---|
| A.1 [!] | BLOCKED (B14): data/public_raw/ does not exist, so no dataset was ingested and no manifest was built. Wrote the intake tool and its config: each dataset folder must be described before it is read, labels map only by an exact per-dataset table, anything else is rejected and listed, byte-identical files are removed and listed. Mapping policy recorded in DECISIONS D49 for the research team. BLOCKERS B14 has the download, licence and placement steps, and flags that the public Wagner dataset found in the literature has no grade 0. | training/intake.py, training/configs/public_v1.yaml, .gitignore, TASKS.md, BLOCKERS.md, DECISIONS.md |
| A.2 [~] | Proxy patient grouping written and tested on synthetic pictures; not yet applied to real data (B14). Uses documented subject ids where a dataset gives them, otherwise links images by perceptual hash or by MobileNetV2 feature similarity and takes each connected set as one patient. There is no one-id-per-image option. Found and fixed before any data arrived: raw network features score about 0.9 between unrelated pictures, so features are centred on the dataset mean first. The limitation is stated in training/README.md and docs/methodology.md. | training/grouping.py, training/README.md, docs/methodology.md |
| A.3 [~] | Report written and tested on synthetic pictures; not yet run on real data (B14). The pipeline writes intake_report.md (sources and licences, label map with who confirmed it, images and groups per label, images per group, duplicates removed, rejected labels by reason, similarity distribution) plus data_quality.md, rejected.csv, duplicates_removed.csv and groups.csv. It warns if one group holds over 20 % of the images or if nothing was linked. Nothing is rebalanced; a target label with no images is reported, not filled. | training/public_pipeline.py, tests/test_public_intake.py |
| A.4 [!] | BLOCKED (B14): not run. There is no dataset, so no cross-validation was run, no final model exists and there are no metrics to report. The training code from Phase 1 is unchanged and takes the manifest the intake will write. | none |
| A.5 [!] | BLOCKED (B14): not run. With no trained model there is nothing to export; models/ still holds no .onnx and no model_meta.json. The export and parity check from Phase 1 are unchanged. | none |
| A.6 [!] | BLOCKED (B15, adding to B10): the Dataflow Compiler is not installed (WSL has Ubuntu 24.04 with Python 3.12 and no hailo_sdk_client), and this laptop has 7.3 GB of RAM against Hailo's 16 GB minimum, so it cannot be the compile machine. Nothing was compiled. The compile script now accepts a hold-out manifest of public images for quantisation and writes a .build.json beside the .hef marking it interim. BLOCKERS B15 lists exactly what the Owner must do. | training/hailo_compile.py, tests/test_training_model.py |
| A.7 [x] | Run A report written below: nothing was trained because no dataset was supplied, no metrics exist, the grouping limitation, and what still needs the station. | PROGRESS.md |

## Run A report (step A.7)

### In one paragraph

Run A did **not** produce a classifier. `data/public_raw/` does not exist, so
there was no dataset to train on, and this laptop cannot run the Hailo
compiler. What was built instead is everything needed to do the run the day
the data arrives: a tested intake, proxy grouping and reporting pipeline, a
compile script ready for interim quantisation, and exact instructions for the
two things only a person can do. **Acceptance line A12 is exactly as blocked
as it was before this run.**

### What was trained, on what data, with what metrics

| Question | Answer |
|---|---|
| What was trained? | **Nothing.** |
| On what data? | **None.** No public dataset has been supplied. |
| Metrics? | **None exist.** No cross-validation was run, so there is no accuracy, recall or confusion matrix to report, and none has been estimated or assumed. |
| ONNX file, `model_meta.json`, `.hef`? | **None.** `models/` is unchanged. |

The only images this run touched were synthetic patterns generated inside the
tests. They are not data about feet and no number from them is a result.

### Step by step

| Step | State | Why |
|---|---|---|
| A.1 Dataset intake | `[!]` blocked | Folder empty. Intake tool and config written and tested (B14). |
| A.2 Patient grouping | `[~]` code done | Written and tested on synthetic pictures; never run on real images. |
| A.3 Data-quality report | `[~]` code done | Written and tested; no real report exists. |
| A.4 Train | `[!]` blocked | No dataset (B14). |
| A.5 Export | `[!]` blocked | No model (B14). |
| A.6 Hailo compile | `[!]` blocked | Compiler not installed; laptop has 7.3 GB RAM against a 16 GB minimum (B15). |
| A.7 Report | `[x]` | This section. |

Checks at the end of the run: `ruff check`, `ruff format --check` and
`mypy src` clean; `pytest` 573 passed, 7 skipped (the 7 are the hardware
tests). 33 new tests cover the intake, grouping, hold-out and compile changes.

### The grouping limitation

**Grouping is a proxy, true patient separation cannot be guaranteed on this
public data.** Where a dataset documents subject ids they are used. Otherwise
images are linked by perceptual hash (near-duplicates) or by similarity of
MobileNetV2 features, and each connected set stands in for one patient. That
keeps copies and look-alike shots of a foot together, but two different-looking
photographs of the same patient can still land in different groups. Any
cross-validation figure from public data may therefore be optimistic and must
be reported with this caveat and with the number of groups. It is written in
`training/README.md`, in `docs/methodology.md` section 9.1, and at the top of
the grouping section of every intake report.

Two things worth knowing about the grouping before it meets real data:

- While building it I ran the real network on synthetic pictures and found
  that unrelated images score a cosine of about 0.9 on raw features. The
  first version of the threshold would have put every image in one group.
  Features are now centred on the dataset mean first, and a test guards it.
- The two thresholds are untuned defaults. On synthetic pictures, resized,
  brightened and lightly cropped copies were grouped; a heavily cropped copy
  was not. The intake report prints the similarity distribution and warns if
  the groups collapse or if nothing is linked, so the thresholds can be judged
  on the real dataset before any figure is trusted.

### Three things the Owner should decide before the next run

1. **Licence.** Many public medical image sets are for non-commercial research
   only. This model goes into a station delivered under a commercial contract.
   Check each dataset's terms first (B14 point 2).
2. **Wagner 0.** The one public Wagner-labelled dataset found in the
   literature has grades 1 to 4 and no grade 0. "Normal" or "healthy" images
   from other datasets are not grade 0 with certainty and are rejected unless
   the clinician confirms otherwise. Without a certain grade 0 source the
   first model has two classes (grade 1 against grade 2), not three (B14
   point 3, D49).
3. **A compile machine.** An x86-64 PC with 16 GB of RAM or more, Ubuntu
   22.04, and a Hailo Developer Zone account (B15).

### What still needs the station

Unchanged from Phase 1, plus what this run adds:

- **Running the model on the Hailo-8L** (B8): needs the `.hef`, then
  `pytest -m hardware tests/test_inference.py` on the Pi.
- **Matching the compiler to the Pi's HailoRT version** (`hailortcli
  --version`), or the `.hef` will not load (B15 step 3).
- **Recompiling with station frames.** A `.hef` quantised on public photos is
  interim. It needs 64 or more `color_registered.png` frames from the station.
- **Retraining on station captures.** A model trained on public close-up
  photographs should not be expected to be right on the station's fixed view
  of both soles (D54). Say this to the client before the A12 demonstration.
- Everything else in B1 to B13.

### To run it once the data is in place

```
python -m training.public_pipeline --config training/configs/public_v1.yaml
python -m training.train --manifest training/manifests/public_v1.csv --image-root data/public_raw --out runs/public_v1 --final
python -m training.export --run runs/public_v1 --out models/
```

then the compile command in B15 on the compile machine. Training MobileNetV2
on this laptop's CPU is possible but slow; the 16 GB machine would be the
better place for it too.

---

# Phase 3 (station bring-up and data-gathering readiness)

Run C needs SSH access to the Pi, which has not been given yet. No station
command has been run and C.1 to C.8 are open. Rows below are laptop work only.

| Task | What was done | Files touched |
|---|---|---|
| C.9 [x] | Laptop work only; nothing here was run on the station. (1) inference.backend: none lets the station gather data with no classifier: scans are captured, measured and stored in full with the predicted-class fields empty. (2) Fake-mode scans now go to data/_fake_mode/ with fake_mode: true in meta.json, so a panel test cannot contaminate research data. (3) The code screen shows the station clock, free storage, scans stored today and a low-storage warning. (4) Every heading is marked DEMO in fake mode. 19 new tests; 592 passed, 7 skipped. | src/config.py, config/config.example.yaml, src/station.py, src/pipeline.py, src/datamodel.py, src/fusion/fuse.py, src/storage/store.py, src/ui/controller.py, src/ui/qt_app.py, tests/test_data_collection.py, tests/test_app_fake.py, tests/conftest.py, docs/operator_manual.md, README.md, DECISIONS.md |
