"""Copying photos to a USB flash drive.

Raspberry Pi OS mounts a flash drive under /media/<user>/<label> when it is
plugged in. Photos are copied to <drive>/FootCaptures/<day>/<name>; a photo
already on the drive with the same size is skipped, so pressing Export again
only copies what is new. Eject flushes the drive and unmounts it so it can be
pulled out safely.
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from capture_app.library import Library, Photo

logger = logging.getLogger(__name__)

EXPORT_FOLDER = "FootCaptures"
MOUNT_ROOTS = ("/media/", "/run/media/")
DRIVE_FILESYSTEMS = {"vfat", "exfat", "ntfs", "ntfs3", "fuseblk", "ext4", "ext3", "hfsplus"}


@dataclass(frozen=True)
class Drive:
    mount: str
    device: str
    label: str
    free_bytes: int
    total_bytes: int

    def to_json(self) -> dict[str, Any]:
        return {
            "mount": self.mount,
            "label": self.label,
            "free_bytes": self.free_bytes,
            "total_bytes": self.total_bytes,
        }


def _unescape(field: str) -> str:
    """/proc/mounts writes spaces and tabs as octal escapes (\\040)."""
    out, i = [], 0
    while i < len(field):
        if field[i] == "\\" and field[i + 1 : i + 4].isdigit():
            out.append(chr(int(field[i + 1 : i + 4], 8)))
            i += 4
        else:
            out.append(field[i])
            i += 1
    return "".join(out)


def find_drives(mounts_file: Path = Path("/proc/mounts"), extra: Path | None = None) -> list[Drive]:
    """Removable drives mounted by the desktop. `extra` adds a folder, for testing."""
    entries: list[tuple[str, str]] = []
    try:
        lines = mounts_file.read_text(encoding="utf-8").splitlines()
    except OSError:
        lines = []
    for line in lines:
        fields = line.split()
        if len(fields) < 3:
            continue
        device, mount, fstype = _unescape(fields[0]), _unescape(fields[1]), fields[2]
        if fstype in DRIVE_FILESYSTEMS and mount.startswith(MOUNT_ROOTS):
            entries.append((device, mount))
    if extra is not None and extra.is_dir():
        entries.append(("", str(extra)))
    drives = []
    for device, mount in entries:
        try:
            usage = shutil.disk_usage(mount)
        except OSError:
            continue
        drives.append(Drive(mount, device, Path(mount).name or mount, usage.free, usage.total))
    return drives


def usb_partitions(by_id: Path = Path("/dev/disk/by-id")) -> list[str]:
    """Device paths of filesystems on USB drives, mounted or not."""
    if not by_id.is_dir():
        return []
    links = sorted(p for p in by_id.glob("usb-*") if p.is_symlink())
    with_parts = {p.name.split("-part")[0] for p in links if "-part" in p.name}
    devices = []
    for link in links:
        # A whole-disk link only counts when the stick has no partition table.
        if "-part" not in link.name and link.name in with_parts:
            continue
        devices.append(str(link.resolve()))
    return devices


def mount_usb_drives(
    devices: list[str], tried: dict[str, float], skip: set[str], retry_s: float = 30.0
) -> None:
    """Mount any of `devices` that is not mounted yet, as the desktop would.

    Raspberry Pi OS leaves this to the file manager, which is set not to do it,
    so the app does it itself. `tried` remembers failures so they are not
    retried on every screen refresh; `skip` holds drives the user ejected.
    """
    mounted = set()
    try:
        for line in Path("/proc/mounts").read_text(encoding="utf-8").splitlines():
            mounted.add(_unescape(line.split()[0]))
    except OSError:
        return
    now = time.monotonic()
    for device in devices:
        if device in mounted or device in skip or now - tried.get(device, -retry_s) < retry_s:
            continue
        probe = subprocess.run(
            ["lsblk", "-no", "FSTYPE", device], capture_output=True, text=True, check=False
        )
        if probe.stdout.strip() not in DRIVE_FILESYSTEMS | {"ntfs3"}:
            tried[device] = now
            continue
        result = subprocess.run(
            ["udisksctl", "mount", "-b", device, "--no-user-interaction"],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        if result.returncode == 0:
            logger.info("mounted %s: %s", device, result.stdout.strip())
            tried.pop(device, None)
        else:
            logger.warning("could not mount %s: %s", device, result.stderr.strip())
            tried[device] = now


class Exporter:
    def __init__(
        self,
        library: Library,
        drives: Callable[[], list[Drive]] = find_drives,
        automount: bool = False,
    ) -> None:
        self._library = library
        self._find_drives = drives
        self._automount = automount
        self._mount_tries: dict[str, float] = {}
        self._ejected: set[str] = set()
        self._lock = threading.Lock()
        self._job: dict[str, Any] = {"state": "idle"}

    def drives(self) -> list[Drive]:
        if self._automount:
            devices = usb_partitions()
            # A drive that was ejected stays unmounted until it is pulled out;
            # plugged in again, it is mounted again.
            self._ejected &= set(devices)
            self._mount_tries = {d: t for d, t in self._mount_tries.items() if d in devices}
            mount_usb_drives(devices, self._mount_tries, self._ejected)
        return self._find_drives()

    def _drive(self, mount: str) -> Drive:
        for drive in self._find_drives():
            if drive.mount == mount:
                return drive
        raise KeyError("That USB drive is no longer connected.")

    @staticmethod
    def _target(drive: Drive, photo: Photo) -> Path:
        return Path(drive.mount) / EXPORT_FOLDER / photo.id

    def _selected(self, ids: list[str] | None) -> list[Photo]:
        photos = self._library.photos()
        if ids is None:
            return photos
        wanted = set(ids)
        return [p for p in photos if p.id in wanted]

    def plan(self, mount: str, ids: list[str] | None) -> dict[str, Any]:
        """How many of the chosen photos are not on the drive yet."""
        drive = self._drive(mount)
        photos = self._selected(ids)
        pending = [p for p in photos if not self._already_there(drive, p)]
        return {
            "total": len(photos),
            "pending": len(pending),
            "pending_bytes": sum(p.size for p in pending),
            "free_bytes": drive.free_bytes,
        }

    def _already_there(self, drive: Drive, photo: Photo) -> bool:
        try:
            return self._target(drive, photo).stat().st_size == photo.size
        except OSError:
            return False

    def status(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._job)

    def start(self, mount: str, ids: list[str] | None, eject_after: bool = False) -> None:
        """Copy in the background. With `eject_after`, unmount the drive when done."""
        drive = self._drive(mount)
        photos = self._selected(ids)
        with self._lock:
            if self._job["state"] == "running":
                raise RuntimeError("An export is already running.")
            self._job = {
                "state": "running",
                "drive": drive.label,
                "mount": drive.mount,
                "total": len(photos),
                "done": 0,
                "copied": 0,
                "skipped": 0,
                "error": "",
                "ejected": False,
            }
        threading.Thread(target=self._run, args=(drive, photos, eject_after), daemon=True).start()

    def _run(self, drive: Drive, photos: list[Photo], eject_after: bool = False) -> None:
        try:
            for photo in photos:
                target = self._target(drive, photo)
                if self._already_there(drive, photo):
                    self._bump("skipped")
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                tmp = target.with_name(target.name + ".part")
                shutil.copyfile(photo.path, tmp)
                tmp.replace(target)
                self._bump("copied")
            if hasattr(os, "sync"):
                os.sync()
        except Exception as exc:
            logger.exception("export failed")
            with self._lock:
                self._job["state"] = "failed"
                self._job["error"] = _plain_error(exc)
            return
        ejected = False
        if eject_after:
            try:
                self._unmount(drive)
                ejected = True
            except (RuntimeError, OSError, subprocess.SubprocessError) as exc:
                logger.warning("copied, but could not eject %s: %s", drive.label, exc)
        with self._lock:
            self._job["state"] = "done"
            self._job["ejected"] = ejected

    def _bump(self, key: str) -> None:
        with self._lock:
            self._job[key] += 1
            self._job["done"] += 1

    def eject(self, mount: str) -> None:
        drive = self._drive(mount)
        with self._lock:
            if self._job["state"] == "running" and self._job.get("mount") == mount:
                raise RuntimeError("Wait for the copy to finish first.")
        self._unmount(drive)
        with self._lock:
            if self._job.get("mount") == mount:
                self._job = {"state": "idle"}

    def _unmount(self, drive: Drive) -> None:
        """Flush, unmount and power off the drive so it can be pulled out."""
        if hasattr(os, "sync"):
            os.sync()
        if not drive.device:
            return
        result = subprocess.run(
            ["udisksctl", "unmount", "-b", drive.device, "--no-user-interaction"],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout).strip().splitlines()
            raise RuntimeError(
                "The drive could not be ejected. Close any open files on it and try again."
                + (f" ({detail[-1]})" if detail else "")
            )
        self._ejected.add(drive.device)
        # Spin the stick down too, where udisks allows it; unmounted is already safe.
        subprocess.run(
            ["udisksctl", "power-off", "-b", drive.device, "--no-user-interaction"],
            capture_output=True,
            timeout=30,
            check=False,
        )


def _plain_error(exc: Exception) -> str:
    if isinstance(exc, OSError) and exc.errno == 28:
        return "The USB drive is full."
    if isinstance(exc, OSError) and exc.errno in (5, 30):
        return "The USB drive cannot be written to. It may have been removed or be locked."
    return str(exc)
