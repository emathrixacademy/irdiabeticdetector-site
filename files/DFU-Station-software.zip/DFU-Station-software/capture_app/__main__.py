"""Start the capture app server.

    python -m capture_app                 # on the Pi, with the Camera Module 3
    python -m capture_app --fake          # anywhere, with a drawn test camera

Then open http://localhost:8080/ (the kiosk launcher does this on the Pi).
"""

from __future__ import annotations

import argparse
import logging
import os
from pathlib import Path
from typing import Any

from capture_app.camera import Camera, FakeCamera, PiCamera
from capture_app.detector import Detector, find_model
from capture_app.exporter import Exporter, find_drives
from capture_app.library import Library
from capture_app.server import CaptureService, create_app
from capture_app.settings import Settings

logger = logging.getLogger("capture_app")


def _hardware_button(service: CaptureService, pin: int) -> Any:
    """Capture on a push button wired from `pin` (BCM) to ground. Optional."""
    try:
        from gpiozero import Button

        button = Button(pin, pull_up=True, bounce_time=0.05)
    except Exception as exc:
        logger.info("no hardware capture button on GPIO %d: %s", pin, exc)
        return None
    button.when_pressed = service.hardware_button
    logger.info("hardware capture button on GPIO %d", pin)
    return button


def main() -> None:
    home = Path.home()
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--fake", action="store_true", help="use a drawn test camera")
    parser.add_argument("--host", default="127.0.0.1", help="0.0.0.0 to allow other machines")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--photos", type=Path, default=home / "Pictures" / "FootCaptures")
    parser.add_argument("--button-pin", type=int, default=17, help="BCM pin of the capture button")
    parser.add_argument(
        "--test-drive", type=Path, help="treat this folder as a USB drive (for testing)"
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s"
    )
    logging.getLogger("werkzeug").setLevel(logging.WARNING)

    data = Path(os.environ.get("XDG_DATA_HOME", home / ".local" / "share")) / "footcam"
    cache = Path(os.environ.get("XDG_CACHE_HOME", home / ".cache")) / "footcam"
    config = Path(os.environ.get("XDG_CONFIG_HOME", home / ".config")) / "footcam"

    library = Library(args.photos, thumbs=cache / "thumbs", trash=data / "trash")
    library.empty_old_trash()
    camera: Camera = FakeCamera() if args.fake else PiCamera()
    test_drive = args.test_drive
    exporter = Exporter(
        library, drives=lambda: find_drives(extra=test_drive), automount=not args.fake
    )
    model = None if args.fake else find_model()
    detector = Detector(model) if model is not None else None
    if detector is None:
        logger.info("live detection off: no Hailo model found")
    service = CaptureService(
        camera, library, Settings(config / "settings.json"), exporter, detector=detector
    )
    button = None if args.fake else _hardware_button(service, args.button_pin)

    logger.info("photos are saved in %s", library.root)
    try:
        create_app(service).run(host=args.host, port=args.port, threaded=True)
    finally:
        service.stop_camera()
        if button is not None:
            button.close()


if __name__ == "__main__":
    main()
