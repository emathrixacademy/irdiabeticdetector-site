"""Settings kept in a small JSON file, changed from the Settings screen."""

from __future__ import annotations

import json
import logging
import threading
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULTS: dict[str, Any] = {
    "title": "Foot Imaging",
    "subtitle": "Clinical photo capture",
    "quality": "high",  # "high" = 12 MP, "standard" = 3 MP
    "rotate180": False,
    "mirror": False,
    "grid": False,
    "guide": True,
    "detection": True,
    "hardware_button": True,
}

CHOICES: dict[str, tuple[str, ...]] = {"quality": ("high", "standard")}


class Settings:
    def __init__(self, path: Path) -> None:
        self._path = path
        self._lock = threading.Lock()
        self._values = dict(DEFAULTS)
        try:
            stored = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            stored = {}
        except (OSError, ValueError) as exc:
            logger.warning("ignoring unreadable settings file %s: %s", path, exc)
            stored = {}
        if isinstance(stored, dict):
            for key, value in stored.items():
                if self._valid(key, value):
                    self._values[key] = value

    def as_dict(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._values)

    def __getitem__(self, key: str) -> Any:
        with self._lock:
            return self._values[key]

    def update(self, changes: dict[str, Any]) -> dict[str, Any]:
        """Apply the valid keys in `changes`, save, and return the new values."""
        with self._lock:
            for key, value in changes.items():
                if not self._valid(key, value):
                    raise ValueError(f"invalid setting {key}={value!r}")
                self._values[key] = value
            self._path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self._path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self._values, indent=2), encoding="utf-8")
            tmp.replace(self._path)
            return dict(self._values)

    @staticmethod
    def _valid(key: str, value: Any) -> bool:
        if key not in DEFAULTS:
            return False
        if key in CHOICES:
            return value in CHOICES[key]
        return isinstance(value, type(DEFAULTS[key]))
