"""Live object detection on the Hailo accelerator, for the camera preview.

Runs the general-purpose YOLOv8s model that ships with Raspberry Pi OS
(`hailo-models`) on the newest preview frame and keeps the latest boxes for the
screen to draw. It recognises the 80 everyday COCO object classes; it is not a
foot or wound model. Boxes are drawn on the preview only and never written into
saved photos.

`hailo_platform` comes from apt (`hailo-all`) and is imported lazily; without it
the detector reports itself unavailable and the app works as before.
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

MODEL_PATHS = (
    Path("/usr/share/hailo-models/yolov8s_h8l.hef"),
    Path("/usr/share/hailo-models/yolov8s_h8.hef"),
)
INPUT_SIZE = 640
SCORE_THRESHOLD = 0.45
MAX_BOXES = 20

COCO_LABELS = (
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat",
    "traffic light", "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog",
    "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella",
    "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite",
    "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle",
    "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
    "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant",
    "bed", "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone",
    "microwave", "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors",
    "teddy bear", "hair drier", "toothbrush",
)  # fmt: skip


def find_model() -> Path | None:
    return next((p for p in MODEL_PATHS if p.is_file()), None)


def device_name(model: Path) -> str:
    return "Hailo-8L" if "h8l" in model.stem else "Hailo-8"


def letterbox(frame: Any) -> tuple[Any, int]:
    """Pad a wide RGB frame (width INPUT_SIZE) to a square. Returns it and the top padding."""
    import numpy as np

    height = frame.shape[0]
    top = (INPUT_SIZE - height) // 2
    square = np.zeros((INPUT_SIZE, INPUT_SIZE, 3), dtype=np.uint8)
    square[top : top + height] = frame
    return square, top


def parse(output: list[Any], top: int, height: int) -> list[dict[str, Any]]:
    """Boxes from the model's per-class NMS output, as fractions of the original frame."""
    boxes: list[dict[str, Any]] = []
    for class_id, rows in enumerate(output):
        for ymin, xmin, ymax, xmax, score in rows:
            if score < SCORE_THRESHOLD:
                continue
            y0 = (ymin * INPUT_SIZE - top) / height
            y1 = (ymax * INPUT_SIZE - top) / height
            x0, x1 = max(0.0, float(xmin)), min(1.0, float(xmax))
            y0, y1 = max(0.0, float(y0)), min(1.0, float(y1))
            if x1 <= x0 or y1 <= y0:
                continue
            boxes.append(
                {
                    "label": COCO_LABELS[class_id] if class_id < len(COCO_LABELS) else "object",
                    "score": round(float(score), 2),
                    "x": round(x0, 4),
                    "y": round(y0, 4),
                    "w": round(x1 - x0, 4),
                    "h": round(y1 - y0, 4),
                }
            )
    boxes.sort(key=lambda b: b["score"], reverse=True)
    return boxes[:MAX_BOXES]


class Detector:
    def __init__(self, model: Path) -> None:
        self.model = model
        self.device = device_name(model)
        self._frame: Any = None
        self._new_frame = threading.Event()
        self._lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._result: dict[str, Any] = {"active": False, "boxes": [], "fps": 0.0}
        self.error: str | None = None

    def submit(self, frame: Any) -> None:
        """Hand over the newest RGB frame, INPUT_SIZE wide. Older ones are dropped."""
        self._frame = frame
        self._new_frame.set()

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {**self._result, "device": self.device, "error": self.error}

    def start(self, keep_going: Callable[[], bool]) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, args=(keep_going,), name="detector", daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._new_frame.set()
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=3.0)
        with self._lock:
            self._result = {"active": False, "boxes": [], "fps": 0.0}

    def _run(self, keep_going: Callable[[], bool]) -> None:
        try:
            from hailo_platform import (
                HEF,
                ConfigureParams,
                FormatType,
                HailoStreamInterface,
                InferVStreams,
                InputVStreamParams,
                OutputVStreamParams,
                VDevice,
            )

            hef = HEF(str(self.model))
            input_name = hef.get_input_vstream_infos()[0].name
            with VDevice() as device:
                params = ConfigureParams.create_from_hef(hef, interface=HailoStreamInterface.PCIe)
                group = device.configure(hef, params)[0]
                inputs = InputVStreamParams.make(group, format_type=FormatType.UINT8)
                outputs = OutputVStreamParams.make(group, format_type=FormatType.FLOAT32)
                with (
                    InferVStreams(group, inputs, outputs) as pipeline,
                    group.activate(group.create_params()),
                ):
                    self.error = None
                    logger.info("detector running on %s with %s", self.device, self.model.name)
                    self._loop(pipeline, input_name, keep_going)
        except Exception as exc:
            self.error = str(exc)
            logger.exception("detector stopped")
        finally:
            with self._lock:
                self._result = {"active": False, "boxes": [], "fps": 0.0}

    def _loop(self, pipeline: Any, input_name: str, keep_going: Callable[[], bool]) -> None:
        import numpy as np

        times: list[float] = []
        while not self._stop.is_set() and keep_going():
            if not self._new_frame.wait(timeout=1.0):
                continue
            self._new_frame.clear()
            frame = self._frame
            if frame is None:
                continue
            square, top = letterbox(np.ascontiguousarray(frame))
            result = pipeline.infer({input_name: square[np.newaxis]})
            boxes = parse(next(iter(result.values()))[0], top, frame.shape[0])
            now = time.monotonic()
            times = [t for t in times if now - t < 2.0] + [now]
            fps = (len(times) - 1) / (times[-1] - times[0]) if len(times) > 1 else 0.0
            with self._lock:
                self._result = {"active": True, "boxes": boxes, "fps": round(fps, 1)}
