"""The photos on disk.

Every photo is a plain JPEG under the photo folder, one sub-folder per day,
so the files can be opened from the desktop file manager without the app:

    ~/Pictures/FootCaptures/2026-10-21/P-014_L_plantar_20261021_143012.jpg

The file name carries the participant code, foot and view, so nothing is lost
if the files are copied somewhere else. Deleting moves a photo to a trash
folder that is emptied after 30 days, in case a photo is removed by mistake.
"""

from __future__ import annotations

import os
import re
import shutil
import threading
import time
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from PIL import Image

NO_ID = "NOID"
FEET = {"B": "Both", "L": "Left", "R": "Right"}
VIEWS = ("plantar", "dorsal", "medial", "lateral", "heel")
THUMB_SIZE = (480, 480)
TRASH_KEEP_DAYS = 30
LIST_CACHE_S = 10.0

NAME_RE = re.compile(
    r"^(?P<pid>[A-Z0-9-]+)_(?:(?P<foot>[BLR])_)?(?:(?P<view>[a-z]+)_)?"
    r"(?P<ts>\d{8}_\d{6})(?:_(?P<n>\d+))?\.jpg$"
)
ID_RE = re.compile(r"^\d{4}-\d{2}-\d{2}/[A-Za-z0-9_-]+\.jpg$")


def clean_participant(text: str) -> str:
    """Upper-case letters, digits and dashes only, at most 20 characters."""
    return re.sub(r"[^A-Z0-9-]", "", text.upper())[:20].strip("-")


@dataclass(frozen=True)
class Photo:
    id: str
    path: Path
    participant: str
    foot: str
    view: str
    taken: datetime
    size: int

    def to_json(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.path.name,
            "participant": "" if self.participant == NO_ID else self.participant,
            "foot": self.foot,
            "view": self.view,
            "date": self.taken.strftime("%Y-%m-%d"),
            "time": self.taken.strftime("%H:%M:%S"),
            "size": self.size,
        }


class Library:
    def __init__(
        self,
        root: Path,
        thumbs: Path,
        trash: Path,
        now: Callable[[], datetime] = datetime.now,
    ) -> None:
        self.root = root
        self._thumbs = thumbs
        self._trash = trash
        self._now = now
        self._lock = threading.Lock()
        self._cache: list[Photo] | None = None
        self._cached_at = 0.0
        root.mkdir(parents=True, exist_ok=True)

    # ---- naming -----------------------------------------------------------
    def new_path(self, participant: str, foot: str, view: str) -> Path:
        """A fresh, unused path for a photo taken now."""
        stamp = self._now()
        pid = clean_participant(participant) or NO_ID
        parts = [pid]
        if foot in FEET:
            parts.append(foot)
        if view in VIEWS:
            parts.append(view)
        parts.append(stamp.strftime("%Y%m%d_%H%M%S"))
        folder = self.root / stamp.strftime("%Y-%m-%d")
        folder.mkdir(parents=True, exist_ok=True)
        base = "_".join(parts)
        path = folder / f"{base}.jpg"
        n = 2
        while path.exists():
            path = folder / f"{base}_{n}.jpg"
            n += 1
        return path

    # ---- reading ----------------------------------------------------------
    def photos(self) -> list[Photo]:
        """All photos, newest first."""
        with self._lock:
            if self._cache is None or time.monotonic() - self._cached_at > LIST_CACHE_S:
                self._cache = self._scan()
                self._cached_at = time.monotonic()
            return list(self._cache)

    def _scan(self) -> list[Photo]:
        found: list[Photo] = []
        for day in self.root.iterdir():
            if not day.is_dir():
                continue
            for path in day.glob("*.jpg"):
                photo = self._photo(path)
                if photo is not None:
                    found.append(photo)
        found.sort(key=lambda p: (p.taken, p.path.name), reverse=True)
        return found

    def _photo(self, path: Path) -> Photo | None:
        match = NAME_RE.match(path.name)
        if match is None:
            return None
        try:
            taken = datetime.strptime(match["ts"], "%Y%m%d_%H%M%S")
            size = path.stat().st_size
        except (ValueError, OSError):
            return None
        return Photo(
            id=f"{path.parent.name}/{path.name}",
            path=path,
            participant=match["pid"],
            foot=match["foot"] or "",
            view=match["view"] or "",
            taken=taken,
            size=size,
        )

    def get(self, photo_id: str) -> Photo:
        """Look a photo up by id. Raises KeyError for anything not in the folder."""
        if not ID_RE.match(photo_id):
            raise KeyError(photo_id)
        path = self.root / photo_id
        photo = self._photo(path) if path.is_file() else None
        if photo is None:
            raise KeyError(photo_id)
        return photo

    def added(self, path: Path) -> Photo:
        """Register a photo just written by the camera and make its thumbnail."""
        photo = self._photo(path)
        if photo is None:
            raise ValueError(f"not a photo name: {path.name}")
        self._make_thumbnail(photo)
        with self._lock:
            self._cache = None
        return photo

    def thumbnail(self, photo_id: str) -> Path:
        photo = self.get(photo_id)
        thumb = self._thumbs / photo.id
        if not thumb.exists():
            self._make_thumbnail(photo)
        return thumb

    def _make_thumbnail(self, photo: Photo) -> None:
        thumb = self._thumbs / photo.id
        thumb.parent.mkdir(parents=True, exist_ok=True)
        with Image.open(photo.path) as image:
            image.draft("RGB", THUMB_SIZE)  # decode at reduced size: much faster for 12 MP
            image = image.convert("RGB")
            image.thumbnail(THUMB_SIZE)
            tmp = thumb.with_suffix(".tmp")
            image.save(tmp, "JPEG", quality=82)
        tmp.replace(thumb)

    # ---- changing ---------------------------------------------------------
    def delete(self, photo_ids: Iterable[str]) -> int:
        """Move photos to the trash folder. Returns how many were moved."""
        moved = 0
        for photo_id in photo_ids:
            try:
                photo = self.get(photo_id)
            except KeyError:
                continue
            target = self._trash / photo.id
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                target = target.with_name(f"{target.stem}_{int(time.time())}.jpg")
            shutil.move(str(photo.path), str(target))
            os.utime(target)  # the 30 days count from deletion, not from capture
            (self._thumbs / photo.id).unlink(missing_ok=True)
            moved += 1
            day = photo.path.parent
            if day.is_dir() and not any(day.iterdir()):
                day.rmdir()
        with self._lock:
            self._cache = None
        return moved

    def empty_old_trash(self) -> None:
        if not self._trash.is_dir():
            return
        cutoff = time.time() - TRASH_KEEP_DAYS * 86400
        for path in self._trash.rglob("*.jpg"):
            try:
                if path.stat().st_mtime < cutoff:
                    path.unlink()
            except OSError:
                pass

    # ---- totals -----------------------------------------------------------
    def stats(self) -> dict[str, Any]:
        photos = self.photos()
        today = self._now().date()
        usage = shutil.disk_usage(self.root)
        return {
            "total": len(photos),
            "today": sum(1 for p in photos if p.taken.date() == today),
            "bytes": sum(p.size for p in photos),
            "free_bytes": usage.free,
            "disk_bytes": usage.total,
        }
