"""HTTP server behind the touchscreen.

The screen is a web page shown full-screen in Chromium on the Pi. It only
talks to this server, which owns the camera, the photo folder and the USB
export. By default the server listens on the Pi itself only, so the photos are
not reachable from other machines on the network.
"""

from __future__ import annotations

import logging
import os
import subprocess
import threading
import time
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from flask import Flask, Response, abort, jsonify, request, send_file

from capture_app import __version__
from capture_app.camera import Camera, CameraError
from capture_app.detector import Detector
from capture_app.exporter import Exporter
from capture_app.library import FEET, VIEWS, Library, Photo, clean_participant
from capture_app.settings import Settings

logger = logging.getLogger(__name__)

STATIC = Path(__file__).parent / "static"
DOUBLE_PRESS_S = 0.8
# The Chromium profile used by deploy/kiosk.sh; it identifies the app's window.
KIOSK_PROFILE = Path.home() / ".local" / "share" / "footcam" / "browser"
KIOSK_APP_ID = "footcam"


def desktop_env() -> dict[str, str]:
    """Environment for reaching the desktop session from the background service."""
    env = dict(os.environ)
    if hasattr(os, "getuid"):
        runtime = Path(env.get("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}"))
        env["XDG_RUNTIME_DIR"] = str(runtime)
        if "WAYLAND_DISPLAY" not in env:
            sockets = sorted(p.name for p in runtime.glob("wayland-[0-9]"))
            if sockets:
                env["WAYLAND_DISPLAY"] = sockets[0]
    return env


class CaptureService:
    """What both the screen and the hardware button act on."""

    def __init__(
        self,
        camera: Camera,
        library: Library,
        settings: Settings,
        exporter: Exporter,
        detector: Detector | None = None,
    ) -> None:
        self.camera = camera
        self.library = library
        self.settings = settings
        self.exporter = exporter
        self.detector = detector
        # Both feet are photographed together on the stand unless one is chosen.
        self.session: dict[str, str] = {"participant": "", "foot": "B", "view": ""}
        self.last_photo: Photo | None = None
        self.capture_count = 0
        self._capture_lock = threading.Lock()
        self._last_capture = 0.0
        self.apply_camera_settings()

    def apply_camera_settings(self) -> None:
        s = self.settings
        self.camera.configure(rotate180=s["rotate180"], mirror=s["mirror"], quality=s["quality"])
        if self.detector is not None:
            self.detector.stop()  # the camera may have restarted under it
        self._apply_detection()

    def start_camera(self) -> None:
        self.camera.start()
        self._apply_detection()

    def stop_camera(self) -> None:
        if self.detector is not None:
            self.detector.stop()
        self.camera.stop()

    def _apply_detection(self) -> None:
        """Run live detection while the camera is open and the setting is on."""
        detector = self.detector
        if detector is None:
            return
        if self.settings["detection"] and self.camera.running:
            self.camera.frame_listener = detector.submit
            detector.start(keep_going=lambda: self.camera.running)
        else:
            self.camera.frame_listener = None
            detector.stop()

    def detection(self) -> dict[str, Any]:
        if self.detector is None:
            return {"available": False, "active": False, "boxes": []}
        return {"available": True, **self.detector.snapshot()}

    def set_session(self, participant: str, foot: str, view: str) -> dict[str, str]:
        self.session = {
            "participant": clean_participant(participant),
            "foot": foot if foot in FEET else "B",
            "view": view if view in VIEWS else "",
        }
        return self.session

    def capture(self) -> Photo | None:
        """Take one photo. Returns None for a second press while one is being taken."""
        if not self._capture_lock.acquire(blocking=False):
            return None
        try:
            if time.monotonic() - self._last_capture < DOUBLE_PRESS_S:
                return None
            path = self.library.new_path(**self.session)
            self.camera.capture(path)
            photo = self.library.added(path)
            self.last_photo = photo
            self.capture_count += 1
            self._last_capture = time.monotonic()
            logger.info("saved %s", photo.id)
            return photo
        finally:
            self._capture_lock.release()

    def hardware_button(self) -> None:
        if not self.settings["hardware_button"] or not self.camera.running:
            return
        try:
            self.capture()
        except CameraError:
            logger.exception("capture from the hardware button failed")


def create_app(service: CaptureService) -> Flask:
    app = Flask(__name__, static_folder=str(STATIC), static_url_path="/static")
    app.json.sort_keys = False

    def fail(message: str, status: int = 400) -> tuple[Response, int]:
        return jsonify({"error": message}), status

    def body() -> dict[str, Any]:
        data = request.get_json(silent=True)
        return data if isinstance(data, dict) else {}

    @app.after_request
    def no_cache(response: Response) -> Response:
        if request.path.startswith("/api/") or request.path == "/":
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/")
    def index() -> Response:
        return send_file(STATIC / "index.html")

    @app.get("/api/state")
    def state() -> Response:
        last = service.last_photo
        return jsonify(
            {
                "version": __version__,
                "settings": service.settings.as_dict(),
                "session": service.session,
                "stats": service.library.stats(),
                "drives": [d.to_json() for d in service.exporter.drives()],
                "export": service.exporter.status(),
                "camera": {
                    "running": service.camera.running,
                    "error": service.camera.error,
                    "checks": service.camera.checks,
                },
                "capture_count": service.capture_count,
                "last_photo": last.to_json() if last else None,
                "folder": str(service.library.root),
            }
        )

    @app.post("/api/session")
    def session() -> Response:
        data = body()
        return jsonify(
            service.set_session(
                str(data.get("participant", "")),
                str(data.get("foot", "")),
                str(data.get("view", "")),
            )
        )

    @app.post("/api/camera/start")
    def camera_start() -> Response | tuple[Response, int]:
        try:
            service.start_camera()
        except CameraError as exc:
            return fail(str(exc), 503)
        return jsonify({"running": True})

    @app.post("/api/camera/stop")
    def camera_stop() -> Response:
        service.stop_camera()
        return jsonify({"running": False})

    @app.get("/api/camera/checks")
    def camera_checks() -> Response:
        service.camera.keep_alive()
        return jsonify(service.camera.checks)

    @app.get("/api/camera/detections")
    def camera_detections() -> Response:
        return jsonify(service.detection())

    @app.post("/api/camera/focus")
    def camera_focus() -> Response:
        service.camera.focus()
        return jsonify({"ok": True})

    @app.get("/stream.mjpg")
    def stream() -> Response:
        def frames() -> Iterator[bytes]:
            for jpeg in service.camera.frames():
                yield (
                    b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: "
                    + str(len(jpeg)).encode()
                    + b"\r\n\r\n"
                    + jpeg
                    + b"\r\n"
                )

        if not service.camera.running:
            abort(503)
        return Response(
            frames(),
            mimetype="multipart/x-mixed-replace; boundary=frame",
            headers={"Cache-Control": "no-store"},
        )

    @app.post("/api/capture")
    def capture() -> Response | tuple[Response, int]:
        try:
            photo = service.capture()
        except CameraError as exc:
            return fail(str(exc), 503)
        if photo is None:
            return fail("busy", 409)
        return jsonify(photo.to_json())

    @app.get("/api/photos")
    def photos() -> Response:
        return jsonify([p.to_json() for p in service.library.photos()])

    @app.get("/media/photo/<path:photo_id>")
    def photo_file(photo_id: str) -> Response:
        try:
            photo = service.library.get(photo_id)
        except KeyError:
            abort(404)
        return send_file(photo.path, mimetype="image/jpeg", max_age=3600)

    @app.get("/media/thumb/<path:photo_id>")
    def thumb_file(photo_id: str) -> Response:
        try:
            thumb = service.library.thumbnail(photo_id)
        except KeyError:
            abort(404)
        return send_file(thumb, mimetype="image/jpeg", max_age=3600)

    @app.post("/api/photos/delete")
    def delete() -> Response | tuple[Response, int]:
        ids = body().get("ids")
        if not isinstance(ids, list) or not all(isinstance(i, str) for i in ids):
            return fail("ids must be a list")
        removed = service.library.delete(ids)
        if service.last_photo and service.last_photo.id in ids:
            service.last_photo = None
        return jsonify({"deleted": removed})

    def chosen_ids(data: dict[str, Any]) -> list[str] | None:
        ids = data.get("ids")
        return [str(i) for i in ids] if isinstance(ids, list) else None

    @app.post("/api/export/plan")
    def export_plan() -> Response | tuple[Response, int]:
        data = body()
        try:
            return jsonify(service.exporter.plan(str(data.get("mount", "")), chosen_ids(data)))
        except KeyError as exc:
            return fail(str(exc.args[0]), 404)

    @app.post("/api/export")
    def export() -> Response | tuple[Response, int]:
        data = body()
        try:
            service.exporter.start(
                str(data.get("mount", "")),
                chosen_ids(data),
                eject_after=bool(data.get("eject_after", False)),
            )
        except KeyError as exc:
            return fail(str(exc.args[0]), 404)
        except RuntimeError as exc:
            return fail(str(exc), 409)
        return jsonify(service.exporter.status())

    @app.post("/api/eject")
    def eject() -> Response | tuple[Response, int]:
        try:
            service.exporter.eject(str(body().get("mount", "")))
        except KeyError as exc:
            return fail(str(exc.args[0]), 404)
        except (RuntimeError, OSError, subprocess.SubprocessError) as exc:
            return fail(str(exc), 409)
        return jsonify({"ok": True})

    @app.post("/api/settings")
    def settings() -> Response | tuple[Response, int]:
        try:
            values = service.settings.update(body())
        except ValueError as exc:
            return fail(str(exc))
        service.apply_camera_settings()
        return jsonify(values)

    @app.post("/api/window/<action>")
    def window(action: str) -> Response | tuple[Response, int]:
        if action == "minimize":
            command = ["wlrctl", "toplevel", "minimize", f"app_id:{KIOSK_APP_ID}"]
        elif action == "exit":
            service.stop_camera()
            command = ["pkill", "-f", "--", f"--user-data-dir={KIOSK_PROFILE}"]
        else:
            abort(404)
        try:
            result = subprocess.run(
                command, env=desktop_env(), capture_output=True, timeout=5, check=False
            )
        except (OSError, subprocess.SubprocessError) as exc:
            return fail(f"Not available on this machine: {exc}", 501)
        if result.returncode != 0 and action == "minimize":
            return fail("The window could not be minimized.", 501)
        return jsonify({"ok": True})

    @app.post("/api/system/<action>")
    def system(action: str) -> Response | tuple[Response, int]:
        commands = {
            "shutdown": ["systemctl", "poweroff"],
            "reboot": ["systemctl", "reboot"],
        }
        if action not in commands:
            abort(404)
        service.stop_camera()
        try:
            subprocess.Popen(commands[action])
        except OSError as exc:
            return fail(f"Not available on this machine: {exc}", 501)
        return jsonify({"ok": True})

    return app
