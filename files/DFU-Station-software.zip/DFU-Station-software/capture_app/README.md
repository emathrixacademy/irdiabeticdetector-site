# Photo capture app

A touchscreen app for taking foot photos with the Camera Module 3 on the
Raspberry Pi 5. It is separate from the thermography station in `src/` and
needs only the colour camera.

## Install on the Pi

Raspberry Pi OS (desktop, 64-bit), camera connected, repository copied to the
Pi. As the desktop user:

```sh
cd ~/irdiabeticdetector
sh capture_app/deploy/install.sh
sudo reboot
```

After the reboot the Pi logs in to the desktop and the app opens full-screen.
The installer:

- installs `python3-picamera2`, `python3-flask`, `python3-pil`, `python3-gpiozero`
  and Chromium from apt (no virtual environment is needed);
- runs the app as the user service `footcam` (restarts if it ever stops);
- opens it full-screen at login, and puts a **Foot Imaging** icon on the desktop
  and in the app menu so it can be reopened with one tap after **Exit to desktop**;
- turns on desktop auto-login and turns off screen blanking.

`sh capture_app/deploy/install.sh --remove` takes it all off again. Photos are
never removed by the installer.

## Where the photos go

```
~/Pictures/FootCaptures/2026-10-21/P-014_L_plantar_20261021_143012.jpg
                        day        code  foot view   date     time
```

Plain JPEG files, 12 MP by default (3 MP in Settings). They can be opened from
the desktop file manager without the app. **Export to USB** copies them to
`FootCaptures/` on a flash drive, one folder per day, skipping any photo that is
already there, so pressing it again only copies new ones.

Deleted photos go to `~/.local/share/footcam/trash/` and are removed after 30
days, in case something is deleted by mistake.

## Screens

| Screen | What it does |
|---|---|
| Home | New capture, Gallery, Export to USB, Settings, recent photos |
| New capture | Participant code (on-screen keypad), foot (both feet by default, or left or right only), view (optional) |
| Camera | Live preview, positioning guide, **Focus** and **Light** indicators, tap to focus, capture button, quick Both / L / R switch, **Undo** for 6 s after each photo |

The foot letter in the file name is `B` (both feet), `L` or `R`.

The indicators are plain photo checks, not a model: **Focus** is the camera's
own autofocus state (Sharp, Focusing, Blurry) and **Light** is the preview's
brightness (Good, Too dark, Too bright). If a photo is taken while either is
not green, the confirmation after the capture says so, and Undo removes it.
| Gallery | Photos by day; tap to view full size; **Select** to delete or export several |
| Export to USB | Copy all, or the selected photos, to a flash drive; eject it safely |
| Settings | Image size, rotate 180°, mirror, grid lines, hardware button, storage, restart, shut down |

A push button wired from GPIO 17 (BCM) to ground also takes a photo while the
camera screen is open. It can be switched off in Settings.

## Working on it from a laptop

```sh
pip install flask pillow
python -m capture_app --fake --port 8080
```

Open http://localhost:8080/. `--fake` draws a test scene in place of the
camera. `--test-drive <folder>` makes a folder appear as a USB drive.
`http://localhost:8080/#gallery` (or `#camera`, `#export`, `#settings`) opens a
screen directly.

## Notes

- The server listens on the Pi only (`127.0.0.1`), so the photos cannot be
  reached from other machines on the Wi-Fi. `--host 0.0.0.0` opens it up; only
  do that on a network you trust, as there is no login.
- Logs: `journalctl --user -u footcam -f`.
- Camera check: `rpicam-hello --list-cameras` should list `imx708`.
