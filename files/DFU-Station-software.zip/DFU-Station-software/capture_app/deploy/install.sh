#!/bin/sh
# Install the capture app on Raspberry Pi OS (desktop, 64-bit).
#
#   sh capture_app/deploy/install.sh              install; open it from the desktop icon
#   sh capture_app/deploy/install.sh --autostart  same, and also open it at every login
#   sh capture_app/deploy/install.sh --remove     stop and remove (photos are kept)
#
# Run as the desktop user (not root), from anywhere inside the repository.
set -eu

APP_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
DEPLOY="$APP_DIR/capture_app/deploy"
UNIT_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"
AUTOSTART="${XDG_CONFIG_HOME:-$HOME/.config}/autostart/footcam-kiosk.desktop"
MENU="$HOME/.local/share/applications/footcam.desktop"
ICON="$HOME/Desktop/footcam.desktop"
LIBFM="${XDG_CONFIG_HOME:-$HOME/.config}/libfm/libfm.conf"
LABWC="${XDG_CONFIG_HOME:-$HOME/.config}/labwc/autostart"
KIOSK_LINE="sh $DEPLOY/kiosk.sh &"

if [ "$(id -u)" -eq 0 ]; then
    echo "Run this as the desktop user, not as root." >&2
    exit 1
fi

if [ "${1:-}" = "--remove" ]; then
    systemctl --user disable --now footcam.service 2>/dev/null || true
    rm -f "$UNIT_DIR/footcam.service" "$AUTOSTART" "$MENU" "$ICON"
    sudo rm -f /etc/polkit-1/rules.d/50-footcam-usb.rules
    if [ -f "$LABWC" ]; then
        grep -vF "$DEPLOY/kiosk.sh" "$LABWC" > "$LABWC.tmp" || true
        mv "$LABWC.tmp" "$LABWC"
    fi
    systemctl --user daemon-reload
    echo "Removed. Photos in ~/Pictures/FootCaptures were not touched."
    exit 0
fi

echo "== Installing packages"
sudo apt-get update
sudo apt-get install -y python3-picamera2 python3-flask python3-pil python3-gpiozero curl wlrctl
if ! command -v chromium >/dev/null 2>&1 && ! command -v chromium-browser >/dev/null 2>&1; then
    sudo apt-get install -y chromium || sudo apt-get install -y chromium-browser
fi

echo "== Checking the camera"
if command -v rpicam-hello >/dev/null 2>&1; then
    rpicam-hello --list-cameras 2>&1 | head -n 5 || true
fi

echo "== USB drives for export"
# The app mounts flash drives itself; this lets it do so without a password.
sudo mkdir -p /etc/polkit-1/rules.d
sudo cp "$DEPLOY/50-footcam-usb.rules" /etc/polkit-1/rules.d/50-footcam-usb.rules
id -nG "$USER" | grep -qw plugdev || sudo usermod -aG plugdev "$USER"

echo "== App service"
mkdir -p "$UNIT_DIR" "$HOME/Pictures/FootCaptures"
sed "s|@APP_DIR@|$APP_DIR|g" "$DEPLOY/footcam.service" > "$UNIT_DIR/footcam.service"
systemctl --user daemon-reload
systemctl --user enable --now footcam.service
sudo loginctl enable-linger "$USER"

echo "== Desktop icon and app menu entry"
mkdir -p "$(dirname "$MENU")" "$(dirname "$ICON")"
for target in "$MENU" "$ICON"; do
    sed "s|@DEPLOY@|$DEPLOY|g" "$DEPLOY/footcam.desktop" > "$target"
done
if [ "${1:-}" = "--autostart" ]; then
    # Optional: open the app full-screen at every login as well.
    mkdir -p "$(dirname "$AUTOSTART")" "$(dirname "$LABWC")"
    sed "s|@DEPLOY@|$DEPLOY|g" "$DEPLOY/footcam.desktop" > "$AUTOSTART"
    touch "$LABWC"
    grep -qF "$DEPLOY/kiosk.sh" "$LABWC" || echo "$KIOSK_LINE" >> "$LABWC"
else
    rm -f "$AUTOSTART"
    if [ -f "$LABWC" ]; then
        grep -vF "$DEPLOY/kiosk.sh" "$LABWC" > "$LABWC.tmp" || true
        mv "$LABWC.tmp" "$LABWC"
    fi
fi
chmod +x "$ICON"
# Open desktop icons with a single tap, without the file manager asking "Execute?" first.
mkdir -p "$(dirname "$LIBFM")"
[ -f "$LIBFM" ] || printf '[config]\n' > "$LIBFM"
grep -q '^\[config\]' "$LIBFM" || printf '\n[config]\n' >> "$LIBFM"
for key in quick_exec single_click; do
    if grep -q "^$key=" "$LIBFM"; then
        sed -i "s/^$key=.*/$key=1/" "$LIBFM"
    else
        sed -i "s/^\[config\]/[config]\n$key=1/" "$LIBFM"
    fi
done
gio set "$ICON" metadata::trusted true 2>/dev/null || true
# The desktop reads these at start; restart it so the icon shows its name now.
pkill -f "pcmanfm.*--desktop" 2>/dev/null || true

echo "== Desktop auto-login, no screen blanking, on-screen keyboard"
if command -v raspi-config >/dev/null 2>&1; then
    sudo raspi-config nonint do_boot_behaviour B4 || true
    sudo raspi-config nonint do_blanking 1 || true
    # "Always on": the keyboard pops up whenever a text field is tapped. The
    # touch-panel autodetect option misses some USB touch controllers.
    sudo raspi-config nonint do_squeekboard S1 || true
fi

echo
echo "Installed. Photos are saved in $HOME/Pictures/FootCaptures"
echo "  Show the screen now:  sh $DEPLOY/kiosk.sh &"
echo "  App status:           systemctl --user status footcam"
echo "  App log:              journalctl --user -u footcam -f"
echo "Reboot to check that it starts by itself:  sudo reboot"
