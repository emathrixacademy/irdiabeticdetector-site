#!/bin/sh
# Show the capture app full-screen. Started at login; safe to run twice.
set -u

URL="http://localhost:8080/?kiosk=1"
PROFILE="$HOME/.local/share/footcam/browser"
APP_ID="footcam"   # window id, used to find the window again

PLATFORM=""
if [ -n "${WAYLAND_DISPLAY:-}" ]; then
    # Wayland, with text input so the on-screen keyboard appears for any text field.
    PLATFORM="--ozone-platform=wayland --enable-wayland-ime --wayland-text-input-version=3"
fi

# Already open (perhaps minimized): bring it back instead of opening a second one.
if pgrep -f -- "--user-data-dir=$PROFILE" >/dev/null 2>&1; then
    wlrctl toplevel focus "app_id:$APP_ID" >/dev/null 2>&1 || true
    exit 0
fi

# Wait for the app service (it starts with the Pi, usually within seconds).
i=0
while [ "$i" -lt 60 ] && ! curl -fs -o /dev/null http://localhost:8080/api/state; do
    sleep 1
    i=$((i + 1))
done

BROWSER="$(command -v chromium || command -v chromium-browser)"
mkdir -p "$PROFILE"
# A clean exit flag stops Chromium offering to "restore pages" after a power cut.
sed -i 's/"exited_cleanly":false/"exited_cleanly":true/; s/"exit_type":"[^"]*"/"exit_type":"Normal"/' \
    "$PROFILE/Default/Preferences" 2>/dev/null || true

exec "$BROWSER" --kiosk --noerrdialogs --disable-infobars --no-first-run \
    --disable-session-crashed-bubble --disable-features=TranslateUI \
    --overscroll-history-navigation=0 --disable-pinch \
    --check-for-update-interval=31536000 --password-store=basic \
    --class="$APP_ID" $PLATFORM --user-data-dir="$PROFILE" "$URL"
