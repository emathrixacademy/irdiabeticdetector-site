"use strict";

/* Screens: home, session, camera, gallery, export, settings. The viewer and
   the confirm dialog sit on top of whichever screen is open. All state that
   matters lives on the server; this file only draws it and sends taps. */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const VIEW_NAMES = { plantar: "Plantar", dorsal: "Dorsal", medial: "Medial", lateral: "Lateral", heel: "Heel" };
const FOOT_NAMES = { B: "Both feet", L: "Left", R: "Right" };
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

let state = null;          // last /api/state
let screen = "home";
let session = { participant: "", foot: "", view: "" };

// ------------------------------------------------------------------ helpers
async function api(path, body) {
  const opts = body === undefined ? {} : {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  };
  const res = await fetch(path, opts);
  let data = null;
  try { data = await res.json(); } catch (_) { /* empty body */ }
  if (!res.ok) {
    const err = new Error((data && data.error) || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

function bytes(n) {
  if (n >= 1e9) return (n / 1e9).toFixed(1) + " GB";
  if (n >= 1e6) return Math.round(n / 1e6) + " MB";
  if (n >= 1e3) return Math.round(n / 1e3) + " KB";
  return n + " B";
}

function plural(n, word) { return `${n} ${word}${n === 1 ? "" : "s"}`; }

function isoDate(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function dayLabel(iso) {
  const today = new Date();
  const yesterday = new Date(today.getTime() - 86400000);
  if (iso === isoDate(today)) return "Today";
  if (iso === isoDate(yesterday)) return "Yesterday";
  const [y, m, d] = iso.split("-").map(Number);
  const date = new Date(y, m - 1, d);
  return `${DAYS[date.getDay()]}, ${d} ${MONTHS[m - 1]} ${y}`;
}

function photoTitle(p) {
  return p.participant || "No code";
}

function photoDetail(p) {
  return [FOOT_NAMES[p.foot], VIEW_NAMES[p.view]].filter(Boolean).join(" · ");
}

function thumbUrl(id) { return "/media/thumb/" + id.split("/").map(encodeURIComponent).join("/"); }
function photoUrl(id) { return "/media/photo/" + id.split("/").map(encodeURIComponent).join("/"); }

let toastTimer = 0;
function toast(text, bad = false) {
  const el = $("#toast");
  el.textContent = text;
  el.classList.toggle("bad", bad);
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), bad ? 4200 : 2600);
}

function confirmBox(title, text, okLabel, danger = false) {
  return new Promise((resolve) => {
    $("#dialog-title").textContent = title;
    $("#dialog-text").textContent = text;
    const ok = $("#dialog-ok");
    ok.textContent = okLabel;
    ok.className = danger ? "btn danger solid" : "btn primary";
    const scrim = $("#dialog");
    scrim.classList.add("show");
    const done = (answer) => {
      scrim.classList.remove("show");
      ok.onclick = null; $("#dialog-cancel").onclick = null;
      resolve(answer);
    };
    ok.onclick = () => done(true);
    $("#dialog-cancel").onclick = () => done(false);
  });
}

// ------------------------------------------------------------------ navigation
const leaving = {
  camera: () => stopCamera(),
  gallery: () => endSelect(),
};

function go(name) {
  if (name === screen) return;
  if (leaving[screen]) leaving[screen]();
  $$(".screen").forEach((s) => s.classList.toggle("active", s.id === "screen-" + name));
  screen = name;
  const entering = { home: renderHome, session: openSession, camera: openCamera,
    gallery: openGallery, export: openExport, settings: renderSettings };
  if (entering[name]) entering[name]();
}

document.addEventListener("click", (e) => {
  const target = e.target.closest("[data-go]");
  if (target) go(target.dataset.go);
});
document.addEventListener("contextmenu", (e) => e.preventDefault());

// ------------------------------------------------------------------ polling
async function refresh() {
  try {
    state = await api("/api/state");
  } catch (_) {
    return;
  }
  session = state.session;
  noticeNewDrives();
  $("#app-title").textContent = state.settings.title;
  $("#app-subtitle").textContent = state.settings.subtitle;
  document.title = state.settings.title;
  if (screen === "home") renderHome();
  if (screen === "export") renderExport();
  if (screen === "camera") cameraTick();
  if (screen === "settings") renderStorage();
}

let knownDrives = null;   // mounts seen on the last refresh; null until the first one
function noticeNewDrives() {
  const mounts = state.drives.map((d) => d.mount);
  if (knownDrives !== null && screen !== "camera") {
    const fresh = state.drives.find((d) => !knownDrives.includes(d.mount));
    if (fresh) toast(`USB drive connected: ${fresh.label}. Tap Export to USB to copy the photos.`);
  }
  knownDrives = mounts;
}

function tickClock() {
  const now = new Date();
  $("#clock-time").textContent = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  $("#clock-date").textContent = `${DAYS[now.getDay()]}, ${now.getDate()} ${MONTHS[now.getMonth()]} ${now.getFullYear()}`;
}

// ------------------------------------------------------------------ home
let recentKey = "";
async function renderHome() {
  if (!state) return;
  const s = state.stats;
  $("#home-photos").textContent = s.total ? `${plural(s.total, "photo")} · ${s.today} today` : "No photos yet";
  const drive = state.drives[0];
  $("#home-usb").textContent = drive ? `${drive.label} connected · tap to copy photos` : "Insert a USB flash drive";
  $("#home-export").classList.toggle("ready", !!drive);
  $("#home-today").textContent = `${bytes(s.free_bytes)} free on this device`;

  const key = `${s.total}:${state.capture_count}`;
  if (key === recentKey) return;
  recentKey = key;
  let photos = [];
  try { photos = await api("/api/photos"); } catch (_) { return; }
  const box = $("#recent");
  box.innerHTML = "";
  if (!photos.length) {
    box.innerHTML = '<span class="empty">Photos you take will appear here.</span>';
    return;
  }
  photos.slice(0, 10).forEach((p, i) => {
    const img = document.createElement("img");
    img.src = thumbUrl(p.id);
    img.alt = "";
    img.draggable = false;
    img.onclick = () => openViewer(photos, i);
    box.appendChild(img);
  });
}

// ------------------------------------------------------------------ session
// [key, columns spanned]. Digits: 4 columns x 4 rows. Letters: 8 columns x 4 rows.
const KEYS = {
  digits: [["1"], ["2"], ["3"], ["DEL"], ["4"], ["5"], ["6"], ["CLR"],
           ["7"], ["8"], ["9"], ["ABC"], ["0", 3], ["-"]],
  letters: [..."ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").map((k) => [k]),
            ["-"], ["CLR"], ["123", 2], ["DEL", 2]],
};
let keypadMode = "digits";

function drawKeypad() {
  const pad = $("#keypad");
  pad.className = "keypad " + keypadMode;
  pad.innerHTML = "";
  KEYS[keypadMode].forEach(([k, span]) => {
    const b = document.createElement("button");
    if (span) b.style.gridColumn = `span ${span}`;
    if (k === "DEL") {
      b.innerHTML = '<svg><use href="#i-backspace"/></svg>';
      b.className = "fn";
    } else if (k === "ABC" || k === "123" || k === "CLR") {
      b.textContent = k === "CLR" ? "Clear" : k;
      b.className = "fn";
    } else {
      b.textContent = k;
    }
    b.onclick = () => keyPress(k);
    pad.appendChild(b);
  });
}

function keyPress(k) {
  let code = session.participant;
  if (k === "ABC") { keypadMode = "letters"; drawKeypad(); return; }
  if (k === "123") { keypadMode = "digits"; drawKeypad(); return; }
  if (k === "DEL") code = code.slice(0, -1);
  else if (k === "CLR") code = "";
  else if (code.length < 20) code += k;
  session.participant = code;
  drawSession();
}

function drawSession() {
  const text = $("#code-text");
  if (session.participant) {
    text.textContent = session.participant;
    text.className = "";
  } else {
    text.textContent = "e.g. P-001";
    text.className = "placeholder";
  }
  $$("#foot-seg button").forEach((b) => b.classList.toggle("on", b.dataset.foot === session.foot));
  $$("#view-chips button").forEach((b) => b.classList.toggle("on", b.dataset.view === session.view));
  const parts = [session.participant || "NOID", session.foot, session.view, "date_time"].filter(Boolean);
  $("#name-preview").innerHTML = `Saved as <b>${parts.join("_")}.jpg</b>`;
}

function openSession() {
  if (state) session = { ...state.session };
  if (!session.foot) session.foot = "B";
  keypadMode = "digits";
  drawKeypad();
  drawSession();
}

$$("#foot-seg button").forEach((b) => b.onclick = () => { session.foot = b.dataset.foot; drawSession(); });
$$("#view-chips button").forEach((b) => b.onclick = () => {
  session.view = session.view === b.dataset.view ? "" : b.dataset.view;
  drawSession();
});
$("#open-camera").onclick = async () => {
  try {
    session = await api("/api/session", session);
  } catch (e) { toast(e.message, true); return; }
  go("camera");
};

// ------------------------------------------------------------------ camera
let shots = [];            // photos taken since the camera screen opened
let seenCaptures = 0;
let snackTimer = 0;

function sessionLabel() {
  const parts = [session.participant || "No code", FOOT_NAMES[session.foot], VIEW_NAMES[session.view]];
  return parts.filter(Boolean).join("  ·  ");
}

function drawCameraChrome() {
  $("#vf-session").innerHTML = `<svg><use href="#i-person"/></svg>${sessionLabel()}`;
  $$("#cam-foot button").forEach((b) => b.classList.toggle("on", b.dataset.foot === session.foot));
  $("#thirds").classList.toggle("on", !!(state && state.settings.grid));
  const guide = !!(state && state.settings.guide);
  $("#guide").classList.toggle("on", guide);
  $("#vf-hint").textContent = guide ? "Place both feet inside the frame  ·  Tap to focus" : "Tap the image to focus";
  const last = shots[shots.length - 1];
  const img = $("#last-shot-img");
  if (last) img.src = thumbUrl(last.id); else img.removeAttribute("src");
  const badge = $("#shot-count");
  badge.textContent = shots.length ? String(shots.length) : "";
}

function vfMessage(text) {
  const el = $("#vf-message");
  el.textContent = text || "";
  el.classList.toggle("hidden", !text);
}

async function openCamera() {
  shots = [];
  seenCaptures = state ? state.capture_count : 0;
  drawCameraChrome();
  vfMessage("Starting camera…");
  const img = $("#stream");
  img.removeAttribute("src");
  try {
    await api("/api/camera/start", {});
  } catch (e) {
    vfMessage("The camera could not be started.\nCheck that the camera ribbon cable is seated firmly, then go back and try again.");
    return;
  }
  if (screen !== "camera") return;
  startChecks();
  img.onload = () => vfMessage("");
  img.onerror = () => vfMessage("Camera stream lost. Go back and open the camera again.");
  img.src = "/stream.mjpg?t=" + Date.now();
}

// ---- focus and light indicators
const CHECK_TEXT = {
  focus: { ok: ["ok", "Sharp"], adjusting: ["warn", "Focusing"], poor: ["bad", "Blurry"] },
  light: { ok: ["ok", "Good"], dark: ["warn", "Too dark"], bright: ["warn", "Too bright"] },
};
let checks = { focus: "unknown", light: "unknown" };
let checkTimer = 0;

function drawChecks() {
  for (const key of ["focus", "light"]) {
    const el = $("#chk-" + key);
    const [cls, word] = CHECK_TEXT[key][checks[key]] || ["", "…"];
    el.className = "check " + cls;
    $("span", el).textContent = word;
  }
}

function startChecks() {
  clearInterval(checkTimer);
  checks = { focus: "unknown", light: "unknown" };
  drawChecks();
  $("#vf-checks").classList.remove("hidden");
  startDetections();
  checkTimer = setInterval(async () => {
    if (screen !== "camera") return;
    try { checks = await api("/api/camera/checks"); drawChecks(); } catch (_) { /* next tick */ }
  }, 700);
}

function stopChecks() {
  clearInterval(checkTimer);
  $("#vf-checks").classList.add("hidden");
  stopDetections();
}

// ---- live detection boxes from the Hailo accelerator (preview only)
let detectTimer = 0;
let detectBusy = false;

function startDetections() {
  stopDetections();
  if (!(state && state.settings.detection)) return;
  detectTimer = setInterval(async () => {
    if (screen !== "camera" || detectBusy) return;
    detectBusy = true;
    try { drawDetections(await api("/api/camera/detections")); } catch (_) { /* next tick */ }
    detectBusy = false;
  }, 150);
}

function stopDetections() {
  clearInterval(detectTimer);
  $("#boxes").innerHTML = "";
  $("#ai-chip").classList.remove("on");
}

function drawDetections(d) {
  const chip = $("#ai-chip");
  if (!d.available) { chip.classList.remove("on"); $("#boxes").innerHTML = ""; return; }
  chip.classList.add("on");
  chip.classList.toggle("idle", !d.active);
  $("#ai-text").textContent = d.active
    ? `${d.device}  ·  ${Math.round(d.fps)} fps`
    : (d.error ? `${d.device}  ·  unavailable` : `${d.device}  ·  starting`);
  const box = $("#boxes");
  box.innerHTML = "";
  (d.boxes || []).forEach((b) => {
    const el = document.createElement("div");
    el.className = "box" + (b.y < 0.06 ? " low" : "");
    el.style.left = (b.x * 100) + "%";
    el.style.top = (b.y * 100) + "%";
    el.style.width = (b.w * 100) + "%";
    el.style.height = (b.h * 100) + "%";
    const tag = document.createElement("span");
    tag.textContent = `${b.label} ${Math.round(b.score * 100)}%`;
    el.appendChild(tag);
    box.appendChild(el);
  });
}

function checkWarning() {
  if (checks.focus === "poor" || checks.focus === "adjusting") return "Saved, but it may be blurry";
  if (checks.light === "dark") return "Saved, but it is quite dark";
  if (checks.light === "bright") return "Saved, but it is very bright";
  return "";
}

function stopCamera() {
  stopChecks();
  const img = $("#stream");
  img.onload = img.onerror = null;
  img.removeAttribute("src");
  hideSnack();
  api("/api/camera/stop", {}).catch(() => {});
}

function cameraTick() {
  // A photo taken with the hardware button shows up here.
  if (!state || state.capture_count === seenCaptures) return;
  seenCaptures = state.capture_count;
  const p = state.last_photo;
  if (p && !shots.some((s) => s.id === p.id)) {
    shots.push(p);
    flash();
    drawCameraChrome();
    showSnack(p);
  }
}

function flash() {
  const f = $("#flash");
  f.classList.remove("go");
  void f.offsetWidth;
  f.classList.add("go");
}

$("#shutter").onclick = async () => {
  const btn = $("#shutter");
  if (btn.classList.contains("busy")) return;
  btn.classList.add("busy");
  flash();
  try {
    const p = await api("/api/capture", {});
    seenCaptures += 1;
    shots.push(p);
    drawCameraChrome();
    showSnack(p);
  } catch (e) {
    if (e.status !== 409) toast(e.message, true);
  } finally {
    btn.classList.remove("busy");
  }
};

function showSnack(p) {
  const warning = checkWarning();
  $("#snackbar").classList.toggle("warn", !!warning);
  $(".snack-text strong").textContent = warning || "Photo saved";
  $("#snack-img").src = thumbUrl(p.id);
  $("#snack-name").textContent = p.name;
  $("#snack-undo").onclick = () => undoShot(p);
  $("#snackbar").classList.add("show");
  clearTimeout(snackTimer);
  snackTimer = setTimeout(hideSnack, 6000);
}

function hideSnack() {
  clearTimeout(snackTimer);
  $("#snackbar").classList.remove("show");
}

async function undoShot(p) {
  hideSnack();
  try {
    await api("/api/photos/delete", { ids: [p.id] });
  } catch (e) { toast(e.message, true); return; }
  shots = shots.filter((s) => s.id !== p.id);
  drawCameraChrome();
  toast("Photo deleted");
}

$("#viewfinder").addEventListener("click", (e) => {
  if (e.target.closest("button")) return;
  const vf = $("#viewfinder").getBoundingClientRect();
  const ring = $("#focus-ring");
  ring.style.left = (e.clientX - vf.left) + "px";
  ring.style.top = (e.clientY - vf.top) + "px";
  ring.classList.add("show");
  api("/api/camera/focus", {}).catch(() => {}).finally(() => setTimeout(() => ring.classList.remove("show"), 250));
});

$$("#cam-foot button").forEach((b) => b.onclick = async () => {
  session.foot = b.dataset.foot;
  try { session = await api("/api/session", session); } catch (e) { toast(e.message, true); }
  drawCameraChrome();
});
$("#vf-session").onclick = () => go("session");
$("#cam-done").onclick = () => go("home");
$("#last-shot").onclick = () => {
  if (shots.length) openViewer([...shots].reverse(), 0, (removed) => {
    shots = shots.filter((s) => !removed.includes(s.id));
    drawCameraChrome();
  });
};

// ------------------------------------------------------------------ viewer
let viewerList = [];
let viewerIndex = 0;
let viewerRemoved = [];
let viewerOnClose = null;

function openViewer(list, index, onClose = null) {
  viewerList = list.slice();
  viewerIndex = index;
  viewerRemoved = [];
  viewerOnClose = onClose;
  $("#viewer").classList.add("show");
  drawViewer();
}

function drawViewer() {
  if (!viewerList.length) { closeViewer(); return; }
  viewerIndex = Math.max(0, Math.min(viewerIndex, viewerList.length - 1));
  const p = viewerList[viewerIndex];
  $("#viewer-img").src = photoUrl(p.id);
  $("#viewer-title").textContent = [photoTitle(p), photoDetail(p)].filter(Boolean).join("  ·  ");
  $("#viewer-sub").textContent = `${dayLabel(p.date)}, ${p.time}  ·  ${p.name}`;
  $("#viewer-pos").textContent = `${viewerIndex + 1} of ${viewerList.length}`;
  $("#viewer-prev").disabled = viewerIndex === 0;
  $("#viewer-next").disabled = viewerIndex === viewerList.length - 1;
}

function closeViewer() {
  $("#viewer").classList.remove("show");
  $("#viewer-img").removeAttribute("src");
  if (viewerOnClose) viewerOnClose(viewerRemoved);
  viewerOnClose = null;
}

$("#viewer-close").onclick = closeViewer;
$("#viewer-prev").onclick = () => { viewerIndex -= 1; drawViewer(); };
$("#viewer-next").onclick = () => { viewerIndex += 1; drawViewer(); };
$("#viewer-delete").onclick = async () => {
  const p = viewerList[viewerIndex];
  const ok = await confirmBox("Delete this photo?", `${p.name} will be removed from the gallery.`, "Delete", true);
  if (!ok) return;
  try { await api("/api/photos/delete", { ids: [p.id] }); } catch (e) { toast(e.message, true); return; }
  viewerRemoved.push(p.id);
  viewerList.splice(viewerIndex, 1);
  toast("Photo deleted");
  drawViewer();
};

let swipeX = null;
$("#viewer").addEventListener("touchstart", (e) => { swipeX = e.touches[0].clientX; }, { passive: true });
$("#viewer").addEventListener("touchend", (e) => {
  if (swipeX === null) return;
  const dx = e.changedTouches[0].clientX - swipeX;
  swipeX = null;
  if (Math.abs(dx) < 60) return;
  if (dx < 0 && viewerIndex < viewerList.length - 1) viewerIndex += 1;
  else if (dx > 0 && viewerIndex > 0) viewerIndex -= 1;
  drawViewer();
});

// ------------------------------------------------------------------ gallery
let galleryPhotos = [];
let galleryFilter = "all";
let picked = new Set();

async function openGallery() {
  $("#gallery").innerHTML = "";
  try { galleryPhotos = await api("/api/photos"); } catch (e) { toast(e.message, true); return; }
  drawGallery();
}

function visiblePhotos() {
  if (galleryFilter === "today") {
    const today = isoDate(new Date());
    return galleryPhotos.filter((p) => p.date === today);
  }
  return galleryPhotos;
}

function drawGallery() {
  const list = visiblePhotos();
  $("#gallery-count").textContent = galleryPhotos.length
    ? `${plural(galleryPhotos.length, "photo")}  ·  press and hold a photo to select`
    : "No photos";
  $$("#gallery-filter button").forEach((b) => b.classList.toggle("on", b.dataset.filter === galleryFilter));
  const box = $("#gallery");
  box.innerHTML = "";
  if (!list.length) {
    box.innerHTML = `<div class="empty-state"><div class="big-icon"><svg><use href="#i-images"/></svg></div>
      <b>${galleryFilter === "today" ? "No photos today" : "No photos yet"}</b>
      <p>Photos taken from New capture are listed here, newest first.</p></div>`;
    $("#select-start").disabled = true;
    return;
  }
  $("#select-start").disabled = false;
  const days = new Map();
  list.forEach((p) => { if (!days.has(p.date)) days.set(p.date, []); days.get(p.date).push(p); });
  days.forEach((photos, date) => {
    const head = document.createElement("div");
    head.className = "day-head";
    head.innerHTML = `<b>${dayLabel(date)}</b><span>${plural(photos.length, "photo")}</span>`;
    box.appendChild(head);
    const grid = document.createElement("div");
    grid.className = "day-grid";
    photos.forEach((p) => {
      const t = document.createElement("button");
      t.className = "thumb" + (picked.has(p.id) ? " picked" : "");
      t.dataset.id = p.id;
      t.innerHTML = `<img loading="lazy" draggable="false" alt="" src="${thumbUrl(p.id)}">
        <span class="tick"><svg><use href="#i-check"/></svg></span>
        <span class="cap"><b></b><span>${p.time.slice(0, 5)}</span></span>`;
      $("b", t).textContent = [photoTitle(p), FOOT_NAMES[p.foot]].filter(Boolean).join(" · ");
      t.onclick = () => {
        if (t.dataset.held) { delete t.dataset.held; return; }  // the long press already acted
        tapThumb(p, t);
      };
      holdToSelect(t, p);
      grid.appendChild(t);
    });
    box.appendChild(grid);
  });
}

function selecting() { return $("#screen-gallery").classList.contains("selecting"); }

// Press and hold a photo to start selecting with it, as on a phone.
function holdToSelect(el, p) {
  let timer = 0;
  let startY = 0;
  const cancel = () => clearTimeout(timer);
  el.addEventListener("pointerdown", (e) => {
    startY = e.clientY;
    timer = setTimeout(() => {
      el.dataset.held = "1";
      if (!selecting()) { picked.clear(); $("#screen-gallery").classList.add("selecting"); }
      picked.add(p.id);
      el.classList.add("picked");
      drawSelectBar();
    }, 500);
  });
  el.addEventListener("pointermove", (e) => { if (Math.abs(e.clientY - startY) > 10) cancel(); });
  el.addEventListener("pointerup", cancel);
  el.addEventListener("pointerleave", cancel);
  el.addEventListener("pointercancel", cancel);
}

function tapThumb(p, el) {
  if (selecting()) {
    if (picked.has(p.id)) picked.delete(p.id); else picked.add(p.id);
    el.classList.toggle("picked", picked.has(p.id));
    drawSelectBar();
    return;
  }
  const list = visiblePhotos();
  openViewer(list, list.findIndex((x) => x.id === p.id), (removed) => {
    if (removed.length) {
      galleryPhotos = galleryPhotos.filter((x) => !removed.includes(x.id));
      drawGallery();
    }
  });
}

function drawSelectBar() {
  $("#select-count").textContent = `${picked.size} selected`;
  $("#select-delete").disabled = picked.size === 0;
  $("#select-export").disabled = picked.size === 0;
  const all = visiblePhotos();
  $("#select-all").textContent = all.length && all.every((p) => picked.has(p.id)) ? "Select none" : "Select all";
}

function endSelect() {
  picked.clear();
  $("#screen-gallery").classList.remove("selecting");
  $$(".thumb.picked").forEach((t) => t.classList.remove("picked"));
}

$("#select-start").onclick = () => {
  picked.clear();
  $("#screen-gallery").classList.add("selecting");
  drawSelectBar();
};
$("#select-cancel").onclick = endSelect;
$("#select-all").onclick = () => {
  const all = visiblePhotos();
  if (all.every((p) => picked.has(p.id))) picked.clear();
  else all.forEach((p) => picked.add(p.id));
  $$(".thumb").forEach((t) => t.classList.toggle("picked", picked.has(t.dataset.id)));
  drawSelectBar();
};
$("#select-delete").onclick = async () => {
  const n = picked.size;
  const ok = await confirmBox(`Delete ${plural(n, "photo")}?`,
    "They will be removed from the gallery. Copies already exported to a USB drive are not affected.",
    "Delete", true);
  if (!ok) return;
  const ids = [...picked];
  try { await api("/api/photos/delete", { ids }); } catch (e) { toast(e.message, true); return; }
  galleryPhotos = galleryPhotos.filter((p) => !picked.has(p.id));
  endSelect();
  drawGallery();
  toast(`${plural(n, "photo")} deleted`);
};
$("#select-export").onclick = () => {
  exportIds = [...picked];
  go("export");
};
$$("#gallery-filter button").forEach((b) => b.onclick = () => {
  galleryFilter = b.dataset.filter;
  drawGallery();
});

// ------------------------------------------------------------------ export
let exportIds = null;      // null = every photo
let exportFrom = "home";
let plans = {};
let lastJobState = "";
let autoCopy = false;      // one tap from Home: copy straight away when a single drive is in
let copiedHere = false;    // a copy was started on this visit, so show its result

function openExport() {
  exportFrom = exportIds ? "gallery" : "home";
  plans = {};
  copiedHere = false;
  $("#export-scope").textContent = exportIds ? `${plural(exportIds.length, "selected photo")}` : "All photos";
  renderExport(true);
}

$("#home-export").onclick = () => {
  autoCopy = !!(state && state.drives.length === 1);
  go("export");
};

$("#export-back").onclick = () => {
  const back = exportFrom;
  exportIds = null;
  autoCopy = false;
  go(back);
};

function drawResult(job) {
  const box = $("#export-body");
  const ok = job.state === "done";
  let title, text;
  if (!ok) {
    title = "Copy stopped";
    text = job.error || "The photos could not be copied.";
  } else {
    title = job.copied ? `${plural(job.copied, "photo")} copied` : "Already up to date";
    const extra = job.skipped ? ` ${job.skipped} were already on ${job.drive}.` : "";
    text = job.ejected
      ? `Saved to ${job.drive}.${extra} You can now remove the USB drive.`
      : `Saved to ${job.drive}.${extra} Tap Eject before removing the drive.`;
  }
  box.innerHTML = `<div class="result ${ok ? "" : "failed"}">
      <div class="big-icon"><svg><use href="#${ok ? "i-check" : "i-close"}"/></svg></div>
      <b></b><p></p><button class="btn primary" id="result-done">Done</button></div>`;
  $("b", box).textContent = title;
  $("p", box).textContent = text;
  $("#result-done").onclick = () => { exportIds = null; go(exportFrom); };
}

async function renderExport(force = false) {
  if (!state) return;
  const box = $("#export-body");
  const job = state.export;
  const drives = state.drives;

  if (job.state !== lastJobState) {
    if (lastJobState === "running" && job.state === "done") plans = {};
    lastJobState = job.state;
  }

  // The copy started here has finished (the drive is usually ejected and gone by now).
  if (copiedHere && (job.state === "done" || job.state === "failed")) {
    if (!$(".result", box)) drawResult(job);
    return;
  }

  if (!drives.length) {
    box.innerHTML = `<div class="empty-state"><div class="big-icon"><svg><use href="#i-drive"/></svg></div>
      <b>Insert a USB flash drive</b>
      <p>Plug a flash drive into any USB port on the device. It will appear here within a few seconds.</p></div>
      <div class="local-note"><svg><use href="#i-folder"/></svg><span>Photos are also kept on this device in
      <code></code></span></div>`;
    $("code", box).textContent = state.folder;
    return;
  }

  for (const d of drives) {
    if (force || !(d.mount in plans)) {
      plans[d.mount] = null;
      api("/api/export/plan", { mount: d.mount, ids: exportIds })
        .then((p) => {
          plans[d.mount] = p;
          if (screen !== "export") return;
          if (autoCopy && !copiedHere) {
            autoCopy = false;
            if (p.pending > 0 && state.export.state !== "running") { startExport(d.mount); return; }
          }
          drawDrives();
        })
        .catch(() => {});
    }
  }
  drawDrives();
}

function drawDrives() {
  const box = $("#export-body");
  const job = state.export;
  box.innerHTML = "";
  state.drives.forEach((d) => {
    const plan = plans[d.mount];
    const running = job.state === "running" && job.mount === d.mount;
    const finished = (job.state === "done" || job.state === "failed") && job.mount === d.mount;
    const card = document.createElement("div");
    card.className = "drive";
    card.innerHTML = `<div class="drive-head">
        <span class="tile-icon"><svg><use href="#i-drive"/></svg></span>
        <div><div class="drive-name"></div><div class="drive-free">${bytes(d.free_bytes)} free of ${bytes(d.total_bytes)}</div></div>
        <button class="btn eject"><svg><use href="#i-eject"/></svg>Eject</button>
      </div>
      <div class="drive-body"><div class="status"></div></div>`;
    $(".drive-name", card).textContent = d.label;
    const status = $(".status", card);
    const body = $(".drive-body", card);

    if (running) {
      const pct = job.total ? Math.round((job.done / job.total) * 100) : 0;
      status.innerHTML = `Copying… <b>${job.done} of ${job.total}</b><div class="progress"><i style="width:${pct}%"></i></div>`;
      $(".eject", card).disabled = true;
    } else {
      if (finished && job.state === "done" && (!plan || plan.pending === 0)) {
        status.innerHTML = `<b class="ok-text">Done.</b> ${plural(job.copied, "photo")} copied` +
          (job.skipped ? `, ${job.skipped} already on the drive.` : ".") + " You can eject the drive now.";
      } else if (finished && job.state === "failed") {
        status.innerHTML = `<b class="err-text">Copy stopped.</b> `;
        status.appendChild(document.createTextNode(job.error));
      } else if (!plan) {
        status.textContent = "Checking the drive…";
      } else if (plan.total === 0) {
        status.textContent = "There are no photos to copy.";
      } else if (plan.pending === 0) {
        status.innerHTML = `<b class="ok-text">Up to date.</b> All ${plural(plan.total, "photo")} are already on this drive.`;
      } else {
        status.innerHTML = `<b>${plural(plan.pending, "photo")}</b> to copy (${bytes(plan.pending_bytes)})` +
          (plan.pending < plan.total ? `; ${plan.total - plan.pending} already on the drive.` : ".");
      }
      const copy = document.createElement("button");
      copy.className = "btn primary";
      copy.innerHTML = '<svg><use href="#i-copy"/></svg>Copy to drive';
      copy.disabled = !plan || plan.pending === 0 || job.state === "running";
      if (plan && plan.pending > plan.free_bytes) copy.disabled = true;
      copy.onclick = () => startExport(d.mount);
      body.appendChild(copy);
    }
    $(".eject", card).onclick = () => ejectDrive(d);
    box.appendChild(card);
  });
  const note = document.createElement("div");
  note.className = "local-note";
  note.innerHTML = '<svg><use href="#i-folder"/></svg><span>Copied into the <code>FootCaptures</code> folder on the drive, one folder per day.</span>';
  box.appendChild(note);
}

async function startExport(mount) {
  try {
    // Eject when done, so the drive can be pulled out as soon as it says so.
    state.export = await api("/api/export", { mount, ids: exportIds, eject_after: true });
    lastJobState = "running";
    copiedHere = true;
  } catch (e) { toast(e.message, true); return; }
  drawDrives();
}

async function ejectDrive(d) {
  try { await api("/api/eject", { mount: d.mount }); } catch (e) { toast(e.message, true); return; }
  toast(`${d.label} can now be removed`);
  delete plans[d.mount];
  refresh();
}

// ------------------------------------------------------------------ settings
function renderSettings() {
  if (!state) return;
  const s = state.settings;
  $$("#set-quality button").forEach((b) => b.classList.toggle("on", b.dataset.value === s.quality));
  $$(".switch[data-setting]").forEach((sw) => sw.classList.toggle("on", !!s[sw.dataset.setting]));
  $("#about").textContent = `Version ${state.version}`;
  renderStorage();
}

function renderStorage() {
  const st = state.stats;
  $("#set-photos").textContent = `${plural(st.total, "photo")} · ${bytes(st.bytes)}`;
  $("#set-folder").textContent = state.folder;
  const used = st.disk_bytes ? 1 - st.free_bytes / st.disk_bytes : 0;
  $("#set-meter").style.width = Math.round(used * 100) + "%";
  $("#set-free").textContent = `${bytes(st.free_bytes)} free of ${bytes(st.disk_bytes)}`;
}

async function saveSetting(change) {
  try {
    state.settings = await api("/api/settings", change);
  } catch (e) { toast(e.message, true); }
  renderSettings();
}

$$("#set-quality button").forEach((b) => b.onclick = () => saveSetting({ quality: b.dataset.value }));
$$(".switch[data-setting]").forEach((sw) => sw.onclick = () => {
  const key = sw.dataset.setting;
  saveSetting({ [key]: !state.settings[key] });
});

// ------------------------------------------------------------------ window
$("#win-minimize").onclick = () => {
  api("/api/window/minimize", {}).catch((e) => toast(e.message, true));
};
$("#win-exit").onclick = async () => {
  if (!(await confirmBox("Exit the app?", "Photos are already saved. Open the app again from the Foot Imaging icon on the desktop.", "Exit", true))) return;
  try { await api("/api/window/exit", {}); } catch (e) { toast(e.message, true); }
};

$$("[data-system]").forEach((b) => b.onclick = async () => {
  const action = b.dataset.system;
  const words = {
    reboot: ["Restart the device?", "The app will be back in about a minute.", "Restart"],
    shutdown: ["Shut down the device?", "Wait for the green light to stop blinking before unplugging the power.", "Shut down"],
  }[action];
  if (!(await confirmBox(words[0], words[1], words[2], action === "shutdown"))) return;
  try { await api("/api/system/" + action, {}); } catch (e) { toast(e.message, true); }
});

// ------------------------------------------------------------------ start
// The kiosk launcher adds ?kiosk=1: hide the pointer, the panel is used by touch.
if (new URLSearchParams(location.search).has("kiosk")) document.body.classList.add("kiosk");
tickClock();
setInterval(tickClock, 1000);
refresh().then(() => {
  const first = location.hash.slice(1);   // e.g. /#gallery, for checking a screen directly
  if (first && $("#screen-" + first)) go(first); else renderHome();
});
setInterval(refresh, 1500);
