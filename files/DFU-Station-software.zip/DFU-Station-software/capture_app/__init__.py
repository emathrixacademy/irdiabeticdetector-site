"""Photo capture app for the foot imaging prototype (Camera Module 3 only)."""

__version__ = "1.0.0"
