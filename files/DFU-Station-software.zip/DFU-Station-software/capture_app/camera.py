"""Camera Module 3 access.

The preview runs at 1280x720 with continuous autofocus and is JPEG-encoded for
the screen. A capture freezes the focus where the preview had it, switches to
the full-resolution still mode for one frame, and switches back. The camera is
only open while the capture screen is showing, and closes itself if the screen
stops asking for frames.

Off the Pi, `FakeCamera` draws frames so the screens can be worked on from a
laptop. picamera2 and libcamera come from apt and are imported lazily.
"""

from __future__ import annotations

import io
import logging
import math
import threading
import time
from collections.abc import Callable, Iterator
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

PREVIEW_SIZE = (1280, 720)
STILL_SIZES = {"high": (4608, 2592), "standard": (2304, 1296)}
PREVIEW_FPS = 30
PREVIEW_JPEG_QUALITY = 72
STILL_JPEG_QUALITY = 95
IDLE_CLOSE_S = 45.0

# Photo checks shown on the camera screen. Light is the mean brightness (0-255)
# of the preview; a frame is too bright if a quarter of it is near white.
DARK_BELOW = 45.0
BRIGHT_ABOVE = 215.0
CLIPPED_LEVEL = 250
CLIPPED_SHARE = 0.25
CHECK_EVERY_N_FRAMES = 5
# libcamera AfStateEnum: Idle, Scanning, Focused, Failed.
AF_STATES = {0: "adjusting", 1: "adjusting", 2: "ok", 3: "poor"}
UNKNOWN_QUALITY = {"focus": "unknown", "light": "unknown"}


class CameraError(RuntimeError):
    pass


def light_level(luma: Any) -> str:
    """'dark', 'bright' or 'ok' for an array of brightness values (0-255)."""
    import numpy as np

    values = np.asarray(luma, dtype=np.float32)
    if values.size == 0:
        return "unknown"
    if values.mean() < DARK_BELOW:
        return "dark"
    if values.mean() > BRIGHT_ABOVE or (values >= CLIPPED_LEVEL).mean() > CLIPPED_SHARE:
        return "bright"
    return "ok"


class Camera:
    """Preview loop and locking shared by the real camera and the stand-in."""

    def __init__(self) -> None:
        self._device_lock = threading.RLock()
        self._frame_ready = threading.Condition()
        self._frame: bytes | None = None
        self._seq = 0
        self._running = False
        self._thread: threading.Thread | None = None
        self._last_wanted = 0.0
        self.rotate180 = False
        self.mirror = False
        self.quality = "high"
        self.error: str | None = None
        self.checks: dict[str, str] = dict(UNKNOWN_QUALITY)
        self._frame_count = 0
        # Called with each preview frame as RGB, 640 pixels wide (for live detection).
        self.frame_listener: Callable[[Any], None] | None = None

    # ---- implemented by subclasses ----------------------------------------
    def _open(self) -> None:
        raise NotImplementedError

    def _close(self) -> None:
        raise NotImplementedError

    def _preview_jpeg(self) -> bytes:
        raise NotImplementedError

    def _capture_still(self, path: Path) -> None:
        raise NotImplementedError

    def _autofocus(self) -> None:
        pass

    # ---- shared -----------------------------------------------------------
    @property
    def running(self) -> bool:
        return self._running

    def configure(self, *, rotate180: bool, mirror: bool, quality: str) -> None:
        changed = (rotate180, mirror, quality) != (self.rotate180, self.mirror, self.quality)
        self.rotate180, self.mirror, self.quality = rotate180, mirror, quality
        if changed and self._running:
            self.stop()
            self.start()

    def start(self) -> None:
        with self._device_lock:
            self._last_wanted = time.monotonic()
            if self._running:
                return
            try:
                self._open()
            except Exception as exc:
                self.error = str(exc)
                logger.exception("cannot open the camera")
                raise CameraError(f"Camera not available: {exc}") from exc
            self.error = None
            self.checks = dict(UNKNOWN_QUALITY)
            self._frame_count = 0
            self._running = True
            self._thread = threading.Thread(target=self._loop, name="preview", daemon=True)
            self._thread.start()
            logger.info("camera open")

    def stop(self) -> None:
        with self._device_lock:
            if not self._running:
                return
            self._running = False
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=3.0)
        with self._device_lock:
            try:
                self._close()
            except Exception:
                logger.exception("error while closing the camera")
        with self._frame_ready:
            self._frame = None
            self._frame_ready.notify_all()
        self.checks = dict(UNKNOWN_QUALITY)
        logger.info("camera closed")

    def _check_due(self) -> bool:
        """True on every Nth preview frame, so the checks cost little."""
        self._frame_count += 1
        return self._frame_count % CHECK_EVERY_N_FRAMES == 1

    def _loop(self) -> None:
        while self._running:
            if time.monotonic() - self._last_wanted > IDLE_CLOSE_S:
                logger.info("no one is watching the preview; closing the camera")
                threading.Thread(target=self.stop, daemon=True).start()
                return
            try:
                with self._device_lock:
                    if not self._running:
                        return
                    jpeg = self._preview_jpeg()
            except Exception as exc:
                self.error = str(exc)
                logger.warning("preview frame failed: %s", exc)
                time.sleep(0.5)
                continue
            with self._frame_ready:
                self._frame = jpeg
                self._seq += 1
                self._frame_ready.notify_all()

    def frames(self) -> Iterator[bytes]:
        """Preview JPEGs as they arrive, until the camera closes."""
        seen = -1

        def news() -> bool:
            return self._seq != seen or not self._running

        while self._running:
            self._last_wanted = time.monotonic()
            with self._frame_ready:
                self._frame_ready.wait_for(news, timeout=2.0)
                if not self._running:
                    return
                if self._seq == seen or self._frame is None:
                    continue
                seen, frame = self._seq, self._frame
            yield frame

    def keep_alive(self) -> None:
        self._last_wanted = time.monotonic()

    def capture(self, path: Path) -> None:
        """Write one full-resolution JPEG to `path`."""
        with self._device_lock:
            if not self._running:
                raise CameraError("The camera is not open.")
            tmp = path.with_name(path.stem + ".part.jpg")
            try:
                self._capture_still(tmp)
                tmp.replace(path)
            except Exception as exc:
                tmp.unlink(missing_ok=True)
                logger.exception("capture failed")
                raise CameraError(f"Capture failed: {exc}") from exc

    def focus(self) -> None:
        with self._device_lock:
            if self._running:
                self._autofocus()


class PiCamera(Camera):
    """Camera Module 3 through picamera2."""

    def __init__(self) -> None:
        super().__init__()
        self._cam: Any = None
        self._still_config: Any = None
        self._controls: Any = None

    def _open(self) -> None:
        from libcamera import Transform, controls
        from picamera2 import Picamera2

        self._controls = controls
        cam = Picamera2()
        try:
            transform = Transform(hflip=self.rotate180 != self.mirror, vflip=self.rotate180)
            preview = cam.create_preview_configuration(
                main={"size": PREVIEW_SIZE, "format": "RGB888"},
                transform=transform,
                buffer_count=4,
                controls={"FrameRate": PREVIEW_FPS},  # the sensor would run at 120 fps
            )
            self._still_config = cam.create_still_configuration(
                main={"size": STILL_SIZES[self.quality], "format": "RGB888"}, transform=transform
            )
            cam.configure(preview)
            cam.options["quality"] = STILL_JPEG_QUALITY
            cam.start()
        except Exception:
            cam.close()
            raise
        self._cam = cam
        self._continuous_focus()

    def _continuous_focus(self) -> None:
        try:
            self._cam.set_controls({"AfMode": self._controls.AfModeEnum.Continuous})
        except Exception as exc:  # a camera without autofocus
            logger.info("continuous autofocus not available: %s", exc)

    def _close(self) -> None:
        cam, self._cam = self._cam, None
        if cam is not None:
            cam.stop()
            cam.close()

    def _preview_jpeg(self) -> bytes:
        request = self._cam.capture_request()
        try:
            frame = request.make_array("main")  # "RGB888" is B, G, R in memory
            metadata = request.get_metadata() if self._check_due() else None
        finally:
            request.release()
        if metadata is not None:
            self._update_checks(frame, metadata)
        listener = self.frame_listener
        if listener is not None:
            listener(frame[::2, ::2, ::-1])  # 1280x720 B,G,R -> 640x360 R,G,B
        try:
            import simplejpeg  # installed with picamera2

            return bytes(
                simplejpeg.encode_jpeg(
                    frame, quality=PREVIEW_JPEG_QUALITY, colorspace="BGR", fastdct=True
                )
            )
        except ImportError:
            from PIL import Image

            buffer = io.BytesIO()
            Image.fromarray(frame[:, :, ::-1]).save(buffer, "JPEG", quality=PREVIEW_JPEG_QUALITY)
            return buffer.getvalue()

    def _update_checks(self, frame: Any, metadata: dict[str, Any]) -> None:
        # Green channel of every 8th pixel is a fair, cheap stand-in for brightness.
        light = light_level(frame[::8, ::8, 1])
        focus = AF_STATES.get(int(metadata.get("AfState", -1)), "unknown")
        self.checks = {"focus": focus, "light": light}

    def _capture_still(self, path: Path) -> None:
        still = self._still_config
        lens = self._cam.capture_metadata().get("LensPosition")
        if lens is not None and isinstance(still, dict):
            # Keep the focus the preview had; the mode switch would otherwise restart the search.
            still = dict(still)
            still["controls"] = {
                **still.get("controls", {}),
                "AfMode": self._controls.AfModeEnum.Manual,
                "LensPosition": lens,
            }
        self._cam.switch_mode_and_capture_file(still, str(path), format="jpeg")
        self._continuous_focus()

    def _autofocus(self) -> None:
        try:
            self._cam.autofocus_cycle()
        except Exception as exc:
            logger.info("autofocus cycle failed: %s", exc)
        self._continuous_focus()


class FakeCamera(Camera):
    """Draws a moving test scene. For working on the screens off the Pi."""

    def __init__(self, delay_s: float = 0.6) -> None:
        super().__init__()
        self._delay_s = delay_s
        self._t0 = 0.0

    def _open(self) -> None:
        self._t0 = time.monotonic()

    def _close(self) -> None:
        pass

    def _scene(self, size: tuple[int, int]) -> Any:
        from PIL import Image, ImageDraw

        w, h = size
        t = time.monotonic() - self._t0
        image = Image.new("RGB", size, (58, 52, 48))
        draw = ImageDraw.Draw(image)
        for i in range(0, w, max(w // 16, 1)):
            draw.line([(i, 0), (i, h)], fill=(66, 60, 56), width=max(w // 640, 1))
        cx = w / 2 + math.sin(t * 0.7) * w * 0.06
        cy = h / 2 + math.cos(t * 0.5) * h * 0.04
        rx, ry = w * 0.13, h * 0.36
        draw.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=(205, 160, 135))
        draw.ellipse(
            [cx - rx * 0.3, cy - ry * 0.1, cx + rx * 0.2, cy + ry * 0.15], fill=(175, 105, 95)
        )
        stamp = datetime.now().strftime("TEST CAMERA  %H:%M:%S")
        draw.text((w * 0.02, h * 0.03), stamp, fill=(230, 230, 230))
        if self.rotate180:
            image = image.rotate(180)
        if self.mirror:
            image = image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        return image

    def _preview_jpeg(self) -> bytes:
        time.sleep(1 / 15)
        scene = self._scene((960, 540))
        if self._check_due():
            import numpy as np

            gray = np.asarray(scene.convert("L").resize((120, 68)))
            self.checks = {"focus": "ok", "light": light_level(gray)}
        buffer = io.BytesIO()
        scene.save(buffer, "JPEG", quality=PREVIEW_JPEG_QUALITY)
        return buffer.getvalue()

    def _capture_still(self, path: Path) -> None:
        time.sleep(self._delay_s)
        size = STILL_SIZES["standard"]
        self._scene(size).save(path, "JPEG", quality=STILL_JPEG_QUALITY)

    def _autofocus(self) -> None:
        time.sleep(0.4)
