# BLOCKERS.md

Things the build could not finish without a person, hardware or data.
Nothing here was worked around with invented data, measurements or results.

Format: task id, what is missing, what a person must do.

---

## B1 - Task 3.4: PureThermal driver not yet run against the real board
- **Missing:** the Raspberry Pi 5 station with the Lepton 3.5 seated in the PureThermal 3. This build ran on a Windows laptop.
- **Done without it:** the full driver (`src/capture/purethermal.py`), with its rules tested against a fake control channel: Y16 only, colour stream refused, TLinear must be on at 0.01 K, FFC state machine, frames stamped on arrival.
- **A person must, on the station:**
  1. Run `pytest -m hardware tests/test_purethermal.py`.
  2. Confirm the UVC extension-unit numbers in the driver match the board: units RAD = 5 and SYS = 6, selectors 17 (run FFC), 18 (FFC status), 49 (TLinear enable), 50 (TLinear resolution). They follow the PureThermal firmware and the GroupGets reference tools but were written from documentation, not observed. If `radiometry_confirmed()` returns False on a board that GetThermal shows as radiometric, these numbers are the first suspect.
  3. Watch one FFC: confirm the shutter clicks on `trigger_ffc()` and that `ffc_state()` reads `in_progress` then `complete`. If the status never reads busy, the driver falls back to waiting `FFC_ASSUMED_DURATION_S` (2.0 s); check that is longer than the real shutter time.
  4. Confirm OpenCV's V4L2 backend on Pi OS returns 16-bit frames with `CAP_PROP_CONVERT_RGB` off. If it does not, the driver raises (it never falls back to the colour stream); the fix is to switch the grabber to raw V4L2 mmap capture.

## B2 - Task 3.5: reference-thermometer check not yet performed (Annex A line 9)
- **Missing:** the station, a target of known temperature that fills the centre of the thermal frame, and a calibrated reference thermometer.
- **Done without it:** the tool (`python -m src.diagnostics.thermal_reference`), tested against the fake camera.
- **A person must:** run the tool on the station with the reference thermometer, enter the reading, and keep the files it writes in `calibration/` (`thermal_reference_log.yaml` and `thermal.yaml`). The real station refuses to start until `calibration/thermal.yaml` exists. No calibration values were invented to get past this.

## B3 - Task 4.1: Camera Module 3 driver not yet run on the Pi
- **Missing:** the Pi 5 with the Camera Module 3 on CSI, and `picamera2` (apt only; it cannot be installed on the build laptop).
- **Done without it:** the driver (`src/capture/picamera.py`), the settings file loader and the lock tool (`python -m src.diagnostics.color_lock`), tested with a stand-in object in place of picamera2.
- **A person must, on the station:**
  1. With the interior LED wired and the shroud closed, run `python -m src.diagnostics.color_lock`. It writes `calibration/color.yaml`. The real station refuses to start without that file.
  2. Look at a captured frame for sharpness at 420 mm. The tool sets focus to 1000 / 420 = 2.38 dioptres; adjust `lens_position_dioptres` in the file if the image is soft.
  3. Run `pytest -m hardware tests/test_color_camera.py`.
  4. Confirm the array really is B, G, R order (the "RGB888" format in picamera2). A red object should look red in the saved `color.png`.

## B4 - Task 4.2: GPIO not yet run on the Pi (Annex A line 6)
- **Missing:** the Pi 5, the wired LED MOSFET, button and status LED, and `lgpio` (apt only).
- **Done without it:** `src/hardware/gpio.py`, tested against the gpiozero mock pin factory (LED pin levels, button debounce, status states).
- **A person must:** confirm the wiring matches `gpio:` in the config (see DECISIONS D5), run `pytest -m hardware tests/test_gpio.py`, then press the button and watch each status-LED state by eye. Check the button is wired to ground (the driver uses the internal pull-up) and the MOSFET gate is active-high.

## B5 - Task 4.3: ambient sensor model is still TBD (Annex A line 7)
- **Missing:** a decision on the sensor model, and the sensor itself. README lists it as "model TBD".
- **Done without it:** the `AmbientSensor` interface and an SHT31 driver (see DECISIONS D15), tested against a fake I2C bus including the datasheet checksum example.
- **A person must:** confirm the fitted sensor is an SHT31 at I2C address 0x44 (or 0x45; set `ambient.i2c_address`). If a different model is fitted, a new driver behind the same interface is needed. Enable I2C with `raspi-config`, check `i2cdetect -y 1`, then run `pytest -m hardware tests/test_sht31.py` and compare the reading with a room thermometer. The ambient gate depends on this sensor being right.

## B6 - Task 4.4: hardware self-check not yet run on the station (Annex A lines 4, 5)
- **Missing:** the assembled station.
- **Done without it:** `python -m src.diagnostics.check_hardware`, with the parsing and reporting tested off-device.
- **A person must:** run it on the station and keep the output for the acceptance record. The Hailo check looks for `HAILO8L` in the `hailortcli fw-control identify` output and the camera check for `imx708` in `rpicam-hello --list-cameras`. If either tool words its output differently on the installed OS, adjust the two constants at the top of the file.

## B7 - Tasks 6.1-6.3: registration has not been calibrated on the real unit (Annex A line 10)
- **Missing:** the station, and a physical calibration target (a perforated plate and a warm backing; none exists yet).
- **Done without it:** target detection, homography fit, the reprojection-error check, applying the registration and the overlay, all tested on a synthetic target with a known homography. The software tasks are complete; the per-unit calibration is not.
- **A person must:** make the target described in `docs/calibration.md` section 3.1, run `python -m src.diagnostics.registration_calibrate` on the station, and inspect `calibration/registration_check.png`. The real station refuses to scan without `calibration/registration.yaml`.
- **Also check on the real unit:** whether the colour frame covers the full height of the thermal frame (see DECISIONS D19). The covered fraction is stored with each scan as `color_coverage_fraction`.

## B8 - Task 9.2: Hailo runner not yet run on the Hailo-8L (Annex A line 12)
- **Missing:** the Pi 5 with the AI HAT+, `hailo_platform` (apt only), and a compiled `.hef` (see B9 and B10).
- **Done without it:** `src/inference/hailo_runner.py`, with its call flow tested against a stand-in for `hailo_platform`: uint8 RGB in, float scores out, one input and one output, input shape checked against the metadata, `.hef` only.
- **A person must, on the station:**
  1. Confirm the device first: `hailortcli fw-control identify`.
  2. Copy the `.hef` and `model_meta.json` into `models/` and run `pytest -m hardware tests/test_inference.py`.
  3. If loading fails with an argument error, check the HailoRT version. The runner calls `InputVStreamParams.make(network_group, format_type=...)`, the form used by HailoRT 4.17 and later; older releases also take a `quantized` argument.
  4. Check one image both ways: the class scores from the `.hef` on the station should be close to the scores from the `.onnx` on a laptop (`inference.backend: onnx`). A large difference means the normalisation built into the `.hef` does not match.

## B9 - Tasks 9.2, 10.4, 10.5, 10.6, 14.3: there is no dataset, so there is no trained model
- **Missing:** the research team's dataset and clinician-assigned labels. Nothing was supplied to the build.
- **Done without it:** the whole pipeline (manifest check, data-quality report, patient-level cross-validation, training, export with parity check), run end to end on small synthetic images to prove it works. Those synthetic images are generated inside the tests and are not a model anyone should use.
- **Not done, and not faked:** no model was trained on real data, no weights exist, no accuracy figure exists, and `models/` contains no `.onnx` or `.hef`. No placeholder model was put in `models/` because a model that looks real and is not would be worse than none.
- **A person must:** supply the dataset with a manifest (see `training/README.md`), run `python -m training.train ... --final`, read `data_quality.md`, then run `python -m training.export`. Until then the real station cannot start with `inference.backend: hailo`, by design.

## B10 - Task 10.6: the Hailo Dataflow Compiler is not installed
- **Missing:** an x86 Linux machine with the Hailo Dataflow Compiler (`hailo_sdk_client`, from the Hailo Developer Zone; it needs a Hailo account and does not run on Windows or on the Pi), a trained ONNX model (B9), and at least 64 colour frames captured by this station for quantisation.
- **Done without it:** `training/hailo_compile.py` and the instructions in `training/README.md`. The parts that do not need the compiler are tested: the normalisation line built into the model script and the calibration-set builder. The compile call itself (`ClientRunner.translate_onnx_model`, `load_model_script`, `optimize`, `compile`) has never been executed.
- **A person must:** install the compiler, run the script, and expect to adjust it on first use. In particular the node names passed to the parser and the model-script syntax can differ between Dataflow Compiler versions.

## B11 - Task 11.3: the station clock must be right, and it is offline
- **Missing:** a decision and a part. Every record is timestamped from the Pi's clock. The station is offline by design, so it cannot set its clock from the network, and a Pi 5 only keeps time through a power cut if a battery is fitted to its RTC connector (J5).
- **Done without it:** all timestamps are stored in UTC, and the code never contacts a time server.
- **A person must:** fit an RTC battery to the Pi 5 and set the clock once (`sudo date -u -s "2026-10-30 01:00:00"` then `sudo hwclock -w`), or add "check the date on the screen" to the operator's start-of-day steps. Without one of these, scans taken after a power cut will carry the wrong date.

## B12 - Task 12.5: autostart has not been installed or tried on the Pi
- **Missing:** the Pi 5 with its touchscreen and a desktop session.
- **Done without it:** the service file and installer in `deploy/`, with the file's contents tested (starts the real app, restarts on crash, logs to the journal, does not depend on the network, uses arguments the app accepts). systemd itself was never run.
- **A person must, on the station:** set Desktop Autologin in `raspi-config`, run `./deploy/install_service.sh`, reboot, and confirm the app comes up full-screen. Then kill the process once (`pkill -f src.app`) and confirm it comes back, and check `journalctl --user -u dfu-station.service`. Also check the whole UI on the real 7-inch panel with a finger: the layout was only seen as 800 x 480 screenshots on a laptop.

## B13 - Task 14.3: the on-device dry run has not been done
- **Missing:** everything physical: the assembled station, a warm object, a reference thermometer, and a person to run it. This build ran on a Windows laptop with no Pi attached.
- **Done without it:** the same full scan, start to finish, on the fake drivers (`tests/test_acceptance_e2e.py`, and `python -m src.app --fake --headless --reference-code DFU-0001 --left-foot image-right`). That run uses synthetic frames. It shows the software path works; it says nothing about the hardware, and its numbers are not measurements.
- **Not done, and not faked:** no scan of a real object, no comparison with a thermometer, and no on-device result of any kind is recorded anywhere in this repository.
- **A person must, on the station, after B1 to B8 and B12 are cleared:**
  1. Run `python -m src.diagnostics.check_hardware` and keep the output.
  2. Do the three calibrations in `docs/calibration.md`.
  3. Place a warm object of known temperature in view, measure it with the reference thermometer, and run a full scan from the touchscreen.
  4. Open the scan's `thermal_temp_c.npy` and compare the object's temperature in it with the thermometer.
  5. Write the results into the "On-device dry run" table in `PROGRESS.md`, which is empty and waiting for them.
- A12 of the acceptance form additionally needs a trained, compiled model (B9, B10).

## B14 - Phase 2 Run A, steps 1 to 5: `data/public_raw/` is empty, so no model was trained
- **Checked on 2026-10-08:** the folder `data/public_raw/` does not exist. No public dataset has been supplied.
- **Not done, and not faked:** no manifest, no grouping of real images, no training, no metrics, no ONNX file, no `models/model_meta.json`. The pipeline was exercised only on synthetic patterns generated inside the tests.
- **Done without it:** the intake, proxy-grouping and reporting tools (`training/intake.py`, `training/grouping.py`, `training/public_pipeline.py`, `training/configs/public_v1.yaml`), tested, and one real check that the grouping network (MobileNetV2 with ImageNet weights) downloads and runs on this laptop.

### What the research team must do

**1. Choose the dataset(s) and check each one against this list before downloading.**

| Must have | Why |
|---|---|
| Colour photographs of feet | The classifier is trained on colour images |
| A **Wagner grade per image**, stated by the dataset | Labels come from a clinician, never from us |
| A licence that allows this use | See point 2 |
| Ideally a patient or subject id per image | Otherwise grouping is only a proxy (DECISIONS D50) |

What I could and could not confirm by searching (I did not download anything):

- A Kaggle dataset with **Wagner grades 1 to 4**, about 10,062 images, is described in recent papers. I could **not** confirm its exact Kaggle address, licence or whether the image count includes augmented copies, so no link is given here. Find it on kaggle.com and record the exact address.
- `kaggle.com/datasets/laithjj/diabetic-foot-ulcer-dfu` exists, but its labels are normal / abnormal skin patches, **not Wagner grades**. Under the mapping rule it would be rejected in full.
- The DFUC challenge datasets (Manchester Metropolitan University) are released on request under a licence agreement. DFUC2021 is labelled for infection and ischaemia, **not Wagner grades**, so it would also be rejected in full.

**2. Check the licence. This is the Owner's decision, not a technical one.** Many public medical image sets are for non-commercial research only. This model is to be built into a station delivered under a commercial contract. Do not use a dataset whose licence does not clearly allow that, and keep a copy of the licence text with the data.

**3. Decide where Wagner 0 comes from.** The target labels are Wagner 0, 1 and 2. The Wagner 1 to 4 dataset described above has **no grade 0**. Wagner 0 means an at-risk foot with intact skin; a "normal" or "healthy skin" label in another dataset is **not** the same thing with certainty, so the intake rejects it unless the research team's clinician confirms the mapping in writing (DECISIONS D49). Without a certain source of grade 0 images, the first model can only separate grade 1 from grade 2. That would be a two-class model and must be described as one.

**4. Place the files.** One folder per dataset, unpacked, with its own structure left as it is:

```
data/public_raw/
  <short_name>/            e.g. kaggle_wagner/   (lower case, no spaces)
    ...the dataset's own folders and files, unchanged...
    LICENCE.txt            a copy of the dataset's licence or terms page
```

From the Kaggle website: open the dataset page, press Download, unzip into `data/public_raw/<short_name>/`. Or with the Kaggle command-line tool, using the address from the dataset page:

```
pip install kaggle
kaggle datasets download -d <owner>/<dataset> -p data/public_raw/<short_name> --unzip
```

`data/` is not committed to git. Do not rename, resize, crop or re-save the images; the intake needs them as published so that duplicates and repeated subjects can be found.

**5. Describe each dataset in `training/configs/public_v1.yaml`** under `sources:` (the file has a commented example): where it came from, its licence, the date, whether labels come from folder names or a CSV file, any documented subject id, and the label map. A dataset folder that is not described there stops the intake.

**6. Run it, on a machine with the dev and training requirements installed:**

```
python -m training.public_pipeline --config training/configs/public_v1.yaml
python -m training.train --manifest training/manifests/public_v1.csv --image-root data/public_raw --out runs/public_v1 --final
python -m training.export --run runs/public_v1 --out models/
```

Read `training/manifests/public_v1_report/intake_report.md` before training. If it warns that one group holds a large share of the images, or that no images were linked at all, the grouping thresholds do not suit the dataset; look at `groups.csv` and adjust them before any figure is trusted.

## B15 - Phase 2 Run A, step 6: the Hailo Dataflow Compiler is not installed, and this laptop cannot run it
This adds to B10 and replaces its "a person must" line.
- **Checked on 2026-10-08:** WSL2 is present with one distribution, **Ubuntu 24.04**, Python **3.12**, and `hailo_sdk_client` is **not installed** (`ModuleNotFoundError`). The laptop has **7.3 GB of RAM in total** (WSL sees about 3 GB) and no NVIDIA GPU.
- **Why that matters:** Hailo's published requirements for the Dataflow Compiler are Ubuntu 20.04 or 22.04, Python 3.8 to 3.10, and **16 GB of RAM as a minimum, 32 GB recommended**. This laptop is under half the minimum. I did not try to work round that; an out-of-memory compile is as likely to fail halfway as to produce a file.
- **Done without it:** the compile script now takes a hold-out manifest of public images for quantisation (`--calibration-manifest`) and writes a `<name>.build.json` beside the `.hef` saying which kind of images were used. The compile call itself has still never been executed, so the node names and model-script syntax are unproven against any compiler version.

### What the Owner must do

1. **Use a different machine**: an x86-64 PC with at least 16 GB of RAM (32 GB is better), running Ubuntu 22.04 natively or under WSL2. On Windows with enough RAM: `wsl --install -d Ubuntu-22.04`, then create `%USERPROFILE%\.wslconfig` containing
   ```
   [wsl2]
   memory=16GB
   ```
   and run `wsl --shutdown` once so it takes effect.
2. **Create a Hailo Developer Zone account** at hailo.ai (Developer Zone, Sign up). It is free; approval can take a working day.
3. **Download the Dataflow Compiler wheel** from Developer Zone, Software Downloads: product **Hailo-8/8L**, package **Dataflow Compiler**, Linux, and the Python version you will use. The file is named like `hailo_dataflow_compiler-<version>-py3-none-linux_x86_64.whl`.
   - Take the **3.x series for Hailo-8/8L**. The 5.x series is for other Hailo chips.
   - **Match the version to the HailoRT on the Pi.** On the station run `hailortcli --version` and pick the compiler release that Hailo's release notes pair with it. A `.hef` from a compiler much newer than the Pi's HailoRT will not load.
4. **Install it in its own virtual environment**, inside Ubuntu:
   ```
   sudo apt update
   sudo apt install -y python3.10 python3.10-venv python3.10-dev graphviz graphviz-dev build-essential
   python3.10 -m venv ~/hailo-dfc
   source ~/hailo-dfc/bin/activate
   pip install --upgrade pip
   pip install /path/to/hailo_dataflow_compiler-<version>-py3-none-linux_x86_64.whl
   python -c "import hailo_sdk_client; print(hailo_sdk_client.__version__)"
   ```
   Ubuntu 22.04 ships Python 3.10. If the release you downloaded names different system packages in its user guide, follow the guide.
5. **Copy across** the repository, `models/dfu_mobilenetv2.onnx`, `models/model_meta.json`, the hold-out manifest and the images it lists, then run:
   ```
   pip install -r requirements.txt
   python -m training.hailo_compile \
       --onnx models/dfu_mobilenetv2.onnx --metadata models/model_meta.json \
       --calibration-manifest training/manifests/public_v1_calibration.csv \
       --image-root data/public_raw --out models/dfu_mobilenetv2.hef
   ```
6. **Expect to adjust the script on first use** and record what changed in DECISIONS.md: the input and output node names passed to the parser, and the normalisation line of the model script, differ between compiler versions.
7. **Recompile later with station frames.** A `.hef` quantised on public photos is interim. Once the station has produced 64 or more `color_registered.png` frames, compile again with `--calibration-images`.
