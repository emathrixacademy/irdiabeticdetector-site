"""Project task runner (a Makefile that also works on Windows).

Usage:
    python tasks.py lint       ruff check, ruff format --check, mypy src
    python tasks.py test       pytest
    python tasks.py check      lint, then test
    python tasks.py format     ruff format and ruff check --fix
    python tasks.py run        start the station app on real hardware
    python tasks.py run-fake   start the app against the fake drivers
    python tasks.py tick ID MARK "summary" "files"
                               tick a box in TASKS.md and log it in PROGRESS.md
"""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PY = sys.executable

LINT_COMMANDS: list[list[str]] = [
    [PY, "-m", "ruff", "check", "."],
    [PY, "-m", "ruff", "format", "--check", "."],
    [PY, "-m", "mypy", "src"],
]
TEST_COMMAND: list[str] = [PY, "-m", "pytest", "-q"]


def _run(command: list[str]) -> int:
    print("$", " ".join(command[2:] if command[:2] == [PY, "-m"] else command), flush=True)
    return subprocess.call(command, cwd=ROOT)


def lint() -> int:
    for command in LINT_COMMANDS:
        code = _run(command)
        if code != 0:
            return code
    return 0


def test(extra: list[str]) -> int:
    return _run(TEST_COMMAND + extra)


def fmt() -> int:
    # Fix first: a lint fix can leave a line that then needs reformatting.
    _run([PY, "-m", "ruff", "check", "--fix", "."])
    return _run([PY, "-m", "ruff", "format", "."])


def tick(task_id: str, mark: str, summary: str, files: str) -> int:
    """Tick one task in TASKS.md and append its line to PROGRESS.md."""
    if mark not in ("x", "~", "!"):
        print(f"mark must be x, ~ or !, got {mark!r}")
        return 2
    tasks_path = ROOT / "TASKS.md"
    text = tasks_path.read_text(encoding="utf-8")
    pattern = re.compile(r"- \[[ x~!]\] \*\*" + re.escape(task_id) + r" ")
    new_text, count = pattern.subn(f"- [{mark}] **{task_id} ", text)
    if count != 1:
        print(f"expected exactly one task {task_id}, found {count}")
        return 2
    tasks_path.write_text(new_text, encoding="utf-8", newline="\n")
    with (ROOT / "PROGRESS.md").open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(f"| {task_id} [{mark}] | {summary} | {files} |\n")
    return 0


def main(argv: list[str]) -> int:
    if not argv:
        print(__doc__)
        return 2
    name, rest = argv[0], argv[1:]
    if name == "lint":
        return lint()
    if name == "test":
        return test(rest)
    if name == "check":
        return lint() or test(rest)
    if name == "format":
        return fmt()
    if name == "run":
        return _run([PY, "-m", "src.app", *rest])
    if name == "run-fake":
        return _run([PY, "-m", "src.app", "--fake", *rest])
    if name == "tick" and len(rest) == 4:
        return tick(*rest)
    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
