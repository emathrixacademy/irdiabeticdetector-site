"""Synthetic scenes for fixtures and tests.

SYNTHETIC DATA. Nothing here is a measurement and none of it ships in `src/`.
The scenes exist so the pipeline can be exercised with exactly known
temperatures: two plantar-shaped feet on a cool background, a hot zone of a
known size on one foot, and a matching colour frame.

Geometry convention (same as the region map in the config): a canonical LEFT
foot seen from the sole with toes up has u = 0 at the hallux (medial) side and
u = 1 at the lateral side, v = 0 at the toe tips and v = 1 at the heel. With
the patient facing the camera, the left foot normally appears on the RIGHT of
the image.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Literal

import cv2
import numpy as np
from numpy.typing import NDArray

from src.asymmetry.regions import points_in_polygon

THERMAL_WIDTH_PX = 160
THERMAL_HEIGHT_PX = 120
COLOR_WIDTH_PX = 1152
COLOR_HEIGHT_PX = 648

KELVIN_OFFSET = 273.15
COUNTS_PER_KELVIN = 100.0

_HR_WIDTH = 400
_HR_HEIGHT = 1000

Side = Literal["left", "right"]
Polygon = tuple[tuple[float, float], ...]


@dataclass(frozen=True)
class HotZone:
    """A rectangle in canonical foot coordinates raised by `delta_c`."""

    u_min: float
    u_max: float
    v_min: float
    v_max: float
    delta_c: float


@dataclass(frozen=True)
class FootSpec:
    side: Side
    center_x_px: float
    center_y_px: float
    width_px: float = 38.0
    length_px: float = 96.0
    rotation_deg: float = 0.0
    base_c: float = 30.0
    region_offsets_c: dict[str, float] = field(default_factory=dict)
    hot_zones: tuple[HotZone, ...] = ()


@dataclass(frozen=True)
class SceneSpec:
    feet: tuple[FootSpec, ...]
    background_c: float = 23.0
    width_px: int = THERMAL_WIDTH_PX
    height_px: int = THERMAL_HEIGHT_PX


# The heel region is v >= 0.70. The hot zone starts well above it so the whole
# measured heel is hot even if segmentation is a pixel or two off; the midfoot
# regions pick up a known partial rise instead.
HEEL_HOT_ZONE_V_MIN = 0.62


def default_scene(
    delta_c: float = 0.0,
    *,
    hot_foot: Side = "left",
    left_on_image_left: bool = False,
    rotation_deg: float = 0.0,
    base_c: float = 30.0,
    background_c: float = 23.0,
) -> SceneSpec:
    """Two feet side by side with the heel of one foot raised by `delta_c`."""
    zones = (HotZone(0.0, 1.0, HEEL_HOT_ZONE_V_MIN, 1.0, delta_c),) if delta_c else ()
    image_left_x, image_right_x = 45.0, 115.0
    left_x = image_left_x if left_on_image_left else image_right_x
    right_x = image_right_x if left_on_image_left else image_left_x
    left = FootSpec(
        "left",
        left_x,
        60.0,
        rotation_deg=rotation_deg,
        base_c=base_c,
        hot_zones=zones if hot_foot == "left" else (),
    )
    right = FootSpec(
        "right",
        right_x,
        60.0,
        rotation_deg=-rotation_deg,
        base_c=base_c,
        hot_zones=zones if hot_foot == "right" else (),
    )
    return SceneSpec(feet=(left, right), background_c=background_c)


def with_feet(scene: SceneSpec, *feet: FootSpec) -> SceneSpec:
    return replace(scene, feet=tuple(feet))


def _canonical_mask() -> NDArray[np.bool_]:
    """A plantar silhouette filling the unit square, at high resolution."""
    mask = np.zeros((_HR_HEIGHT, _HR_WIDTH), dtype=np.uint8)

    def point(u: float, v: float) -> tuple[int, int]:
        return round(u * (_HR_WIDTH - 1)), round(v * (_HR_HEIGHT - 1))

    body = [
        (0.03, 0.14),
        (0.40, 0.10),
        (0.90, 0.15),
        (0.97, 0.20),
        (1.00, 0.32),
        (0.97, 0.50),
        (0.90, 0.70),
        (0.84, 0.86),
        (0.16, 0.86),
        (0.14, 0.72),
        (0.08, 0.55),
        (0.02, 0.42),
        (0.00, 0.28),
    ]
    cv2.fillPoly(mask, [np.array([point(u, v) for u, v in body], dtype=np.int32)], 1)

    def ellipse(u: float, v: float, radius_u: float, radius_v: float) -> None:
        axes = (round(radius_u * (_HR_WIDTH - 1)), round(radius_v * (_HR_HEIGHT - 1)))
        cv2.ellipse(mask, point(u, v), axes, 0.0, 0.0, 360.0, 1, -1)

    ellipse(0.50, 0.86, 0.34, 0.14)  # heel
    ellipse(0.16, 0.085, 0.16, 0.085)  # hallux
    ellipse(0.43, 0.085, 0.085, 0.065)
    ellipse(0.60, 0.100, 0.080, 0.060)
    ellipse(0.75, 0.125, 0.075, 0.055)
    ellipse(0.89, 0.160, 0.070, 0.050)
    return mask.astype(bool)


_CANONICAL = _canonical_mask()


def _foot_uv(
    foot: FootSpec, x: NDArray[np.float64], y: NDArray[np.float64]
) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
    """Canonical (u, v) of image points for one foot."""
    angle = np.deg2rad(foot.rotation_deg)
    dx = x - foot.center_x_px
    dy = y - foot.center_y_px
    local_x = np.cos(angle) * dx + np.sin(angle) * dy
    local_y = -np.sin(angle) * dx + np.cos(angle) * dy
    u = local_x / foot.width_px + 0.5
    if foot.side == "right":
        u = 1.0 - u
    v = local_y / foot.length_px + 0.5
    return u, v


def _inside(u: NDArray[np.float64], v: NDArray[np.float64]) -> NDArray[np.bool_]:
    in_square = (u >= 0.0) & (u <= 1.0) & (v >= 0.0) & (v <= 1.0)
    column = np.clip(np.rint(u * (_HR_WIDTH - 1)), 0, _HR_WIDTH - 1).astype(np.intp)
    row = np.clip(np.rint(v * (_HR_HEIGHT - 1)), 0, _HR_HEIGHT - 1).astype(np.intp)
    return np.asarray(in_square & _CANONICAL[row, column], dtype=np.bool_)


def render_temperature_c(
    scene: SceneSpec, region_polygons: dict[str, Polygon] | None = None
) -> NDArray[np.float64]:
    """The scene as temperatures on the thermal grid (before quantising)."""
    ys, xs = np.mgrid[0 : scene.height_px, 0 : scene.width_px].astype(np.float64)
    temps = np.full((scene.height_px, scene.width_px), scene.background_c, dtype=np.float64)
    for foot in scene.feet:
        u, v = _foot_uv(foot, xs, ys)
        inside = _inside(u, v)
        foot_temps = np.full(temps.shape, foot.base_c, dtype=np.float64)
        if foot.region_offsets_c:
            if region_polygons is None:
                raise ValueError("region offsets need the region polygons")
            for name, offset_c in foot.region_offsets_c.items():
                foot_temps[points_in_polygon(region_polygons[name], u, v)] += offset_c
        for zone in foot.hot_zones:
            in_zone = (u >= zone.u_min) & (u <= zone.u_max) & (v >= zone.v_min) & (v <= zone.v_max)
            foot_temps[in_zone] += zone.delta_c
        temps[inside] = foot_temps[inside]
    return temps


def celsius_to_y16(temps_c: NDArray[np.float64]) -> NDArray[np.uint16]:
    """Quantise to TLinear centikelvin counts, as the Lepton would report."""
    counts = np.rint((temps_c + KELVIN_OFFSET) * COUNTS_PER_KELVIN)
    return np.asarray(counts, dtype=np.uint16)


def render_thermal_y16(
    scene: SceneSpec, region_polygons: dict[str, Polygon] | None = None
) -> NDArray[np.uint16]:
    return celsius_to_y16(render_temperature_c(scene, region_polygons))


def fixture_homography() -> NDArray[np.float64]:
    """Colour pixel -> thermal pixel for the synthetic camera pair.

    Five colour pixels per thermal pixel, a small offset and a 0.8 degree
    rotation, so registration has something real to undo.
    """
    scale = 1.0 / 5.0
    angle = np.deg2rad(0.8)
    color_center = np.array([COLOR_WIDTH_PX / 2 + 6.0, COLOR_HEIGHT_PX / 2 - 4.0])
    thermal_center = np.array([(THERMAL_WIDTH_PX - 1) / 2, (THERMAL_HEIGHT_PX - 1) / 2])
    rotation = scale * np.array(
        [[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]], dtype=np.float64
    )
    translation = thermal_center - rotation @ color_center
    homography = np.eye(3, dtype=np.float64)
    homography[:2, :2] = rotation
    homography[:2, 2] = translation
    return homography


def _color_grid_in_thermal(
    homography: NDArray[np.float64], width_px: int, height_px: int
) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
    ys, xs = np.mgrid[0:height_px, 0:width_px].astype(np.float64)
    denominator = homography[2, 0] * xs + homography[2, 1] * ys + homography[2, 2]
    tx = (homography[0, 0] * xs + homography[0, 1] * ys + homography[0, 2]) / denominator
    ty = (homography[1, 0] * xs + homography[1, 1] * ys + homography[1, 2]) / denominator
    return tx, ty


def render_color_bgr(
    scene: SceneSpec,
    homography: NDArray[np.float64] | None = None,
    width_px: int = COLOR_WIDTH_PX,
    height_px: int = COLOR_HEIGHT_PX,
) -> NDArray[np.uint8]:
    """The same scene as the colour camera would see it under the interior LED."""
    matrix = fixture_homography() if homography is None else homography
    tx, ty = _color_grid_in_thermal(matrix, width_px, height_px)
    image = np.full((height_px, width_px, 3), 24, dtype=np.uint8)
    for foot in scene.feet:
        u, v = _foot_uv(foot, tx, ty)
        inside = _inside(u, v)
        shade = 1.0 - 0.12 * np.clip(v, 0.0, 1.0)
        for channel, level in enumerate((150.0, 178.0, 222.0)):  # BGR skin tone
            plane = image[:, :, channel]
            plane[inside] = np.clip(level * shade[inside], 0, 255).astype(np.uint8)
    return image


@dataclass(frozen=True)
class TargetSpec:
    """A perforated plate over a warm surface, visible to both cameras."""

    rows: int = 5
    cols: int = 7
    spacing_px: float = 18.0
    hole_radius_px: float = 3.2
    plate_c: float = 26.0
    hole_c: float = 34.0


def target_centers_px(spec: TargetSpec) -> NDArray[np.float64]:
    """Hole centres in thermal pixels, row by row, left to right."""
    center_x = (THERMAL_WIDTH_PX - 1) / 2
    center_y = (THERMAL_HEIGHT_PX - 1) / 2
    points = [
        (
            center_x + (col - (spec.cols - 1) / 2) * spec.spacing_px,
            center_y + (row - (spec.rows - 1) / 2) * spec.spacing_px,
        )
        for row in range(spec.rows)
        for col in range(spec.cols)
    ]
    return np.array(points, dtype=np.float64)


def _in_any_hole(
    spec: TargetSpec, x: NDArray[np.float64], y: NDArray[np.float64]
) -> NDArray[np.bool_]:
    inside = np.zeros(x.shape, dtype=bool)
    for center_x, center_y in target_centers_px(spec):
        inside |= (x - center_x) ** 2 + (y - center_y) ** 2 <= spec.hole_radius_px**2
    return inside


def render_target_y16(spec: TargetSpec) -> NDArray[np.uint16]:
    ys, xs = np.mgrid[0:THERMAL_HEIGHT_PX, 0:THERMAL_WIDTH_PX].astype(np.float64)
    temps = np.where(_in_any_hole(spec, xs, ys), spec.hole_c, spec.plate_c)
    return celsius_to_y16(temps)


def render_target_bgr(
    spec: TargetSpec,
    homography: NDArray[np.float64] | None = None,
    width_px: int = COLOR_WIDTH_PX,
    height_px: int = COLOR_HEIGHT_PX,
) -> NDArray[np.uint8]:
    matrix = fixture_homography() if homography is None else homography
    tx, ty = _color_grid_in_thermal(matrix, width_px, height_px)
    image = np.full((height_px, width_px, 3), 205, dtype=np.uint8)
    image[_in_any_hole(spec, tx, ty)] = 28
    return image
