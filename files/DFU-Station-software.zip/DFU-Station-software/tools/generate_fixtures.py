"""Write the synthetic fixtures under tests/fixtures/.

    python -m tools.generate_fixtures

SYNTHETIC DATA. Every file written here is generated, not captured. The
output is deterministic, so re-running it leaves the committed fixtures
unchanged.
"""

from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np
import yaml

from src.config import load_config
from tools import synthetic

ROOT = Path(__file__).resolve().parent.parent
FIXTURE_DIR = ROOT / "tests" / "fixtures"
EXAMPLE_CONFIG = ROOT / "config" / "config.example.yaml"

# Hot-zone deltas required by TASKS.md 2.2 and the project guide "Testing".
DELTAS_C: tuple[float, ...] = (0.0, 1.5, 2.19, 2.2, 2.21, 3.5)

MODEL_LABELS = ("class_0", "class_1", "class_2")


def scenario_name(delta_c: float) -> str:
    return "delta_" + f"{delta_c:.2f}".replace(".", "p")


def _write_png(path: Path, image: np.ndarray) -> None:
    ok, encoded = cv2.imencode(".png", image)
    if not ok:
        raise RuntimeError(f"could not encode {path}")
    path.write_bytes(encoded.tobytes())


def write_scenario(delta_c: float, threshold_c: float) -> None:
    scene = synthetic.default_scene(delta_c)
    folder = FIXTURE_DIR / scenario_name(delta_c)
    folder.mkdir(parents=True, exist_ok=True)
    np.save(folder / "thermal_y16.npy", synthetic.render_thermal_y16(scene))
    _write_png(folder / "color.png", synthetic.render_color_bgr(scene))
    truth = {
        "synthetic": True,
        "hot_foot": "left",
        "hot_region": "heel",
        "hot_zone_v_min": synthetic.HEEL_HOT_ZONE_V_MIN,
        "heel_delta_c": delta_c,
        "expect_heel_flag": delta_c >= threshold_c,
        "base_c": scene.feet[0].base_c,
        "background_c": scene.background_c,
        "left_foot_on_image_left": False,
    }
    (folder / "truth.json").write_text(json.dumps(truth, indent=2) + "\n", encoding="utf-8")


def write_registration() -> None:
    homography = synthetic.fixture_homography()
    data = {
        "synthetic": True,
        "homography_color_to_thermal": [[float(v) for v in row] for row in homography],
        "color_width_px": synthetic.COLOR_WIDTH_PX,
        "color_height_px": synthetic.COLOR_HEIGHT_PX,
        "thermal_width_px": synthetic.THERMAL_WIDTH_PX,
        "thermal_height_px": synthetic.THERMAL_HEIGHT_PX,
        "reprojection_error_px": 0.0,
        "point_count": 0,
        "calibrated_at": "synthetic",
    }
    (FIXTURE_DIR / "registration.yaml").write_text(
        yaml.safe_dump(data, sort_keys=True), encoding="utf-8"
    )
    target = synthetic.TargetSpec()
    folder = FIXTURE_DIR / "registration_target"
    folder.mkdir(parents=True, exist_ok=True)
    np.save(folder / "thermal_y16.npy", synthetic.render_target_y16(target))
    _write_png(folder / "color.png", synthetic.render_target_bgr(target))


def write_model_metadata() -> None:
    metadata = {
        "synthetic": True,
        "model_id": "fake-accelerator",
        "labels": list(MODEL_LABELS),
        "input_width_px": 224,
        "input_height_px": 224,
        "mean_rgb": [0.485, 0.456, 0.406],
        "std_rgb": [0.229, 0.224, 0.225],
        "scores_are_logits": True,
    }
    (FIXTURE_DIR / "model_meta.json").write_text(
        json.dumps(metadata, indent=2) + "\n", encoding="utf-8"
    )


def main() -> None:
    config = load_config(EXAMPLE_CONFIG)
    FIXTURE_DIR.mkdir(parents=True, exist_ok=True)
    for delta_c in DELTAS_C:
        write_scenario(delta_c, config.asymmetry_threshold_c)
    write_registration()
    write_model_metadata()
    (FIXTURE_DIR / "README.md").write_text(
        "# Test fixtures\n\n"
        "Everything in this folder is **synthetic**, written by\n"
        "`python -m tools.generate_fixtures`. No file here was captured from a\n"
        "person or from the station.\n",
        encoding="utf-8",
    )
    print(f"wrote {len(DELTAS_C)} scenarios to {FIXTURE_DIR}")


if __name__ == "__main__":
    main()
