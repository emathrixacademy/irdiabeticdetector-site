# DECISIONS.md

Defaults chosen during the unattended build where the work would normally
have stopped to ask. Every entry is **Owner to review**.

Format: question, choice, reason.

---

## D1 (task 0.1) - Which model files are kept out of git?
- **Choice:** every `.hef`, `.onnx`, `.pt` and `.pth` file is ignored, whatever its size.
- **Reason:** git cannot ignore by file size, so "over 50 MB" cannot be expressed in `.gitignore`. Ignoring all weights is the safe side of that rule and also keeps trained weights (eMathrix IP) out of the history.
- Owner to review.

## D2 (task 1.1) - Can the config file widen the ambient gate?
- **Choice:** no. `ambient_min_c` may not go below 22.0 and `ambient_max_c` may not go above 25.0. The config can only tighten the range.
- **Reason:** a config value of 0-50 C would be a bypass of the ambient gate in everything but name. Non-negotiable 5 forbids any bypass that could reach production.
- Owner to review.

## D3 (task 1.1) - Can the acclimatisation time be shortened in config?
- **Choice:** no. `acclimatisation_s` must be at least 900 (the 15-minute rest in README section 1). It can be made longer.
- **Reason:** same reasoning as D2. Fake mode does not shorten it either; it runs the same 900 s against a sped-up fake clock (`fake.time_scale`), which only exists when the fake drivers are in use.
- Owner to review.

## D4 (task 1.1) - Should missing config keys fall back to defaults?
- **Choice:** no. Every key is required, and unknown keys are refused.
- **Reason:** a silently defaulted threshold, or a misspelt key that is ignored, gives results that look fine and are wrong. The loader names the exact key so the fix is quick.
- Owner to review.

## D5 (task 1.1) - Which GPIO pins?
- **Choice:** interior LED on GPIO 18, capture button on GPIO 17, status LED on GPIO 27 (BCM numbering), set in `gpio:` in the config.
- **Reason:** no wiring diagram was supplied. These are free pins that do not clash with I2C (GPIO 2/3) or the AI HAT+. Change the config to match the built harness.
- Owner to review.

## D6 (task 1.1) - What does an anonymised reference code look like?
- **Choice:** default pattern `^[A-Z]{2,5}-[0-9]{3,6}$`, for example `DFU-0001`. Configurable in `reference_code.pattern`.
- **Reason:** the research team has not supplied their code format. The loader also refuses any pattern that would accept a sample of real-looking names.
- Owner to review.

## D7 (task 2.1) - How is the colour camera kept consistent between scans?
- **Choice:** focus, exposure, gain and white balance are fixed values read from `calibration/color.yaml`, found once with the interior LED on. The sequencer waits `color.led_on_settle_s` after switching the LED on and then takes the frame.
- **Reason:** The project guide asks for exposure and white balance locked after the LED is on, because auto-exposure drifting between scans makes colour features inconsistent. Re-running auto-exposure on every scan and locking it would still drift from scan to scan; one stored lock does not.
- Owner to review.

## D8 (task 2.2) - Where does synthetic test data live, and can it reach the station?
- **Choice:** the scene generator is in `tools/` (not in `src/`), and writes fixtures clearly marked `synthetic: true`. The fake drivers only replay files; they contain no generator. The factory builds fakes only when `hardware.mode: fake`.
- **Reason:** "never fabricate a temperature". No code path in the station package can create a temperature that did not come from a file or the sensor.
- Owner to review.

## D9 (task 2.2) - How big is the synthetic hot spot?
- **Choice:** the hot zone on the left heel starts at v = 0.62, above the heel region boundary at v = 0.70.
- **Reason:** segmentation can be a pixel or two off, and a hot zone that only just covered the region would make the measured heel delta depend on boundary pixels. With the margin, the measured heel delta is exactly the fixture delta (2.19, 2.2, 2.21), which is what the threshold tests need. The midfoot regions pick up a known partial rise.
- Owner to review.

## D10 (task 2.4) - How does a headless fake scan get past the 900 s rest period?
- **Choice:** `--fake --headless` runs on a manual clock, so the same 900 s timer is started and then elapses at once. The fake UI runs on a clock sped up by `fake.time_scale`. Neither exists when real drivers are in use.
- **Reason:** the gate must not be bypassed, even in development. Faking the clock exercises the real gate; a skip flag would not.
- Owner to review.

## D11 (task 3.2) - What happens to a frame taken during or just after FFC?
- **Choice:** it is discarded and another real frame is read, up to `thermal.max_capture_attempts` (5). The same applies to a stale frame. Any other fault (all-zero, saturated, dead pixels, wrong shape, implausible temperature) raises at once with no retry.
- **Reason:** The project guide says to discard frames flagged mid-FFC. Reading the next real frame is not substitution. A frame is never repaired, interpolated or replaced with stored data.
- Owner to review.

## D12 (task 3.2) - Is a single implausible pixel enough to reject a frame?
- **Choice:** yes. Any pixel outside `thermal.plausible_min_c`-`plausible_max_c` (0-60 C), or any zero or saturated count, rejects the whole frame.
- **Reason:** fail loudly. If the real sensor turns out to have a known dead pixel, the right fix is a documented dead-pixel map in calibration, decided by the Owner, not a silent tolerance.
- Owner to review.

## D13 (task 3.3 / 3.5) - What form does the thermal calibration take, and who writes it?
- **Choice:** `corrected = gain * measured + offset_c`, limited to gain 0.8-1.2 and offset within 10 C. The reference-check tool writes an identity file when the uncorrected sensor is within `thermal.reference_tolerance_c` (1.0 C), and writes a single-point offset only when run with `--apply-offset`. A fake-mode run never writes into `calibration/`.
- **Reason:** a correction derived from a reference thermometer is a measurement, not a fabricated temperature, but it should be a deliberate act. A larger correction than the limits means something is wrong with the sensor, target or reference and should not be corrected away. The 1.0 C tolerance is a placeholder for the research team's own acceptance figure.
- Owner to review.

## D14 (task 3.4) - Is automatic FFC switched off on the Lepton?
- **Choice:** no. The driver leaves the Lepton's own FFC mode alone, polls the FFC status around every frame and flags any frame taken during one. The sequencer always triggers its own FFC first.
- **Reason:** changing the shutter mode from documentation alone, without the board, risks leaving the sensor uncorrected. Flagging and discarding mid-FFC frames is safe in either mode.
- Owner to review.

## D15 (task 4.3) - Which ambient sensor?
- **Choice:** Sensirion SHT31 on I2C bus 1, address 0x44, single-shot high-repeatability measurement with checksum verification.
- **Reason:** TASKS.md names SHT31 as the default while the model is TBD. Its stated accuracy (about 0.2 C) is comfortably inside a 3 C gate. Any checksum or bus error raises a sensor fault; a reading is never cached or estimated.
- Owner to review.

## D16 (task 4.2) - How does one status LED show five states?
- **Choice:** idle = off, acclimatising = slow blink (1 s on, 1 s off), ready = steady on, capturing = fast blink (0.1 s on, 0.1 s off), error = short flash once a second (0.1 s on, 0.9 s off).
- **Reason:** README lists a single status LED. These five are tellable apart at a glance. If the build has an RGB LED instead, only `GpioStatusLed` changes.
- Owner to review.

## D17 (task 4.2) - Button debounce
- **Choice:** the gpiozero edge debounce plus a second guard that ignores any press within `gpio.button_debounce_s` (50 ms) of the last accepted press. The button is wired to ground with the internal pull-up.
- **Reason:** one press must give exactly one capture (Annex A line 8).
- Owner to review.

## D18 (task 6.2) - What resolution does the classifier see?
- **Choice:** registration produces two colour images of the thermal field of view: one on the thermal grid (160 x 120) for overlays, and a crop at `registration.color_scale` (4) times that grid (640 x 480) for the classifier and the display.
- **Reason:** The project guide says registration maps colour down to the thermal field and resolution and that thermal must never be upsampled. A 160 x 120 colour image stretched to the 224 x 224 network input would throw away real skin detail the colour camera did capture. The larger crop has the same field of view and contains only real colour pixels; the thermal frame is untouched.
- Owner to review.

## D19 (task 6.2) - What if the colour camera does not cover the whole thermal frame?
- **Choice:** the station measures and stores the covered fraction with each scan and leaves uncovered colour pixels black. It does not stop the scan and does not fill in colour.
- **Reason:** from the published optics, the Camera Module 3 is wider than the Lepton horizontally (about 66 vs 57 degrees) but slightly shorter vertically (about 41 vs 42.5 degrees). A few rows at the top and bottom of the thermal frame may have no colour. Asymmetry is measured on the thermal frame alone, so the measurement is unaffected. This needs checking on the real unit (B7).
- Owner to review.

## D20 (task 6.1) - Calibration target design
- **Choice:** a matte, light-coloured plate with a 5 x 7 grid of round holes (about 18 mm holes on a 50 mm pitch) held in the sole plane over a dark, warm backing. Holes are found as warm blobs in the thermal frame and dark blobs in the colour frame, ordered row by row, and fitted with a least-squares homography. Calibration fails above 1.0 thermal pixel RMS error.
- **Reason:** TASKS.md suggests a perforated plate over a warm surface. The sizes are worked out from the 2.85 mm thermal pixel at 420 mm. The grid size is in the config if a different plate is made.
- Owner to review.

## D21 (task 7.1) - What counts as a foot pixel?
- **Choice:** a pixel is foot if it is more than `segmentation.min_above_reference_c` (2.0 C) above the reference, where the reference is the warmer of the ambient sensor reading and the frame's own background (its 20th percentile). Morphology (3 x 3 open then close) only groups pixels into feet; a pixel that is not itself above the threshold is never included in a mask.
- **Reason:** "adaptive threshold above ambient plus morphology" in TASKS.md. Using the frame's background as well as the room sensor stops a warmed cabinet interior being taken for foot. Keeping only warm pixels means a gap between two toes is not averaged into a toe region.
- **Known limit, for the research team:** skin that is within 2 C of the background, such as very cold toes in a patient with poor circulation, falls outside the mask and is not measured. The pixel count of each region on each foot is stored with every scan so this can be seen. Lowering the margin risks measuring background as foot.
- Owner to review.

## D22 (task 7.2) - How are left and right decided?
- **Choice:** each foot's hallux side is found from its shape (toes shorten from the hallux outwards, so the toe-tip pixels lean to the hallux side). That gives a proposal. The operator must always confirm or correct it; a scan cannot be analysed without that answer. The record stores `geometry_confirmed` or `operator_override` and what geometry proposed.
- **Reason:** The project guide says left and right are anatomical, not positional, and must come from foot geometry or explicit operator confirmation. With unusual feet (amputated toes, deformity) the shape rule can fail, so geometry never decides alone.
- Owner to review.

## D23 (task 7.3) - How are the two feet lined up?
- **Choice:** each foot gets its own frame from the principal axes of its mask, with the wider end taken as the forefoot. Position is normalised by the foot's own length and width into a canonical left-foot frame, and the right foot is mirrored into it. Temperatures are not resampled for measurement; the frame only decides which real thermal pixel belongs to which region.
- **Reason:** "principal axes and foot length" in TASKS.md, and "never upsample thermal" in the project guide. On the synthetic feet the principal axis leans about 2.4 degrees towards the hallux, the same way on both feet, so matched regions still correspond. Along-foot error is about 1 pixel.
- Owner to review.

## D24 (task 7.1) - Is a refused scan stored?
- **Choice:** no. If segmentation refuses a scan (wrong number of feet, foot cut off at the edge), nothing is written. The operator repositions and scans again.
- **Reason:** a frame that fails the placement rules is not a valid scan under the protocol, and a stored half-result invites misuse later.
- Owner to review.

## D25 (task 8.2) - How is "delta >= 2.2" made exact in floating point?
- **Choice:** a region is flagged when `abs(delta) >= threshold - 1e-6`. The 1e-6 C tolerance is a named constant in `src/asymmetry/compute.py`.
- **Reason:** the threshold is inclusive, but 2.20 cannot be held exactly in binary floating point. Two sensor readings exactly 2.20 C apart (32.20 C and 30.00 C through `raw / 100 - 273.15`) subtract to 2.1999999999999993, which would miss a plain `>=`. The tolerance is ten thousand times smaller than one sensor count (0.01 C), so it cannot turn a 2.19 C difference into a flag. Tests cover 2.19 (no flag), 2.2 (flag) and 2.21 (flag) both directly and through the full fixtures. This touches a clinical threshold, so it is flagged for review even though it does not change the rule.
- Owner to review.

## D26 (task 8.1) - Where exactly are the eight plantar regions?
- **Choice:** eight rectangles in the canonical foot frame, listed in `regions.polygons` in the config: toes in the first 18 % of foot length (hallux medial 35 %), metatarsal heads from 18 % to 38 % (first, central, fifth), midfoot from 38 % to 70 % (medial and lateral halves), heel from 70 % to 100 %.
- **Reason:** TASKS.md names the regions but not their boundaries. These proportions are a reasonable anatomical default, not a published standard. They are config values so the research team's clinician can redraw them without a code change; the config hash stored with every scan records which map was used.
- Owner to review. This one most needs a clinician's eye.

## D27 (task 8.2) - What if a region has no pixels on one foot?
- **Choice:** a region with fewer than `regions.min_region_px` (5) pixels on either foot is reported as not comparable: its delta is empty, it is never flagged, and both pixel counts are stored. The scan still completes if at least one region is comparable.
- **Reason:** amputated toes and very cold areas are expected in this patient group. Refusing the whole scan would lose the other regions; filling in a value would be fabricating a temperature. An empty delta is the honest result.
- Owner to review.

## D28 (task 8.2) - Sign of delta T
- **Choice:** delta = left mean minus right mean. Positive means the left region is warmer. The flag uses the absolute value.
- **Reason:** as written in TASKS.md 8.2.
- Owner to review.

## D29 (task 9.1) - How is the colour crop resized for the network?
- **Choice:** the whole registered crop is resized to 224 x 224 without cropping (area averaging when shrinking), converted to RGB, scaled to 0..1 and normalised with the ImageNet mean and standard deviation. One module, `src/inference/preprocess.py`, is used by both training and the station.
- **Reason:** both feet must stay in view, so no centre crop. The 4:3 crop is squeezed to a square, the same way in training and on the station, which is what matters. ImageNet statistics match the pretrained MobileNetV2 weights.
- Owner to review.

## D30 (task 9.4) - What are the classifier's classes called?
- **Choice:** the station only ever sees neutral names, `class_0`, `class_1`, and so on. The mapping from those names back to the clinician's labels is written to `label_map.json` in the training output and is not copied to the station. The station refuses to load a model whose labels contain "grade", "wagner" or "diagnos". The UI and CSV call the output "predicted class".
- **Reason:** non-negotiable 3. If the label text on the device said "Grade 2", the screen would be displaying a grade no matter what the field was called.
- Owner to review.

## D31 (task 9.2) - Where does input normalisation happen for the Hailo model?
- **Choice:** inside the `.hef`. The compile script adds a normalisation layer from the same mean and standard deviation, and the Hailo runner feeds plain RGB bytes. The ONNX runner normalises in Python, because an ONNX export expects a normalised tensor.
- **Reason:** this is the usual Hailo arrangement and avoids a float conversion on the Pi. Both paths take their numbers from `model_meta.json`.
- Owner to review.

## D32 (task 10.3) - How are cross-validation folds built?
- **Choice:** grouped k-fold by `patient_id` (default 5 folds). Patients of each label are shuffled with a fixed seed and dealt to the folds in turn, so each class is spread as evenly as its patient count allows. A patient with more than one label is placed by their most common label and still goes wholly to one side. The patient-disjoint check runs when folds are built and again when each fold is used.
- **Reason:** non-negotiable 2. No scikit-learn dependency is needed for this, and writing it out keeps the rule visible. A class with fewer patients than folds produces a warning in the report, not an error and not a silent fix.
- Owner to review.

## D33 (task 10.4) - Training defaults
- **Choice:** MobileNetV2 with ImageNet weights, backbone frozen, new final layer; Adam, learning rate 1e-3, 20 epochs, batch 16; inverse-frequency class weights computed from the training side of each fold only; augmentation is a horizontal flip and a 10 % brightness and contrast jitter; fixed seeds. All are command-line options.
- **Reason:** sensible starting values for a small dataset. They are not tuned to anything, because there is no dataset yet (B9). No accuracy target is asserted anywhere.
- **Note on the flip:** a horizontal flip swaps the left and right foot in the image. That is harmless for a classifier of skin appearance, but if the research team wants the classifier to treat sides differently, run with `--no-augment`.
- Owner to review.

## D34 (task 10.5) - Which ONNX exporter?
- **Choice:** the TorchScript-based exporter (`dynamo=False`), opset 13, fixed 1 x 3 x 224 x 224 input, no dynamic axes. The export is kept only if ONNX Runtime matches PyTorch within 1e-4.
- **Reason:** the Hailo parser is most reliable with this exporter and a fixed shape. PyTorch marks it as legacy; if a later PyTorch removes it, switch to the new exporter and re-run the parity check.
- Owner to review.

## D35 (build machine) - Where the build environment lives
- **Choice:** checks from Phase 9 onward ran in a virtual environment at `C:\tmp\dfu-venv` instead of `.venv` inside the project.
- **Reason:** the project folder path is long enough that `pip install onnx` fails on Windows with "filename or extension is too long". Nothing in the repository depends on where the environment is. `C:\tmp\dfu-venv` can be deleted at any time.
- Owner to review.

## D36 (task 11.1) - Does fusion produce one combined verdict?
- **Choice:** no. `FusedResult` holds the asymmetry flags and the classifier output side by side. There is no combined score, risk level or pass/fail. The on-screen summary states the flagged regions, the largest difference and the predicted class, followed by a fixed notice that these are research measurements and not a clinical assessment.
- **Reason:** TASKS.md asks for a combination "with no diagnosis wording anywhere", and README section 9 puts diagnosis out of scope. A combined verdict would be a diagnosis by another name, and would also tie the deterministic 2.2 C result to a model output. A test checks the classifier cannot change the flags.
- Owner to review.

## D37 (task 11.2) - What is in a scan folder, and what is a session?
- **Choice:** `data/<session_id>/<scan_id>/` with `color.png`, `color_registered.png`, `thermal_raw_y16.npy`, `thermal_temp_c.npy`, `overlay.png`, `meta.json`. A session is one reference code on one UTC date (`20261008_DFU-0001`). The scan id is the UTC trigger time to the millisecond.
- **Reason:** TASKS.md lists five files. `color_registered.png` is added because it is exactly what the classifier saw, so it is the right image to train on and to build the Hailo calibration set from. All times are UTC so the record does not depend on the station's time zone setting.
- Owner to review.

## D38 (task 11.3) - What if the CSV on disk has different columns?
- **Choice:** the station refuses to write, leaves the old file exactly as it is, and undoes the scan folder it had just written. The operator moves the old CSV aside.
- **Reason:** the log is append-only. Rewriting an old file to a new layout, or appending rows that do not match its header, would both corrupt the research record. This only happens after a software update that changes the columns.
- Owner to review.

## D39 (task 11.3) - How is a region with no comparable value written?
- **Choice:** as an empty cell in the CSV and `null` in `meta.json`, with the flag column `0`.
- **Reason:** an empty cell cannot be mistaken for a measured difference of zero.
- Owner to review.

## D40 (task 12.1) - Which UI framework?
- **Choice:** PyQt5, from apt on the Pi (`python3-pyqt5`) and from pip on a laptop. The UI is split in two: `src/ui/controller.py` holds the whole workflow with no toolkit in it, and `src/ui/qt_app.py` is a thin PyQt5 layer that draws and forwards taps.
- **Reason:** PyQt5 is packaged for Raspberry Pi OS, runs full-screen without a browser, and handles a touchscreen well. Keeping the workflow out of the toolkit means every rule is tested without a display, and the toolkit could be swapped without touching a rule.
- Owner to review.

## D41 (task 12.2) - Screen size and text entry
- **Choice:** laid out for 800 x 480 (the common 7-inch panel), with an on-screen keypad of capital letters, digits, hyphen and underscore for the reference code.
- **Reason:** no keyboard is listed in the hardware. If the panel is a different resolution the layout stretches, but check it on the real screen.
- Owner to review.

## D42 (task 12.2) - What do the live previews show?
- **Choice:** the thermal preview is a false-colour picture of the Y16 frame, for positioning the feet. The colour preview is shown unlit, with a note saying so. The interior light comes on only during the capture itself.
- **Reason:** switching the light on for a live preview would warm the skin that is about to be measured. The thermal preview is the one that matters for placement. The preview skips the freshness and flat-field checks, is never stored and is never measured from.
- Owner to review.

## D43 (task 12.2) - How does the operator confirm left and right?
- **Choice:** after capture the screen shows the thermal picture with the two feet marked A and B by position, says which one the station thinks is the left foot (or that it cannot tell), and makes the operator tap "Foot A is the LEFT foot" or "Foot B is the LEFT foot". Nothing is analysed or stored until they answer.
- **Reason:** The project guide requires foot geometry or explicit operator confirmation; TASKS.md 7.2 requires both. Naming the feet A and B avoids the trap of the operator reading "left" as "left of the picture".
- Owner to review.

## D44 (task 12.2) - What is on the results screen?
- **Choice:** the thermal picture with the region map drawn on it and flagged regions outlined, the registered colour picture, a table of all eight regions (left, right, left minus right, FLAG), a three-line summary and a fixed notice that this is a research instrument and not a clinical assessment. The classifier output appears only as "Colour model predicted class: class_N (confidence X %)".
- **Reason:** shows what was measured without wording that reads as a diagnosis or a grade.
- Owner to review.

## D45 (task 12.5) - How does the app start on boot?
- **Choice:** a systemd user service (`deploy/dfu-station.service`, installed by `deploy/install_service.sh`) tied to the desktop session, with `Restart=on-failure`, logs to the journal, and no restart on exit code 2. The Pi must be set to Desktop Autologin.
- **Reason:** a user service inherits the display settings of the desktop session on both X11 and Wayland, which a system service does not. Exit code 2 means "cannot start as configured" (bad config, missing calibration); restarting that in a loop would only hide the reason.
- Owner to review.

## D46 (task 13.1) - What does the methodology document leave blank?
- **Choice:** it describes the method fully but leaves four boxed "to be completed by the research team" notes: the reference-thermometer result, the registration error on the delivered unit, the dataset and training details, and all performance results. Its last section lists what had not been verified on hardware when it was written.
- **Reason:** those numbers do not exist yet. Writing plausible ones would be fabrication, and a methods document that hides its own gaps is worse than one that names them. A test checks the document makes no accuracy claim and that the protocol values it quotes match the config.
- Owner to review, and to pass to the research team: the region boundaries, the 2.0 C mask margin and the Lepton emissivity setting are flagged in it for their clinician and their methods section.

## D47 (task 13.2) - Cleaning guidance in the operator manual
- **Choice:** the manual says to follow the facility's infection-control policy, wipe the foot rest and patient-contact surfaces with the facility's own disinfectant wipe, let it dry fully, never touch or spray the camera lenses, and never spray liquid into the cabinet.
- **Reason:** the builder does not know the cabinet's surface materials or the facility's approved products, so the manual defers to facility policy instead of naming a chemical. The drying point matters for measurement: a damp foot rest chills the heels.
- Owner to review against the actual materials and the client's facility policy.

## D48 (task 13.2) - Shutting down from the touchscreen
- **Choice:** an Exit button on the reference-code screen closes the app cleanly (the service does not restart it after a clean exit), and the operator then uses the desktop's own Shutdown.
- **Reason:** there is no keyboard on the station, so there has to be a way out by touch. The app does not power the Pi off itself, to avoid giving it system privileges.
- Owner to review.

---

# Phase 2, Run A (first classifier on public photos)

## D49 (Run A step 1) - How are public dataset labels mapped to Wagner 0, 1, 2?
- **Choice:** by an explicit table per dataset in `training/configs/public_v1.yaml`, matched on the exact label text. Anything not in the table is rejected and listed in `rejected.csv`. The intake refuses a dataset folder that has no table at all.
- **The mapping table, for the research team to confirm.** No dataset has been supplied yet (BLOCKERS B14), so these are the rules that will be applied, not rows from a real dataset. The per-dataset rows are printed in `intake_report.md` with a "confirmed by" column that reads NOT YET CONFIRMED until someone signs it.

| Source label means | Maps to | Status |
|---|---|---|
| Wagner grade 0, stated as such by the dataset | `0` | Accept |
| Wagner grade 1, stated as such | `1` | Accept |
| Wagner grade 2, stated as such | `2` | Accept |
| Wagner grade 3, 4 or 5 | none | **Reject.** Outside the three target labels. Not merged into grade 2. |
| "Normal", "healthy", "no ulcer", "control" | none | **Reject unless the clinician confirms in writing.** Healthy skin is not the same as a Wagner 0 at-risk foot with certainty. |
| "Ulcer", "abnormal", "DFU" with no grade | none | **Reject.** The grade is unknown. |
| Infection, ischaemia, or any other grading system (Texas, SINBAD, PEDIS) | none | **Reject.** Not Wagner. No conversion between systems is attempted. |
| A grade range or a combined label ("Grade 1-2") | none | **Reject.** Not certain. |
| No label found for the image | none | **Reject.** |

- **Reason:** the instruction was that anything not mapped with certainty goes to a rejected list. Grades come from a clinician; this project never assigns or converts one.
- **Consequence to know about:** the one public Wagner-labelled dataset found in the literature has grades 1 to 4 and **no grade 0**. Unless the team supplies a certain source of grade 0 images, the first model has two classes, not three.
- Owner to review, and the research team's clinician to confirm.

## D50 (Run A step 2) - How are images grouped when a dataset has no patient ids?
- **Choice:** documented subject ids are used wherever a dataset gives them. Otherwise two images are linked if a 64-bit perceptual (difference) hash differs by at most 8 bits, **or** if their MobileNetV2 (ImageNet) features, after subtracting the dataset mean, have a cosine similarity of at least 0.90. Groups are everything connected through such links, and the group id is used as `patient_id`. Both thresholds are in `training/configs/public_v1.yaml`. There is no option to give each image its own id.
- **Reason:** as instructed. Erring towards bigger groups is the safe direction, since it can only take images out of a test fold, never leak a foot across the split.
- **Something found while building it:** raw network features give a cosine near 0.9 between completely unrelated pictures, because the features are all positive. Without subtracting the mean, a 0.90 threshold would have put every image in one group. That is fixed and tested.
- **The thresholds are untuned defaults.** They were only exercised on synthetic patterns, where near-copies (resized, brightened, lightly cropped) were grouped reliably and a heavily cropped copy was not. They must be checked against the real dataset: the intake report gives the similarity distribution, warns if one group swallows more than 20 % of the images, and warns if nothing was linked at all.
- **Stated limitation:** grouping is a proxy, true patient separation cannot be guaranteed on this public data. Two different-looking photographs of one patient can land in different groups, so cross-validation figures from public data may be optimistic. This is written in `training/README.md`, `docs/methodology.md` and every intake report.
- Owner to review.

## D51 (Run A step 1) - What happens to exact duplicate files?
- **Choice:** byte-identical files are reduced to one and the removed paths are listed in `duplicates_removed.csv`. If identical files carry different labels, all copies are rejected.
- **Reason:** an exact copy adds nothing and would otherwise inflate a class count. Identical pictures with different grades mean the label cannot be trusted. Near-duplicates are not removed; they are kept and grouped together (D50).
- Owner to review.

## D52 (Run A step 6) - Which images quantise the interim Hailo model?
- **Choice:** whole groups of public images, at least 64 images, chosen with a fixed seed and spread across the labels, are set aside before training and written to `training/manifests/public_v1_calibration.csv`. They are never trained on. If 64 images would be more than 20 % of the dataset, no hold-out is made and the report says so.
- **Reason:** station captures do not exist yet. The `.hef` built this way is recorded as interim in a `.build.json` file beside it, and must be recompiled with 64 or more station frames.
- Owner to review.

## D53 (Run A) - Are the public manifests and reports committed?
- **Choice:** no. `training/manifests/` and `runs/` are in `.gitignore`. The intake config (`training/configs/public_v1.yaml`), which holds the source addresses, licences and label maps, is committed.
- **Reason:** the manifests list files from datasets with their own licences, and the folder will later hold manifests of station data, which must never be committed. Everything in them can be regenerated from the config and the downloaded data.
- Owner to review.

## D54 (Run A) - What will this first model be good for?
- **Choice:** it is treated as a stand-in to show the classifier path working end to end on the station (acceptance line A12), and nothing more.
- **Reason:** public photographs are close-up wound pictures taken with other cameras, in other light, from other angles. The station takes a fixed view of both whole soles at 420 mm. A model trained on the first and run on the second should not be expected to be right, and the acceptance line makes no accuracy promise. Whatever cross-validation figures it produces describe the public data only. It is to be retrained on station captures.
- Owner to review, and worth saying plainly to the client before the demonstration.

---

# Phase 3 (station bring-up and data-gathering readiness)

## D55 (C.7) - What does "fake-thermal mode" mean for the panel walk-through?
- **Choice:** the existing fully fake mode (`--fake`): every driver is a stand-in. The service installer has an explicit `--fake-panel-test` option for the reboot and kill-restart test. No mode was built that pairs a fake thermal camera with the real colour camera.
- **Reason:** chosen by the Owner on 2026-10-08. A mixed mode would put synthetic temperatures beside real colour frames on a real station, which is a change on the thermal path. The real button and LEDs are tested separately.
- Decided by the Owner.

## D56 (C.9) - How does the station gather data before a classifier exists?
- **Choice:** `inference.backend: none`. The station captures, measures and stores every scan in full. The classifier is not run: `predicted_class`, `predicted_label`, `confidence` and `model_id` are empty in the CSV and null in `meta.json` (with `"ran": false`), and the results screen says "Colour model: not installed. This scan is stored for data collection." No model file or metadata file is needed.
- **Reason:** the classifier is to be trained on the station's own captures, so the station must run without it first. Before this change the real station refused to start without a compiled `.hef`, which made data gathering impossible. Nothing about the thermal measurement, the 2.2 C rule, the gates or the capture sequence is changed. Empty is used, not zero and not a placeholder class, so a row from data collection can never be read as a model output.
- **Note for acceptance:** line A12 still needs `inference.backend: hailo` with a real `.hef`. Running with `none` does not satisfy it.
- Owner to review.

## D57 (C.9) - Where do scans made in fake mode go?
- **Choice:** to `data/_fake_mode/` with their own `scans.csv`, and `"fake_mode": true` in each `meta.json`. This applies however fake mode is switched on. Every screen heading is prefixed `DEMO:` and the code screen states that nothing shown is a measurement.
- **Reason:** the panel walk-through on the real station runs in fake mode. Before this change those synthetic scans would have been written into the same folder and the same CSV as real patient scans, with nothing to tell them apart. That would have contaminated the research dataset.
- Owner to review.

## D58 (C.9) - What does the operator see about the station itself?
- **Choice:** the code-entry screen shows the station clock (local time and UTC), free storage, the number of scans stored today, a warning when free storage is below `storage.low_space_warning_mb` (2000), and the mode lines. The operator manual tells the operator to check the clock there daily.
- **Reason:** the app covers the whole screen, so the desktop clock the manual used to point to is not visible, and the station is offline and cannot set its own time (B11). Colour frames are several megabytes each, so storage will fill during a campaign and the operator should see it coming. The low-space line is a warning; a full disk still refuses the scan cleanly, as before.
- Owner to review.
