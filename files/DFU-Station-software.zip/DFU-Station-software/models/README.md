ONNX sources and compiled .hef files live here. Model binaries are not committed.
