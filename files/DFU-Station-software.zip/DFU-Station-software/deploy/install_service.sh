#!/bin/sh
# Install the station as a systemd user service on the Raspberry Pi 5.
#
#   ./deploy/install_service.sh            install and start
#   ./deploy/install_service.sh --remove   stop and remove
#   ./deploy/install_service.sh --fake-panel-test
#                                          bring-up only: start the app on stand-in
#                                          drivers to try the screens and autostart
#
# Run as the desktop user (not root), from the repository folder, after:
#   - the virtual environment exists at .venv (created with --system-site-packages)
#   - config/config.yaml exists
#   - python -m src.diagnostics.check_hardware passes
#   - the Pi is set to Desktop Autologin in raspi-config
set -eu

SERVICE=dfu-station.service
INSTALL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
UNIT_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"

if [ "$(id -u)" -eq 0 ]; then
    echo "Run this as the desktop user, not as root." >&2
    exit 1
fi

if [ "${1:-}" = "--remove" ]; then
    systemctl --user disable --now "$SERVICE" 2>/dev/null || true
    rm -f "$UNIT_DIR/$SERVICE"
    systemctl --user daemon-reload
    echo "Removed $SERVICE."
    exit 0
fi

for needed in ".venv/bin/python" "config/config.yaml"; do
    if [ ! -e "$INSTALL_DIR/$needed" ]; then
        echo "Missing $INSTALL_DIR/$needed. See README section 6." >&2
        exit 1
    fi
done

mkdir -p "$UNIT_DIR"
if [ "${1:-}" = "--fake-panel-test" ]; then
    # Bring-up only: every driver is a stand-in replaying synthetic fixtures.
    # Used to try the screens and the autostart before the cameras are fitted.
    sed -e "s|@INSTALL_DIR@|$INSTALL_DIR|g" -e 's|^\(ExecStart=.*\)$|\1 --fake|' \
        "$INSTALL_DIR/deploy/$SERVICE" > "$UNIT_DIR/$SERVICE"
    echo "FAKE PANEL TEST: the service starts the app with --fake. No hardware is used"
    echo "and nothing it shows is a measurement. Run this script again with no option"
    echo "to install the real service before the station is used."
elif [ -n "${1:-}" ]; then
    echo "Unknown option: $1" >&2
    exit 1
else
    sed "s|@INSTALL_DIR@|$INSTALL_DIR|g" "$INSTALL_DIR/deploy/$SERVICE" > "$UNIT_DIR/$SERVICE"
fi
systemctl --user daemon-reload
systemctl --user enable --now "$SERVICE"

echo "Installed. The station now starts with the desktop session."
echo "  Status:  systemctl --user status $SERVICE"
echo "  Log:     journalctl --user -u $SERVICE -f"
echo "  Stop:    systemctl --user stop $SERVICE"
