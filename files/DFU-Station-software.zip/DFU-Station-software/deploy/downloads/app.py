"""DFU station documents page (Railway). Public, no secrets.

Shows the station manuals as readable pages, plus download buttons for the
software and the wiring schematic once those files exist. Everything is read
from the public site repository, so this service needs no token and no access
code. To update a manual or add a file, push it to that repository; the page
picks it up within CACHE_SECONDS.

This page only hands files OUT. It has no upload: scans and session data never
leave the station.

Environment:
    SITE_RAW   base URL of the public files, default the irdiabeticdetector-site repo on GitHub
    PORT       set by Railway
"""

from __future__ import annotations

import html
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

import markdown

SITE_RAW = os.environ.get(
    "SITE_RAW",
    "https://raw.githubusercontent.com/emathrixacademy/irdiabeticdetector-site/main",
).rstrip("/")
CACHE_SECONDS = 300

# Manuals in display order: slug -> title. Each is docs/<slug>.md in the site repo.
DOCS: dict[str, str] = {
    "operator_manual": "Operator manual",
    "acceptance_test": "Acceptance test runbook (Annex A)",
    "calibration": "Calibration manual",
    "methodology": "System development and testing methodology",
}

# Downloadable files: name -> label. Each is files/<name> in the site repo.
SOFTWARE = "DFU-Station-software.zip"
SCHEMATIC = "DFU-Station-schematic.pdf"
BOM = "DFU-Station-bill-of-materials.pdf"
SOFTWARE_LIST = "DFU-Station-software-list.pdf"
TRAINING = "DFU-Station-model-training.pdf"
FILES: dict[str, str] = {
    SOFTWARE: "Station software (zip)",
    SOFTWARE_LIST: "Software list (PDF)",
    TRAINING: "How the model is trained (PDF)",
    SCHEMATIC: "Wiring schematic (PDF)",
    BOM: "Bill of materials (PDF)",
}

# The interactive 3D model: a self-contained page in the site repo.
CAD_PAGE = "cad.html"

_cache: dict[str, tuple[float, Any]] = {}


def _fetch(path: str) -> bytes | None:
    """Bytes of a file in the site repo, or None if it does not exist."""
    req = urllib.request.Request(f"{SITE_RAW}/{path}", headers={"User-Agent": "dfu-docs"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return bytes(r.read())
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise


def _cached(key: str, load: Any) -> Any:
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < CACHE_SECONDS:
        return hit[1]
    value = load()
    _cache[key] = (time.time(), value)
    return value


def strip_front_matter(text: str) -> str:
    """Drop a leading Jekyll front-matter block (--- ... ---) if there is one."""
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            return text[end + 4 :].lstrip("\n")
    return text


def render_markdown(text: str) -> str:
    extensions = ["tables", "fenced_code", "sane_lists"]
    return str(markdown.markdown(strip_front_matter(text), extensions=extensions))


def doc_html(slug: str) -> str | None:
    if slug not in DOCS:
        return None

    def load() -> str | None:
        data = _fetch(f"docs/{slug}.md")
        return None if data is None else render_markdown(data.decode("utf-8"))

    result: str | None = _cached(f"doc:{slug}", load)
    return result


def file_sizes() -> dict[str, int]:
    """Size in bytes of each downloadable file that exists; missing files are left out."""

    def load() -> dict[str, int]:
        sizes = {}
        for name in FILES:
            req = urllib.request.Request(
                f"{SITE_RAW}/files/{urllib.parse.quote(name)}",
                method="HEAD",
                headers={"User-Agent": "dfu-docs"},
            )
            try:
                with urllib.request.urlopen(req, timeout=20) as r:
                    sizes[name] = int(r.headers.get("Content-Length") or 0)
            except urllib.error.HTTPError:
                continue
        return sizes

    result: dict[str, int] = _cached("files", load)
    return result


PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>DFU Station files</title>
<style>
:root{{--brand:#0f5f73;--tint:#e6f2f4;--ink:#1d2327;--muted:#5b6770;--line:#d5dee2;
--bg:#fff}}
@media (prefers-color-scheme:dark){{:root{{--brand:#4fb3c9;--tint:#14313a;--ink:#e6eaec;
--muted:#9aa7ae;--line:#2c3a40;--bg:#0f1417}}}}
body{{font-family:system-ui,Segoe UI,Roboto,sans-serif;margin:0;background:var(--bg);
color:var(--ink);line-height:1.55}}
main{{max-width:560px;margin:0 auto;padding:24px 16px 48px}}
main.doc{{max-width:760px}}
h1{{color:var(--brand);margin:.2em 0}} a{{color:var(--brand)}}
.muted{{color:var(--muted);font-size:14px}}
.banner{{background:#000;color:#ffeb3b;font-weight:800;padding:12px 14px;border-radius:12px}}
.big{{display:block;text-align:center;background:var(--brand);color:#fff;text-decoration:none;
font-size:20px;font-weight:700;padding:18px;border-radius:16px;margin:18px 0}}
.big.off{{opacity:.45;pointer-events:none}}
.box{{background:var(--tint);border-radius:12px;padding:12px 14px;font-size:15px}}
ul{{padding-left:18px}} li{{margin:8px 0}}
table{{border-collapse:collapse;display:block;overflow-x:auto}}
th,td{{border:1px solid var(--line);padding:6px 10px;text-align:left;vertical-align:top}}
pre{{background:var(--tint);padding:12px;border-radius:8px;overflow-x:auto}}
</style></head><body><main class="{cls}">{body}</main></body></html>"""


def _page(body: str, cls: str = "") -> str:
    return PAGE.format(body=body, cls=cls)


def _size(n: int) -> str:
    return f"{n / 1e6:.1f} MB" if n >= 1e6 else f"{max(1, round(n / 1e3))} KB"


def _big(sizes: dict[str, int], name: str, text: str) -> str:
    """A big button for a file, or a greyed-out one until the file is added."""
    if name in sizes:
        return f'<a class="big" href="/download/{urllib.parse.quote(name)}">{text}</a>'
    return f'<a class="big off" aria-disabled="true">{text} (coming soon)</a>'


def home_page(sizes: dict[str, int]) -> str:
    doc_rows = "".join(
        f'<li><a href="/doc/{slug}">{html.escape(title)}</a></li>' for slug, title in DOCS.items()
    )
    file_rows = "".join(
        f'<li><a href="/download/{urllib.parse.quote(name)}">{html.escape(label)}</a>'
        f' <span class="muted">({_size(sizes[name])})</span></li>'
        for name, label in FILES.items()
        if name in sizes
    )
    return _page(
        f"""<div class="banner">RESEARCH INSTRUMENT. Not a medical device.</div>
<h1>DFU Thermography Screening Station</h1>
<p class="muted">Manuals and files · eMathrix Technologies</p>
{_big(sizes, SOFTWARE, "Download the station software")}
<div class="box"><b>Installing:</b> the eMathrix technician installs the software on the
station's Raspberry Pi 5. Operators do not install anything. Wagner grades come only from a
licensed clinician, never from the station.</div>
<h2>3D model</h2>
<a class="big" href="/cad">Open the interactive 3D model</a>
<div class="box">Turn, zoom and open up the station, tap any part for its role, and run a simulated
capture sequence. Design dimensions; electronics positions are illustrative.</div>
<h2>Software and model training</h2>
{_big(sizes, SOFTWARE_LIST, "Open the software list")}
{_big(sizes, TRAINING, "Open how the model is trained")}
<h2>Hardware</h2>
{_big(sizes, SCHEMATIC, "Open the wiring schematic")}
{_big(sizes, BOM, "Open the bill of materials")}
<h2>Using the station</h2>
<a class="big" href="/doc/operator_manual">Read the operator manual</a>
<div class="box">Where the scans are: on the station's own storage, one folder per scan and
one list of all scans. <b>Nothing is sent anywhere.</b> Copying data off the station is done
by the research team under their own data procedures. Never upload scans, session files or
patient details to any online service. Reference codes only, never names.</div>
<h2>All files</h2><ul>{doc_rows}<li><a href="/cad">Interactive 3D model</a></li>{file_rows}</ul>
<p class="muted">eMathrix Technologies, Cabuyao, Laguna</p>"""
    )


def doc_page(body_html: str) -> str:
    return _page(f'<p><a href="/">&larr; Back to all files</a></p>{body_html}', cls="doc")


class Handler(BaseHTTPRequestHandler):
    server_version = "dfu-docs"

    def _send(self, status: int, body: str = "", headers: dict[str, str] | None = None) -> None:
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        path = urllib.parse.urlparse(self.path).path
        if path == "/health":
            return self._send(200, "ok")
        try:
            if path == "/":
                return self._send(200, home_page(file_sizes()))
            if path == "/index.html":  # the 3D page links back with a relative URL
                return self._send(302, "", {"Location": "/"})
            if path == "/cad":
                page = _cached("cad", lambda: _fetch(CAD_PAGE))
                if page is None:
                    return self._send(404, _page("<p>The 3D model is not available.</p>"))
                return self._send(200, page.decode("utf-8"))
            if path.startswith("/doc/"):
                body = doc_html(urllib.parse.unquote(path[len("/doc/") :]))
                if body is None:
                    return self._send(404, _page("<p>Document not found.</p>"))
                return self._send(200, doc_page(body))
            if path.startswith("/download/"):
                name = urllib.parse.unquote(path[len("/download/") :])
                if name not in FILES:
                    return self._send(404, _page("<p>File not found.</p>"))
                url = f"{SITE_RAW}/files/{urllib.parse.quote(name)}"
                return self._send(302, "", {"Location": url})
        except (urllib.error.URLError, OSError) as e:
            msg = f"<p>The files could not be reached ({html.escape(type(e).__name__)}). "
            return self._send(502, _page(msg + "Please try again in a minute.</p>"))
        return self._send(404, _page("<p>Not found.</p>"))

    def log_message(self, format: str, *args: Any) -> None:  # no IPs in the logs
        status = args[1] if len(args) > 1 else ""
        print(f"{self.command} {urllib.parse.urlparse(self.path).path} -> {status}", flush=True)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    print(f"DFU documents from {SITE_RAW} on port {port}", flush=True)
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
