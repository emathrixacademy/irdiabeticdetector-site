"""Local storage of analysed scans: one folder per scan and one CSV row.

    data/<session_id>/<scan_id>/
        color.png              the colour frame as captured
        color_registered.png   the colour frame on the thermal field of view
        thermal_raw_y16.npy    raw Lepton counts
        thermal_temp_c.npy     temperatures in degrees Celsius
        overlay.png            thermal false colour over registered colour
        meta.json              everything else
    data/scans.csv             one row per scan, append-only

Everything stays on the device. This module opens no network connection and
the reference code is the only identifier it ever writes.
"""

from __future__ import annotations

import csv
import io
import logging
import os
import shutil
from pathlib import Path
from typing import Any

from src import __version__
from src.config import REQUIRED_REGIONS
from src.errors import StorageError
from src.fusion.fuse import RESEARCH_NOTICE
from src.pipeline import AnalysedScan
from src.storage import layout
from src.storage.writer import (
    encode_json,
    encode_png,
    paired_record_files,
    record_metadata,
    write_scan_folder,
)

logger = logging.getLogger(__name__)

REGION_FIELDS: tuple[str, ...] = ("left_mean_c", "right_mean_c", "delta_c", "flagged")

CSV_COLUMNS: tuple[str, ...] = (
    "reference_code",
    "session_id",
    "scan_id",
    "triggered_at_utc",
    "color_captured_at_utc",
    "thermal_captured_at_utc",
    "ambient_temp_c",
    "ambient_humidity_pct",
    "config_hash",
    "software_version",
    "left_foot_position",
    "sidedness_source",
    "asymmetry_threshold_c",
    *(f"{region}_{name}" for region in REQUIRED_REGIONS for name in REGION_FIELDS),
    "max_abs_delta_c",
    "any_region_flagged",
    "flagged_regions",
    "predicted_class",
    "predicted_label",
    "confidence",
    "model_id",
    "registration_error_px",
    "color_coverage_fraction",
    "scan_folder",
)


def _number(value: float | None, digits: int = 4) -> str:
    """Empty for a missing value. A missing value is never written as zero."""
    return "" if value is None else f"{value:.{digits}f}"


def _whole(value: int | None) -> str:
    return "" if value is None else str(value)


def _flag(value: bool) -> str:
    return "1" if value else "0"


def analysis_metadata(scan: AnalysedScan) -> dict[str, Any]:
    """meta.json: the capture metadata plus every result."""
    meta = record_metadata(scan.record)
    meta["notice"] = RESEARCH_NOTICE
    meta["sidedness"] = {
        "left_foot_position": "image_left" if scan.decision.left_is_image_left else "image_right",
        "source": scan.decision.source,
        "geometry_proposed_left_foot_position": (
            None
            if scan.decision.geometry_left_is_image_left is None
            else ("image_left" if scan.decision.geometry_left_is_image_left else "image_right")
        ),
    }
    meta["segmentation"] = {
        "threshold_c": scan.masks.threshold_c,
        "reference_c": scan.masks.reference_c,
        "background_c": scan.masks.background_c,
    }
    meta["registration"] = {
        "reprojection_error_px": scan.registered.reprojection_error_px,
        "color_coverage_fraction": scan.registered.coverage_fraction,
    }
    meta["asymmetry"] = {
        "threshold_c": scan.asymmetry.threshold_c,
        "rule": "flag when abs(left mean - right mean) >= threshold_c (inclusive)",
        "max_abs_delta_c": scan.asymmetry.max_abs_delta_c,
        "flagged_regions": list(scan.asymmetry.flagged_regions),
        "regions": [
            {
                "name": region.name,
                "left_mean_c": region.left_mean_c,
                "right_mean_c": region.right_mean_c,
                "delta_c": region.delta_c,
                "flagged": region.flagged,
                "left_pixel_count": region.left_pixel_count,
                "right_pixel_count": region.right_pixel_count,
            }
            for region in scan.asymmetry.regions
        ],
    }
    meta["classifier"] = {
        "ran": scan.classifier is not None,
        "predicted_class": scan.fused.predicted_class,
        "predicted_label": scan.fused.predicted_label,
        "confidence": scan.fused.confidence,
        "model_id": scan.fused.model_id,
        "note": "model output on the colour image; not assigned by a clinician",
    }
    return meta


def csv_row(scan: AnalysedScan, scan_folder: str) -> dict[str, str]:
    """One CSV row. Keys are exactly CSV_COLUMNS."""
    record = scan.record
    row: dict[str, str] = {
        "reference_code": record.reference_code,
        "session_id": record.session_id,
        "scan_id": record.scan_id,
        "triggered_at_utc": record.step_timestamps.get("trigger", ""),
        "color_captured_at_utc": record.color.captured_at.isoformat(),
        "thermal_captured_at_utc": record.thermal.captured_at.isoformat(),
        "ambient_temp_c": _number(record.ambient.temp_c, 2),
        "ambient_humidity_pct": _number(record.ambient.humidity_pct, 1),
        "config_hash": record.config_hash,
        "software_version": __version__,
        "left_foot_position": "image_left" if scan.decision.left_is_image_left else "image_right",
        "sidedness_source": scan.decision.source,
        "asymmetry_threshold_c": _number(scan.asymmetry.threshold_c, 2),
        "max_abs_delta_c": _number(scan.asymmetry.max_abs_delta_c),
        "any_region_flagged": _flag(scan.fused.any_region_flagged),
        "flagged_regions": ";".join(scan.asymmetry.flagged_regions),
        "predicted_class": _whole(scan.fused.predicted_class),
        "predicted_label": scan.fused.predicted_label or "",
        "confidence": _number(scan.fused.confidence, 6),
        "model_id": scan.fused.model_id or "",
        "registration_error_px": _number(scan.registered.reprojection_error_px),
        "color_coverage_fraction": _number(scan.registered.coverage_fraction),
        "scan_folder": scan_folder,
    }
    for region in scan.asymmetry.regions:
        row[f"{region.name}_left_mean_c"] = _number(region.left_mean_c)
        row[f"{region.name}_right_mean_c"] = _number(region.right_mean_c)
        row[f"{region.name}_delta_c"] = _number(region.delta_c)
        row[f"{region.name}_flagged"] = _flag(region.flagged)
    if set(row) != set(CSV_COLUMNS):
        raise StorageError("internal error: CSV row does not match the CSV columns")
    return row


def _csv_line(values: list[str]) -> str:
    buffer = io.StringIO()
    csv.writer(buffer, lineterminator="\n").writerow(values)
    return buffer.getvalue()


def append_csv_row(path: Path, row: dict[str, str]) -> None:
    """Append one row with a single write, then force it to disk.

    The file is only ever appended to. If it exists with different columns
    (an older software version) it is left untouched and an error is raised.
    """
    header = _csv_line(list(CSV_COLUMNS))
    line = _csv_line([row[column] for column in CSV_COLUMNS])
    try:
        if path.is_file() and path.stat().st_size > 0:
            with path.open("r", encoding="utf-8", newline="") as handle:
                existing_header = handle.readline()
            if existing_header != header:
                raise StorageError(
                    f"{path.name} has different columns from this software version. "
                    "Move the old file aside; it is never rewritten."
                )
            payload = line
        else:
            payload = header + line
        path.parent.mkdir(parents=True, exist_ok=True)
        # O_BINARY only exists on Windows, where it stops line endings being rewritten.
        flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_BINARY", 0)
        descriptor = os.open(path, flags, 0o644)
        try:
            os.write(descriptor, payload.encode("utf-8"))
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    except OSError as exc:
        raise StorageError(f"could not append to {path.name}: {exc}") from exc


class ScanStore:
    def __init__(self, data_dir: Path, csv_name: str, *, fake_mode: bool = False) -> None:
        self._data_dir = data_dir
        self._csv_path = data_dir / csv_name
        self._fake_mode = fake_mode

    @property
    def data_dir(self) -> Path:
        return self._data_dir

    @property
    def csv_path(self) -> Path:
        return self._csv_path

    def save(self, scan: AnalysedScan) -> Path:
        """Write the scan folder and its CSV row. Both, or neither."""
        record = scan.record
        final_dir = layout.scan_dir(self._data_dir, record.session_id, record.scan_id)
        files = paired_record_files(record)
        files[layout.COLOR_REGISTERED_FILE] = encode_png(scan.registered.crop_bgr)
        files[layout.OVERLAY_FILE] = encode_png(scan.overlay_bgr)
        meta = analysis_metadata(scan)
        # True only for scans made with the stand-in drivers: synthetic, not data.
        meta["fake_mode"] = self._fake_mode
        files[layout.META_FILE] = encode_json(meta)
        write_scan_folder(final_dir, files)
        relative = final_dir.relative_to(self._data_dir).as_posix()
        try:
            append_csv_row(self._csv_path, csv_row(scan, relative))
        except StorageError:
            # No folder without its row: undo the folder so nothing is half stored.
            shutil.rmtree(final_dir, ignore_errors=True)
            raise
        logger.info("scan stored: folder and CSV row written")
        return final_dir
