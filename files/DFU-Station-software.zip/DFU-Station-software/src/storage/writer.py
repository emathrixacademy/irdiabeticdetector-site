"""Writes scans to local storage.

A scan folder appears complete or not at all: files are written to a hidden
temporary folder beside the destination and moved into place in one rename.
Nothing here opens a network connection.
"""

from __future__ import annotations

import io
import json
import logging
import os
import shutil
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from numpy.typing import NDArray

from src import __version__
from src.datamodel import ImageArray, ScanRecord
from src.errors import StorageError
from src.storage import layout

logger = logging.getLogger(__name__)

TEMP_PREFIX = ".incomplete-"


def encode_png(image: ImageArray) -> bytes:
    ok, encoded = cv2.imencode(".png", image)
    if not ok:
        raise StorageError("could not encode an image as PNG")
    return bytes(encoded.tobytes())


def encode_npy(array: NDArray[Any]) -> bytes:
    buffer = io.BytesIO()
    np.save(buffer, array, allow_pickle=False)
    return buffer.getvalue()


def encode_json(data: dict[str, Any]) -> bytes:
    return (json.dumps(data, indent=2, sort_keys=True, allow_nan=False) + "\n").encode("utf-8")


def record_metadata(record: ScanRecord) -> dict[str, Any]:
    """Metadata for the paired capture."""
    return {
        "software_version": __version__,
        "reference_code": record.reference_code,
        "session_id": record.session_id,
        "scan_id": record.scan_id,
        "config_hash": record.config_hash,
        "step_timestamps_utc": dict(record.step_timestamps),
        "ambient": {
            "temp_c": record.ambient.temp_c,
            "humidity_pct": record.ambient.humidity_pct,
            "captured_at_utc": record.ambient.captured_at.isoformat(),
        },
        "color": {
            "captured_at_utc": record.color.captured_at.isoformat(),
            "width_px": int(record.color.image_bgr.shape[1]),
            "height_px": int(record.color.image_bgr.shape[0]),
        },
        "thermal": {
            "captured_at_utc": record.thermal.captured_at.isoformat(),
            "width_px": int(record.thermal.temps_c.shape[1]),
            "height_px": int(record.thermal.temps_c.shape[0]),
            "ffc_state": record.thermal.ffc_state.value,
            "raw_units": "centikelvin (TLinear Y16)",
            "temp_units": "degrees Celsius, after per-unit calibration",
        },
    }


def write_scan_folder(final_dir: Path, files: dict[str, bytes]) -> Path:
    """Write all files, then move the folder into place. All or nothing."""
    if final_dir.exists():
        raise StorageError(f"scan folder already exists: {final_dir.name}")
    temp_dir = final_dir.parent / (TEMP_PREFIX + final_dir.name)
    try:
        final_dir.parent.mkdir(parents=True, exist_ok=True)
        if temp_dir.exists():
            shutil.rmtree(temp_dir)
        temp_dir.mkdir()
        for name, content in files.items():
            with (temp_dir / name).open("wb") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
        os.replace(temp_dir, final_dir)
    except OSError as exc:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise StorageError(f"could not write the scan folder: {exc}") from exc
    return final_dir


def paired_record_files(record: ScanRecord) -> dict[str, bytes]:
    return {
        layout.COLOR_FILE: encode_png(record.color.image_bgr),
        layout.THERMAL_RAW_FILE: encode_npy(record.thermal.raw),
        layout.THERMAL_TEMP_FILE: encode_npy(record.thermal.temps_c),
        layout.META_FILE: encode_json(record_metadata(record)),
    }


def write_paired_record(record: ScanRecord, data_dir: Path) -> Path:
    """Store the paired colour and thermal frames of one capture."""
    final_dir = layout.scan_dir(data_dir, record.session_id, record.scan_id)
    path = write_scan_folder(final_dir, paired_record_files(record))
    logger.info("paired record written")
    return path
