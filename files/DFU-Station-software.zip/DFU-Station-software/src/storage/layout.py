"""Names and paths for stored scans: data/<session_id>/<scan_id>/."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

COLOR_FILE = "color.png"
COLOR_REGISTERED_FILE = "color_registered.png"
THERMAL_RAW_FILE = "thermal_raw_y16.npy"
THERMAL_TEMP_FILE = "thermal_temp_c.npy"
OVERLAY_FILE = "overlay.png"
META_FILE = "meta.json"

SCAN_FILES: tuple[str, ...] = (
    COLOR_FILE,
    COLOR_REGISTERED_FILE,
    THERMAL_RAW_FILE,
    THERMAL_TEMP_FILE,
    OVERLAY_FILE,
    META_FILE,
)


def make_session_id(reference_code: str, when: datetime) -> str:
    """One session is one reference code on one UTC date."""
    return f"{when:%Y%m%d}_{reference_code}"


def make_scan_id(when: datetime) -> str:
    """UTC trigger time to the millisecond."""
    return f"{when:%Y%m%dT%H%M%S}{when.microsecond // 1000:03d}Z"


def scan_dir(data_dir: Path, session_id: str, scan_id: str) -> Path:
    return data_dir / session_id / scan_id
