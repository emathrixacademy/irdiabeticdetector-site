"""Puts the asymmetry result and the classifier output side by side.

Fusion does not combine them into a verdict. The station reports two separate
things: which regions crossed the temperature-difference threshold, and what
class the colour-image model predicted. Neither is a clinical finding, and
the wording here says so.

The classifier is optional. While the station is collecting the data a model
will later be trained on, there is no model to run: the scan is measured and
stored in full and the classifier fields are simply empty.
"""

from __future__ import annotations

from src.datamodel import AsymmetryResult, ClassifierResult, FusedResult

RESEARCH_NOTICE = (
    "Research instrument. These are measurements and a model output for the research "
    "team's study. They are not a clinical assessment."
)
NO_CLASSIFIER_LINE = "Colour model: not installed. This scan is stored for data collection."


def fuse(asymmetry: AsymmetryResult, classifier: ClassifierResult | None) -> FusedResult:
    return FusedResult(
        any_region_flagged=bool(asymmetry.flagged_regions),
        flagged_regions=asymmetry.flagged_regions,
        max_abs_delta_c=asymmetry.max_abs_delta_c,
        region_deltas_c={region.name: region.delta_c for region in asymmetry.regions},
        asymmetry_threshold_c=asymmetry.threshold_c,
        predicted_class=classifier.predicted_class if classifier else None,
        predicted_label=classifier.predicted_label if classifier else None,
        confidence=classifier.confidence if classifier else None,
        model_id=classifier.model_id if classifier else None,
    )


def summary_lines(fused: FusedResult) -> list[str]:
    """Plain-language summary for the results screen."""
    count = len(fused.flagged_regions)
    if count == 0:
        flags = (
            f"No region reached the {fused.asymmetry_threshold_c:.1f} C left-right "
            "difference threshold."
        )
    else:
        names = ", ".join(name.replace("_", " ") for name in fused.flagged_regions)
        plural = "region" if count == 1 else "regions"
        flags = (
            f"{count} {plural} at or above the {fused.asymmetry_threshold_c:.1f} C "
            f"left-right difference threshold: {names}."
        )
    if fused.predicted_label is None or fused.confidence is None:
        model_line = NO_CLASSIFIER_LINE
    else:
        model_line = (
            f"Colour model predicted class: {fused.predicted_label} "
            f"(confidence {fused.confidence * 100:.0f} %)."
        )
    return [
        flags,
        f"Largest left-right difference: {fused.max_abs_delta_c:.2f} C.",
        model_line,
        RESEARCH_NOTICE,
    ]
