"""Sensirion SHT31 temperature and humidity sensor on I2C.

The ambient reading gates every capture, so every failure here raises
SensorFaultError. A value is never estimated, cached or defaulted.

HARDWARE VERIFICATION PENDING: see BLOCKERS.md (task 4.3).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from src.clock import Clock
from src.datamodel import AmbientReading
from src.errors import SensorFaultError
from src.hardware.interfaces import AmbientSensor

# Single-shot measurement, high repeatability, no clock stretching.
COMMAND_MEASURE_HIGH = bytes([0x24, 0x00])
MEASUREMENT_TIME_S = 0.016
RESPONSE_LENGTH = 6

CRC_POLYNOMIAL = 0x31
CRC_INIT = 0xFF
RAW_FULL_SCALE = 65535.0


class I2cBus(ABC):
    @abstractmethod
    def write(self, address: int, data: bytes) -> None: ...

    @abstractmethod
    def read(self, address: int, length: int) -> bytes: ...

    def close(self) -> None:  # noqa: B027 - optional hook
        """Release the bus."""


class Smbus2Bus(I2cBus):
    def __init__(self, bus_number: int) -> None:
        try:
            import smbus2

            self._smbus2: Any = smbus2
            self._bus = smbus2.SMBus(bus_number)
        except (ImportError, OSError) as exc:
            raise SensorFaultError(f"cannot open I2C bus {bus_number}: {exc}") from exc

    def write(self, address: int, data: bytes) -> None:
        self._bus.i2c_rdwr(self._smbus2.i2c_msg.write(address, list(data)))

    def read(self, address: int, length: int) -> bytes:
        message = self._smbus2.i2c_msg.read(address, length)
        self._bus.i2c_rdwr(message)
        return bytes(message)

    def close(self) -> None:
        self._bus.close()


def crc8(data: bytes) -> int:
    """Sensirion CRC-8: polynomial 0x31, initial value 0xFF."""
    crc = CRC_INIT
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ CRC_POLYNOMIAL) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def decode_measurement(response: bytes) -> tuple[float, float]:
    """Temperature in Celsius and relative humidity in percent from 6 bytes."""
    if len(response) != RESPONSE_LENGTH:
        raise SensorFaultError(f"SHT31 returned {len(response)} bytes, expected {RESPONSE_LENGTH}")
    for start in (0, 3):
        if crc8(response[start : start + 2]) != response[start + 2]:
            raise SensorFaultError("SHT31 checksum mismatch; the reading is not trusted")
    raw_temp = (response[0] << 8) | response[1]
    raw_humidity = (response[3] << 8) | response[4]
    temp_c = -45.0 + 175.0 * raw_temp / RAW_FULL_SCALE
    humidity_pct = 100.0 * raw_humidity / RAW_FULL_SCALE
    return temp_c, humidity_pct


class Sht31Sensor(AmbientSensor):
    def __init__(self, bus: I2cBus, address: int, clock: Clock) -> None:
        self._bus = bus
        self._address = address
        self._clock = clock

    def read(self) -> AmbientReading:
        try:
            self._bus.write(self._address, COMMAND_MEASURE_HIGH)
            self._clock.sleep(MEASUREMENT_TIME_S)
            response = self._bus.read(self._address, RESPONSE_LENGTH)
        except OSError as exc:
            raise SensorFaultError(f"SHT31 did not respond on I2C: {exc}") from exc
        temp_c, humidity_pct = decode_measurement(response)
        return AmbientReading(
            temp_c=temp_c,
            humidity_pct=humidity_pct,
            captured_at=self._clock.now_utc(),
            monotonic_s=self._clock.monotonic(),
        )

    def close(self) -> None:
        self._bus.close()
