"""Hardware interfaces.

Every device sits behind one of these. Each has a real driver for the Pi 5
station and a fake that replays fixtures, so the full pipeline runs on a
laptop with nothing attached.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass
from enum import StrEnum

import numpy as np
from numpy.typing import NDArray

from src.datamodel import AmbientReading, ColorFrame, FfcState, ImageArray, RawThermalFrame


class StatusState(StrEnum):
    IDLE = "idle"
    ACCLIMATISING = "acclimatising"
    READY = "ready"
    CAPTURING = "capturing"
    ERROR = "error"


class ThermalCamera(ABC):
    """The Lepton 3.5. Produces raw Y16 frames only, never the colour stream."""

    @abstractmethod
    def radiometry_confirmed(self) -> bool:
        """True only if TLinear is on with 0.01 K resolution, read from the unit."""

    @abstractmethod
    def trigger_ffc(self) -> None:
        """Start a flat-field correction. Returns at once; poll `ffc_state`."""

    @abstractmethod
    def ffc_state(self) -> FfcState:
        """Current flat-field correction state."""

    @abstractmethod
    def read_raw(self) -> RawThermalFrame:
        """Read one fresh Y16 frame. Raises HardwareError if none arrives."""

    def close(self) -> None:  # noqa: B027 - optional hook
        """Release the device."""


class ColorCamera(ABC):
    """The Camera Module 3, with focus, exposure and white balance fixed."""

    @abstractmethod
    def capture(self) -> ColorFrame:
        """Capture one full-resolution frame."""

    def close(self) -> None:  # noqa: B027 - optional hook
        """Release the device."""


class InteriorLight(ABC):
    """The MOSFET-switched interior LED. On only for the colour frame."""

    @abstractmethod
    def on(self) -> None: ...

    @abstractmethod
    def off(self) -> None: ...

    @property
    @abstractmethod
    def is_on(self) -> bool: ...

    def close(self) -> None:  # noqa: B027 - optional hook
        """Release the device."""


class CaptureButton(ABC):
    """The physical capture button, debounced."""

    @abstractmethod
    def set_handler(self, handler: Callable[[], None] | None) -> None:
        """Call `handler` once per debounced press. None removes it."""

    def close(self) -> None:  # noqa: B027 - optional hook
        """Release the device."""


class StatusLed(ABC):
    @abstractmethod
    def set_state(self, state: StatusState) -> None: ...

    def close(self) -> None:  # noqa: B027 - optional hook
        """Release the device."""


class AmbientSensor(ABC):
    """Room temperature and humidity. Raises SensorFaultError on any failure."""

    @abstractmethod
    def read(self) -> AmbientReading: ...

    def close(self) -> None:  # noqa: B027 - optional hook
        """Release the device."""


class Accelerator(ABC):
    """Runs the classifier network. Hailo-8L on the station, ONNX on a laptop."""

    @property
    @abstractmethod
    def model_id(self) -> str:
        """Identifies the loaded model file."""

    @abstractmethod
    def infer(self, input_rgb: ImageArray) -> NDArray[np.float32]:
        """Run one RGB uint8 image (model input size) and return class scores."""

    def close(self) -> None:  # noqa: B027 - optional hook
        """Release the device."""


@dataclass(frozen=True)
class Devices:
    """Every device the station uses, real or fake."""

    thermal: ThermalCamera
    color: ColorCamera
    light: InteriorLight
    button: CaptureButton
    status_led: StatusLed
    ambient: AmbientSensor
    accelerator: Accelerator

    def close(self) -> None:
        for device in (
            self.thermal,
            self.color,
            self.light,
            self.button,
            self.status_led,
            self.ambient,
            self.accelerator,
        ):
            device.close()
