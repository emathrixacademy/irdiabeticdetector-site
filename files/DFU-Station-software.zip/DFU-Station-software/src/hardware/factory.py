"""Builds the device set, real or fake, from the config."""

from __future__ import annotations

import logging

import numpy as np
from numpy.typing import NDArray

from src.clock import Clock, RealClock, ScaledClock
from src.config import Config
from src.datamodel import ImageArray
from src.errors import HardwareError, InferenceError
from src.hardware.fakes import (
    EventLog,
    FakeAccelerator,
    FakeAmbientSensor,
    FakeCaptureButton,
    FakeColorCamera,
    FakeInteriorLight,
    FakeStatusLed,
    FakeThermalCamera,
    load_color_fixture,
    load_thermal_fixture,
)
from src.hardware.interfaces import Accelerator, Devices, ThermalCamera
from src.inference.metadata import ModelMetadata

logger = logging.getLogger(__name__)


def build_clock(config: Config) -> Clock:
    """Real time on the station. Fake mode may run a sped-up clock."""
    if config.is_fake:
        return ScaledClock(config.fake.time_scale)
    return RealClock()


class UnavailableAccelerator(Accelerator):
    """Stands in when a tool needs the cameras but not the classifier."""

    @property
    def model_id(self) -> str:
        return "unavailable"

    def infer(self, input_rgb: ImageArray) -> NDArray[np.float32]:
        raise InferenceError("no classifier was loaded for this tool")


def build_fake_devices(
    config: Config, clock: Clock, metadata: ModelMetadata | None, events: EventLog | None = None
) -> Devices:
    """Fake devices replaying the configured fixture scenario."""
    log = events or EventLog()
    scenario_dir = config.fake.fixture_dir / config.fake.scenario
    light = FakeInteriorLight(clock, log)
    return Devices(
        thermal=FakeThermalCamera(load_thermal_fixture(scenario_dir), clock, events=log),
        color=FakeColorCamera(load_color_fixture(scenario_dir), clock, light=light, events=log),
        light=light,
        button=FakeCaptureButton(),
        status_led=FakeStatusLed(),
        ambient=FakeAmbientSensor(
            clock, config.fake.ambient_temp_c, config.fake.ambient_humidity_pct, log
        ),
        accelerator=build_accelerator(config, metadata),
    )


def build_thermal_camera(config: Config, clock: Clock) -> ThermalCamera:
    """Just the thermal camera, for the diagnostic tools."""
    if config.is_fake:
        scenario_dir = config.fake.fixture_dir / config.fake.scenario
        return FakeThermalCamera(load_thermal_fixture(scenario_dir), clock)
    from src.capture.purethermal import PureThermalCamera

    return PureThermalCamera.open(config.thermal, clock)


def build_devices(config: Config, clock: Clock, metadata: ModelMetadata | None) -> Devices:
    """Pick real or fake drivers from `hardware.mode`.

    Pass `metadata=None` to leave the classifier out (calibration tools).
    """
    if config.is_fake:
        logger.warning("FAKE MODE: replaying fixtures, no hardware is in use")
        return build_fake_devices(config, clock, metadata)
    return build_real_devices(config, clock, metadata)


def build_accelerator(config: Config, metadata: ModelMetadata | None) -> Accelerator:
    """The classifier runner named by `inference.backend`."""
    if metadata is None:
        return UnavailableAccelerator()
    backend = config.inference.backend
    if backend == "fake":
        if not config.is_fake:
            raise HardwareError("inference.backend 'fake' is only allowed in fake mode")
        return FakeAccelerator(config.fake.predicted_class, metadata.class_count)
    if backend == "onnx":
        from src.inference.onnx_runner import OnnxAccelerator

        return OnnxAccelerator(config.inference.model_path, metadata)
    from src.inference.hailo_runner import HailoAccelerator

    return HailoAccelerator(config.inference.model_path, metadata)


def build_real_devices(config: Config, clock: Clock, metadata: ModelMetadata | None) -> Devices:
    """Real drivers for the Pi 5 station. Imports are lazy: Pi-only packages."""
    from src.capture.picamera import PiCamera3
    from src.capture.purethermal import PureThermalCamera
    from src.hardware.gpio import (
        GpioCaptureButton,
        GpioInteriorLight,
        GpioStatusLed,
        real_pin_factory,
    )
    from src.hardware.sht31 import Sht31Sensor, Smbus2Bus

    pin_factory = real_pin_factory()
    return Devices(
        thermal=PureThermalCamera.open(config.thermal, clock),
        color=PiCamera3.open(config.color, clock),
        light=GpioInteriorLight(config.gpio.interior_led_pin, pin_factory),
        button=GpioCaptureButton(
            config.gpio.capture_button_pin, config.gpio.button_debounce_s, clock, pin_factory
        ),
        status_led=GpioStatusLed(config.gpio.status_led_pin, pin_factory),
        ambient=Sht31Sensor(Smbus2Bus(config.ambient.i2c_bus), config.ambient.i2c_address, clock),
        accelerator=build_accelerator(config, metadata),
    )
