"""GPIO devices: interior LED, capture button and status LED.

Uses `gpiozero` with the `lgpio` pin factory. `RPi.GPIO` does not work on the
Pi 5's RP1 chip and is not used. The pin factory is passed in, so the same
classes run against gpiozero's mock factory in tests.

HARDWARE VERIFICATION PENDING: see BLOCKERS.md (task 4.2).
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from src.clock import Clock
from src.errors import HardwareError
from src.hardware.interfaces import CaptureButton, InteriorLight, StatusLed, StatusState

logger = logging.getLogger(__name__)

# Status LED blink patterns as (on seconds, off seconds). None is steady.
STATUS_PATTERNS: dict[StatusState, tuple[float, float] | None] = {
    StatusState.ACCLIMATISING: (1.0, 1.0),
    StatusState.READY: None,
    StatusState.CAPTURING: (0.1, 0.1),
    StatusState.ERROR: (0.1, 0.9),
}


def real_pin_factory() -> Any:
    """The lgpio pin factory for the Pi 5."""
    try:
        from gpiozero.pins.lgpio import LGPIOFactory
    except ImportError as exc:
        raise HardwareError(
            "the lgpio pin factory is not available. On the Pi install python3-lgpio with apt."
        ) from exc
    try:
        return LGPIOFactory()
    except Exception as exc:
        raise HardwareError(f"cannot open the GPIO chip: {exc}") from exc


class GpioInteriorLight(InteriorLight):
    """Interior LED through a MOSFET. Off at start-up and on close."""

    def __init__(self, pin: int, pin_factory: Any) -> None:
        from gpiozero import DigitalOutputDevice

        try:
            self._device = DigitalOutputDevice(
                pin, active_high=True, initial_value=False, pin_factory=pin_factory
            )
        except Exception as exc:
            raise HardwareError(f"cannot set up the interior LED on GPIO {pin}: {exc}") from exc

    def on(self) -> None:
        self._device.on()

    def off(self) -> None:
        self._device.off()

    @property
    def is_on(self) -> bool:
        return bool(self._device.value)

    def close(self) -> None:
        self._device.off()
        self._device.close()


class GpioCaptureButton(CaptureButton):
    """Capture button to ground with the internal pull-up, debounced.

    gpiozero debounces the edge; a second guard here ignores any press within
    `debounce_s` of the last accepted one.
    """

    def __init__(self, pin: int, debounce_s: float, clock: Clock, pin_factory: Any) -> None:
        from gpiozero import Button

        self._debounce_s = debounce_s
        self._clock = clock
        self._handler: Callable[[], None] | None = None
        self._last_press_s: float | None = None
        try:
            self._button = Button(
                pin, pull_up=True, bounce_time=debounce_s or None, pin_factory=pin_factory
            )
        except Exception as exc:
            raise HardwareError(f"cannot set up the capture button on GPIO {pin}: {exc}") from exc
        self._button.when_pressed = self._on_press

    def _on_press(self) -> None:
        now_s = self._clock.monotonic()
        if self._last_press_s is not None and now_s - self._last_press_s < self._debounce_s:
            return
        self._last_press_s = now_s
        handler = self._handler
        if handler is not None:
            handler()

    def set_handler(self, handler: Callable[[], None] | None) -> None:
        self._handler = handler

    def close(self) -> None:
        self._button.close()


class GpioStatusLed(StatusLed):
    """One LED: off idle, slow blink acclimatising, steady ready, fast blink
    capturing, short flash once a second on error."""

    def __init__(self, pin: int, pin_factory: Any) -> None:
        from gpiozero import LED

        try:
            self._led = LED(pin, pin_factory=pin_factory)
        except Exception as exc:
            raise HardwareError(f"cannot set up the status LED on GPIO {pin}: {exc}") from exc
        self._state = StatusState.IDLE

    @property
    def state(self) -> StatusState:
        return self._state

    def set_state(self, state: StatusState) -> None:
        self._state = state
        if state is StatusState.IDLE:
            self._led.off()
            return
        pattern = STATUS_PATTERNS[state]
        if pattern is None:
            self._led.on()
        else:
            self._led.blink(on_time=pattern[0], off_time=pattern[1])

    def close(self) -> None:
        self._led.off()
        self._led.close()
