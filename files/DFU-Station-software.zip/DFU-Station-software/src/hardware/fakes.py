"""Fake drivers that replay fixtures.

These never run on the station: the factory builds them only when
`hardware.mode` is `fake`. They replay recorded or synthetic frames exactly as
stored and can be told to misbehave so the refusal paths can be tested.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np
from numpy.typing import NDArray

from src.clock import Clock
from src.datamodel import (
    AmbientReading,
    ColorFrame,
    FfcState,
    ImageArray,
    RawArray,
    RawThermalFrame,
)
from src.errors import HardwareError, SensorFaultError
from src.hardware.interfaces import (
    Accelerator,
    AmbientSensor,
    CaptureButton,
    ColorCamera,
    InteriorLight,
    StatusLed,
    StatusState,
    ThermalCamera,
)

THERMAL_FIXTURE_NAME = "thermal_y16.npy"
COLOR_FIXTURE_NAME = "color.png"


@dataclass
class EventLog:
    """Order of device actions, shared by the fakes, for sequence tests."""

    events: list[tuple[str, float]] = field(default_factory=list)

    def add(self, name: str, monotonic_s: float) -> None:
        self.events.append((name, monotonic_s))

    def names(self) -> list[str]:
        return [name for name, _ in self.events]

    def time_of(self, name: str) -> float:
        for event, monotonic_s in self.events:
            if event == name:
                return monotonic_s
        raise KeyError(name)


def load_thermal_fixture(scenario_dir: Path) -> RawArray:
    path = scenario_dir / THERMAL_FIXTURE_NAME
    if not path.is_file():
        raise HardwareError(f"fake thermal fixture not found: {path}")
    raw = np.load(path, allow_pickle=False)
    if raw.dtype != np.uint16 or raw.ndim != 2:
        raise HardwareError(f"fake thermal fixture is not a 2-D uint16 array: {path}")
    return np.asarray(raw, dtype=np.uint16)


def load_color_fixture(scenario_dir: Path) -> ImageArray:
    path = scenario_dir / COLOR_FIXTURE_NAME
    data = np.fromfile(path, dtype=np.uint8) if path.is_file() else None
    image = cv2.imdecode(data, cv2.IMREAD_COLOR) if data is not None else None
    if image is None:
        raise HardwareError(f"fake colour fixture not found or unreadable: {path}")
    return np.asarray(image, dtype=np.uint8)


class FakeThermalCamera(ThermalCamera):
    """Replays one Y16 frame. FFC takes `ffc_duration_s` of clock time."""

    def __init__(
        self,
        raw: RawArray,
        clock: Clock,
        *,
        events: EventLog | None = None,
        ffc_duration_s: float = 0.5,
        radiometry: bool = True,
    ) -> None:
        self._raw = raw
        self._clock = clock
        self._events = events or EventLog()
        self._ffc_duration_s = ffc_duration_s
        self._ffc_started_s: float | None = None
        self.radiometry = radiometry
        # Test controls
        self.frame_age_s = 0.0
        self.ffc_never_completes = False
        self.fail_reads = False
        self.reads = 0

    def set_frame(self, raw: RawArray) -> None:
        self._raw = raw

    def radiometry_confirmed(self) -> bool:
        return self.radiometry

    def trigger_ffc(self) -> None:
        self._ffc_started_s = self._clock.monotonic()
        self._events.add("ffc_trigger", self._ffc_started_s)

    def ffc_state(self) -> FfcState:
        if self._ffc_started_s is None:
            return FfcState.NEVER
        if self.ffc_never_completes:
            return FfcState.IN_PROGRESS
        elapsed_s = self._clock.monotonic() - self._ffc_started_s
        return FfcState.COMPLETE if elapsed_s >= self._ffc_duration_s else FfcState.IN_PROGRESS

    def read_raw(self) -> RawThermalFrame:
        if self.fail_reads:
            raise HardwareError("fake thermal camera: no frame")
        self.reads += 1
        now_s = self._clock.monotonic()
        self._events.add("thermal_read", now_s)
        return RawThermalFrame(
            raw=self._raw.copy(),
            monotonic_s=now_s - self.frame_age_s,
            captured_at=self._clock.now_utc(),
            ffc_state=self.ffc_state(),
        )


class FakeInteriorLight(InteriorLight):
    def __init__(self, clock: Clock, events: EventLog | None = None) -> None:
        self._clock = clock
        self._events = events or EventLog()
        self._on = False

    def on(self) -> None:
        self._on = True
        self._events.add("led_on", self._clock.monotonic())

    def off(self) -> None:
        self._on = False
        self._events.add("led_off", self._clock.monotonic())

    @property
    def is_on(self) -> bool:
        return self._on


class FakeColorCamera(ColorCamera):
    """Replays one colour frame and records whether the light was on."""

    def __init__(
        self,
        image_bgr: ImageArray,
        clock: Clock,
        *,
        light: InteriorLight | None = None,
        events: EventLog | None = None,
    ) -> None:
        self._image = image_bgr
        self._clock = clock
        self._light = light
        self._events = events or EventLog()
        self.fail = False
        self.light_was_on: list[bool] = []

    def capture(self) -> ColorFrame:
        if self.fail:
            raise HardwareError("fake colour camera: capture failed")
        now_s = self._clock.monotonic()
        self._events.add("color_capture", now_s)
        if self._light is not None:
            self.light_was_on.append(self._light.is_on)
        return ColorFrame(
            image_bgr=self._image.copy(), captured_at=self._clock.now_utc(), monotonic_s=now_s
        )


class FakeCaptureButton(CaptureButton):
    def __init__(self) -> None:
        self._handler: Callable[[], None] | None = None

    def set_handler(self, handler: Callable[[], None] | None) -> None:
        self._handler = handler

    def press(self) -> None:
        """Simulate one debounced press."""
        if self._handler is not None:
            self._handler()


class FakeStatusLed(StatusLed):
    def __init__(self) -> None:
        self.states: list[StatusState] = []

    def set_state(self, state: StatusState) -> None:
        self.states.append(state)

    @property
    def state(self) -> StatusState | None:
        return self.states[-1] if self.states else None


class FakeAmbientSensor(AmbientSensor):
    def __init__(
        self,
        clock: Clock,
        temp_c: float,
        humidity_pct: float,
        events: EventLog | None = None,
    ) -> None:
        self._clock = clock
        self._events = events or EventLog()
        self.temp_c = temp_c
        self.humidity_pct = humidity_pct
        self.fail = False
        self.reading_age_s = 0.0

    def read(self) -> AmbientReading:
        if self.fail:
            raise SensorFaultError("fake ambient sensor: no response")
        now_s = self._clock.monotonic()
        self._events.add("ambient_read", now_s)
        return AmbientReading(
            temp_c=self.temp_c,
            humidity_pct=self.humidity_pct,
            captured_at=self._clock.now_utc(),
            monotonic_s=now_s - self.reading_age_s,
        )


class FakeAccelerator(Accelerator):
    """Returns the same class every time. It does not look at the image."""

    def __init__(self, predicted_class: int, class_count: int) -> None:
        if not 0 <= predicted_class < class_count:
            raise HardwareError(
                f"fake accelerator: class {predicted_class} is outside 0..{class_count - 1}"
            )
        self._predicted_class = predicted_class
        self._class_count = class_count
        self.calls = 0

    @property
    def model_id(self) -> str:
        return "fake-accelerator"

    def infer(self, input_rgb: ImageArray) -> NDArray[np.float32]:
        if input_rgb.dtype != np.uint8 or input_rgb.ndim != 3 or input_rgb.shape[2] != 3:
            raise HardwareError("fake accelerator: expected an RGB uint8 image")
        self.calls += 1
        scores = np.zeros(self._class_count, dtype=np.float32)
        scores[self._predicted_class] = 4.0
        return scores
