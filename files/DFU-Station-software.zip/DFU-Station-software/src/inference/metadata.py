"""Model metadata: labels and input description for the loaded classifier.

Labels are plain class names. A label that reads like a clinical grade is
refused, because the classifier's output is never shown or stored as a grade.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

from src.config import Config
from src.errors import InferenceError

FAKE_METADATA_NAME = "model_meta.json"
_FORBIDDEN_LABEL = re.compile(r"grade|wagner|diagnos|ulcer stage", re.IGNORECASE)


@dataclass(frozen=True)
class ModelMetadata:
    model_id: str
    labels: tuple[str, ...]
    input_width_px: int
    input_height_px: int
    mean_rgb: tuple[float, float, float]
    std_rgb: tuple[float, float, float]
    scores_are_logits: bool

    @property
    def class_count(self) -> int:
        return len(self.labels)


def metadata_path(config: Config) -> Path:
    """Where the metadata lives: beside the fixtures in fake mode."""
    if config.is_fake:
        return config.fake.fixture_dir / FAKE_METADATA_NAME
    return config.inference.metadata_path


def _triple(value: object, name: str) -> tuple[float, float, float]:
    if (
        not isinstance(value, list)
        or len(value) != 3
        or not all(isinstance(item, int | float) and not isinstance(item, bool) for item in value)
    ):
        raise InferenceError(f"model metadata: {name} must be three numbers")
    return (float(value[0]), float(value[1]), float(value[2]))


def parse_model_metadata(data: object) -> ModelMetadata:
    if not isinstance(data, dict):
        raise InferenceError("model metadata: expected a JSON object")
    try:
        model_id = data["model_id"]
        labels = data["labels"]
        width = data["input_width_px"]
        height = data["input_height_px"]
        mean = _triple(data["mean_rgb"], "mean_rgb")
        std = _triple(data["std_rgb"], "std_rgb")
        logits = data["scores_are_logits"]
    except KeyError as exc:
        raise InferenceError(f"model metadata: missing key {exc}") from exc
    if not isinstance(model_id, str) or not model_id:
        raise InferenceError("model metadata: model_id must be a non-empty string")
    if (
        not isinstance(labels, list)
        or len(labels) < 2
        or not all(isinstance(label, str) and label for label in labels)
        or len(set(labels)) != len(labels)
    ):
        raise InferenceError("model metadata: labels must be at least two distinct names")
    for label in labels:
        if _FORBIDDEN_LABEL.search(label):
            raise InferenceError(
                "model metadata: a label reads like a clinical grade. Classifier "
                "classes must have neutral names such as class_0."
            )
    for name, value in (("input_width_px", width), ("input_height_px", height)):
        if isinstance(value, bool) or not isinstance(value, int) or not 16 <= value <= 1024:
            raise InferenceError(f"model metadata: {name} must be an integer from 16 to 1024")
    if any(item <= 0 for item in std):
        raise InferenceError("model metadata: std_rgb values must be positive")
    if not isinstance(logits, bool):
        raise InferenceError("model metadata: scores_are_logits must be true or false")
    return ModelMetadata(
        model_id=model_id,
        labels=tuple(labels),
        input_width_px=width,
        input_height_px=height,
        mean_rgb=mean,
        std_rgb=std,
        scores_are_logits=logits,
    )


def load_model_metadata(path: Path) -> ModelMetadata:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise InferenceError(f"cannot read model metadata {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise InferenceError(f"model metadata {path} is not valid JSON: {exc}") from exc
    return parse_model_metadata(data)
