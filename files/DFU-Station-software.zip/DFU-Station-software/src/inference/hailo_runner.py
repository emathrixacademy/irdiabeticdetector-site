"""HailoRT runner for the Hailo-8L on the AI HAT+.

Loads a `.hef` compiled off-device with the Hailo Dataflow Compiler. Nothing
is compiled on the Pi. The `.hef` takes an RGB uint8 image; normalisation is
built into it at compile time from the same mean and standard deviation the
training code used.

`hailo_platform` comes from apt (`hailo-all`) and is imported lazily.

HARDWARE VERIFICATION PENDING: see BLOCKERS.md (task 9.2). Before debugging
anything here, confirm the device with `hailortcli fw-control identify`.
"""

from __future__ import annotations

import contextlib
from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray

from src.datamodel import ImageArray
from src.errors import InferenceError
from src.hardware.interfaces import Accelerator
from src.inference.metadata import ModelMetadata


def import_hailo() -> Any:
    try:
        import hailo_platform
    except ImportError as exc:
        raise InferenceError(
            "hailo_platform is not available. On the Pi install hailo-all with apt and "
            "create the virtual environment with --system-site-packages."
        ) from exc
    return hailo_platform


class HailoAccelerator(Accelerator):
    def __init__(self, hef_path: Path, metadata: ModelMetadata, hailo: Any | None = None) -> None:
        if not hef_path.is_file():
            raise InferenceError(f"compiled model not found: {hef_path}")
        if hef_path.suffix != ".hef":
            raise InferenceError("the Hailo runner only loads .hef files compiled off-device")
        platform = hailo if hailo is not None else import_hailo()
        self._metadata = metadata
        self._model_id = f"hailo:{hef_path.name}"
        self._stack = contextlib.ExitStack()
        try:
            hef = platform.HEF(str(hef_path))
            device = self._stack.enter_context(platform.VDevice())
            configure_params = platform.ConfigureParams.create_from_hef(
                hef, interface=platform.HailoStreamInterface.PCIe
            )
            network_group = device.configure(hef, configure_params)[0]
            input_params = platform.InputVStreamParams.make(
                network_group, format_type=platform.FormatType.UINT8
            )
            output_params = platform.OutputVStreamParams.make(
                network_group, format_type=platform.FormatType.FLOAT32
            )
            input_infos = hef.get_input_vstream_infos()
            output_infos = hef.get_output_vstream_infos()
            if len(input_infos) != 1 or len(output_infos) != 1:
                raise InferenceError("the .hef must have exactly one input and one output")
            self._input_name = str(input_infos[0].name)
            self._output_name = str(output_infos[0].name)
            expected = (metadata.input_height_px, metadata.input_width_px, 3)
            shape = tuple(int(value) for value in input_infos[0].shape)
            if shape != expected:
                raise InferenceError(
                    f"the .hef input is {shape}; the metadata describes {expected}"
                )
            self._pipeline = self._stack.enter_context(
                platform.InferVStreams(network_group, input_params, output_params)
            )
            self._stack.enter_context(network_group.activate(network_group.create_params()))
        except InferenceError:
            self._stack.close()
            raise
        except Exception as exc:
            self._stack.close()
            raise InferenceError(f"cannot load {hef_path.name} on the Hailo-8L: {exc}") from exc

    @property
    def model_id(self) -> str:
        return self._model_id

    def infer(self, input_rgb: ImageArray) -> NDArray[np.float32]:
        expected = (self._metadata.input_height_px, self._metadata.input_width_px, 3)
        if input_rgb.dtype != np.uint8 or input_rgb.shape != expected:
            raise InferenceError(f"expected an RGB uint8 image of shape {expected}")
        batch = np.ascontiguousarray(input_rgb[np.newaxis, ...])
        try:
            results = self._pipeline.infer({self._input_name: batch})
        except Exception as exc:
            raise InferenceError(f"Hailo inference failed: {exc}") from exc
        return np.asarray(results[self._output_name], dtype=np.float32).reshape(-1)

    def close(self) -> None:
        self._stack.close()
