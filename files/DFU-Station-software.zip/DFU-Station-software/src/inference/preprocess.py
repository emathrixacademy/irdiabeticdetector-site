"""Image preprocessing for the classifier, defined once.

Training (`training/`) and on-device inference both call these functions, so
the network sees the same resize and the same normalisation in both places.
Only NumPy and OpenCV are used, so the module imports anywhere.

Steps:
1. `to_model_input_rgb`: BGR -> RGB and resize to the model input size.
2. `normalise`: scale to 0..1, subtract the mean, divide by the standard
   deviation, and lay out as 1 x 3 x H x W float32.

The Hailo runner uses step 1 only: step 2 is compiled into the `.hef` from
the same mean and standard deviation (see `training/hailo_compile.py`).
"""

from __future__ import annotations

import cv2
import numpy as np
from numpy.typing import NDArray

from src.datamodel import ImageArray
from src.errors import InferenceError
from src.inference.metadata import ModelMetadata

PIXEL_MAX = 255.0


def to_model_input_rgb(image_bgr: ImageArray, metadata: ModelMetadata) -> ImageArray:
    """Resize a BGR image to the model input size and return it as RGB uint8.

    The whole image is resized to the input shape without cropping, so both
    feet stay in view. Area averaging is used when shrinking.
    """
    if image_bgr.dtype != np.uint8 or image_bgr.ndim != 3 or image_bgr.shape[2] != 3:
        raise InferenceError("the classifier needs a BGR uint8 image")
    target = (metadata.input_width_px, metadata.input_height_px)
    shrinking = image_bgr.shape[1] >= target[0] and image_bgr.shape[0] >= target[1]
    interpolation = cv2.INTER_AREA if shrinking else cv2.INTER_LINEAR
    resized = cv2.resize(image_bgr, target, interpolation=interpolation)
    return np.asarray(cv2.cvtColor(resized, cv2.COLOR_BGR2RGB), dtype=np.uint8)


def normalise(input_rgb: ImageArray, metadata: ModelMetadata) -> NDArray[np.float32]:
    """RGB uint8 H x W x 3 -> normalised float32 1 x 3 x H x W."""
    expected = (metadata.input_height_px, metadata.input_width_px, 3)
    if input_rgb.dtype != np.uint8 or input_rgb.shape != expected:
        raise InferenceError(f"expected an RGB uint8 image of shape {expected}")
    mean = np.array(metadata.mean_rgb, dtype=np.float32)
    std = np.array(metadata.std_rgb, dtype=np.float32)
    scaled = (input_rgb.astype(np.float32) / PIXEL_MAX - mean) / std
    return np.ascontiguousarray(scaled.transpose(2, 0, 1)[np.newaxis, ...], dtype=np.float32)


def preprocess(image_bgr: ImageArray, metadata: ModelMetadata) -> NDArray[np.float32]:
    """Both steps: a BGR image to the tensor the network was trained on."""
    return normalise(to_model_input_rgb(image_bgr, metadata), metadata)


def softmax(scores: NDArray[np.float32]) -> NDArray[np.float32]:
    shifted = scores.astype(np.float64) - float(np.max(scores))
    exponent = np.exp(shifted)
    return np.asarray(exponent / np.sum(exponent), dtype=np.float32)
