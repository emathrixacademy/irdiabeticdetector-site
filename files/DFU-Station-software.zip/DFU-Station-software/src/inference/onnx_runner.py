"""ONNX Runtime CPU runner, for laptops and for checking an export.

Implements the same `Accelerator` interface as the Hailo runner. It applies
the shared normalisation itself, because an ONNX export expects a normalised
float tensor.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray

from src.datamodel import ImageArray
from src.errors import InferenceError
from src.hardware.interfaces import Accelerator
from src.inference.metadata import ModelMetadata
from src.inference.preprocess import normalise


class OnnxAccelerator(Accelerator):
    def __init__(self, model_path: Path, metadata: ModelMetadata) -> None:
        if not model_path.is_file():
            raise InferenceError(f"ONNX model not found: {model_path}")
        try:
            import onnxruntime
        except ImportError as exc:
            raise InferenceError("onnxruntime is not installed") from exc
        try:
            self._session: Any = onnxruntime.InferenceSession(
                str(model_path), providers=["CPUExecutionProvider"]
            )
        except Exception as exc:
            raise InferenceError(f"cannot load ONNX model {model_path.name}: {exc}") from exc
        inputs = self._session.get_inputs()
        if len(inputs) != 1:
            raise InferenceError("the ONNX model must have exactly one input")
        self._input_name = str(inputs[0].name)
        expected = [1, 3, metadata.input_height_px, metadata.input_width_px]
        shape = list(inputs[0].shape)
        fixed = [dim for dim in shape if isinstance(dim, int)]
        if len(shape) != 4 or (len(fixed) == 4 and shape != expected):
            raise InferenceError(
                f"the ONNX model input is {shape}; the metadata describes {expected}"
            )
        self._metadata = metadata
        self._model_id = f"onnx:{model_path.name}"

    @property
    def model_id(self) -> str:
        return self._model_id

    def infer(self, input_rgb: ImageArray) -> NDArray[np.float32]:
        tensor = normalise(input_rgb, self._metadata)
        try:
            outputs = self._session.run(None, {self._input_name: tensor})
        except Exception as exc:
            raise InferenceError(f"ONNX inference failed: {exc}") from exc
        return np.asarray(outputs[0], dtype=np.float32).reshape(-1)
