"""Runs the classifier on the registered colour crop.

The result is a `predicted_class`: a model output about the look of the skin
in a colour image. It is not a Wagner grade, is never stored or shown as one,
and is never treated as ground truth. Grades come from a clinician.
"""

from __future__ import annotations

import numpy as np

from src.datamodel import ClassifierResult, ImageArray
from src.errors import InferenceError
from src.hardware.interfaces import Accelerator
from src.inference.metadata import ModelMetadata
from src.inference.preprocess import softmax, to_model_input_rgb


class Classifier:
    def __init__(self, accelerator: Accelerator, metadata: ModelMetadata) -> None:
        self._accelerator = accelerator
        self._metadata = metadata

    def classify(self, crop_bgr: ImageArray) -> ClassifierResult:
        """Class index, label and confidence for one colour crop."""
        input_rgb = to_model_input_rgb(crop_bgr, self._metadata)
        scores = np.asarray(self._accelerator.infer(input_rgb), dtype=np.float32).reshape(-1)
        if scores.size != self._metadata.class_count:
            raise InferenceError(
                f"the model returned {scores.size} scores but the metadata lists "
                f"{self._metadata.class_count} classes"
            )
        if not np.all(np.isfinite(scores)):
            raise InferenceError("the model returned non-finite scores")
        probabilities = softmax(scores) if self._metadata.scores_are_logits else scores
        index = int(np.argmax(probabilities))
        confidence = float(probabilities[index])
        if not 0.0 <= confidence <= 1.0 + 1e-6:
            raise InferenceError("the model scores are not probabilities; check the metadata")
        return ClassifierResult(
            predicted_class=index,
            predicted_label=self._metadata.labels[index],
            confidence=min(confidence, 1.0),
            model_id=self._accelerator.model_id,
        )
