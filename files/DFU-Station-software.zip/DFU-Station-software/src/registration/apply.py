"""Apply the registration: bring the colour frame onto the thermal field.

The thermal frame is the limiting frame. Colour is mapped DOWN to the thermal
field of view and grid. The thermal frame is never resampled here, and never
upsampled anywhere to be treated as real detail.

Two colour outputs share the thermal field of view:
- `thermal_grid_bgr`, one colour pixel per thermal pixel, for overlays;
- `crop_bgr`, the same field at `registration.color_scale` times the thermal
  grid, so the classifier keeps real colour detail instead of working from a
  160 x 120 image.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import cv2
import numpy as np

from src.config import RegistrationConfig
from src.datamodel import ImageArray, MaskArray, TempArray
from src.errors import RegistrationError
from src.registration.model import Registration

OVERLAY_COLOR_WEIGHT = 0.45
DISPLAY_COLORMAP = cv2.COLORMAP_INFERNO


@dataclass(frozen=True)
class RegisteredColor:
    thermal_grid_bgr: ImageArray = field(repr=False)
    crop_bgr: ImageArray = field(repr=False)
    # True where the colour camera actually saw the thermal pixel.
    covered: MaskArray = field(repr=False)
    coverage_fraction: float
    reprojection_error_px: float


def register_color(
    color_bgr: ImageArray, registration: Registration, config: RegistrationConfig
) -> RegisteredColor:
    """Warp the colour frame into the thermal field of view."""
    expected = (registration.color_height_px, registration.color_width_px, 3)
    if color_bgr.shape != expected or color_bgr.dtype != np.uint8:
        raise RegistrationError(
            f"colour frame is {color_bgr.shape} {color_bgr.dtype}; the registration was "
            f"calibrated for {expected} uint8. Recalibrate after changing the colour mode."
        )
    scale = config.color_scale
    width = registration.thermal_width_px
    height = registration.thermal_height_px
    # Thermal pixel centre i sits at scale * i + (scale - 1) / 2 on the finer grid.
    shift = (scale - 1) / 2.0
    to_crop = np.array(
        [[scale, 0.0, shift], [0.0, scale, shift], [0.0, 0.0, 1.0]], dtype=np.float64
    )
    matrix = to_crop @ registration.homography_color_to_thermal
    crop_size = (width * scale, height * scale)
    crop = cv2.warpPerspective(color_bgr, matrix, crop_size, flags=cv2.INTER_LINEAR)
    seen = cv2.warpPerspective(
        np.full(color_bgr.shape[:2], 255, dtype=np.uint8),
        matrix,
        crop_size,
        flags=cv2.INTER_NEAREST,
    )
    # Each thermal pixel is the mean of its scale x scale block of colour pixels.
    thermal_grid = cv2.resize(crop, (width, height), interpolation=cv2.INTER_AREA)
    covered = (
        seen.reshape(height, scale, width, scale).min(axis=(1, 3)) == 255  # whole block seen
    )
    return RegisteredColor(
        thermal_grid_bgr=np.asarray(thermal_grid, dtype=np.uint8),
        crop_bgr=np.asarray(crop, dtype=np.uint8),
        covered=np.asarray(covered, dtype=np.bool_),
        coverage_fraction=float(np.mean(covered)),
        reprojection_error_px=registration.reprojection_error_px,
    )


def thermal_display_bgr(temps_c: TempArray) -> ImageArray:
    """A false-colour picture of a temperature frame. For display only."""
    low = float(np.min(temps_c))
    high = float(np.max(temps_c))
    span = high - low if high > low else 1.0
    scaled = np.asarray(np.rint((temps_c - low) / span * 255.0), dtype=np.uint8)
    return np.asarray(cv2.applyColorMap(scaled, DISPLAY_COLORMAP), dtype=np.uint8)


def make_overlay(temps_c: TempArray, registered: RegisteredColor) -> ImageArray:
    """Thermal false colour blended with the registered colour frame.

    Both are on the thermal grid. This picture is for the operator and the
    registration check; no temperature is read back from it.
    """
    if temps_c.shape != registered.thermal_grid_bgr.shape[:2]:
        raise RegistrationError("thermal frame and registered colour frame differ in size")
    thermal_picture = thermal_display_bgr(temps_c)
    overlay = cv2.addWeighted(
        registered.thermal_grid_bgr,
        OVERLAY_COLOR_WEIGHT,
        thermal_picture,
        1.0 - OVERLAY_COLOR_WEIGHT,
        0.0,
    )
    return np.asarray(overlay, dtype=np.uint8)
