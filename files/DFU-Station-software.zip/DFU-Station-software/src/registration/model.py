"""The stored registration: one homography from colour pixels to thermal pixels."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import yaml
from numpy.typing import NDArray

from src.config import Config
from src.errors import RegistrationError

logger = logging.getLogger(__name__)

FIXTURE_REGISTRATION_NAME = "registration.yaml"


@dataclass(frozen=True)
class Registration:
    """Maps a colour pixel (x, y) to the thermal pixel that sees the same point.

    Valid for subjects in the calibrated plane (the sole plane at the working
    distance). The cameras are 40 mm apart, so points nearer or farther shift
    slightly; see docs/calibration.md.
    """

    homography_color_to_thermal: NDArray[np.float64]
    color_width_px: int
    color_height_px: int
    thermal_width_px: int
    thermal_height_px: int
    reprojection_error_px: float
    point_count: int
    calibrated_at: str

    def to_dict(self) -> dict[str, object]:
        return {
            "homography_color_to_thermal": [
                [float(value) for value in row] for row in self.homography_color_to_thermal
            ],
            "color_width_px": self.color_width_px,
            "color_height_px": self.color_height_px,
            "thermal_width_px": self.thermal_width_px,
            "thermal_height_px": self.thermal_height_px,
            "reprojection_error_px": float(self.reprojection_error_px),
            "point_count": self.point_count,
            "calibrated_at": self.calibrated_at,
        }


def parse_registration(data: object, source: str) -> Registration:
    if not isinstance(data, dict):
        raise RegistrationError(f"{source}: expected a mapping")
    try:
        matrix = np.array(data["homography_color_to_thermal"], dtype=np.float64)
        sizes = [
            data[key]
            for key in (
                "color_width_px",
                "color_height_px",
                "thermal_width_px",
                "thermal_height_px",
                "point_count",
            )
        ]
        error_px = data["reprojection_error_px"]
        calibrated_at = str(data["calibrated_at"])
    except (KeyError, TypeError, ValueError) as exc:
        raise RegistrationError(f"{source}: missing or malformed value: {exc}") from exc
    if matrix.shape != (3, 3) or not np.all(np.isfinite(matrix)):
        raise RegistrationError(f"{source}: the homography must be a finite 3x3 matrix")
    if abs(float(np.linalg.det(matrix))) < 1e-12:
        raise RegistrationError(f"{source}: the homography is singular")
    if not all(isinstance(value, int) and not isinstance(value, bool) for value in sizes):
        raise RegistrationError(f"{source}: sizes and point_count must be integers")
    if isinstance(error_px, bool) or not isinstance(error_px, int | float) or error_px < 0:
        raise RegistrationError(f"{source}: reprojection_error_px must be a non-negative number")
    return Registration(
        homography_color_to_thermal=matrix,
        color_width_px=sizes[0],
        color_height_px=sizes[1],
        thermal_width_px=sizes[2],
        thermal_height_px=sizes[3],
        reprojection_error_px=float(error_px),
        point_count=sizes[4],
        calibrated_at=calibrated_at,
    )


def read_registration(path: Path) -> Registration:
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise RegistrationError(f"cannot read registration file {path}: {exc}") from exc
    return parse_registration(data, str(path))


def save_registration(registration: Registration, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(registration.to_dict(), sort_keys=True), encoding="utf-8")


def load_registration(config: Config) -> Registration:
    """Load this unit's registration and check it against the config.

    On real hardware a missing file is an error. In fake mode the synthetic
    registration stored beside the fixtures is used instead, with a warning.
    """
    path = config.registration.calibration_path
    if not path.is_file():
        fixture_path = config.fake.fixture_dir / FIXTURE_REGISTRATION_NAME
        if not config.is_fake:
            raise RegistrationError(
                f"registration file {path} is missing. Run "
                "`python -m src.diagnostics.registration_calibrate` with the target first."
            )
        logger.warning("registration file is absent; using the synthetic one (fake mode only)")
        path = fixture_path
    registration = read_registration(path)
    limit_px = config.registration.max_reprojection_error_px
    if registration.reprojection_error_px > limit_px:
        raise RegistrationError(
            f"stored registration error {registration.reprojection_error_px:.2f} px is above "
            f"the limit {limit_px:.2f} px; recalibrate"
        )
    expected = (config.thermal.width_px, config.thermal.height_px)
    if (registration.thermal_width_px, registration.thermal_height_px) != expected:
        raise RegistrationError("registration was made for a different thermal frame size")
    return registration
