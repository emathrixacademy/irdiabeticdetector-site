"""Registration calibration from a target both cameras can see.

The target is a flat, light-coloured perforated plate held in the sole plane
over a warm, dark surface. Each hole is warm in the thermal frame and dark in
the colour frame. Matching hole centres in the two frames give the homography
from colour pixels to thermal pixels. See docs/calibration.md.
"""

from __future__ import annotations

import cv2
import numpy as np
from numpy.typing import NDArray

from src.config import Config
from src.datamodel import ImageArray, TempArray
from src.errors import RegistrationError
from src.registration.model import Registration

# A hole smaller than this many pixels is noise, not a hole.
MIN_BLOB_AREA_PX = 4
# Holes in one row must sit within this fraction of the row spacing of each
# other vertically, or the plate is turned too far to order the grid safely.
MAX_ROW_SPREAD_FRACTION = 0.5

Points = NDArray[np.float64]


def _blob_centroids(mask: NDArray[np.bool_], weights: NDArray[np.float64]) -> Points:
    """Weighted centroids of blobs that do not touch the image border."""
    count, labels, stats, _ = cv2.connectedComponentsWithStats(
        mask.astype(np.uint8), connectivity=8
    )
    height, width = mask.shape
    centroids: list[tuple[float, float]] = []
    for label in range(1, count):
        left, top, blob_width, blob_height, area = (int(value) for value in stats[label])
        if area < MIN_BLOB_AREA_PX:
            continue
        touches_border = (
            left == 0 or top == 0 or left + blob_width == width or top + blob_height == height
        )
        if touches_border:
            continue
        ys, xs = np.nonzero(labels == label)
        blob_weights = weights[ys, xs]
        total = float(blob_weights.sum())
        if total <= 0:
            continue
        centroids.append(
            (float((xs * blob_weights).sum() / total), float((ys * blob_weights).sum() / total))
        )
    return np.array(centroids, dtype=np.float64).reshape(-1, 2)


def _otsu_threshold(values: NDArray[np.float64]) -> float:
    """Otsu's threshold on a float image, returned in the image's own units."""
    low = float(np.min(values))
    high = float(np.max(values))
    if high - low <= 0:
        raise RegistrationError("the calibration image is flat; no target is visible")
    scaled = np.asarray(np.rint((values - low) / (high - low) * 255.0), dtype=np.uint8)
    level, _ = cv2.threshold(scaled, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    # Otsu gives the lowest equally good level, which for a two-tone image sits
    # on the darker tone itself. Use the midpoint between the two class means.
    lower = scaled <= level
    if lower.all() or not lower.any():
        raise RegistrationError("the calibration image is flat; no target is visible")
    return (float(np.mean(values[lower])) + float(np.mean(values[~lower]))) / 2.0


def find_thermal_holes(temps_c: TempArray) -> Points:
    """Centres of the warm holes, in thermal pixels."""
    threshold_c = _otsu_threshold(temps_c)
    above = temps_c > threshold_c
    return _blob_centroids(above, np.where(above, temps_c - threshold_c, 0.0) + 1e-9)


def find_color_holes(color_bgr: ImageArray) -> Points:
    """Centres of the dark holes, in colour pixels."""
    gray = cv2.cvtColor(color_bgr, cv2.COLOR_BGR2GRAY).astype(np.float64)
    threshold = _otsu_threshold(gray)
    below = gray < threshold
    return _blob_centroids(below, np.where(below, threshold - gray, 0.0) + 1e-9)


def order_grid(points: Points, rows: int, cols: int, what: str) -> Points:
    """Sort hole centres row by row, left to right, and check it is a clean grid."""
    expected = rows * cols
    if len(points) != expected:
        raise RegistrationError(
            f"found {len(points)} holes in the {what} frame, expected {expected} "
            f"({rows} x {cols}). Check the target is fully in view and evenly warm."
        )
    by_row = points[np.argsort(points[:, 1], kind="stable")].reshape(rows, cols, 2)
    row_centres = by_row[:, :, 1].mean(axis=1)
    row_spacing = float(np.median(np.diff(row_centres)))
    row_spread = float(np.max(np.ptp(by_row[:, :, 1], axis=1)))
    if row_spread >= MAX_ROW_SPREAD_FRACTION * row_spacing:
        raise RegistrationError(
            f"the target rows overlap in the {what} frame; hold the plate square to the cameras"
        )
    ordered = np.stack([row[np.argsort(row[:, 0], kind="stable")] for row in by_row])
    return np.asarray(ordered.reshape(expected, 2), dtype=np.float64)


def project(homography: NDArray[np.float64], points: Points) -> Points:
    """Apply a homography to an N x 2 array of points."""
    homogeneous = np.hstack([points, np.ones((len(points), 1))])
    mapped = homogeneous @ homography.T
    return np.asarray(mapped[:, :2] / mapped[:, 2:3], dtype=np.float64)


def reprojection_error_px(
    homography: NDArray[np.float64], color_points: Points, thermal_points: Points
) -> float:
    """RMS distance, in thermal pixels, between mapped colour points and thermal points."""
    residual = project(homography, color_points) - thermal_points
    return float(np.sqrt(np.mean(np.sum(residual**2, axis=1))))


def fit_registration(
    color_points: Points,
    thermal_points: Points,
    *,
    color_size_px: tuple[int, int],
    thermal_size_px: tuple[int, int],
    max_error_px: float,
    calibrated_at: str,
) -> Registration:
    """Fit the homography and fail if the reprojection error is above the limit."""
    if len(color_points) != len(thermal_points) or len(color_points) < 4:
        raise RegistrationError("registration needs at least 4 matching points")
    homography, _ = cv2.findHomography(color_points, thermal_points, 0)
    if homography is None or not np.all(np.isfinite(homography)):
        raise RegistrationError("could not fit a homography to the target points")
    matrix = np.asarray(homography, dtype=np.float64)
    error_px = reprojection_error_px(matrix, color_points, thermal_points)
    if error_px > max_error_px:
        raise RegistrationError(
            f"registration error {error_px:.2f} px is above the limit {max_error_px:.2f} px. "
            "Calibration failed and nothing was stored."
        )
    return Registration(
        homography_color_to_thermal=matrix,
        color_width_px=color_size_px[0],
        color_height_px=color_size_px[1],
        thermal_width_px=thermal_size_px[0],
        thermal_height_px=thermal_size_px[1],
        reprojection_error_px=error_px,
        point_count=len(color_points),
        calibrated_at=calibrated_at,
    )


def calibrate_from_target(
    color_bgr: ImageArray, temps_c: TempArray, config: Config, calibrated_at: str
) -> Registration:
    """Detect the target in both frames and fit the registration."""
    rows = config.registration.target_rows
    cols = config.registration.target_cols
    thermal_points = order_grid(find_thermal_holes(temps_c), rows, cols, "thermal")
    color_points = order_grid(find_color_holes(color_bgr), rows, cols, "colour")
    return fit_registration(
        color_points,
        thermal_points,
        color_size_px=(int(color_bgr.shape[1]), int(color_bgr.shape[0])),
        thermal_size_px=(int(temps_c.shape[1]), int(temps_c.shape[0])),
        max_error_px=config.registration.max_reprojection_error_px,
        calibrated_at=calibrated_at,
    )
