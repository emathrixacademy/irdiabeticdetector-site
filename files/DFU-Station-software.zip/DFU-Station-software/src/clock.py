"""Time behind an interface, so gates and delays can be tested without waiting."""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from datetime import UTC, datetime, timedelta


class Clock(ABC):
    @abstractmethod
    def monotonic(self) -> float:
        """Seconds on a clock that never goes backwards. Used for ages and delays."""

    @abstractmethod
    def now_utc(self) -> datetime:
        """Wall-clock time in UTC. Used only for timestamps in records."""

    @abstractmethod
    def sleep(self, seconds: float) -> None:
        """Wait for the given number of clock seconds."""


class RealClock(Clock):
    def monotonic(self) -> float:
        return time.monotonic()

    def now_utc(self) -> datetime:
        return datetime.now(UTC)

    def sleep(self, seconds: float) -> None:
        if seconds > 0:
            time.sleep(seconds)


class ScaledClock(Clock):
    """A clock that runs faster than real time. Fake mode only.

    It lets the fake UI show a full 900 s acclimatisation countdown in a few
    seconds. The factory never builds it when real drivers are in use.
    """

    def __init__(self, time_scale: float) -> None:
        if time_scale < 1.0:
            raise ValueError("time_scale must be at least 1.0")
        self._scale = time_scale
        self._start = time.monotonic()

    def monotonic(self) -> float:
        return (time.monotonic() - self._start) * self._scale

    def now_utc(self) -> datetime:
        return datetime.now(UTC)

    def sleep(self, seconds: float) -> None:
        if seconds > 0:
            time.sleep(seconds / self._scale)


class ManualClock(Clock):
    """A clock that only moves when told to. For tests and headless fake runs."""

    def __init__(self, start_utc: datetime | None = None) -> None:
        self._elapsed_s = 0.0
        self._start_utc = start_utc or datetime(2026, 10, 8, 1, 0, 0, tzinfo=UTC)
        self.sleeps: list[float] = []

    def monotonic(self) -> float:
        return self._elapsed_s

    def now_utc(self) -> datetime:
        return self._start_utc + timedelta(seconds=self._elapsed_s)

    def sleep(self, seconds: float) -> None:
        self.sleeps.append(seconds)
        self.advance(seconds)

    def advance(self, seconds: float) -> None:
        if seconds < 0:
            raise ValueError("a clock cannot go backwards")
        self._elapsed_s += seconds
