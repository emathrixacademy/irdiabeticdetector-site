"""Record the software versions on the station.

    python -m src.diagnostics.versions

Prints a Markdown table for PROGRESS.md: Pi model, OS release, kernel, Python,
HailoRT, Hailo firmware and picamera2. The HailoRT version decides which
Dataflow Compiler release may be used to build the `.hef`.

Every value is read from the system. A value that cannot be read is reported
as "not found", never guessed.
"""

from __future__ import annotations

import platform
import re
import sys
from pathlib import Path

from src.diagnostics.check_hardware import CommandRunner, run_command

NOT_FOUND = "not found"
MODEL_FILE = Path("/proc/device-tree/model")
OS_RELEASE_FILE = Path("/etc/os-release")


def _first_match(pattern: str, text: str) -> str:
    match = re.search(pattern, text, flags=re.IGNORECASE | re.MULTILINE)
    return match.group(1).strip() if match else NOT_FOUND


def pi_model(path: Path = MODEL_FILE) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore").strip("\x00\n ") or NOT_FOUND
    except OSError:
        return NOT_FOUND


def os_release(path: Path = OS_RELEASE_FILE) -> str:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return NOT_FOUND
    return _first_match(r'^PRETTY_NAME="?([^"\n]+)"?', text)


def hailort_version(run: CommandRunner) -> str:
    code, output = run(["hailortcli", "--version"])
    return _first_match(r"(\d+\.\d+\.\d+)", output) if code == 0 else NOT_FOUND


def hailo_firmware(run: CommandRunner) -> tuple[str, str]:
    """(firmware version, device architecture) from `fw-control identify`."""
    code, output = run(["hailortcli", "fw-control", "identify"])
    if code != 0:
        return NOT_FOUND, NOT_FOUND
    return (
        _first_match(r"^Firmware Version:\s*(.+)$", output),
        _first_match(r"^Device Architecture:\s*(.+)$", output),
    )


def picamera2_version(run: CommandRunner) -> str:
    """From the apt package, since picamera2 is installed system-wide on the Pi."""
    code, output = run(["dpkg-query", "-W", "-f=${Version}", "python3-picamera2"])
    if code == 0 and output.strip():
        return output.strip()
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version("picamera2")
    except PackageNotFoundError:
        return NOT_FOUND


def collect(run: CommandRunner) -> list[tuple[str, str]]:
    firmware, architecture = hailo_firmware(run)
    return [
        ("Board", pi_model()),
        ("OS release", os_release()),
        ("Kernel", platform.release() or NOT_FOUND),
        ("Python", platform.python_version()),
        ("HailoRT (`hailortcli --version`)", hailort_version(run)),
        ("Hailo firmware (`fw-control identify`)", firmware),
        ("Hailo device architecture", architecture),
        ("picamera2", picamera2_version(run)),
    ]


def format_table(rows: list[tuple[str, str]]) -> str:
    lines = ["| Item | Version |", "|---|---|"]
    lines += [f"| {name} | {value} |" for name, value in rows]
    return "\n".join(lines)


def main() -> int:
    rows = collect(run_command)
    print(format_table(rows))
    missing = [name for name, value in rows if value == NOT_FOUND]
    if missing:
        print(f"\nNot found: {', '.join(missing)}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
