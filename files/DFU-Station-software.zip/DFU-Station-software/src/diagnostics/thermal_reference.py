"""Reference-thermometer check for the Lepton (Annex A line 9).

    python -m src.diagnostics.thermal_reference
    python -m src.diagnostics.thermal_reference --reference-c 35.2 --apply-offset

Point the camera head at a target of known temperature that fills the centre
of the thermal frame, measure it with a reference thermometer, and enter that
value. The tool reads the Lepton at the centre, reports the error and writes
the result to `calibration/`.

The reference value always comes from a person with a thermometer. The tool
never guesses or defaults it.
"""

from __future__ import annotations

import argparse
import logging
import math
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import yaml

from src.clock import Clock, ManualClock, RealClock
from src.config import Config, ThermalConfig, load_config
from src.errors import CalibrationError, StationError
from src.hardware.factory import build_thermal_camera
from src.logging_setup import setup_logging
from src.thermal.calibration import (
    MAX_ABS_OFFSET_C,
    ThermalCalibration,
    load_thermal_calibration,
)
from src.thermal.source import LEPTON_FRAME_INTERVAL_S, ThermalSource

logger = logging.getLogger("src.diagnostics.thermal_reference")

CHECK_LOG_NAME = "thermal_reference_log.yaml"
UNCALIBRATED = ThermalCalibration(gain=1.0, offset_c=0.0, source="uncalibrated")


@dataclass(frozen=True)
class ReferenceCheck:
    checked_at_utc: str
    reference_c: float
    measured_uncalibrated_c: float
    measured_calibrated_c: float
    error_uncalibrated_c: float
    error_calibrated_c: float
    roi_px: int
    frames: int
    roi_spread_c: float
    tolerance_c: float
    gain_in_use: float
    offset_in_use_c: float
    passed: bool


def centre_roi_mean_c(temps_c: np.ndarray, roi_px: int) -> tuple[float, float]:
    """Mean and spread (max - min) of a centred square of real pixels."""
    height, width = temps_c.shape
    top = (height - roi_px) // 2
    left = (width - roi_px) // 2
    roi = temps_c[top : top + roi_px, left : left + roi_px]
    return float(np.mean(roi)), float(np.max(roi) - np.min(roi))


def run_reference_check(
    source: ThermalSource,
    reference_c: float,
    config: ThermalConfig,
    calibration: ThermalCalibration,
    clock: Clock,
) -> ReferenceCheck:
    """Measure the centre of the frame and compare it with the reference.

    `source` must be built with the identity calibration, so the uncalibrated
    reading is what the sensor reports. `calibration` is the one currently in
    use on the station (identity if there is none yet).
    """
    if not math.isfinite(reference_c):
        raise CalibrationError("the reference temperature must be a finite number")
    if not config.plausible_min_c <= reference_c <= config.plausible_max_c:
        raise CalibrationError(
            f"reference temperature {reference_c} C is outside the plausible range "
            f"{config.plausible_min_c}-{config.plausible_max_c} C"
        )
    source.ensure_radiometry()
    source.run_ffc()
    clock.sleep(config.post_ffc_discard_s + LEPTON_FRAME_INTERVAL_S)

    means: list[float] = []
    spreads: list[float] = []
    for _ in range(config.reference_frames):
        frame = source.capture()
        mean_c, spread_c = centre_roi_mean_c(frame.temps_c, config.reference_roi_px)
        means.append(mean_c)
        spreads.append(spread_c)
        clock.sleep(LEPTON_FRAME_INTERVAL_S)

    measured_c = float(np.mean(means))
    calibrated_c = calibration.gain * measured_c + calibration.offset_c
    error_calibrated_c = calibrated_c - reference_c
    return ReferenceCheck(
        checked_at_utc=clock.now_utc().isoformat(),
        reference_c=reference_c,
        measured_uncalibrated_c=measured_c,
        measured_calibrated_c=calibrated_c,
        error_uncalibrated_c=measured_c - reference_c,
        error_calibrated_c=error_calibrated_c,
        roi_px=config.reference_roi_px,
        frames=config.reference_frames,
        roi_spread_c=float(np.max(spreads)),
        tolerance_c=config.reference_tolerance_c,
        gain_in_use=calibration.gain,
        offset_in_use_c=calibration.offset_c,
        passed=abs(error_calibrated_c) <= config.reference_tolerance_c,
    )


def append_check_log(check: ReferenceCheck, calibration_dir: Path) -> Path:
    """Add the check to the running log in the calibration folder."""
    calibration_dir.mkdir(parents=True, exist_ok=True)
    path = calibration_dir / CHECK_LOG_NAME
    entries: list[object] = []
    if path.is_file():
        loaded = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(loaded, list):
            raise CalibrationError(f"{path} is not a list of checks; refusing to overwrite it")
        entries = loaded
    entries.append(asdict(check))
    path.write_text(yaml.safe_dump(entries, sort_keys=True), encoding="utf-8")
    return path


def write_calibration(path: Path, gain: float, offset_c: float, check: ReferenceCheck) -> None:
    if abs(offset_c) > MAX_ABS_OFFSET_C:
        raise CalibrationError(
            f"an offset of {offset_c:.2f} C is too large to correct. Check the sensor, the "
            "target's emissivity and the reference thermometer."
        )
    data = {
        "gain": gain,
        "offset_c": offset_c,
        "derived_at_utc": check.checked_at_utc,
        "derived_from_reference_c": check.reference_c,
        "derived_from_measured_uncalibrated_c": check.measured_uncalibrated_c,
        "method": "single-point reference thermometer check",
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(data, sort_keys=True), encoding="utf-8")


def format_report(check: ReferenceCheck) -> str:
    lines = [
        f"Reference thermometer:      {check.reference_c:8.2f} C",
        f"Lepton, uncalibrated:       {check.measured_uncalibrated_c:8.2f} C"
        f"   (error {check.error_uncalibrated_c:+.2f} C)",
        f"Lepton, calibration in use: {check.measured_calibrated_c:8.2f} C"
        f"   (error {check.error_calibrated_c:+.2f} C)",
        f"Spread inside the {check.roi_px}x{check.roi_px} px target area: "
        f"{check.roi_spread_c:.2f} C over {check.frames} frames",
        f"Tolerance: {check.tolerance_c:.2f} C   ->   {'PASS' if check.passed else 'FAIL'}",
    ]
    return "\n".join(lines)


def _ask_reference_c() -> float:
    text = input("Reference thermometer reading at the target, in degrees C: ").strip()
    try:
        return float(text)
    except ValueError as exc:
        raise CalibrationError("that is not a number; nothing was written") from exc


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Lepton reference-thermometer check")
    parser.add_argument("--config", type=Path, default=Path("config/config.yaml"))
    parser.add_argument("--fake", action="store_true", help="run against the fake camera")
    parser.add_argument("--reference-c", type=float, default=None)
    parser.add_argument(
        "--apply-offset",
        action="store_true",
        help="write a single-point offset correction to the thermal calibration file",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=None, help="where to write (default: calibration/)"
    )
    args = parser.parse_args(argv)

    try:
        config: Config = load_config(args.config, force_fake=args.fake)
        setup_logging(config.logging.level, config.reference_code.pattern)
        calibration_path = config.thermal.calibration_path
        output_dir: Path | None = args.output_dir or calibration_path.parent
        if config.is_fake and args.output_dir is None:
            # A fake run must never leave files the real station would load.
            output_dir = None
        clock: Clock = ManualClock() if config.is_fake else RealClock()
        in_use = (
            load_thermal_calibration(calibration_path, allow_missing=False)
            if calibration_path.is_file()
            else UNCALIBRATED
        )
        reference_c = args.reference_c if args.reference_c is not None else _ask_reference_c()
        camera = build_thermal_camera(config, clock)
        try:
            source = ThermalSource(camera, config.thermal, UNCALIBRATED, clock)
            check = run_reference_check(source, reference_c, config.thermal, in_use, clock)
        finally:
            camera.close()
        print(format_report(check))
        if output_dir is None:
            print("Fake mode: nothing was written.")
            return 0 if check.passed else 1
        log_path = append_check_log(check, output_dir)
        print(f"Result recorded in {log_path}")
        target = output_dir / calibration_path.name
        if args.apply_offset:
            write_calibration(target, 1.0, -check.error_uncalibrated_c, check)
            print(f"Offset {-check.error_uncalibrated_c:+.2f} C written to {target}.")
            print("Run this check again to confirm the corrected reading passes.")
        elif check.passed and not target.is_file():
            write_calibration(target, 1.0, 0.0, check)
            print(f"Sensor is within tolerance uncorrected; identity written to {target}.")
        elif not check.passed:
            print("FAIL. Re-run with --apply-offset to store a single-point correction,")
            print("or check the target, its emissivity and the reference thermometer.")
        return 0 if check.passed else 1
    except StationError as exc:
        print(f"Reference check could not be completed: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
