"""Thermal-to-colour registration calibration (Annex A line 10).

    python -m src.diagnostics.registration_calibrate

Hold the perforated target in the sole plane over a warm surface (see
docs/calibration.md), then run this. It takes one colour frame with the
interior LED on and one thermal frame, finds the holes in both, fits the
homography and reports the reprojection error. If the error is within
`registration.max_reprojection_error_px` it writes
`calibration/registration.yaml` and a check overlay image beside it.
Otherwise it fails and writes nothing.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from src.clock import Clock, ManualClock, RealClock
from src.config import Config, load_config
from src.datamodel import ColorFrame, ThermalFrame
from src.errors import StationError
from src.hardware.factory import build_devices
from src.hardware.interfaces import Devices
from src.logging_setup import setup_logging
from src.registration.apply import make_overlay, register_color
from src.registration.model import Registration, save_registration
from src.registration.target import calibrate_from_target
from src.storage.writer import encode_png
from src.thermal.calibration import load_thermal_calibration
from src.thermal.source import LEPTON_FRAME_INTERVAL_S, ThermalSource

OVERLAY_NAME = "registration_check.png"
TARGET_SCENARIO = "registration_target"


def capture_target_pair(
    devices: Devices, source: ThermalSource, config: Config, clock: Clock
) -> tuple[ColorFrame, ThermalFrame]:
    """One colour frame under the LED and one thermal frame of the target.

    This is a calibration capture of an object, not a patient scan, so the
    ambient and acclimatisation gates do not apply and nothing is stored as a
    scan.
    """
    source.ensure_radiometry()
    source.run_ffc()
    try:
        devices.light.on()
        clock.sleep(config.color.led_on_settle_s)
        color = devices.color.capture()
    finally:
        devices.light.off()
    clock.sleep(config.thermal.post_ffc_discard_s + LEPTON_FRAME_INTERVAL_S)
    return color, source.capture()


def calibrate(
    config: Config, devices: Devices, clock: Clock, output_dir: Path | None
) -> Registration:
    """Capture the target, fit the registration and store it if it passes."""
    thermal_calibration = load_thermal_calibration(
        config.thermal.calibration_path, allow_missing=config.is_fake
    )
    source = ThermalSource(devices.thermal, config.thermal, thermal_calibration, clock)
    color, thermal = capture_target_pair(devices, source, config, clock)
    registration = calibrate_from_target(
        color.image_bgr, thermal.temps_c, config, clock.now_utc().isoformat()
    )
    if output_dir is not None:
        registered = register_color(color.image_bgr, registration, config.registration)
        overlay = make_overlay(thermal.temps_c, registered)
        save_registration(registration, output_dir / config.registration.calibration_path.name)
        (output_dir / OVERLAY_NAME).write_bytes(encode_png(overlay))
    return registration


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Thermal-to-colour registration calibration")
    parser.add_argument("--config", type=Path, default=Path("config/config.yaml"))
    parser.add_argument("--fake", action="store_true", help="use the synthetic target fixture")
    parser.add_argument(
        "--output-dir", type=Path, default=None, help="where to write (default: calibration/)"
    )
    args = parser.parse_args(argv)
    try:
        config = load_config(args.config, force_fake=args.fake)
        setup_logging(config.logging.level, config.reference_code.pattern)
        output_dir: Path | None = args.output_dir or config.registration.calibration_path.parent
        if config.is_fake:
            import dataclasses

            config = dataclasses.replace(
                config, fake=dataclasses.replace(config.fake, scenario=TARGET_SCENARIO)
            )
            # A fake run must never leave files the real station would load.
            output_dir = args.output_dir
        clock: Clock = ManualClock() if config.is_fake else RealClock()
        devices = build_devices(config, clock, None)
        try:
            registration = calibrate(config, devices, clock, output_dir)
        finally:
            devices.light.off()
            devices.close()
    except StationError as exc:
        print(f"Registration calibration FAILED: {exc}", file=sys.stderr)
        return 1
    print(
        f"Registration fitted from {registration.point_count} holes. "
        f"Reprojection error {registration.reprojection_error_px:.3f} px "
        f"(limit {config.registration.max_reprojection_error_px:.2f} px): PASS"
    )
    if output_dir is None:
        print("Fake mode: nothing was written.")
    else:
        print(f"Written to {output_dir}. Check {OVERLAY_NAME} by eye.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
