"""Hardware self-check (Annex A lines 4 and 5).

    python -m src.diagnostics.check_hardware

Checks each device on its own and prints a clear PASS or FAIL per item. One
failing item never hides the others. Nothing here is assumed: a check passes
only on what the device itself reports.

HARDWARE ONLY. See BLOCKERS.md (task 4.4).
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from src.clock import Clock, RealClock
from src.config import Config, load_config
from src.errors import StationError

CommandRunner = Callable[[list[str]], tuple[int, str]]

COMMAND_TIMEOUT_S = 20.0
HAILO_ARCHITECTURE = "HAILO8L"
CAMERA_MODULE_3_SENSOR = "imx708"


@dataclass(frozen=True)
class CheckResult:
    name: str
    passed: bool
    detail: str


def run_command(command: list[str]) -> tuple[int, str]:
    """Run a system command and return (exit code, combined output)."""
    try:
        completed = subprocess.run(
            command, capture_output=True, text=True, timeout=COMMAND_TIMEOUT_S, check=False
        )
    except FileNotFoundError:
        return 127, f"{command[0]}: command not found"
    except subprocess.TimeoutExpired:
        return 124, f"{command[0]}: timed out after {COMMAND_TIMEOUT_S:.0f} s"
    return completed.returncode, completed.stdout + completed.stderr


def check_hailo(run: CommandRunner) -> CheckResult:
    name = "Hailo-8L accelerator (AI HAT+)"
    code, output = run(["hailortcli", "fw-control", "identify"])
    if code != 0:
        return CheckResult(name, False, f"hailortcli failed: {_last_line(output)}")
    if HAILO_ARCHITECTURE not in output.upper().replace("-", ""):
        return CheckResult(name, False, "a Hailo device answered, but it is not a Hailo-8L")
    return CheckResult(name, True, "identified as Hailo-8L")


def check_camera_module(run: CommandRunner) -> CheckResult:
    name = "Camera Module 3 (CSI)"
    code, output = run(["rpicam-hello", "--list-cameras"])
    if code != 0:
        return CheckResult(name, False, f"rpicam-hello failed: {_last_line(output)}")
    if CAMERA_MODULE_3_SENSOR not in output.lower():
        return CheckResult(name, False, "no imx708 sensor is listed; check the CSI ribbon")
    return CheckResult(name, True, "imx708 sensor listed")


def check_purethermal_enumeration() -> CheckResult:
    from src.capture.purethermal import find_purethermal_device

    device = find_purethermal_device()
    return CheckResult("PureThermal 3 on USB", True, f"found at {device}")


def check_y16_radiometry(config: Config, clock: Clock) -> CheckResult:
    from src.capture.purethermal import PureThermalCamera

    name = "Lepton Y16 stream and TLinear radiometry"
    camera = PureThermalCamera.open(config.thermal, clock)
    try:
        if not camera.radiometry_confirmed():
            return CheckResult(name, False, "the Lepton does not report TLinear at 0.01 K")
        frame = camera.read_raw()
    finally:
        camera.close()
    return CheckResult(name, True, f"Y16 frame {frame.raw.shape[1]}x{frame.raw.shape[0]}")


def check_gpio(config: Config, clock: Clock) -> CheckResult:
    from src.hardware.gpio import (
        GpioCaptureButton,
        GpioInteriorLight,
        GpioStatusLed,
        real_pin_factory,
    )

    factory = real_pin_factory()
    light = GpioInteriorLight(config.gpio.interior_led_pin, factory)
    light.close()
    button = GpioCaptureButton(
        config.gpio.capture_button_pin, config.gpio.button_debounce_s, clock, factory
    )
    button.close()
    led = GpioStatusLed(config.gpio.status_led_pin, factory)
    led.close()
    return CheckResult(
        "GPIO (interior LED, capture button, status LED)",
        True,
        "pins claimed and released; wiring must still be checked by eye",
    )


def check_ambient(config: Config, clock: Clock) -> CheckResult:
    from src.hardware.sht31 import Sht31Sensor, Smbus2Bus

    sensor = Sht31Sensor(Smbus2Bus(config.ambient.i2c_bus), config.ambient.i2c_address, clock)
    try:
        reading = sensor.read()
    finally:
        sensor.close()
    in_range = config.ambient_min_c <= reading.temp_c <= config.ambient_max_c
    note = "inside" if in_range else "OUTSIDE"
    return CheckResult(
        "Ambient sensor (SHT31)",
        True,
        f"{reading.temp_c:.1f} C, {reading.humidity_pct:.0f} % RH ({note} the capture range)",
    )


def check_calibration_files(config: Config) -> CheckResult:
    name = "Calibration files"
    paths: list[Path] = [
        config.thermal.calibration_path,
        config.color.calibration_path,
        config.registration.calibration_path,
    ]
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        return CheckResult(name, False, "missing: " + ", ".join(missing))
    return CheckResult(name, True, "thermal, colour and registration files present")


def _last_line(text: str) -> str:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    return lines[-1] if lines else "no output"


def run_checks(checks: list[tuple[str, Callable[[], CheckResult]]]) -> list[CheckResult]:
    """Run every check. A crash in one is that check's failure, nothing more."""
    results: list[CheckResult] = []
    for name, check in checks:
        try:
            results.append(check())
        except StationError as exc:
            results.append(CheckResult(name, False, str(exc)))
        except Exception as exc:  # a self-check must report, not crash
            results.append(CheckResult(name, False, f"{type(exc).__name__}: {exc}"))
    return results


def station_checks(
    config: Config, clock: Clock, run: CommandRunner
) -> list[tuple[str, Callable[[], CheckResult]]]:
    return [
        ("Hailo-8L accelerator (AI HAT+)", lambda: check_hailo(run)),
        ("Camera Module 3 (CSI)", lambda: check_camera_module(run)),
        ("PureThermal 3 on USB", check_purethermal_enumeration),
        ("Lepton Y16 stream and TLinear radiometry", lambda: check_y16_radiometry(config, clock)),
        ("GPIO (interior LED, capture button, status LED)", lambda: check_gpio(config, clock)),
        ("Ambient sensor (SHT31)", lambda: check_ambient(config, clock)),
        ("Calibration files", lambda: check_calibration_files(config)),
    ]


def format_results(results: list[CheckResult]) -> str:
    lines = [f"[{'PASS' if r.passed else 'FAIL'}] {r.name}: {r.detail}" for r in results]
    failed = sum(1 for r in results if not r.passed)
    lines.append("")
    lines.append("All checks passed." if failed == 0 else f"{failed} check(s) FAILED.")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Station hardware self-check")
    parser.add_argument("--config", type=Path, default=Path("config/config.yaml"))
    args = parser.parse_args(argv)
    try:
        config = load_config(args.config)
    except StationError as exc:
        print(f"Cannot start: {exc}", file=sys.stderr)
        return 2
    if config.is_fake:
        print("hardware.mode is fake: there is no hardware to check.", file=sys.stderr)
        return 2
    results = run_checks(station_checks(config, RealClock(), run_command))
    print(format_results(results))
    return 0 if all(result.passed for result in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
