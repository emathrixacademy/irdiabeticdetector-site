"""Find and store the fixed colour-camera settings for this unit.

    python -m src.diagnostics.color_lock

Run once, with a foot-like target (or a hand) in the cabinet and the shroud
closed. The tool switches the interior LED on, lets auto-exposure and auto
white balance settle under that light, and writes the values they settle on
to `calibration/color.yaml`. From then on the camera uses those fixed values.

Focus is set from the working distance (1 / 0.42 m is about 2.4 dioptres).
Check the saved image for sharpness and adjust `lens_position_dioptres` in the
file if needed.

HARDWARE ONLY. See BLOCKERS.md (task 4.1).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

from src.capture.color_calibration import (
    ColorCalibration,
    nominal_lens_position_dioptres,
    save_color_calibration,
)
from src.capture.picamera import PICAMERA_BGR_FORMAT, _af_mode_manual, open_picamera2
from src.clock import Clock, RealClock
from src.config import Config, load_config
from src.errors import HardwareError, StationError
from src.hardware.interfaces import InteriorLight

AUTO_SETTLE_S = 4.0


def settled_calibration(
    camera: Any, light: InteriorLight, config: Config, clock: Clock
) -> ColorCalibration:
    """Let auto-exposure and white balance settle under the LED and read them."""
    lens_position = nominal_lens_position_dioptres(config.working_distance_mm)
    still = camera.create_still_configuration(
        main={
            "size": (config.color.width_px, config.color.height_px),
            "format": PICAMERA_BGR_FORMAT,
        }
    )
    camera.configure(still)
    camera.set_controls(
        {
            "AfMode": _af_mode_manual(),
            "LensPosition": lens_position,
            "AeEnable": True,
            "AwbEnable": True,
        }
    )
    light.on()
    try:
        camera.start()
        clock.sleep(config.color.led_on_settle_s + AUTO_SETTLE_S)
        metadata = camera.capture_metadata()
    finally:
        light.off()
        camera.stop()
    try:
        red_gain, blue_gain = metadata["ColourGains"]
        return ColorCalibration(
            lens_position_dioptres=lens_position,
            exposure_time_us=int(metadata["ExposureTime"]),
            analogue_gain=float(metadata["AnalogueGain"]),
            colour_gain_red=float(red_gain),
            colour_gain_blue=float(blue_gain),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise HardwareError(f"the camera did not report its settled settings: {exc}") from exc


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Lock colour camera settings under the LED")
    parser.add_argument("--config", type=Path, default=Path("config/config.yaml"))
    args = parser.parse_args(argv)
    try:
        config = load_config(args.config)
        if config.is_fake:
            raise HardwareError("this tool needs the real camera; hardware.mode is fake")
        from src.hardware.gpio import GpioInteriorLight, real_pin_factory

        light = GpioInteriorLight(config.gpio.interior_led_pin, real_pin_factory())
        camera = open_picamera2()
        try:
            calibration = settled_calibration(camera, light, config, RealClock())
        finally:
            light.close()
            camera.close()
        save_color_calibration(calibration, config.color.calibration_path)
    except StationError as exc:
        print(f"Colour lock failed: {exc}", file=sys.stderr)
        return 2
    print(f"Fixed colour settings written to {config.color.calibration_path}:")
    print(f"  {calibration}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
