"""Central logging setup.

Logs never contain images or reference codes. Call sites should not log them
in the first place; the filter here is the backstop that makes it a guarantee.
Logs go to stderr only (the systemd journal on the station). Nothing is sent
off the device.
"""

from __future__ import annotations

import logging
import re
import sys

import numpy as np

REDACTED_CODE = "[reference-code]"
ROOT_LOGGER_NAME = "src"
_FORMAT = "%(asctime)s %(levelname)s %(name)s: %(message)s"


def _scrub_argument(value: object) -> object:
    """Replace image-like arguments with a short description."""
    if isinstance(value, np.ndarray):
        return f"<array shape={value.shape} dtype={value.dtype}>"
    if isinstance(value, bytes | bytearray | memoryview):
        return f"<{len(value)} bytes>"
    return value


class RedactingFilter(logging.Filter):
    """Removes reference codes and image data from every log record."""

    def __init__(self, reference_pattern: str) -> None:
        super().__init__()
        # The configured pattern is anchored; search for it anywhere in a line.
        self._pattern = re.compile(reference_pattern.lstrip("^").rstrip("$"))

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.args, tuple):
            record.args = tuple(_scrub_argument(arg) for arg in record.args)
        elif isinstance(record.args, dict):
            record.args = {key: _scrub_argument(arg) for key, arg in record.args.items()}
        message = record.getMessage()
        record.msg = self._pattern.sub(REDACTED_CODE, message)
        record.args = None
        return True


def setup_logging(level: str, reference_pattern: str) -> logging.Logger:
    """Configure the station logger. Safe to call more than once."""
    logger = logging.getLogger(ROOT_LOGGER_NAME)
    logger.setLevel(level)
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter(_FORMAT))
    logger.addHandler(handler)
    for existing in list(logger.filters):
        logger.removeFilter(existing)
    # A logger-level filter only sees records logged on that exact logger, so
    # the filter goes on the handler, which sees every child logger too.
    handler.addFilter(RedactingFilter(reference_pattern))
    logger.propagate = True
    return logger


def attach_redaction(handler: logging.Handler, reference_pattern: str) -> None:
    """Add the redacting filter to an extra handler (used by tests)."""
    handler.addFilter(RedactingFilter(reference_pattern))
