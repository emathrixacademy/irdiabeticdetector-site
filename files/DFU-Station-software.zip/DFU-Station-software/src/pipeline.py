"""Analysis of one captured pair, in two steps around the operator.

`prepare` registers the colour frame, segments the feet and proposes left and
right. The operator then confirms or corrects that. `analyse` computes the
asymmetry, runs the classifier and fuses the two.

Temperatures are measured on the thermal frame alone. Registration and the
classifier only use the colour frame.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from src.asymmetry.compute import compute_asymmetry
from src.config import Config
from src.datamodel import (
    AsymmetryResult,
    ClassifierResult,
    FusedResult,
    ImageArray,
    ScanRecord,
    SidednessDecision,
)
from src.fusion.fuse import fuse
from src.inference.classifier import Classifier
from src.registration.apply import RegisteredColor, make_overlay, register_color
from src.registration.model import Registration
from src.segmentation.mask import PlantarMasks, segment_feet
from src.segmentation.sidedness import (
    FootPair,
    OrientedFeet,
    SidednessProposal,
    confirm_sidedness,
    measure_feet,
    orient_feet,
    propose_sidedness,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PreparedScan:
    """A captured pair that passed placement checks and awaits left/right."""

    record: ScanRecord
    registered: RegisteredColor
    overlay_bgr: ImageArray = field(repr=False)
    masks: PlantarMasks
    feet: FootPair
    proposal: SidednessProposal


@dataclass(frozen=True)
class AnalysedScan:
    """Everything stored for one scan."""

    record: ScanRecord
    registered: RegisteredColor
    overlay_bgr: ImageArray = field(repr=False)
    masks: PlantarMasks
    oriented: OrientedFeet
    decision: SidednessDecision
    asymmetry: AsymmetryResult
    classifier: ClassifierResult | None
    fused: FusedResult


class ScanPipeline:
    def __init__(
        self, config: Config, registration: Registration, classifier: Classifier | None
    ) -> None:
        self._config = config
        self._registration = registration
        self._classifier = classifier

    def prepare(self, record: ScanRecord) -> PreparedScan:
        """Register, segment and propose left/right. Raises if the scan is refused."""
        registered = register_color(
            record.color.image_bgr, self._registration, self._config.registration
        )
        masks = segment_feet(
            record.thermal.temps_c, record.ambient.temp_c, self._config.segmentation
        )
        feet = measure_feet(masks, self._config.segmentation)
        proposal = propose_sidedness(feet)
        logger.info("scan prepared; left/right proposal: %s", proposal.detail)
        return PreparedScan(
            record=record,
            registered=registered,
            overlay_bgr=make_overlay(record.thermal.temps_c, registered),
            masks=masks,
            feet=feet,
            proposal=proposal,
        )

    def analyse(
        self, prepared: PreparedScan, operator_left_is_image_left: bool | None
    ) -> AnalysedScan:
        """Finish the analysis once the operator has confirmed left and right."""
        decision = confirm_sidedness(prepared.proposal, operator_left_is_image_left)
        oriented = orient_feet(prepared.feet, decision)
        asymmetry = compute_asymmetry(prepared.record.thermal.temps_c, oriented, self._config)
        # With no classifier installed (data collection) the scan is still
        # measured and stored; the classifier fields are left empty.
        classifier = (
            self._classifier.classify(prepared.registered.crop_bgr)
            if self._classifier is not None
            else None
        )
        logger.info(
            "analysis complete: %d region(s) flagged, sidedness %s",
            len(asymmetry.flagged_regions),
            decision.source,
        )
        return AnalysedScan(
            record=prepared.record,
            registered=prepared.registered,
            overlay_bgr=prepared.overlay_bgr,
            masks=prepared.masks,
            oriented=oriented,
            decision=decision,
            asymmetry=asymmetry,
            classifier=classifier,
            fused=fuse(asymmetry, classifier),
        )
