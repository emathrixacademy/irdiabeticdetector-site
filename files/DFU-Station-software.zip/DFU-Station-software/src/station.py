"""Wires the station together from a config: devices, gates, sequencer, analysis, storage."""

from __future__ import annotations

from dataclasses import dataclass

from src.capture.gates import AcclimatisationTracker, AmbientGate
from src.capture.sequencer import CaptureSequencer
from src.clock import Clock
from src.config import Config
from src.hardware.factory import build_devices
from src.hardware.interfaces import Devices
from src.inference.classifier import Classifier
from src.inference.metadata import ModelMetadata, load_model_metadata, metadata_path
from src.pipeline import ScanPipeline
from src.registration.model import load_registration
from src.storage.store import ScanStore
from src.thermal.calibration import load_thermal_calibration
from src.thermal.source import ThermalSource


@dataclass(frozen=True)
class Station:
    config: Config
    clock: Clock
    devices: Devices
    metadata: ModelMetadata | None
    thermal_source: ThermalSource
    ambient_gate: AmbientGate
    acclimatisation: AcclimatisationTracker
    sequencer: CaptureSequencer
    pipeline: ScanPipeline
    store: ScanStore

    def close(self) -> None:
        self.devices.light.off()
        self.devices.close()


def build_station(config: Config, clock: Clock, devices: Devices | None = None) -> Station:
    """Build the station. Pass `devices` to inject fakes in tests."""
    # With `inference.backend: none` the station collects data with no
    # classifier, so no model file or metadata is needed.
    metadata = (
        load_model_metadata(metadata_path(config)) if config.inference.backend != "none" else None
    )
    station_devices = devices or build_devices(config, clock, metadata)
    calibration = load_thermal_calibration(
        config.thermal.calibration_path, allow_missing=config.is_fake
    )
    thermal_source = ThermalSource(station_devices.thermal, config.thermal, calibration, clock)
    ambient_gate = AmbientGate(
        config.ambient_min_c, config.ambient_max_c, config.ambient.max_reading_age_s
    )
    acclimatisation = AcclimatisationTracker(config.acclimatisation_s, clock)
    sequencer = CaptureSequencer(
        config,
        ambient=station_devices.ambient,
        color=station_devices.color,
        light=station_devices.light,
        thermal_source=thermal_source,
        ambient_gate=ambient_gate,
        acclimatisation=acclimatisation,
        clock=clock,
    )
    return Station(
        config=config,
        clock=clock,
        devices=station_devices,
        metadata=metadata,
        thermal_source=thermal_source,
        ambient_gate=ambient_gate,
        acclimatisation=acclimatisation,
        sequencer=sequencer,
        pipeline=ScanPipeline(
            config,
            load_registration(config),
            Classifier(station_devices.accelerator, metadata) if metadata is not None else None,
        ),
        store=ScanStore(config.storage.data_dir, config.storage.csv_name, fake_mode=config.is_fake),
    )
