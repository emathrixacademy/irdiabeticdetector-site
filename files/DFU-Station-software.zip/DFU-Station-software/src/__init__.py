"""DFU Thermography Screening Station."""

__version__ = "0.1.0"
