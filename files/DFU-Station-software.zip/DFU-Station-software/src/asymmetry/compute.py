"""Left-right temperature asymmetry.

This is deterministic arithmetic, not a model: the mean temperature of each
plantar region on the left foot minus the mean of the same region on the
right foot. A region is flagged when the absolute difference is at or above
the threshold (2.2 C, inclusive). Nothing here is learned or tuned.
"""

from __future__ import annotations

import numpy as np

from src.asymmetry.regions import region_masks
from src.config import Config
from src.datamodel import AsymmetryResult, RegionResult, TempArray
from src.errors import AsymmetryError
from src.segmentation.geometry import warp_to_canonical
from src.segmentation.sidedness import OrientedFeet

# Absorbs binary floating-point error only. Sensor resolution is 0.01 C, ten
# thousand times coarser, so this never turns a 2.19 C difference into a flag.
# Without it a difference that is exactly 2.20 C can compute as
# 2.1999999999999993 and miss an inclusive threshold.
FLOAT_TOLERANCE_C = 1e-6


def is_flagged(delta_c: float, threshold_c: float) -> bool:
    """True when |delta| >= threshold. The threshold is inclusive."""
    return abs(delta_c) >= threshold_c - FLOAT_TOLERANCE_C


def difference_map_c(
    temps_c: TempArray, feet: OrientedFeet, width_px: int, height_px: int
) -> TempArray:
    """Left minus mirrored right on the canonical grid. For display only."""
    left = warp_to_canonical(temps_c, feet.left, width_px, height_px)
    right = warp_to_canonical(temps_c, feet.right, width_px, height_px)
    return np.asarray(left - right, dtype=np.float64)


def compute_asymmetry(temps_c: TempArray, feet: OrientedFeet, config: Config) -> AsymmetryResult:
    """Per-region delta T (left minus right) and flags."""
    threshold_c = config.asymmetry_threshold_c
    polygons = config.regions.polygon_map()
    left_masks = region_masks(feet.left, polygons)
    right_masks = region_masks(feet.right, polygons)

    regions: list[RegionResult] = []
    for name in polygons:
        left_pixels = temps_c[left_masks[name]]
        right_pixels = temps_c[right_masks[name]]
        comparable = min(left_pixels.size, right_pixels.size) >= config.regions.min_region_px
        if not comparable:
            # Too few real pixels on one foot (for example a missing toe).
            # The region is reported as not comparable, never filled in.
            regions.append(
                RegionResult(
                    name=name,
                    left_mean_c=float(np.mean(left_pixels)) if left_pixels.size else None,
                    right_mean_c=float(np.mean(right_pixels)) if right_pixels.size else None,
                    delta_c=None,
                    flagged=False,
                    left_pixel_count=int(left_pixels.size),
                    right_pixel_count=int(right_pixels.size),
                )
            )
            continue
        left_mean_c = float(np.mean(left_pixels))
        right_mean_c = float(np.mean(right_pixels))
        delta_c = left_mean_c - right_mean_c
        regions.append(
            RegionResult(
                name=name,
                left_mean_c=left_mean_c,
                right_mean_c=right_mean_c,
                delta_c=delta_c,
                flagged=is_flagged(delta_c, threshold_c),
                left_pixel_count=int(left_pixels.size),
                right_pixel_count=int(right_pixels.size),
            )
        )

    deltas = [abs(region.delta_c) for region in regions if region.delta_c is not None]
    if not deltas:
        raise AsymmetryError("no plantar region has enough pixels on both feet to compare")
    return AsymmetryResult(
        regions=tuple(regions),
        threshold_c=threshold_c,
        max_abs_delta_c=max(deltas),
        flagged_regions=tuple(region.name for region in regions if region.flagged),
        difference_map_c=difference_map_c(
            temps_c,
            feet,
            config.regions.difference_map_width_px,
            config.regions.difference_map_height_px,
        ),
    )
