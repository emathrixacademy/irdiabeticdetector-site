"""The fixed plantar region map.

Regions are polygons in the canonical foot frame (see
`src/segmentation/geometry.py`), defined in the config. Each thermal pixel of
a foot belongs to the region whose polygon contains the pixel's centre.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from src.config import Polygon
from src.datamodel import MaskArray
from src.segmentation.geometry import FootFrame

JUST_BELOW_ONE = float(np.nextafter(1.0, 0.0))


def points_in_polygon(
    polygon: Polygon, u: NDArray[np.float64], v: NDArray[np.float64]
) -> NDArray[np.bool_]:
    """Even-odd point-in-polygon test for arrays of points.

    A point on an edge shared by two polygons falls in exactly one of them,
    so no pixel is counted in two regions.
    """
    inside = np.zeros(u.shape, dtype=np.bool_)
    count = len(polygon)
    for index in range(count):
        u1, v1 = polygon[index]
        u2, v2 = polygon[(index + 1) % count]
        if v1 == v2:
            continue
        crosses = (v1 > v) != (v2 > v)
        at_u = (u2 - u1) * (v - v1) / (v2 - v1) + u1
        inside ^= crosses & (u < at_u)
    return inside


def region_masks(frame: FootFrame, polygons: dict[str, Polygon]) -> dict[str, MaskArray]:
    """Which pixels of this foot's mask fall in each region, on the thermal grid."""
    foot_mask = frame.shape.mask
    rows, columns = np.nonzero(foot_mask)
    u, v = frame.canonical_uv(columns.astype(np.float64), rows.astype(np.float64))
    # The outermost pixel centres of a foot sit exactly on u = 1 or v = 1 (and
    # rounding can put them a hair outside 0..1). Pull them just inside so
    # every foot pixel belongs to a region.
    u = np.clip(u, 0.0, JUST_BELOW_ONE)
    v = np.clip(v, 0.0, JUST_BELOW_ONE)
    masks: dict[str, MaskArray] = {}
    for name, polygon in polygons.items():
        in_region = points_in_polygon(polygon, u, v)
        mask = np.zeros(foot_mask.shape, dtype=np.bool_)
        mask[rows[in_region], columns[in_region]] = True
        masks[name] = mask
    return masks
