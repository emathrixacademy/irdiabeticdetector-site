"""Y16 counts to degrees Celsius.

This is the one place raw Lepton counts become temperatures. With TLinear
radiometry at 0.01 K resolution each count is one centikelvin.
"""

from __future__ import annotations

import numpy as np

from src.datamodel import RawArray, TempArray
from src.errors import InvalidFrameError

COUNTS_PER_KELVIN = 100.0
KELVIN_OFFSET = 273.15


def y16_to_celsius(raw: RawArray) -> TempArray:
    """temp_c = raw / 100 - 273.15, for every pixel at once."""
    if raw.dtype != np.uint16:
        raise InvalidFrameError(f"thermal frame must be uint16 Y16 data, got {raw.dtype}")
    return np.asarray(raw.astype(np.float64) / COUNTS_PER_KELVIN - KELVIN_OFFSET, dtype=np.float64)


def check_plausible(temps_c: TempArray, min_c: float, max_c: float) -> None:
    """Reject a frame with any pixel outside the plausible scene range."""
    if not np.all(np.isfinite(temps_c)):
        raise InvalidFrameError("thermal frame contains non-finite temperatures")
    low = float(np.min(temps_c))
    high = float(np.max(temps_c))
    if low < min_c or high > max_c:
        raise InvalidFrameError(
            f"thermal frame spans {low:.2f} to {high:.2f} C, outside the plausible "
            f"range {min_c:.1f} to {max_c:.1f} C"
        )
