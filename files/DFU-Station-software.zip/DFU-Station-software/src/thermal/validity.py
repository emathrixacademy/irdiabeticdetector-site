"""Checks a raw thermal frame must pass before it can become a measurement.

A frame that fails is rejected with an exception. Nothing here repairs,
substitutes or interpolates a frame.
"""

from __future__ import annotations

import numpy as np

from src.config import ThermalConfig
from src.datamodel import FfcState, RawThermalFrame
from src.errors import FfcInProgressError, InvalidFrameError, StaleFrameError

Y16_SATURATED = np.iinfo(np.uint16).max


def validate_raw_frame(
    frame: RawThermalFrame,
    config: ThermalConfig,
    *,
    now_monotonic_s: float,
    last_ffc_activity_s: float | None,
) -> None:
    """Raise unless the frame is fresh, clear of FFC and physically sensible.

    `last_ffc_activity_s` is the last time an FFC was known to be running or
    to have just finished, on the same clock as the frame timestamp.
    """
    expected_shape = (config.height_px, config.width_px)
    if frame.raw.dtype != np.uint16 or frame.raw.shape != expected_shape:
        raise InvalidFrameError(
            f"thermal frame is {frame.raw.shape} {frame.raw.dtype}, "
            f"expected {expected_shape} uint16"
        )

    age_s = now_monotonic_s - frame.monotonic_s
    if age_s < 0:
        raise StaleFrameError("thermal frame timestamp is in the future; clock fault")
    if age_s > config.max_frame_age_s:
        raise StaleFrameError(
            f"thermal frame is {age_s:.2f} s old; the limit is {config.max_frame_age_s:.2f} s"
        )

    if frame.ffc_state is FfcState.IN_PROGRESS:
        raise FfcInProgressError("thermal frame was taken during flat-field correction")
    if frame.ffc_state is FfcState.NEVER:
        raise FfcInProgressError("no flat-field correction has completed before this frame")
    if last_ffc_activity_s is not None:
        since_ffc_s = frame.monotonic_s - last_ffc_activity_s
        if since_ffc_s < config.post_ffc_discard_s:
            raise FfcInProgressError(
                f"thermal frame was taken {max(since_ffc_s, 0.0):.2f} s after flat-field "
                f"correction; frames in the first {config.post_ffc_discard_s:.2f} s are discarded"
            )

    if not frame.raw.any():
        raise InvalidFrameError("thermal frame is all zero")
    if int(np.max(frame.raw)) >= Y16_SATURATED:
        raise InvalidFrameError("thermal frame has saturated pixels")
    if int(np.min(frame.raw)) == 0:
        raise InvalidFrameError("thermal frame has zero-valued pixels")
