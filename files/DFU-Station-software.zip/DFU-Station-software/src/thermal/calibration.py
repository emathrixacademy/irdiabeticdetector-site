"""Per-unit thermal calibration.

`calibration/thermal.yaml` holds the gain and offset found by comparing this
station's Lepton against a reference thermometer. On real hardware a missing
file is an error: an uncalibrated sensor must not produce temperatures. In
fake mode the identity calibration is allowed, with a warning.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from pathlib import Path

import yaml

from src.datamodel import TempArray
from src.errors import CalibrationError

logger = logging.getLogger(__name__)

# Sanity limits. A correction outside these means the sensor or the reference
# is wrong and should be investigated, not corrected away.
MAX_ABS_OFFSET_C = 10.0
MIN_GAIN = 0.8
MAX_GAIN = 1.2


@dataclass(frozen=True)
class ThermalCalibration:
    gain: float
    offset_c: float
    source: str

    def apply(self, temps_c: TempArray) -> TempArray:
        """corrected = gain * measured + offset."""
        return temps_c * self.gain + self.offset_c


IDENTITY_FAKE = ThermalCalibration(gain=1.0, offset_c=0.0, source="identity (fake mode)")


def parse_thermal_calibration(data: object, source: str) -> ThermalCalibration:
    if not isinstance(data, dict):
        raise CalibrationError(f"{source}: expected a mapping with gain and offset_c")
    values: dict[str, float] = {}
    for key in ("gain", "offset_c"):
        value = data.get(key)
        if isinstance(value, bool) or not isinstance(value, int | float):
            raise CalibrationError(f"{source}: {key} is missing or not a number")
        if not math.isfinite(float(value)):
            raise CalibrationError(f"{source}: {key} must be finite")
        values[key] = float(value)
    if not MIN_GAIN <= values["gain"] <= MAX_GAIN:
        raise CalibrationError(
            f"{source}: gain {values['gain']} is outside {MIN_GAIN}-{MAX_GAIN}; "
            "check the sensor and the reference instead of correcting this much"
        )
    if abs(values["offset_c"]) > MAX_ABS_OFFSET_C:
        raise CalibrationError(
            f"{source}: offset {values['offset_c']} C is larger than {MAX_ABS_OFFSET_C} C; "
            "check the sensor and the reference instead of correcting this much"
        )
    return ThermalCalibration(gain=values["gain"], offset_c=values["offset_c"], source=source)


def load_thermal_calibration(path: Path, *, allow_missing: bool) -> ThermalCalibration:
    """Load the calibration. `allow_missing` is True only in fake mode."""
    if not path.is_file():
        if allow_missing:
            logger.warning("thermal calibration file is absent; using identity (fake mode only)")
            return IDENTITY_FAKE
        raise CalibrationError(
            f"thermal calibration file {path} is missing. Run "
            "`python -m src.diagnostics.thermal_reference` against a reference thermometer first."
        )
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise CalibrationError(f"cannot read thermal calibration {path}: {exc}") from exc
    return parse_thermal_calibration(data, str(path))
