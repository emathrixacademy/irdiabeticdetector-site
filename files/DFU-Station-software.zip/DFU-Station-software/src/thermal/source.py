"""Turns raw Lepton frames into validated temperature frames.

Everything outside `src/thermal/` gets temperatures from here and never sees
how raw counts are interpreted.
"""

from __future__ import annotations

import logging

from src.clock import Clock
from src.config import ThermalConfig
from src.datamodel import FfcState, TempArray, ThermalFrame
from src.errors import (
    FfcInProgressError,
    FfcTimeoutError,
    InvalidFrameError,
    RadiometryError,
    StaleFrameError,
    ThermalFrameError,
)
from src.hardware.interfaces import ThermalCamera
from src.thermal.calibration import ThermalCalibration
from src.thermal.convert import check_plausible, y16_to_celsius
from src.thermal.validity import validate_raw_frame

logger = logging.getLogger(__name__)

# The Lepton 3.5 delivers about 8.7 frames per second.
LEPTON_FRAME_INTERVAL_S = 1.0 / 8.7


class ThermalSource:
    def __init__(
        self,
        camera: ThermalCamera,
        config: ThermalConfig,
        calibration: ThermalCalibration,
        clock: Clock,
    ) -> None:
        self._camera = camera
        self._config = config
        self._calibration = calibration
        self._clock = clock
        self._last_ffc_activity_s: float | None = None

    def ensure_radiometry(self) -> None:
        """Refuse to run unless the unit itself reports TLinear radiometry."""
        if not self._camera.radiometry_confirmed():
            raise RadiometryError(
                "the Lepton does not report TLinear radiometry at 0.01 K resolution; "
                "its Y16 values cannot be read as temperatures"
            )

    def run_ffc(self) -> None:
        """Trigger a flat-field correction and wait for it to finish."""
        self._camera.trigger_ffc()
        started_s = self._clock.monotonic()
        self._last_ffc_activity_s = started_s
        while True:
            state = self._camera.ffc_state()
            now_s = self._clock.monotonic()
            self._last_ffc_activity_s = now_s
            if state is FfcState.COMPLETE:
                logger.info("flat-field correction completed in %.2f s", now_s - started_s)
                return
            if now_s - started_s >= self._config.ffc_timeout_s:
                raise FfcTimeoutError(
                    f"flat-field correction did not complete within "
                    f"{self._config.ffc_timeout_s:.1f} s"
                )
            self._clock.sleep(LEPTON_FRAME_INTERVAL_S)

    def preview_temps_c(self) -> TempArray:
        """The latest frame as temperatures, for the live preview only.

        It skips the freshness and flat-field checks that a measurement must
        pass, so it must never be stored or measured from. The sensor still
        has to report radiometry, and the values are real sensor values.
        """
        self.ensure_radiometry()
        raw_frame = self._camera.read_raw()
        expected = (self._config.height_px, self._config.width_px)
        if raw_frame.raw.shape != expected:
            raise InvalidFrameError(f"thermal preview frame is {raw_frame.raw.shape}")
        return self._calibration.apply(y16_to_celsius(raw_frame.raw))

    def capture(self) -> ThermalFrame:
        """Read one valid measurement frame.

        Frames that are stale or too close to an FFC are discarded and a new
        real frame is read, up to `max_capture_attempts`. Any other fault
        raises at once. A frame is never repaired or substituted.
        """
        self.ensure_radiometry()
        last_error: ThermalFrameError | None = None
        for attempt in range(1, self._config.max_capture_attempts + 1):
            raw_frame = self._camera.read_raw()
            if raw_frame.ffc_state is FfcState.IN_PROGRESS:
                self._last_ffc_activity_s = self._clock.monotonic()
            try:
                validate_raw_frame(
                    raw_frame,
                    self._config,
                    now_monotonic_s=self._clock.monotonic(),
                    last_ffc_activity_s=self._last_ffc_activity_s,
                )
            except (FfcInProgressError, StaleFrameError) as exc:
                logger.warning("discarded thermal frame %d: %s", attempt, exc)
                last_error = exc
                self._clock.sleep(LEPTON_FRAME_INTERVAL_S)
                continue
            temps_c = self._calibration.apply(y16_to_celsius(raw_frame.raw))
            check_plausible(temps_c, self._config.plausible_min_c, self._config.plausible_max_c)
            return ThermalFrame(
                temps_c=temps_c,
                raw=raw_frame.raw,
                captured_at=raw_frame.captured_at,
                monotonic_s=raw_frame.monotonic_s,
                ffc_state=raw_frame.ffc_state,
            )
        assert last_error is not None
        raise last_error
