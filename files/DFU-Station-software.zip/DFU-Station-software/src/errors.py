"""Every way the station can refuse or fail.

The station fails loudly instead of degrading quietly. Each refusal is its own
exception type so the operator UI can show a clear message and tests can
assert the exact reason.
"""

from __future__ import annotations


class StationError(Exception):
    """Base class for all station errors."""


class ConfigError(StationError):
    """The configuration is missing, malformed or out of range."""


class ReferenceCodeError(StationError):
    """The reference code is not a valid anonymised code."""


# --- Gates -----------------------------------------------------------------


class GateRefusal(StationError):  # noqa: N818 - a refusal, not a fault
    """A precondition for capture is not met. The scan is refused."""


class AmbientOutOfRangeError(GateRefusal):
    """Ambient temperature is outside the protocol range."""

    def __init__(self, ambient_temp_c: float, min_c: float, max_c: float) -> None:
        self.ambient_temp_c = ambient_temp_c
        self.min_c = min_c
        self.max_c = max_c
        super().__init__(
            f"ambient {ambient_temp_c:.2f} C is outside {min_c:.1f}-{max_c:.1f} C; capture refused"
        )

    @property
    def too_warm(self) -> bool:
        return self.ambient_temp_c > self.max_c


class AcclimatisationNotMetError(GateRefusal):
    """The patient has not rested for the full acclimatisation time."""

    def __init__(self, remaining_s: float) -> None:
        self.remaining_s = remaining_s
        super().__init__(f"acclimatisation not complete; {remaining_s:.0f} s remaining")


class AcclimatisationNotStartedError(GateRefusal):
    """No acclimatisation timer is running for this reference code."""


# --- Hardware --------------------------------------------------------------


class HardwareError(StationError):
    """A device is missing, not responding or misconfigured."""


class SensorFaultError(HardwareError):
    """A sensor gave no reading, a stale reading or an impossible reading."""


class RadiometryError(HardwareError):
    """The Lepton is not confirmed to be in TLinear radiometric mode."""


class CalibrationError(StationError):
    """Calibration data is missing or invalid."""


# --- Thermal frames --------------------------------------------------------


class ThermalFrameError(StationError):
    """A thermal frame cannot be used for measurement. Never substituted."""


class StaleFrameError(ThermalFrameError):
    """The frame is older than the allowed age."""


class FfcInProgressError(ThermalFrameError):
    """The frame was taken during or too soon after flat-field correction."""


class FfcTimeoutError(ThermalFrameError):
    """Flat-field correction did not complete in time."""


class InvalidFrameError(ThermalFrameError):
    """The frame is all-zero, saturated, the wrong shape or implausible."""


# --- Capture and analysis --------------------------------------------------


class CaptureError(StationError):
    """The capture sequence failed. No record was produced."""


class RegistrationError(StationError):
    """Thermal-to-colour registration is missing or failed its check."""


class SegmentationError(StationError):
    """The plantar surfaces could not be segmented."""


class FootCountError(SegmentationError):
    """The frame does not contain exactly two feet."""

    def __init__(self, found: int) -> None:
        self.found = found
        super().__init__(f"expected exactly 2 feet in the thermal frame, found {found}")


class FootOutOfFrameError(SegmentationError):
    """A foot is cut off at the edge of the thermal frame."""


class SidednessError(SegmentationError):
    """Left and right could not be decided or was not confirmed."""


class AsymmetryError(StationError):
    """The asymmetry computation could not be completed."""


class InferenceError(StationError):
    """The classifier could not run."""


class StorageError(StationError):
    """A scan could not be written. No partial record is left behind."""
