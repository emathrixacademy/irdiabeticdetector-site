"""Configuration loading and validation.

Every value is required and checked. The station refuses to start on a missing
key, an unknown key, a wrong type or an out-of-range value, because a silently
defaulted threshold would produce results that look fine and are wrong.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from src.errors import ConfigError

# Protocol limits. Config may tighten these, never loosen them, so a config
# file cannot be used as a bypass of the ambient gate or the rest period.
PROTOCOL_AMBIENT_MIN_C = 22.0
PROTOCOL_AMBIENT_MAX_C = 25.0
PROTOCOL_MIN_ACCLIMATISATION_S = 900.0

# Sub-folder of the data folder that holds scans made in fake mode.
FAKE_DATA_SUBDIR = "_fake_mode"

REQUIRED_REGIONS: tuple[str, ...] = (
    "hallux",
    "lesser_toes",
    "metatarsal_head_1",
    "metatarsal_heads_central",
    "metatarsal_head_5",
    "medial_midfoot",
    "lateral_midfoot",
    "heel",
)

# Strings a reference-code pattern must never accept.
_NAME_SAMPLES: tuple[str, ...] = (
    "Juan Dela Cruz",
    "Maria",
    "MARIA SANTOS",
    "Santos, Ana",
    "juan.delacruz",
    "Reyes",
)

Polygon = tuple[tuple[float, float], ...]


@dataclass(frozen=True)
class ThermalConfig:
    device: str
    width_px: int
    height_px: int
    plausible_min_c: float
    plausible_max_c: float
    max_frame_age_s: float
    ffc_timeout_s: float
    post_ffc_discard_s: float
    max_capture_attempts: int
    calibration_path: Path
    reference_roi_px: int
    reference_frames: int
    reference_tolerance_c: float


@dataclass(frozen=True)
class ColorConfig:
    width_px: int
    height_px: int
    calibration_path: Path
    led_on_settle_s: float


@dataclass(frozen=True)
class GpioConfig:
    interior_led_pin: int
    capture_button_pin: int
    status_led_pin: int
    button_debounce_s: float


@dataclass(frozen=True)
class AmbientConfig:
    sensor: str
    i2c_bus: int
    i2c_address: int
    max_reading_age_s: float


@dataclass(frozen=True)
class RegistrationConfig:
    calibration_path: Path
    max_reprojection_error_px: float
    color_scale: int
    target_rows: int
    target_cols: int


@dataclass(frozen=True)
class SegmentationConfig:
    background_percentile: float
    min_above_reference_c: float
    min_foot_area_px: int
    edge_margin_px: int
    morphology_kernel_px: int
    min_sidedness_margin: float


@dataclass(frozen=True)
class RegionsConfig:
    min_region_px: int
    difference_map_width_px: int
    difference_map_height_px: int
    polygons: tuple[tuple[str, Polygon], ...]

    def polygon_map(self) -> dict[str, Polygon]:
        return dict(self.polygons)


@dataclass(frozen=True)
class InferenceConfig:
    backend: str
    model_path: Path
    metadata_path: Path


@dataclass(frozen=True)
class StorageConfig:
    data_dir: Path
    csv_name: str
    low_space_warning_mb: int


@dataclass(frozen=True)
class ReferenceCodeConfig:
    pattern: str
    max_length: int


@dataclass(frozen=True)
class UiConfig:
    fullscreen: bool
    preview_interval_ms: int


@dataclass(frozen=True)
class LoggingConfig:
    level: str


@dataclass(frozen=True)
class FakeConfig:
    fixture_dir: Path
    scenario: str
    ambient_temp_c: float
    ambient_humidity_pct: float
    time_scale: float
    predicted_class: int


@dataclass(frozen=True)
class Config:
    asymmetry_threshold_c: float
    ambient_min_c: float
    ambient_max_c: float
    acclimatisation_s: float
    working_distance_mm: float
    settle_delay_s: float
    hardware_mode: str
    thermal: ThermalConfig
    color: ColorConfig
    gpio: GpioConfig
    ambient: AmbientConfig
    registration: RegistrationConfig
    segmentation: SegmentationConfig
    regions: RegionsConfig
    inference: InferenceConfig
    storage: StorageConfig
    reference_code: ReferenceCodeConfig
    ui: UiConfig
    logging: LoggingConfig
    fake: FakeConfig

    @property
    def is_fake(self) -> bool:
        return self.hardware_mode == "fake"

    def to_dict(self) -> dict[str, Any]:
        """The effective config as plain JSON-compatible data."""
        result = _plain(dataclasses.asdict(self))
        assert isinstance(result, dict)
        return result

    def config_hash(self) -> str:
        """Stable SHA-256 of the effective config, stored with every scan."""
        canonical = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _plain(value: Any) -> Any:
    if isinstance(value, Path):
        return value.as_posix()
    if isinstance(value, Mapping):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, list | tuple):
        return [_plain(item) for item in value]
    return value


def _real_data_dir(data_dir: Path) -> Path:
    """Undo `_scan_data_dir`, so forcing fake mode twice does not nest folders."""
    return data_dir.parent if data_dir.name == FAKE_DATA_SUBDIR else data_dir


def _scan_data_dir(data_dir: Path, hardware_mode: str) -> Path:
    """Where scans are written.

    Scans made with the stand-in drivers are synthetic. They go in their own
    folder so they can never be mixed into the research data.
    """
    if hardware_mode == "fake" and data_dir.name != FAKE_DATA_SUBDIR:
        return data_dir / FAKE_DATA_SUBDIR
    return data_dir


class _Reader:
    """Reads one mapping, tracking which keys were consumed."""

    def __init__(self, data: object, where: str) -> None:
        if not isinstance(data, Mapping):
            raise ConfigError(f"{where or 'config'}: expected a mapping")
        self._data: Mapping[str, Any] = data
        self._where = where
        self._seen: set[str] = set()

    def _name(self, key: str) -> str:
        return f"{self._where}.{key}" if self._where else key

    def _get(self, key: str) -> Any:
        if key not in self._data:
            raise ConfigError(f"missing required config key: {self._name(key)}")
        self._seen.add(key)
        return self._data[key]

    def number(
        self,
        key: str,
        *,
        minimum: float | None = None,
        maximum: float | None = None,
        exclusive_minimum: float | None = None,
    ) -> float:
        value = self._get(key)
        if isinstance(value, bool) or not isinstance(value, int | float):
            raise ConfigError(f"{self._name(key)}: expected a number, got {value!r}")
        number = float(value)
        if number != number or number in (float("inf"), float("-inf")):
            raise ConfigError(f"{self._name(key)}: must be finite")
        if minimum is not None and number < minimum:
            raise ConfigError(f"{self._name(key)}: {number} is below the minimum {minimum}")
        if exclusive_minimum is not None and number <= exclusive_minimum:
            raise ConfigError(f"{self._name(key)}: {number} must be above {exclusive_minimum}")
        if maximum is not None and number > maximum:
            raise ConfigError(f"{self._name(key)}: {number} is above the maximum {maximum}")
        return number

    def integer(self, key: str, *, minimum: int | None = None, maximum: int | None = None) -> int:
        value = self._get(key)
        if isinstance(value, bool) or not isinstance(value, int):
            raise ConfigError(f"{self._name(key)}: expected an integer, got {value!r}")
        if minimum is not None and value < minimum:
            raise ConfigError(f"{self._name(key)}: {value} is below the minimum {minimum}")
        if maximum is not None and value > maximum:
            raise ConfigError(f"{self._name(key)}: {value} is above the maximum {maximum}")
        return value

    def text(self, key: str, *, choices: tuple[str, ...] | None = None) -> str:
        value = self._get(key)
        if not isinstance(value, str) or not value:
            raise ConfigError(f"{self._name(key)}: expected a non-empty string, got {value!r}")
        if choices is not None and value not in choices:
            raise ConfigError(f"{self._name(key)}: {value!r} is not one of {list(choices)}")
        return value

    def boolean(self, key: str) -> bool:
        value = self._get(key)
        if not isinstance(value, bool):
            raise ConfigError(f"{self._name(key)}: expected true or false, got {value!r}")
        return value

    def path(self, key: str) -> Path:
        return Path(self.text(key))

    def raw(self, key: str) -> Any:
        return self._get(key)

    def section(self, key: str) -> _Reader:
        return _Reader(self._get(key), self._name(key))

    def finish(self) -> None:
        unknown = sorted(set(self._data) - self._seen)
        if unknown:
            names = ", ".join(self._name(key) for key in unknown)
            raise ConfigError(f"unknown config key(s): {names}")


def _read_polygons(raw: object) -> tuple[tuple[str, Polygon], ...]:
    if not isinstance(raw, Mapping):
        raise ConfigError("regions.polygons: expected a mapping of region name to polygon")
    names = set(raw)
    if names != set(REQUIRED_REGIONS):
        missing = sorted(set(REQUIRED_REGIONS) - names)
        extra = sorted(names - set(REQUIRED_REGIONS))
        raise ConfigError(f"regions.polygons: missing {missing}, unexpected {extra}")
    polygons: list[tuple[str, Polygon]] = []
    for name in REQUIRED_REGIONS:
        points = raw[name]
        if not isinstance(points, list) or len(points) < 3:
            raise ConfigError(f"regions.polygons.{name}: needs at least 3 points")
        polygon: list[tuple[float, float]] = []
        for point in points:
            ok = (
                isinstance(point, list)
                and len(point) == 2
                and all(isinstance(c, int | float) and not isinstance(c, bool) for c in point)
                and all(0.0 <= float(c) <= 1.0 for c in point)
            )
            if not ok:
                raise ConfigError(
                    f"regions.polygons.{name}: each point must be [u, v] within 0..1, got {point!r}"
                )
            polygon.append((float(point[0]), float(point[1])))
        polygons.append((name, tuple(polygon)))
    return tuple(polygons)


def _check_reference_pattern(pattern: str) -> None:
    try:
        compiled = re.compile(pattern)
    except re.error as exc:
        raise ConfigError(f"reference_code.pattern: not a valid regular expression: {exc}") from exc
    for sample in _NAME_SAMPLES:
        if compiled.fullmatch(sample):
            raise ConfigError(
                "reference_code.pattern: accepts something that looks like a name; "
                "patient names must never be stored"
            )


def parse_config(data: object) -> Config:
    """Validate a parsed YAML mapping and build the Config."""
    root = _Reader(data, "")

    asymmetry_threshold_c = root.number("asymmetry_threshold_c", minimum=0.5, maximum=5.0)
    ambient_min_c = root.number(
        "ambient_min_c", minimum=PROTOCOL_AMBIENT_MIN_C, maximum=PROTOCOL_AMBIENT_MAX_C
    )
    ambient_max_c = root.number(
        "ambient_max_c", minimum=PROTOCOL_AMBIENT_MIN_C, maximum=PROTOCOL_AMBIENT_MAX_C
    )
    if ambient_min_c >= ambient_max_c:
        raise ConfigError("ambient_min_c must be below ambient_max_c")
    acclimatisation_s = root.number(
        "acclimatisation_s", minimum=PROTOCOL_MIN_ACCLIMATISATION_S, maximum=7200.0
    )
    working_distance_mm = root.number("working_distance_mm", minimum=400.0, maximum=450.0)
    settle_delay_s = root.number("settle_delay_s", minimum=0.5, maximum=30.0)

    hardware = root.section("hardware")
    hardware_mode = hardware.text("mode", choices=("real", "fake"))
    hardware.finish()

    section = root.section("thermal")
    thermal = ThermalConfig(
        device=section.text("device"),
        width_px=section.integer("width_px", minimum=16, maximum=1024),
        height_px=section.integer("height_px", minimum=16, maximum=1024),
        plausible_min_c=section.number("plausible_min_c", minimum=-40.0, maximum=100.0),
        plausible_max_c=section.number("plausible_max_c", minimum=-40.0, maximum=150.0),
        max_frame_age_s=section.number("max_frame_age_s", exclusive_minimum=0.0, maximum=5.0),
        ffc_timeout_s=section.number("ffc_timeout_s", exclusive_minimum=0.0, maximum=60.0),
        post_ffc_discard_s=section.number("post_ffc_discard_s", minimum=0.0, maximum=30.0),
        max_capture_attempts=section.integer("max_capture_attempts", minimum=1, maximum=50),
        calibration_path=section.path("calibration_path"),
        reference_roi_px=section.integer("reference_roi_px", minimum=1, maximum=64),
        reference_frames=section.integer("reference_frames", minimum=1, maximum=100),
        reference_tolerance_c=section.number(
            "reference_tolerance_c", exclusive_minimum=0.0, maximum=5.0
        ),
    )
    section.finish()
    if thermal.plausible_min_c >= thermal.plausible_max_c:
        raise ConfigError("thermal.plausible_min_c must be below thermal.plausible_max_c")

    section = root.section("color")
    color = ColorConfig(
        width_px=section.integer("width_px", minimum=160, maximum=4608),
        height_px=section.integer("height_px", minimum=120, maximum=2592),
        calibration_path=section.path("calibration_path"),
        led_on_settle_s=section.number("led_on_settle_s", minimum=0.0, maximum=10.0),
    )
    section.finish()

    section = root.section("gpio")
    gpio = GpioConfig(
        interior_led_pin=section.integer("interior_led_pin", minimum=2, maximum=27),
        capture_button_pin=section.integer("capture_button_pin", minimum=2, maximum=27),
        status_led_pin=section.integer("status_led_pin", minimum=2, maximum=27),
        button_debounce_s=section.number("button_debounce_s", minimum=0.0, maximum=1.0),
    )
    section.finish()
    pins = (gpio.interior_led_pin, gpio.capture_button_pin, gpio.status_led_pin)
    if len(set(pins)) != len(pins):
        raise ConfigError("gpio: each pin may be used only once")

    section = root.section("ambient")
    ambient = AmbientConfig(
        sensor=section.text("sensor", choices=("sht31",)),
        i2c_bus=section.integer("i2c_bus", minimum=0, maximum=20),
        i2c_address=section.integer("i2c_address", minimum=0x03, maximum=0x77),
        max_reading_age_s=section.number("max_reading_age_s", exclusive_minimum=0.0, maximum=60.0),
    )
    section.finish()

    section = root.section("registration")
    registration = RegistrationConfig(
        calibration_path=section.path("calibration_path"),
        max_reprojection_error_px=section.number(
            "max_reprojection_error_px", exclusive_minimum=0.0, maximum=10.0
        ),
        color_scale=section.integer("color_scale", minimum=1, maximum=8),
        target_rows=section.integer("target_rows", minimum=2, maximum=20),
        target_cols=section.integer("target_cols", minimum=2, maximum=20),
    )
    section.finish()

    section = root.section("segmentation")
    segmentation = SegmentationConfig(
        background_percentile=section.number("background_percentile", minimum=0.0, maximum=50.0),
        min_above_reference_c=section.number(
            "min_above_reference_c", exclusive_minimum=0.0, maximum=15.0
        ),
        min_foot_area_px=section.integer("min_foot_area_px", minimum=1),
        edge_margin_px=section.integer("edge_margin_px", minimum=1, maximum=20),
        morphology_kernel_px=section.integer("morphology_kernel_px", minimum=1, maximum=15),
        min_sidedness_margin=section.number("min_sidedness_margin", minimum=0.0, maximum=0.5),
    )
    section.finish()

    section = root.section("regions")
    regions = RegionsConfig(
        min_region_px=section.integer("min_region_px", minimum=1, maximum=1000),
        difference_map_width_px=section.integer("difference_map_width_px", minimum=8, maximum=640),
        difference_map_height_px=section.integer(
            "difference_map_height_px", minimum=8, maximum=640
        ),
        polygons=_read_polygons(section.raw("polygons")),
    )
    section.finish()

    section = root.section("inference")
    inference = InferenceConfig(
        backend=section.text("backend", choices=("hailo", "onnx", "fake", "none")),
        model_path=section.path("model_path"),
        metadata_path=section.path("metadata_path"),
    )
    section.finish()

    section = root.section("storage")
    storage = StorageConfig(
        data_dir=_scan_data_dir(section.path("data_dir"), hardware_mode),
        csv_name=section.text("csv_name"),
        low_space_warning_mb=section.integer("low_space_warning_mb", minimum=0),
    )
    section.finish()
    if not storage.csv_name.endswith(".csv") or Path(storage.csv_name).name != storage.csv_name:
        raise ConfigError("storage.csv_name: must be a plain file name ending in .csv")

    section = root.section("reference_code")
    reference_code = ReferenceCodeConfig(
        pattern=section.text("pattern"),
        max_length=section.integer("max_length", minimum=4, maximum=32),
    )
    section.finish()
    _check_reference_pattern(reference_code.pattern)

    section = root.section("ui")
    ui = UiConfig(
        fullscreen=section.boolean("fullscreen"),
        preview_interval_ms=section.integer("preview_interval_ms", minimum=50, maximum=5000),
    )
    section.finish()

    section = root.section("logging")
    logging_config = LoggingConfig(
        level=section.text("level", choices=("DEBUG", "INFO", "WARNING", "ERROR"))
    )
    section.finish()

    section = root.section("fake")
    fake = FakeConfig(
        fixture_dir=section.path("fixture_dir"),
        scenario=section.text("scenario"),
        ambient_temp_c=section.number("ambient_temp_c", minimum=-40.0, maximum=85.0),
        ambient_humidity_pct=section.number("ambient_humidity_pct", minimum=0.0, maximum=100.0),
        time_scale=section.number("time_scale", minimum=1.0, maximum=10000.0),
        predicted_class=section.integer("predicted_class", minimum=0),
    )
    section.finish()

    root.finish()

    return Config(
        asymmetry_threshold_c=asymmetry_threshold_c,
        ambient_min_c=ambient_min_c,
        ambient_max_c=ambient_max_c,
        acclimatisation_s=acclimatisation_s,
        working_distance_mm=working_distance_mm,
        settle_delay_s=settle_delay_s,
        hardware_mode=hardware_mode,
        thermal=thermal,
        color=color,
        gpio=gpio,
        ambient=ambient,
        registration=registration,
        segmentation=segmentation,
        regions=regions,
        inference=inference,
        storage=storage,
        reference_code=reference_code,
        ui=ui,
        logging=logging_config,
        fake=fake,
    )


def load_config(path: Path, *, force_fake: bool = False) -> Config:
    """Load and validate a config file. Raises ConfigError on any problem.

    `force_fake` switches every driver to its fake. It cannot loosen a gate:
    the protocol limits above apply in both modes.
    """
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigError(f"cannot read config file {path}: {exc}") from exc
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ConfigError(f"config file {path} is not valid YAML: {exc}") from exc
    config = parse_config(data)
    if force_fake:
        config = dataclasses.replace(
            config,
            hardware_mode="fake",
            inference=dataclasses.replace(config.inference, backend="fake"),
            storage=dataclasses.replace(
                config.storage,
                data_dir=_scan_data_dir(_real_data_dir(config.storage.data_dir), "fake"),
            ),
        )
    return config
