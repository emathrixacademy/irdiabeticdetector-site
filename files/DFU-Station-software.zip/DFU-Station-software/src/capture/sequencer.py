"""The capture sequence. Order matters and is fixed:

1. ambient 22-25 C, else refuse
2. acclimatisation timer met, else refuse
3. Lepton flat-field correction, wait for it to finish
4. interior LED on -> colour frame
5. interior LED off -> settle delay (light warms skin)
6. thermal Y16 frame
7. one paired record

One trigger gives exactly one paired record or an exception. There is no path
that returns one frame without the other.
"""

from __future__ import annotations

import logging

from src.capture.gates import AcclimatisationTracker, AmbientGate
from src.clock import Clock
from src.config import Config
from src.datamodel import ScanRecord
from src.hardware.interfaces import AmbientSensor, ColorCamera, InteriorLight
from src.storage.layout import make_scan_id, make_session_id
from src.thermal.source import ThermalSource

logger = logging.getLogger(__name__)

# Step names recorded in the scan metadata, in the order they happen.
STEP_NAMES: tuple[str, ...] = (
    "trigger",
    "ambient_checked",
    "acclimatisation_checked",
    "ffc_triggered",
    "ffc_complete",
    "led_on",
    "color_captured",
    "led_off",
    "settle_complete",
    "thermal_captured",
)


class CaptureSequencer:
    def __init__(
        self,
        config: Config,
        *,
        ambient: AmbientSensor,
        color: ColorCamera,
        light: InteriorLight,
        thermal_source: ThermalSource,
        ambient_gate: AmbientGate,
        acclimatisation: AcclimatisationTracker,
        clock: Clock,
    ) -> None:
        self._config = config
        self._ambient = ambient
        self._color = color
        self._light = light
        self._thermal_source = thermal_source
        self._ambient_gate = ambient_gate
        self._acclimatisation = acclimatisation
        self._clock = clock

    def capture(self, reference_code: str) -> ScanRecord:
        """Run the full sequence for one trigger and return the paired record."""
        steps: dict[str, str] = {}

        def mark(name: str) -> None:
            steps[name] = self._clock.now_utc().isoformat()

        mark("trigger")
        triggered_at = self._clock.now_utc()

        ambient_reading = self._ambient.read()
        self._ambient_gate.check(ambient_reading, self._clock.monotonic())
        mark("ambient_checked")

        self._acclimatisation.check(reference_code)
        mark("acclimatisation_checked")

        self._thermal_source.ensure_radiometry()
        mark("ffc_triggered")
        self._thermal_source.run_ffc()
        mark("ffc_complete")

        try:
            self._light.on()
            mark("led_on")
            self._clock.sleep(self._config.color.led_on_settle_s)
            color_frame = self._color.capture()
            mark("color_captured")
        finally:
            # The light must never stay on: it warms the skin being measured.
            self._light.off()
            mark("led_off")

        self._clock.sleep(self._config.settle_delay_s)
        mark("settle_complete")

        thermal_frame = self._thermal_source.capture()
        mark("thermal_captured")

        logger.info("capture sequence complete: one paired colour and thermal frame")
        return ScanRecord(
            scan_id=make_scan_id(triggered_at),
            session_id=make_session_id(reference_code, triggered_at),
            reference_code=reference_code,
            color=color_frame,
            thermal=thermal_frame,
            ambient=ambient_reading,
            step_timestamps=steps,
            config_hash=self._config.config_hash(),
        )
