"""Raspberry Pi Camera Module 3 on CSI, through picamera2.

Focus is manual at the calibrated lens position (about 2.4 dioptres for the
420 mm working distance). Exposure, gain and white balance are fixed to the
values found with the interior LED on. Nothing is left on auto, so frames are
repeatable between scans.

picamera2 comes from apt (`python3-picamera2`) and is imported lazily.

HARDWARE VERIFICATION PENDING: see BLOCKERS.md (task 4.1).
"""

from __future__ import annotations

import logging
from typing import Any

import numpy as np

from src.capture.color_calibration import ColorCalibration, load_color_calibration
from src.clock import Clock
from src.config import ColorConfig
from src.datamodel import ColorFrame
from src.errors import HardwareError
from src.hardware.interfaces import ColorCamera

logger = logging.getLogger(__name__)

# picamera2 names formats by libcamera's convention: "RGB888" arrives in
# memory as B, G, R, which is what OpenCV expects.
PICAMERA_BGR_FORMAT = "RGB888"

# libcamera AfModeEnum.Manual. Read from libcamera when it is importable.
AF_MODE_MANUAL_FALLBACK = 0


def _af_mode_manual() -> Any:
    try:
        from libcamera import controls
    except ImportError:
        return AF_MODE_MANUAL_FALLBACK
    return controls.AfModeEnum.Manual


def fixed_controls(calibration: ColorCalibration) -> dict[str, Any]:
    """The libcamera controls that pin focus, exposure and white balance."""
    return {
        "AfMode": _af_mode_manual(),
        "LensPosition": calibration.lens_position_dioptres,
        "AeEnable": False,
        "ExposureTime": calibration.exposure_time_us,
        "AnalogueGain": calibration.analogue_gain,
        "AwbEnable": False,
        "ColourGains": (calibration.colour_gain_red, calibration.colour_gain_blue),
    }


def open_picamera2() -> Any:
    """Create the picamera2 object, or raise a clear error off the Pi."""
    try:
        from picamera2 import Picamera2
    except ImportError as exc:
        raise HardwareError(
            "picamera2 is not available. On the Pi install python3-picamera2 with apt and "
            "create the virtual environment with --system-site-packages."
        ) from exc
    try:
        return Picamera2()
    except Exception as exc:
        raise HardwareError(f"cannot open the Camera Module 3: {exc}") from exc


class PiCamera3(ColorCamera):
    def __init__(
        self,
        camera: Any,
        config: ColorConfig,
        calibration: ColorCalibration,
        clock: Clock,
    ) -> None:
        self._camera = camera
        self._config = config
        self._clock = clock
        try:
            still = camera.create_still_configuration(
                main={"size": (config.width_px, config.height_px), "format": PICAMERA_BGR_FORMAT}
            )
            camera.configure(still)
            camera.set_controls(fixed_controls(calibration))
            camera.start()
        except Exception as exc:
            raise HardwareError(f"cannot configure the Camera Module 3: {exc}") from exc
        logger.info(
            "colour camera fixed at %.2f dioptres, %d us, gain %.2f",
            calibration.lens_position_dioptres,
            calibration.exposure_time_us,
            calibration.analogue_gain,
        )

    @classmethod
    def open(cls, config: ColorConfig, clock: Clock) -> PiCamera3:
        calibration = load_color_calibration(config.calibration_path)
        return cls(open_picamera2(), config, calibration, clock)

    def capture(self) -> ColorFrame:
        try:
            array = self._camera.capture_array("main")
        except Exception as exc:
            raise HardwareError(f"colour capture failed: {exc}") from exc
        image = np.asarray(array)
        expected = (self._config.height_px, self._config.width_px, 3)
        if image.dtype != np.uint8 or image.shape != expected:
            raise HardwareError(
                f"colour camera returned {image.shape} {image.dtype}, expected {expected} uint8"
            )
        return ColorFrame(
            image_bgr=np.ascontiguousarray(image),
            captured_at=self._clock.now_utc(),
            monotonic_s=self._clock.monotonic(),
        )

    def close(self) -> None:
        try:
            self._camera.stop()
            self._camera.close()
        except Exception as exc:
            logger.warning("error while closing the colour camera: %s", exc)
