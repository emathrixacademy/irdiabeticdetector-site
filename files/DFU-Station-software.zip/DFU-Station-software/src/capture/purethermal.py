"""FLIR Lepton 3.5 on a GroupGets PureThermal 3, over USB (UVC).

The board offers two kinds of output. The colourised video stream is a
picture and carries no temperatures; this driver never uses it. The Y16
stream is the measurement: with TLinear radiometry at 0.01 K resolution each
value is centikelvin.

Lepton control (FFC, radiometry state) goes through UVC extension units, as
in the GroupGets `purethermal1-uvc-capture` reference tools.

HARDWARE VERIFICATION PENDING: the extension-unit numbers below follow the
PureThermal firmware and reference tools but have not yet been exercised
against this station's board. See BLOCKERS.md (task 3.4).
"""

from __future__ import annotations

import ctypes
import logging
import struct
import threading
from abc import ABC, abstractmethod
from pathlib import Path

import numpy as np

from src.clock import Clock
from src.config import ThermalConfig
from src.datamodel import FfcState, RawArray, RawThermalFrame
from src.errors import HardwareError
from src.hardware.interfaces import ThermalCamera

logger = logging.getLogger(__name__)

# --- Lepton command mapping over UVC extension units -----------------------

# Extension unit ids exposed by the PureThermal firmware.
XU_UNIT_RAD = 5
XU_UNIT_SYS = 6

# Lepton SDK command ids (module base + command).
LEP_CID_SYS_RUN_FFC = 0x0242
LEP_CID_SYS_FFC_STATUS = 0x0244
LEP_CID_RAD_TLINEAR_ENABLE_STATE = 0x4EC0
LEP_CID_RAD_TLINEAR_RESOLUTION = 0x4EC4

# LEP_SYS_STATUS_E values returned by the FFC status command.
LEP_SYS_FFC_STATUS_READY = 0
LEP_SYS_FFC_STATUS_BUSY = 1
LEP_SYS_FFC_STATUS_FRAME_AVERAGE = 2

LEP_RAD_ENABLE = 1
# LEP_RAD_TLINEAR_RESOLUTION_E: 0 is 0.1 K per count, 1 is 0.01 K per count.
LEP_RAD_RESOLUTION_0_01_K = 1

UVC_SET_CUR = 0x01
UVC_GET_CUR = 0x81

# If the status never reads busy after an FFC is commanded, treat the FFC as
# running for this long before trusting a "ready" status.
FFC_ASSUMED_DURATION_S = 2.0

FIRST_FRAME_TIMEOUT_S = 3.0

SYSFS_VIDEO_DIR = Path("/sys/class/video4linux")
DEVICE_NAME_FRAGMENT = "PureThermal"


def xu_selector(command_id: int) -> int:
    """UVC control selector for a Lepton command id."""
    return ((command_id & 0x00FF) >> 2) + 1


class LeptonControl(ABC):
    """Raw access to the Lepton command channel."""

    @abstractmethod
    def get(self, unit: int, selector: int, size: int) -> bytes: ...

    @abstractmethod
    def set(self, unit: int, selector: int, data: bytes) -> None: ...

    def close(self) -> None:  # noqa: B027 - optional hook
        """Release the channel."""


class Y16Grabber(ABC):
    """Source of raw frames from the UVC device."""

    @abstractmethod
    def read(self) -> np.ndarray | None:
        """Block for the next frame. None if the device gave nothing."""

    def close(self) -> None:  # noqa: B027 - optional hook
        """Release the device."""


class _UvcXuControlQuery(ctypes.Structure):
    _fields_ = (
        ("unit", ctypes.c_uint8),
        ("selector", ctypes.c_uint8),
        ("query", ctypes.c_uint8),
        ("size", ctypes.c_uint16),
        ("data", ctypes.POINTER(ctypes.c_uint8)),
    )


def _uvcioc_ctrl_query() -> int:
    """_IOWR('u', 0x21, struct uvc_xu_control_query)."""
    read_write = 3
    return (read_write << 30) | (ctypes.sizeof(_UvcXuControlQuery) << 16) | (ord("u") << 8) | 0x21


class V4l2LeptonControl(LeptonControl):
    """Lepton commands through the Linux UVC driver's extension-unit ioctl."""

    def __init__(self, device: str) -> None:
        import os

        try:
            self._fd = os.open(device, os.O_RDWR | os.O_NONBLOCK)
        except OSError as exc:
            raise HardwareError(f"cannot open {device} for Lepton control: {exc}") from exc

    def _query(
        self, unit: int, selector: int, query: int, buffer: ctypes.Array[ctypes.c_uint8]
    ) -> None:
        import fcntl

        request = _UvcXuControlQuery(
            unit=unit,
            selector=selector,
            query=query,
            size=len(buffer),
            data=ctypes.cast(buffer, ctypes.POINTER(ctypes.c_uint8)),
        )
        try:
            fcntl.ioctl(self._fd, _uvcioc_ctrl_query(), request)
        except OSError as exc:
            raise HardwareError(
                f"Lepton control query failed (unit {unit}, selector {selector}): {exc}"
            ) from exc

    def get(self, unit: int, selector: int, size: int) -> bytes:
        buffer = (ctypes.c_uint8 * size)()
        self._query(unit, selector, UVC_GET_CUR, buffer)
        return bytes(buffer)

    def set(self, unit: int, selector: int, data: bytes) -> None:
        buffer = (ctypes.c_uint8 * len(data))(*data)
        self._query(unit, selector, UVC_SET_CUR, buffer)

    def close(self) -> None:
        import os

        os.close(self._fd)


class OpenCvY16Grabber(Y16Grabber):
    """Y16 frames through OpenCV's V4L2 backend, with RGB conversion off."""

    def __init__(self, device: str, width_px: int, height_px: int) -> None:
        import cv2

        self._capture = cv2.VideoCapture(device, cv2.CAP_V4L2)
        if not self._capture.isOpened():
            raise HardwareError(f"cannot open thermal camera {device}")
        self._capture.set(cv2.CAP_PROP_FOURCC, float(cv2.VideoWriter.fourcc("Y", "1", "6", " ")))
        self._capture.set(cv2.CAP_PROP_FRAME_WIDTH, float(width_px))
        self._capture.set(cv2.CAP_PROP_FRAME_HEIGHT, float(height_px))
        self._capture.set(cv2.CAP_PROP_CONVERT_RGB, 0.0)
        self._capture.set(cv2.CAP_PROP_BUFFERSIZE, 1.0)
        fourcc = int(self._capture.get(cv2.CAP_PROP_FOURCC))
        name = struct.pack("<I", fourcc & 0xFFFFFFFF).decode("ascii", errors="replace")
        if name.strip() != "Y16":
            self._capture.release()
            raise HardwareError(
                f"thermal camera {device} is streaming {name!r}, not Y16. The colour "
                "stream carries no temperatures and is never used."
            )

    def read(self) -> np.ndarray | None:
        ok, frame = self._capture.read()
        if not ok or frame is None:
            return None
        return np.asarray(frame)

    def close(self) -> None:
        self._capture.release()


def find_purethermal_device(sysfs_dir: Path = SYSFS_VIDEO_DIR) -> str:
    """Find the PureThermal's capture node, e.g. /dev/video0."""
    candidates: list[tuple[int, str]] = []
    if sysfs_dir.is_dir():
        for entry in sysfs_dir.iterdir():
            name_file = entry / "name"
            index_file = entry / "index"
            try:
                name = name_file.read_text(encoding="utf-8", errors="ignore")
                index = int(index_file.read_text(encoding="utf-8").strip())
            except (OSError, ValueError):
                continue
            # index 0 is the capture node; higher indexes are metadata nodes.
            if DEVICE_NAME_FRAGMENT in name and index == 0:
                number = int("".join(ch for ch in entry.name if ch.isdigit()) or "0")
                candidates.append((number, f"/dev/{entry.name}"))
    if not candidates:
        raise HardwareError(
            "no PureThermal board found. Check the USB cable and `v4l2-ctl --list-devices`."
        )
    return min(candidates)[1]


def to_y16(frame: np.ndarray, width_px: int, height_px: int) -> RawArray:
    """Accept only a single-channel 16-bit frame of the expected size."""
    if frame.dtype != np.uint16:
        raise HardwareError(
            f"thermal camera returned {frame.dtype} data, not 16-bit Y16. Refusing to "
            "treat a colour stream as temperatures."
        )
    if frame.size != width_px * height_px:
        raise HardwareError(
            f"thermal camera returned {frame.size} values, expected {width_px * height_px}"
        )
    return np.ascontiguousarray(frame.reshape(height_px, width_px))


class PureThermalCamera(ThermalCamera):
    def __init__(
        self,
        grabber: Y16Grabber,
        control: LeptonControl,
        config: ThermalConfig,
        clock: Clock,
        *,
        start_reader: bool = True,
    ) -> None:
        self._grabber = grabber
        self._control = control
        self._config = config
        self._clock = clock
        self._lock = threading.Lock()
        self._latest: RawThermalFrame | None = None
        self._frame_ready = threading.Event()
        self._reader_error: str | None = None
        self._ffc_commanded_s: float | None = None
        self._ffc_seen_busy = False
        self._ffc_completed = False
        self._running = start_reader
        self._thread: threading.Thread | None = None
        if start_reader:
            self._thread = threading.Thread(target=self._reader_loop, name="lepton", daemon=True)
            self._thread.start()

    @classmethod
    def open(cls, config: ThermalConfig, clock: Clock) -> PureThermalCamera:
        """Open the real device named in the config (or found by name)."""
        device = find_purethermal_device() if config.device == "auto" else config.device
        control = V4l2LeptonControl(device)
        try:
            grabber = OpenCvY16Grabber(device, config.width_px, config.height_px)
        except HardwareError:
            control.close()
            raise
        return cls(grabber, control, config, clock)

    # --- Lepton control ----------------------------------------------------

    def _get_u32(self, unit: int, command_id: int) -> int:
        data = self._control.get(unit, xu_selector(command_id), 4)
        return int(struct.unpack("<I", data)[0])

    def radiometry_confirmed(self) -> bool:
        """Read TLinear state from the unit. Any doubt counts as not confirmed."""
        try:
            enabled = self._get_u32(XU_UNIT_RAD, LEP_CID_RAD_TLINEAR_ENABLE_STATE)
            resolution = self._get_u32(XU_UNIT_RAD, LEP_CID_RAD_TLINEAR_RESOLUTION)
        except HardwareError as exc:
            logger.error("could not read the Lepton radiometry state: %s", exc)
            return False
        if enabled != LEP_RAD_ENABLE:
            logger.error("Lepton TLinear radiometry is off")
            return False
        if resolution != LEP_RAD_RESOLUTION_0_01_K:
            logger.error("Lepton TLinear resolution is not 0.01 K")
            return False
        return True

    def trigger_ffc(self) -> None:
        selector = xu_selector(LEP_CID_SYS_RUN_FFC)
        with self._lock:
            self._ffc_commanded_s = self._clock.monotonic()
            self._ffc_seen_busy = False
            self._ffc_completed = False
        self._control.set(XU_UNIT_SYS, selector, bytes([selector]))

    def _ffc_busy(self) -> bool:
        status = self._get_u32(XU_UNIT_SYS, LEP_CID_SYS_FFC_STATUS)
        if status in (LEP_SYS_FFC_STATUS_BUSY, LEP_SYS_FFC_STATUS_FRAME_AVERAGE):
            return True
        if status == LEP_SYS_FFC_STATUS_READY:
            return False
        raise HardwareError(f"Lepton reported FFC status {status}")

    def ffc_state(self) -> FfcState:
        busy = self._ffc_busy()
        now_s = self._clock.monotonic()
        with self._lock:
            if busy:
                self._ffc_seen_busy = True
                self._ffc_completed = False
                return FfcState.IN_PROGRESS
            if self._ffc_seen_busy:
                self._ffc_completed = True
                self._ffc_seen_busy = False
                self._ffc_commanded_s = None
            elif self._ffc_commanded_s is not None:
                # Commanded but never seen busy: wait out the assumed duration.
                if now_s - self._ffc_commanded_s < FFC_ASSUMED_DURATION_S:
                    return FfcState.IN_PROGRESS
                self._ffc_completed = True
                self._ffc_commanded_s = None
            return FfcState.COMPLETE if self._ffc_completed else FfcState.NEVER

    # --- Frames ------------------------------------------------------------

    def poll(self) -> None:
        """Read one frame from the device and keep it as the latest."""
        state_before = self.ffc_state()
        frame = self._grabber.read()
        if frame is None:
            raise HardwareError("the thermal camera delivered no frame")
        raw = to_y16(frame, self._config.width_px, self._config.height_px)
        arrived_s = self._clock.monotonic()
        arrived_at = self._clock.now_utc()
        state_after = self.ffc_state()
        state = (
            FfcState.IN_PROGRESS
            if FfcState.IN_PROGRESS in (state_before, state_after)
            else state_after
        )
        with self._lock:
            self._latest = RawThermalFrame(
                raw=raw, monotonic_s=arrived_s, captured_at=arrived_at, ffc_state=state
            )
        self._frame_ready.set()

    def _reader_loop(self) -> None:
        while self._running:
            try:
                self.poll()
                self._reader_error = None
            except HardwareError as exc:
                self._reader_error = str(exc)
                self._clock.sleep(0.2)

    def read_raw(self) -> RawThermalFrame:
        """The most recent frame, stamped with the time it arrived.

        A frame that stopped arriving keeps its old timestamp, so the validity
        check sees it as stale instead of being handed a re-stamped copy.
        """
        if self._thread is not None and not self._frame_ready.wait(FIRST_FRAME_TIMEOUT_S):
            raise HardwareError(
                f"no thermal frame arrived: {self._reader_error or 'timed out waiting'}"
            )
        with self._lock:
            latest = self._latest
        if latest is None:
            raise HardwareError("no thermal frame has been read yet")
        return latest

    def close(self) -> None:
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        self._grabber.close()
        self._control.close()
