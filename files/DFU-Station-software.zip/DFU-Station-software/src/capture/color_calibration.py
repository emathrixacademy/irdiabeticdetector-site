"""Fixed colour-camera settings for this unit, from `calibration/color.yaml`.

Focus, exposure, gain and white balance are found once with the interior LED
on and then held, so colour frames are repeatable from scan to scan.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from pathlib import Path

import yaml

from src.errors import CalibrationError

MM_PER_M = 1000.0

# Sanity limits for the stored values.
_LIMITS: dict[str, tuple[float, float]] = {
    "lens_position_dioptres": (0.0, 15.0),
    "exposure_time_us": (50.0, 1_000_000.0),
    "analogue_gain": (1.0, 16.0),
    "colour_gain_red": (0.1, 8.0),
    "colour_gain_blue": (0.1, 8.0),
}


@dataclass(frozen=True)
class ColorCalibration:
    lens_position_dioptres: float
    exposure_time_us: int
    analogue_gain: float
    colour_gain_red: float
    colour_gain_blue: float


def nominal_lens_position_dioptres(working_distance_mm: float) -> float:
    """Focus setting for a subject at the working distance: 1 / distance in metres."""
    return MM_PER_M / working_distance_mm


def parse_color_calibration(data: object, source: str) -> ColorCalibration:
    if not isinstance(data, dict):
        raise CalibrationError(f"{source}: expected a mapping of colour camera settings")
    values: dict[str, float] = {}
    for key, (low, high) in _LIMITS.items():
        value = data.get(key)
        if isinstance(value, bool) or not isinstance(value, int | float):
            raise CalibrationError(f"{source}: {key} is missing or not a number")
        number = float(value)
        if not math.isfinite(number) or not low <= number <= high:
            raise CalibrationError(f"{source}: {key} = {value} is outside {low}-{high}")
        values[key] = number
    return ColorCalibration(
        lens_position_dioptres=values["lens_position_dioptres"],
        exposure_time_us=round(values["exposure_time_us"]),
        analogue_gain=values["analogue_gain"],
        colour_gain_red=values["colour_gain_red"],
        colour_gain_blue=values["colour_gain_blue"],
    )


def load_color_calibration(path: Path) -> ColorCalibration:
    if not path.is_file():
        raise CalibrationError(
            f"colour calibration file {path} is missing. Run "
            "`python -m src.diagnostics.color_lock` with the interior LED working first."
        )
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise CalibrationError(f"cannot read colour calibration {path}: {exc}") from exc
    return parse_color_calibration(data, str(path))


def save_color_calibration(calibration: ColorCalibration, path: Path) -> None:
    # Round-trip through the parser so a bad value is never written.
    parse_color_calibration(asdict(calibration), "new colour calibration")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(asdict(calibration), sort_keys=True), encoding="utf-8")
