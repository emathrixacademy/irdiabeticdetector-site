"""The two gates every capture must pass: ambient range and acclimatisation.

There is no override. Tests exercise these by faking the sensor and the
clock, never by weakening the checks.
"""

from __future__ import annotations

import math

from src.clock import Clock
from src.datamodel import AmbientReading
from src.errors import (
    AcclimatisationNotMetError,
    AcclimatisationNotStartedError,
    AmbientOutOfRangeError,
    SensorFaultError,
)


class AmbientGate:
    """Refuses capture unless the room is within the protocol range (inclusive)."""

    def __init__(self, min_c: float, max_c: float, max_reading_age_s: float) -> None:
        self._min_c = min_c
        self._max_c = max_c
        self._max_reading_age_s = max_reading_age_s

    @property
    def min_c(self) -> float:
        return self._min_c

    @property
    def max_c(self) -> float:
        return self._max_c

    def check(self, reading: AmbientReading, now_monotonic_s: float) -> None:
        """Raise unless the reading is fresh, sane and inside the range."""
        if not math.isfinite(reading.temp_c) or not math.isfinite(reading.humidity_pct):
            raise SensorFaultError("ambient sensor returned a non-finite value")
        age_s = now_monotonic_s - reading.monotonic_s
        if age_s < 0 or age_s > self._max_reading_age_s:
            raise SensorFaultError(
                f"ambient reading is {age_s:.1f} s old; "
                f"the limit is {self._max_reading_age_s:.1f} s"
            )
        if not self._min_c <= reading.temp_c <= self._max_c:
            raise AmbientOutOfRangeError(reading.temp_c, self._min_c, self._max_c)

    def in_range(self, reading: AmbientReading) -> bool:
        """For the status display only. Capture always goes through `check`."""
        return math.isfinite(reading.temp_c) and self._min_c <= reading.temp_c <= self._max_c


class AcclimatisationTracker:
    """One rest timer per reference code."""

    def __init__(self, required_s: float, clock: Clock) -> None:
        self._required_s = required_s
        self._clock = clock
        self._started_s: dict[str, float] = {}

    @property
    def required_s(self) -> float:
        return self._required_s

    def start(self, reference_code: str) -> None:
        """Start the timer for a patient. A running timer is left alone."""
        self._started_s.setdefault(reference_code, self._clock.monotonic())

    def restart(self, reference_code: str) -> None:
        """Start the rest period again, e.g. after the patient moved."""
        self._started_s[reference_code] = self._clock.monotonic()

    def clear(self, reference_code: str) -> None:
        self._started_s.pop(reference_code, None)

    def remaining_s(self, reference_code: str) -> float:
        started_s = self._started_s.get(reference_code)
        if started_s is None:
            raise AcclimatisationNotStartedError(
                "no acclimatisation timer is running for this reference code"
            )
        return max(0.0, self._required_s - (self._clock.monotonic() - started_s))

    def check(self, reference_code: str) -> None:
        """Raise unless the full rest period has passed."""
        remaining_s = self.remaining_s(reference_code)
        if remaining_s > 0:
            raise AcclimatisationNotMetError(remaining_s)
