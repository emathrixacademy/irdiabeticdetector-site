"""Left and right are anatomical, not positional.

The station never assumes the left foot is on the left of the frame. Foot
geometry proposes which is which (the hallux is on the medial side), and the
operator must confirm or correct it on the touchscreen. The record says which
of the two was used.
"""

from __future__ import annotations

from dataclasses import dataclass

from src.config import SegmentationConfig
from src.datamodel import SidednessDecision
from src.errors import SidednessError
from src.segmentation.geometry import FootFrame, FootShape, canonical_frame, measure_foot
from src.segmentation.mask import PlantarMasks


@dataclass(frozen=True)
class FootPair:
    """Both feet measured, still ordered by image position."""

    image_left: FootShape
    image_right: FootShape


@dataclass(frozen=True)
class SidednessProposal:
    """What geometry says. `left_is_image_left` is None when it cannot say."""

    left_is_image_left: bool | None
    detail: str

    @property
    def confident(self) -> bool:
        return self.left_is_image_left is not None


@dataclass(frozen=True)
class OrientedFeet:
    """The two feet in the canonical frame, by anatomical side."""

    left: FootFrame
    right: FootFrame
    decision: SidednessDecision


def measure_feet(masks: PlantarMasks, config: SegmentationConfig) -> FootPair:
    return FootPair(
        image_left=measure_foot(masks.image_left, config),
        image_right=measure_foot(masks.image_right, config),
    )


def propose_sidedness(feet: FootPair) -> SidednessProposal:
    """Propose left/right from where each foot's hallux is.

    Seen from the sole with toes up, a left foot has its hallux on its low
    (image-left) side and a right foot on its high side.
    """
    left_foot_looks_left = feet.image_left.hallux_on_low_side
    right_foot_looks_left = feet.image_right.hallux_on_low_side
    if left_foot_looks_left is None or right_foot_looks_left is None:
        return SidednessProposal(None, "the hallux side of a foot is not clear from its shape")
    if left_foot_looks_left == right_foot_looks_left:
        return SidednessProposal(None, "both feet look like the same side")
    if left_foot_looks_left:
        return SidednessProposal(True, "the foot on the left of the image looks like a left foot")
    return SidednessProposal(False, "the foot on the right of the image looks like a left foot")


def confirm_sidedness(
    proposal: SidednessProposal, operator_left_is_image_left: bool | None
) -> SidednessDecision:
    """Combine the proposal with the operator's answer. The answer is required."""
    if operator_left_is_image_left is None:
        raise SidednessError("left and right were not confirmed by the operator")
    agrees = proposal.left_is_image_left == operator_left_is_image_left
    return SidednessDecision(
        left_is_image_left=operator_left_is_image_left,
        source="geometry_confirmed" if agrees else "operator_override",
        geometry_left_is_image_left=proposal.left_is_image_left,
    )


def orient_feet(feet: FootPair, decision: SidednessDecision) -> OrientedFeet:
    """Assign the anatomical sides and put both feet in the canonical frame."""
    left_shape = feet.image_left if decision.left_is_image_left else feet.image_right
    right_shape = feet.image_right if decision.left_is_image_left else feet.image_left
    return OrientedFeet(
        left=canonical_frame(left_shape, is_left_foot=True),
        right=canonical_frame(right_shape, is_left_foot=False),
        decision=decision,
    )
