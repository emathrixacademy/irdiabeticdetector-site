"""Foot geometry and normalisation.

Each foot gets its own coordinate frame from its shape: the long axis from
the principal axes of the mask, the toe end from where the foot is wider, and
the hallux side from where the toes reach furthest. Both feet are then
described in one canonical frame, a LEFT foot seen from the sole with toes up:

    u: 0 = medial (hallux side) -> 1 = lateral
    v: 0 = toe tip              -> 1 = heel

The right foot is mirrored into that frame. Scale comes from the foot's own
length and width, so feet of different sizes line up.

Temperatures are not resampled for measurement. The frame is used to decide
which thermal pixel belongs to which region.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from numpy.typing import NDArray

from src.config import SegmentationConfig
from src.datamodel import MaskArray, TempArray
from src.errors import SegmentationError

# Bands along the foot (fractions of its length, measured from each end) used
# to tell the forefoot from the heel: the forefoot is the wider end.
END_BAND_START = 0.15
END_BAND_STOP = 0.35
MIN_FOREFOOT_TO_HEEL_WIDTH_RATIO = 1.05
# The first tenth of the foot from the toe tips. Toes shorten from the hallux
# outwards, so the pixels in this band lean towards the hallux side.
TOE_BAND_FRACTION = 0.10

Vector = NDArray[np.float64]


@dataclass(frozen=True)
class FootShape:
    """One foot's own frame in the image, before left/right is decided."""

    mask: MaskArray = field(repr=False)
    origin_xy: Vector
    # Unit vectors in image (x, y): across the foot, and from toes to heel.
    across: Vector
    toe_to_heel: Vector
    width_px: float
    length_px: float
    # Mean position across the foot of the toe-band pixels, minus 0.5.
    # Negative means the hallux is on the low side of `across`.
    toe_skew: float
    # None when the skew is too small to trust.
    hallux_on_low_side: bool | None

    def raw_uv(
        self, xs: NDArray[np.float64], ys: NDArray[np.float64]
    ) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        """Position of image points across (0..1) and along (0..1) the foot."""
        dx = xs - self.origin_xy[0]
        dy = ys - self.origin_xy[1]
        u = (dx * self.across[0] + dy * self.across[1]) / self.width_px
        v = (dx * self.toe_to_heel[0] + dy * self.toe_to_heel[1]) / self.length_px
        return u, v

    @property
    def angle_deg(self) -> float:
        """Tilt of the long axis from the image's vertical, in degrees."""
        return float(np.degrees(np.arctan2(self.toe_to_heel[0], self.toe_to_heel[1])))


@dataclass(frozen=True)
class FootFrame:
    """A foot placed in the canonical left-foot frame."""

    shape: FootShape
    # True when the across axis is flipped so that u = 0 is the hallux side.
    mirrored: bool

    def canonical_uv(
        self, xs: NDArray[np.float64], ys: NDArray[np.float64]
    ) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        u, v = self.shape.raw_uv(xs, ys)
        return (1.0 - u if self.mirrored else u), v

    def image_xy(
        self, u: NDArray[np.float64], v: NDArray[np.float64]
    ) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        """Image position of canonical points (the inverse of `canonical_uv`)."""
        shape = self.shape
        raw_u = 1.0 - u if self.mirrored else u
        across_px = raw_u * shape.width_px
        along_px = v * shape.length_px
        xs = shape.origin_xy[0] + across_px * shape.across[0] + along_px * shape.toe_to_heel[0]
        ys = shape.origin_xy[1] + across_px * shape.across[1] + along_px * shape.toe_to_heel[1]
        return xs, ys


def _extent(values: NDArray[np.float64]) -> float:
    return float(np.max(values) - np.min(values)) if values.size else 0.0


def measure_foot(mask: MaskArray, config: SegmentationConfig) -> FootShape:
    """Find a foot's long axis, toe end and hallux side from its mask."""
    ys_int, xs_int = np.nonzero(mask)
    if xs_int.size < 3:
        raise SegmentationError("a foot mask is too small to measure")
    xs = xs_int.astype(np.float64)
    ys = ys_int.astype(np.float64)
    points = np.stack([xs, ys], axis=1)
    centred = points - points.mean(axis=0)
    _, vectors = np.linalg.eigh(np.cov(centred, rowvar=False))
    long_axis: Vector = np.asarray(vectors[:, 1], dtype=np.float64)  # largest eigenvalue

    along = points @ long_axis
    low, high = float(np.min(along)), float(np.max(along))
    length_px = high - low
    if length_px <= 0:
        raise SegmentationError("a foot mask has no length")

    def band_width(start: float, stop: float) -> float:
        position = (along - low) / length_px
        in_band = (position >= start) & (position <= stop)
        across_axis = np.array([long_axis[1], -long_axis[0]])
        return _extent(points[in_band] @ across_axis)

    width_low_end = band_width(END_BAND_START, END_BAND_STOP)
    width_high_end = band_width(1.0 - END_BAND_STOP, 1.0 - END_BAND_START)
    wider, narrower = max(width_low_end, width_high_end), min(width_low_end, width_high_end)
    if narrower <= 0 or wider / narrower < MIN_FOREFOOT_TO_HEEL_WIDTH_RATIO:
        raise SegmentationError(
            "cannot tell the toe end from the heel end of a foot; check foot placement"
        )
    # Point the long axis from toes (the wider end) to heel.
    toe_to_heel: Vector = long_axis if width_low_end > width_high_end else -long_axis
    # With toes up in the image this axis points to the image's right.
    across: Vector = np.array([toe_to_heel[1], -toe_to_heel[0]], dtype=np.float64)

    along = points @ toe_to_heel
    sideways = points @ across
    along_min = float(np.min(along))
    sideways_min = float(np.min(sideways))
    width_px = float(np.max(sideways)) - sideways_min
    if width_px <= 0:
        raise SegmentationError("a foot mask has no width")
    origin_xy: Vector = sideways_min * across + along_min * toe_to_heel

    raw_u = (sideways - sideways_min) / width_px
    raw_v = (along - along_min) / length_px
    toe_band = raw_v <= TOE_BAND_FRACTION
    toe_skew = float(np.mean(raw_u[toe_band])) - 0.5
    hallux_on_low_side: bool | None = None
    if abs(toe_skew) >= config.min_sidedness_margin:
        hallux_on_low_side = toe_skew < 0

    return FootShape(
        mask=mask,
        origin_xy=origin_xy,
        across=across,
        toe_to_heel=toe_to_heel,
        width_px=width_px,
        length_px=length_px,
        toe_skew=toe_skew,
        hallux_on_low_side=hallux_on_low_side,
    )


def canonical_frame(shape: FootShape, is_left_foot: bool) -> FootFrame:
    """Place a foot in the canonical frame so that u = 0 is its hallux side.

    The hallux side comes from the foot's own shape when that is clear. When
    it is not, it is inferred from the confirmed side: seen from the sole with
    toes up, a left foot has its hallux on the low side.
    """
    hallux_on_low_side = shape.hallux_on_low_side
    if hallux_on_low_side is None:
        hallux_on_low_side = is_left_foot
    return FootFrame(shape=shape, mirrored=not hallux_on_low_side)


def warp_to_canonical(
    temps_c: TempArray, frame: FootFrame, width_px: int, height_px: int
) -> TempArray:
    """One foot on the canonical grid, for the display-only difference map.

    Each grid cell takes the nearest real thermal pixel. Nothing is
    interpolated. Cells outside the foot are NaN.
    """
    grid_v, grid_u = np.mgrid[0:height_px, 0:width_px].astype(np.float64)
    u = (grid_u + 0.5) / width_px
    v = (grid_v + 0.5) / height_px
    xs, ys = frame.image_xy(u, v)
    columns = np.rint(xs).astype(np.intp)
    rows = np.rint(ys).astype(np.intp)
    frame_height, frame_width = temps_c.shape
    inside = (columns >= 0) & (columns < frame_width) & (rows >= 0) & (rows < frame_height)
    canonical = np.full((height_px, width_px), np.nan, dtype=np.float64)
    safe_rows = np.clip(rows, 0, frame_height - 1)
    safe_columns = np.clip(columns, 0, frame_width - 1)
    on_foot = inside & frame.shape.mask[safe_rows, safe_columns]
    canonical[on_foot] = temps_c[safe_rows[on_foot], safe_columns[on_foot]]
    return canonical
