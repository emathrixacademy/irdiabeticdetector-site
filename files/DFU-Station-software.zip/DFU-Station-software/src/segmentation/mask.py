"""Plantar mask: find exactly two feet on the temperature frame, or refuse.

Works on temperatures only. The colour frame plays no part in what is
measured.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import cv2
import numpy as np

from src.config import SegmentationConfig
from src.datamodel import MaskArray, TempArray
from src.errors import FootCountError, FootOutOfFrameError, SegmentationError

EXPECTED_FEET = 2


@dataclass(frozen=True)
class PlantarMasks:
    """The two foot masks, ordered by position in the image (not anatomy)."""

    image_left: MaskArray = field(repr=False)
    image_right: MaskArray = field(repr=False)
    threshold_c: float
    reference_c: float
    background_c: float


def foot_threshold_c(
    temps_c: TempArray, ambient_temp_c: float, config: SegmentationConfig
) -> tuple[float, float, float]:
    """Threshold above which a pixel counts as foot.

    The reference is the warmer of the room and the frame's own background,
    so a cabinet interior that has warmed above the room does not turn into
    foot. Returns (threshold, reference, background).
    """
    background_c = float(np.percentile(temps_c, config.background_percentile))
    reference_c = max(ambient_temp_c, background_c)
    return reference_c + config.min_above_reference_c, reference_c, background_c


def _touches_edge(component: MaskArray, margin_px: int) -> bool:
    return bool(
        component[:margin_px, :].any()
        or component[-margin_px:, :].any()
        or component[:, :margin_px].any()
        or component[:, -margin_px:].any()
    )


def segment_feet(
    temps_c: TempArray, ambient_temp_c: float, config: SegmentationConfig
) -> PlantarMasks:
    """Segment both plantar surfaces.

    Raises FootOutOfFrameError if a foot is cut off at the frame edge and
    FootCountError if the frame does not hold exactly two feet.
    """
    if temps_c.ndim != 2:
        raise SegmentationError("segmentation needs a 2-D temperature frame")
    threshold_c, reference_c, background_c = foot_threshold_c(temps_c, ambient_temp_c, config)
    warm = (temps_c > threshold_c).astype(np.uint8)
    size = config.morphology_kernel_px
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (size, size))
    # Opening removes speckle and closing joins a foot across pinholes, so each
    # foot is one component. Morphology only decides which pixels belong to
    # which foot: the final masks keep warm pixels only, so a background pixel
    # between two toes is never measured as foot.
    cleaned = cv2.morphologyEx(warm, cv2.MORPH_OPEN, kernel)
    cleaned = cv2.morphologyEx(cleaned, cv2.MORPH_CLOSE, kernel)

    count, labels, stats, centroids = cv2.connectedComponentsWithStats(cleaned, connectivity=8)
    feet: list[tuple[float, MaskArray]] = []
    for label in range(1, count):
        if int(stats[label, cv2.CC_STAT_AREA]) < config.min_foot_area_px:
            continue
        component = np.asarray((labels == label) & (warm == 1), dtype=np.bool_)
        feet.append((float(centroids[label][0]), component))

    for _, component in feet:
        if _touches_edge(component, config.edge_margin_px):
            raise FootOutOfFrameError(
                "a foot is cut off at the edge of the thermal frame; both soles must be "
                "fully inside the frame"
            )
    if len(feet) != EXPECTED_FEET:
        raise FootCountError(len(feet))

    feet.sort(key=lambda item: item[0])
    return PlantarMasks(
        image_left=feet[0][1],
        image_right=feet[1][1],
        threshold_c=threshold_c,
        reference_c=reference_c,
        background_c=background_c,
    )
