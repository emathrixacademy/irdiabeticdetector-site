"""Station entry point.

python -m src.app                 run on the station
python -m src.app --fake          run against the fake drivers on a laptop
python -m src.app --fake --headless --reference-code DFU-0001 --left-foot image-right
                                  one scan with no UI
"""

from __future__ import annotations

import argparse
import logging
import sys
from datetime import UTC, datetime
from pathlib import Path

from src.clock import Clock, ManualClock
from src.config import Config, load_config
from src.errors import StationError
from src.hardware.factory import build_clock
from src.logging_setup import setup_logging
from src.reference_code import validate_reference_code
from src.station import Station, build_station

logger = logging.getLogger("src.app")

LEFT_FOOT_IMAGE_LEFT = "image-left"
LEFT_FOOT_IMAGE_RIGHT = "image-right"
LEFT_FOOT_CHOICES = (LEFT_FOOT_IMAGE_LEFT, LEFT_FOOT_IMAGE_RIGHT)

DEFAULT_CONFIG = Path("config/config.yaml")
EXAMPLE_CONFIG = Path("config/config.example.yaml")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="DFU Thermography Screening Station")
    parser.add_argument("--config", type=Path, default=None, help="path to config.yaml")
    parser.add_argument("--fake", action="store_true", help="use the fake drivers (no hardware)")
    parser.add_argument("--headless", action="store_true", help="run one scan without the UI")
    parser.add_argument("--reference-code", default=None, help="reference code for --headless")
    parser.add_argument(
        "--left-foot",
        choices=LEFT_FOOT_CHOICES,
        default=None,
        help="for --headless: where the patient's LEFT foot is in the image, as confirmed "
        "by the operator",
    )
    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)


def resolve_config_path(explicit: Path | None, fake: bool) -> Path:
    """config.yaml on the station. Fake mode may fall back to the example."""
    if explicit is not None:
        return explicit
    if DEFAULT_CONFIG.is_file() or not fake:
        return DEFAULT_CONFIG
    return EXAMPLE_CONFIG


def run_headless_scan(station: Station, reference_code: str, left_foot: str) -> Path:
    """Wait out the acclimatisation timer, take one scan, analyse and store it.

    `left_foot` is the operator's statement of where the left foot is in the
    image. There is no default: left and right are never assumed.
    """
    config = station.config
    code = validate_reference_code(reference_code, config.reference_code)
    station.acclimatisation.start(code)
    remaining_s = station.acclimatisation.remaining_s(code)
    logger.info("waiting %.0f s for acclimatisation", remaining_s)
    station.clock.sleep(remaining_s)
    record = station.sequencer.capture(code)
    prepared = station.pipeline.prepare(record)
    analysed = station.pipeline.analyse(prepared, left_foot == LEFT_FOOT_IMAGE_LEFT)
    return station.store.save(analysed)


def run_touchscreen(station: Station) -> int:
    """Start the operator UI. The window closes the station when it exits."""
    try:
        from src.ui.qt_app import run_ui
    except ImportError as exc:
        station.close()
        print(
            f"The touchscreen UI needs PyQt5 ({exc}). On the Pi: sudo apt install "
            "python3-pyqt5. On a laptop: pip install -r requirements-dev.txt.",
            file=sys.stderr,
        )
        return 2
    return run_ui(station)


def build_app_clock(config: Config, headless: bool) -> Clock:
    # A headless fake run uses a manual clock so the full acclimatisation
    # period elapses at once. The gate itself is unchanged.
    if config.is_fake and headless:
        # Start from the real time so repeated fake runs get different scan ids.
        return ManualClock(start_utc=datetime.now(UTC))
    return build_clock(config)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        config = load_config(resolve_config_path(args.config, args.fake), force_fake=args.fake)
    except StationError as exc:
        print(f"Cannot start: {exc}", file=sys.stderr)
        return 2
    setup_logging(config.logging.level, config.reference_code.pattern)

    if args.headless and (args.reference_code is None or args.left_foot is None):
        print("--headless needs --reference-code and --left-foot", file=sys.stderr)
        return 2

    try:
        station = build_station(config, build_app_clock(config, args.headless))
    except StationError as exc:
        logger.error("cannot start: %s", exc)
        return 2
    if not args.headless:
        return run_touchscreen(station)
    try:
        run_headless_scan(station, args.reference_code, args.left_foot)
    except StationError as exc:
        logger.error("scan refused or failed: %s", exc)
        return 1
    finally:
        station.close()
    print("Scan complete. One scan folder and one CSV row written.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
