"""Validation of the anonymised patient reference code.

The station stores only the code the research team supplies. Anything that
looks like a name or another identifier is refused before it can be stored.
"""

from __future__ import annotations

import re

from src.config import ReferenceCodeConfig
from src.errors import ReferenceCodeError

# Longest run of letters allowed in a code. Real codes are a short prefix and
# digits; a longer run of letters is most likely a name.
MAX_LETTER_RUN = 5

_SAFE_CHARACTERS = re.compile(r"[A-Za-z0-9_-]+")
_LETTER_RUN = re.compile(r"[A-Za-z]+")


def validate_reference_code(code: str, config: ReferenceCodeConfig) -> str:
    """Return the code unchanged if it is acceptable, else raise.

    The error message never repeats the rejected text, since it may be a name.
    """
    if not isinstance(code, str) or not code:
        raise ReferenceCodeError("reference code is empty")
    if code != code.strip():
        raise ReferenceCodeError("reference code has leading or trailing spaces")
    if len(code) > config.max_length:
        raise ReferenceCodeError(f"reference code is longer than {config.max_length} characters")
    if not _SAFE_CHARACTERS.fullmatch(code):
        raise ReferenceCodeError(
            "reference code may contain only letters, digits, hyphen and underscore"
        )
    if not any(character.isdigit() for character in code):
        raise ReferenceCodeError("reference code has no digits; it looks like a name")
    if any(len(run) > MAX_LETTER_RUN for run in _LETTER_RUN.findall(code)):
        raise ReferenceCodeError("reference code has a long run of letters; it looks like a name")
    if not re.fullmatch(config.pattern, code):
        raise ReferenceCodeError("reference code does not match the configured format")
    return code
