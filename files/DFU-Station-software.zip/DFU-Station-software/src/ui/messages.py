"""Operator-facing messages for every refusal and fault.

Written for a clinic operator, not an engineer: what happened and what to do
next, with no internal terms. Every station error has its own message.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from src import errors

SECONDS_PER_MINUTE = 60


@dataclass(frozen=True)
class UserMessage:
    title: str
    text: str


def _minutes_and_seconds(seconds: float) -> str:
    whole = math.ceil(seconds)
    minutes, rest = divmod(whole, SECONDS_PER_MINUTE)
    if minutes and rest:
        return f"{minutes} min {rest} s"
    if minutes:
        return f"{minutes} min"
    return f"{rest} s"


def friendly_message(error: BaseException) -> UserMessage:
    """The message shown on the touchscreen for an error."""
    if isinstance(error, errors.AmbientOutOfRangeError):
        if error.too_warm:
            return UserMessage(
                "Room too warm",
                f"The room is {error.ambient_temp_c:.1f} °C. Scanning needs "
                f"{error.min_c:.0f} to {error.max_c:.0f} °C. Cool the room, wait for the "
                "reading to come down, then try again.",
            )
        return UserMessage(
            "Room too cold",
            f"The room is {error.ambient_temp_c:.1f} °C. Scanning needs "
            f"{error.min_c:.0f} to {error.max_c:.0f} °C. Warm the room, wait for the "
            "reading to come up, then try again.",
        )
    if isinstance(error, errors.AcclimatisationNotMetError):
        return UserMessage(
            "Rest period not finished",
            f"The patient's feet must rest uncovered before scanning. "
            f"{_minutes_and_seconds(error.remaining_s)} to go.",
        )
    if isinstance(error, errors.AcclimatisationNotStartedError):
        return UserMessage(
            "Rest period not started",
            "Enter the patient's reference code to start the rest period.",
        )
    if isinstance(error, errors.GateRefusal):
        return UserMessage(
            "Not ready to scan",
            "The conditions for scanning are not met yet. Check the room temperature and "
            "the rest time on the screen, then try again.",
        )
    if isinstance(error, errors.FootOutOfFrameError):
        return UserMessage(
            "Foot out of view",
            "Part of a foot is outside the picture. Move both feet so each sole is fully "
            "inside the frame on the preview, then scan again.",
        )
    if isinstance(error, errors.FootCountError):
        if error.found < 2:
            detail = "Fewer than two feet were found."
        else:
            detail = "The feet could not be told apart."
        return UserMessage(
            "Both soles are needed",
            f"{detail} Place both bare soles in view, slightly apart and not touching, "
            "with nothing else warm in the cabinet, then scan again.",
        )
    if isinstance(error, errors.SidednessError):
        return UserMessage(
            "Left and right not confirmed",
            "Confirm on the screen which foot is the patient's left before the scan can "
            "be finished.",
        )
    if isinstance(error, errors.SegmentationError):
        return UserMessage(
            "Feet not clear",
            "The feet could not be outlined. Check both soles face the cameras with the "
            "toes up, then scan again.",
        )
    if isinstance(error, errors.SensorFaultError):
        return UserMessage(
            "Room sensor not responding",
            "The room temperature sensor gave no reading, so the scan cannot start. "
            "Wait a moment and try again. If this keeps happening, call the technician.",
        )
    if isinstance(error, errors.RadiometryError):
        return UserMessage(
            "Thermal camera not ready to measure",
            "The thermal camera is not set up to give temperatures. Do not scan. "
            "Call the technician.",
        )
    if isinstance(error, errors.FfcTimeoutError | errors.FfcInProgressError):
        return UserMessage(
            "Thermal camera busy",
            "The thermal camera was adjusting itself. Nothing was saved. Scan again.",
        )
    if isinstance(error, errors.StaleFrameError):
        return UserMessage(
            "Thermal camera not responding",
            "The thermal camera stopped sending pictures. Nothing was saved. Check its "
            "USB cable and scan again. If this keeps happening, call the technician.",
        )
    if isinstance(error, errors.InvalidFrameError | errors.ThermalFrameError):
        return UserMessage(
            "Thermal picture not usable",
            "The thermal picture was not usable, so nothing was saved. Check that nothing "
            "very hot or very cold is in the cabinet and scan again.",
        )
    if isinstance(error, errors.CalibrationError | errors.RegistrationError):
        return UserMessage(
            "Station needs calibration",
            "The station's calibration is missing or out of date. Do not scan. "
            "Call the technician.",
        )
    if isinstance(error, errors.AsymmetryError):
        return UserMessage(
            "Feet could not be compared",
            "There was not enough of both feet in view to compare them. Reposition the "
            "feet and scan again.",
        )
    if isinstance(error, errors.InferenceError):
        return UserMessage(
            "Colour analysis not available",
            "The colour-image analysis could not run, so the scan was not saved. "
            "Try again. If this keeps happening, call the technician.",
        )
    if isinstance(error, errors.StorageError):
        return UserMessage(
            "Scan could not be saved",
            "The scan could not be written to storage. Nothing was half-saved. "
            "The storage may be full. Call the technician.",
        )
    if isinstance(error, errors.ReferenceCodeError):
        return UserMessage(
            "Reference code not accepted",
            "Enter the study reference code exactly as given by the research team, "
            "for example DFU-0001. Never enter the patient's name.",
        )
    if isinstance(error, errors.CaptureError | errors.HardwareError):
        return UserMessage(
            "Equipment problem",
            "A camera or sensor did not respond. Nothing was saved. Try again. "
            "If this keeps happening, call the technician.",
        )
    if isinstance(error, errors.ConfigError):
        return UserMessage(
            "Station settings problem",
            "The station's settings file has a problem. Do not scan. Call the technician.",
        )
    return UserMessage(
        "Something went wrong",
        "The scan was stopped and nothing was saved. Try again. "
        "If this keeps happening, call the technician.",
    )
