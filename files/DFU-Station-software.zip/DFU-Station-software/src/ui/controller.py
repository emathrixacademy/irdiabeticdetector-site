"""Operator workflow, independent of any UI toolkit.

    reference code -> rest countdown and live previews -> capture
        -> confirm left/right -> results -> next patient

The touchscreen layer calls these methods and draws what they return. The
physical capture button and the on-screen button both end in
`request_capture`, so they always behave the same.

The controller never loosens a gate: it calls the sequencer, and whatever the
sequencer refuses is shown to the operator as a plain message.
"""

from __future__ import annotations

import logging
import shutil
import threading
from collections.abc import Callable
from dataclasses import dataclass
from enum import StrEnum

from src.datamodel import ImageArray
from src.errors import HardwareError, StationError, ThermalFrameError
from src.hardware.interfaces import StatusState
from src.pipeline import AnalysedScan, PreparedScan
from src.reference_code import validate_reference_code
from src.registration.apply import thermal_display_bgr
from src.station import Station
from src.storage import layout
from src.ui.messages import UserMessage, friendly_message

logger = logging.getLogger(__name__)

BYTES_PER_MB = 1024 * 1024


class Screen(StrEnum):
    REFERENCE = "reference"
    PREPARE = "prepare"
    CONFIRM_SIDES = "confirm_sides"
    RESULTS = "results"


@dataclass(frozen=True)
class PrepareStatus:
    """What the countdown screen shows."""

    remaining_s: float
    ambient_temp_c: float | None
    ambient_humidity_pct: float | None
    ambient_ok: bool
    ambient_text: str
    ready: bool


@dataclass(frozen=True)
class StationInfo:
    """What the code-entry screen shows about the station itself."""

    local_time_text: str
    utc_time_text: str
    free_mb: int | None
    low_space: bool
    scans_today: int
    fake_mode: bool
    classifier_installed: bool

    def lines(self) -> list[str]:
        """Plain lines for the screen."""
        free = "unknown" if self.free_mb is None else f"{self.free_mb / 1024:.1f} GB"
        lines = [
            f"Station clock: {self.local_time_text} ({self.utc_time_text}). "
            "If this is wrong, stop and call the technician.",
            f"Storage free: {free}.  Scans stored today: {self.scans_today}.",
        ]
        if self.low_space:
            lines.append("STORAGE IS NEARLY FULL. Tell the technician before scanning.")
        modes: list[str] = []
        if self.fake_mode:
            modes.append("DEMO MODE: stand-in pictures, nothing shown is a measurement.")
        if not self.classifier_installed:
            modes.append("Data collection: no colour model.")
        if modes:
            # One line, so the keypad below keeps its full height on a 480-pixel screen.
            lines.append("  ".join(modes))
        return lines


@dataclass(frozen=True)
class Previews:
    """Live pictures for positioning. Either may be missing."""

    thermal_bgr: ImageArray | None
    color_bgr: ImageArray | None


class StationController:
    def __init__(self, station: Station) -> None:
        self._station = station
        self._screen = Screen.REFERENCE
        self._reference_code: str | None = None
        self._prepared: PreparedScan | None = None
        self._result: AnalysedScan | None = None
        self._message: UserMessage | None = None
        # `_busy` rejects a second capture while one is running. `_devices`
        # keeps the live preview and a capture from using the cameras at once.
        self._busy = threading.Lock()
        self._devices = threading.Lock()
        self._capture_hook: Callable[[], None] | None = None
        station.devices.status_led.set_state(StatusState.IDLE)
        station.devices.button.set_handler(self._on_button)

    # --- State the UI reads ---------------------------------------------------

    @property
    def screen(self) -> Screen:
        return self._screen

    @property
    def reference_code(self) -> str | None:
        return self._reference_code

    @property
    def prepared(self) -> PreparedScan | None:
        return self._prepared

    @property
    def result(self) -> AnalysedScan | None:
        return self._result

    @property
    def message(self) -> UserMessage | None:
        return self._message

    @property
    def busy(self) -> bool:
        return self._busy.locked()

    def dismiss_message(self) -> None:
        self._message = None

    def station_info(self) -> StationInfo:
        """Clock, storage and mode, for the operator to check before the first patient.

        The app covers the whole screen, so this is the only place the operator
        can see the station's clock. The station is offline and cannot set it.
        """
        station = self._station
        config = station.config
        now_utc = station.clock.now_utc()
        data_dir = station.store.data_dir
        free_mb: int | None = None
        existing = next((p for p in (data_dir, *data_dir.parents) if p.exists()), None)
        if existing is not None:
            try:
                free_mb = shutil.disk_usage(existing).free // BYTES_PER_MB
            except OSError:
                free_mb = None
        today = f"{now_utc:%Y%m%d}_"
        scans_today = 0
        if data_dir.is_dir():
            scans_today = sum(
                1
                for session in data_dir.iterdir()
                if session.is_dir() and session.name.startswith(today)
                for scan in session.iterdir()
                if (scan / layout.META_FILE).is_file()
            )
        return StationInfo(
            local_time_text=f"{now_utc.astimezone():%a %d %b %Y, %H:%M}",
            utc_time_text=f"{now_utc:%H:%M} UTC",
            free_mb=free_mb,
            low_space=free_mb is not None and free_mb < config.storage.low_space_warning_mb,
            scans_today=scans_today,
            fake_mode=config.is_fake,
            classifier_installed=station.metadata is not None,
        )

    def _fail(self, error: StationError) -> None:
        logger.warning("shown to operator: %s", type(error).__name__)
        self._message = friendly_message(error)
        self._station.devices.status_led.set_state(StatusState.ERROR)

    # --- Reference code -------------------------------------------------------

    def submit_reference_code(self, text: str) -> bool:
        """Accept the code and start the rest timer. False if it is refused."""
        try:
            code = validate_reference_code(text.strip(), self._station.config.reference_code)
        except StationError as error:
            self._fail(error)
            return False
        self._reference_code = code
        self._message = None
        self._station.acclimatisation.start(code)
        self._screen = Screen.PREPARE
        self._station.devices.status_led.set_state(StatusState.ACCLIMATISING)
        return True

    # --- Countdown and previews -----------------------------------------------

    def prepare_status(self) -> PrepareStatus | None:
        """Countdown and room status. None while a capture is running."""
        if self._screen is not Screen.PREPARE or self._reference_code is None or self.busy:
            return None
        if not self._devices.acquire(blocking=False):
            return None
        try:
            return self._read_prepare_status(self._reference_code)
        finally:
            self._devices.release()

    def _read_prepare_status(self, reference_code: str) -> PrepareStatus:
        station = self._station
        remaining_s = station.acclimatisation.remaining_s(reference_code)
        temp_c: float | None = None
        humidity_pct: float | None = None
        ambient_ok = False
        try:
            reading = station.devices.ambient.read()
            temp_c, humidity_pct = reading.temp_c, reading.humidity_pct
            ambient_ok = station.ambient_gate.in_range(reading)
            if ambient_ok:
                ambient_text = f"Room {temp_c:.1f} °C, {humidity_pct:.0f} % humidity. OK to scan."
            else:
                gate = station.ambient_gate
                side = "warm" if temp_c > gate.max_c else "cold"
                ambient_text = (
                    f"Room {temp_c:.1f} °C is too {side}. "
                    f"Scanning needs {gate.min_c:.0f} to {gate.max_c:.0f} °C."
                )
        except StationError:
            ambient_text = "Room sensor not responding."
        ready = remaining_s <= 0 and ambient_ok
        if self._message is None:
            station.devices.status_led.set_state(
                StatusState.READY if ready else StatusState.ACCLIMATISING
            )
        return PrepareStatus(
            remaining_s=remaining_s,
            ambient_temp_c=temp_c,
            ambient_humidity_pct=humidity_pct,
            ambient_ok=ambient_ok,
            ambient_text=ambient_text,
            ready=ready,
        )

    def previews(self) -> Previews:
        """Live pictures for positioning the feet. Display only.

        The thermal preview is a false-colour picture of the Y16 frame. The
        colour preview is unlit, because the interior light only comes on for
        the capture itself.
        """
        if self._screen is not Screen.PREPARE or self.busy:
            return Previews(None, None)
        if not self._devices.acquire(blocking=False):
            return Previews(None, None)
        thermal_bgr: ImageArray | None = None
        color_bgr: ImageArray | None = None
        try:
            try:
                thermal_bgr = thermal_display_bgr(self._station.thermal_source.preview_temps_c())
            except (HardwareError, ThermalFrameError):
                thermal_bgr = None
            try:
                color_bgr = self._station.devices.color.capture().image_bgr
            except HardwareError:
                color_bgr = None
        finally:
            self._devices.release()
        return Previews(thermal_bgr, color_bgr)

    # --- Capture: the one path for both buttons ---------------------------------

    def set_capture_hook(self, hook: Callable[[], None] | None) -> None:
        """Let the UI move a physical button press onto its own thread.

        The hook must end up calling `request_capture`.
        """
        self._capture_hook = hook

    def _on_button(self) -> None:
        if self._capture_hook is not None:
            self._capture_hook()
        else:
            self.request_capture()

    def request_capture(self) -> bool:
        """Run one scan up to the left/right question. Same for both buttons."""
        if self._screen is not Screen.PREPARE or self._reference_code is None:
            return False
        if not self._busy.acquire(blocking=False):
            return False
        station = self._station
        try:
            self._message = None
            station.devices.status_led.set_state(StatusState.CAPTURING)
            with self._devices:  # waits for a preview read in progress to finish
                try:
                    record = station.sequencer.capture(self._reference_code)
                finally:
                    station.devices.light.off()
            self._prepared = station.pipeline.prepare(record)
        except StationError as error:
            self._prepared = None
            self._fail(error)
            return False
        finally:
            self._busy.release()
        self._screen = Screen.CONFIRM_SIDES
        station.devices.status_led.set_state(StatusState.READY)
        return True

    # --- Left / right -----------------------------------------------------------

    def confirm_sides(self, left_is_image_left: bool) -> bool:
        """Finish and store the scan with the operator's answer."""
        if self._screen is not Screen.CONFIRM_SIDES or self._prepared is None:
            return False
        if not self._busy.acquire(blocking=False):
            return False
        station = self._station
        try:
            self._message = None
            analysed = station.pipeline.analyse(self._prepared, left_is_image_left)
            station.store.save(analysed)
        except StationError as error:
            self._fail(error)
            return False
        finally:
            self._busy.release()
        self._result = analysed
        self._prepared = None
        self._screen = Screen.RESULTS
        return True

    def retake(self) -> None:
        """Throw away the unconfirmed scan and go back to positioning."""
        if self._screen is Screen.CONFIRM_SIDES:
            self._prepared = None
            self._message = None
            self._screen = Screen.PREPARE

    # --- After the results --------------------------------------------------------

    def scan_again(self) -> None:
        """Another scan of the same patient. The rest timer keeps running."""
        if self._screen is Screen.RESULTS:
            self._result = None
            self._message = None
            self._screen = Screen.PREPARE

    def next_patient(self) -> None:
        """Forget this patient and return to code entry."""
        if self._reference_code is not None:
            self._station.acclimatisation.clear(self._reference_code)
        self._reference_code = None
        self._prepared = None
        self._result = None
        self._message = None
        self._screen = Screen.REFERENCE
        self._station.devices.status_led.set_state(StatusState.IDLE)

    def restart_rest_period(self) -> None:
        """Start the rest period again, for example after the patient moved."""
        if self._screen is Screen.PREPARE and self._reference_code is not None:
            self._station.acclimatisation.restart(self._reference_code)
            self._station.devices.status_led.set_state(StatusState.ACCLIMATISING)
