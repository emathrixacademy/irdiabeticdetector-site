"""Touchscreen operator app (PyQt5), sized for a 7-inch 800 x 480 screen.

A thin layer over `StationController`: it draws what the controller reports
and passes on what the operator taps. All rules live in the controller and
below it. It runs in fake mode on a laptop.

PyQt5 comes from apt on the Pi (`python3-pyqt5`) and from pip on a laptop.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from functools import partial
from typing import Any

from PyQt5 import QtCore as _QtCore
from PyQt5 import QtGui as _QtGui
from PyQt5 import QtWidgets as _QtWidgets

from src.datamodel import ImageArray
from src.fusion.fuse import summary_lines
from src.station import Station
from src.ui import render
from src.ui.controller import Screen, StationController

logger = logging.getLogger(__name__)

# PyQt5's type stubs differ between the pip wheel and the apt package and are
# incomplete for enums, so the Qt modules are used untyped in this one file.
QtCore: Any = _QtCore
QtGui: Any = _QtGui
QtWidgets: Any = _QtWidgets

SCREEN_WIDTH_PX = 800
SCREEN_HEIGHT_PX = 480
PREVIEW_WIDTH_PX = 320
PREVIEW_HEIGHT_PX = 240
# About 15 mm on a 7-inch 800-pixel-wide panel: comfortable for a fingertip.
MIN_TOUCH_WIDTH_PX = 78
RESULT_MAP_WIDTH_PX = 360
RESULT_MAP_HEIGHT_PX = 270
TABLE_ROW_HEIGHT_PX = 23
TABLE_VALUE_COLUMN_WIDTHS_PX = (62, 62, 104)

KEY_ROWS: tuple[str, ...] = ("1234567890", "QWERTYUIOP", "ASDFGHJKL-", "ZXCVBNM_")

STYLE = """
QWidget { background: #101418; color: #f2f2f2; font-size: 16px; }
QPushButton { background: #26323d; border: 1px solid #44525f; border-radius: 6px;
              padding: 8px; min-height: 34px; }
QPushButton:pressed { background: #3a4b5a; }
QPushButton:disabled { color: #6b7780; background: #1a2026; }
QPushButton#primary { background: #1f6f4a; font-size: 20px; font-weight: bold; }
QPushButton#primary:disabled { background: #1a2a22; color: #6b7780; }
QLabel#title { font-size: 20px; font-weight: bold; }
QLabel#big { font-size: 44px; font-weight: bold; }
QLabel#code { font-size: 28px; background: #1a2026; border: 1px solid #44525f; padding: 6px; }
QLabel#note { color: #b9c2c9; font-size: 13px; }
QLabel#info { color: #d7dde2; font-size: 13px; }
QLabel#info[alert="true"] { color: #ffb74d; font-weight: bold; }
QLabel#picture { background: #000000; border: 1px solid #44525f; }
QTableWidget { background: #151b21; gridline-color: #33404b; font-size: 13px; }
QHeaderView::section { background: #26323d; padding: 2px; font-size: 13px; }
"""


def to_pixmap(image_bgr: ImageArray, width: int, height: int, *, smooth: bool) -> Any:
    """A BGR array as a pixmap scaled to fit, keeping its shape."""
    rows, columns = image_bgr.shape[:2]
    data = image_bgr.tobytes()
    image = QtGui.QImage(data, columns, rows, columns * 3, QtGui.QImage.Format_BGR888).copy()
    mode = QtCore.Qt.SmoothTransformation if smooth else QtCore.Qt.FastTransformation
    return QtGui.QPixmap.fromImage(image).scaled(width, height, QtCore.Qt.KeepAspectRatio, mode)


class Worker(QtCore.QThread):
    """Runs one blocking controller call off the UI thread."""

    done = QtCore.pyqtSignal()

    def __init__(self, task: Callable[[], object]) -> None:
        super().__init__()
        self._task = task

    def run(self) -> None:
        try:
            self._task()
        except Exception:  # the UI must stay alive whatever a task does
            logger.exception("a background task failed")
        self.done.emit()


class MainWindow(QtWidgets.QMainWindow):
    capture_requested = QtCore.pyqtSignal()

    def __init__(self, station: Station, *, synchronous: bool = False) -> None:
        super().__init__()
        self.station = station
        self.controller = StationController(station)
        self._synchronous = synchronous
        self._worker: Worker | None = None
        self._entered = ""
        self._shown_message: object = None

        self.setWindowTitle("DFU Thermography Screening Station")
        self.setStyleSheet(STYLE)
        self.stack = QtWidgets.QStackedWidget()
        self.setCentralWidget(self.stack)
        self._pages: dict[Screen, Any] = {
            Screen.REFERENCE: self._build_reference_page(),
            Screen.PREPARE: self._build_prepare_page(),
            Screen.CONFIRM_SIDES: self._build_confirm_page(),
            Screen.RESULTS: self._build_results_page(),
        }
        for page in self._pages.values():
            self.stack.addWidget(page)

        # A press of the physical button arrives on a GPIO thread. The signal
        # carries it to the UI thread, where it takes the same path as a tap.
        self.capture_requested.connect(self.start_capture)
        self.controller.set_capture_hook(self.capture_requested.emit)

        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(station.config.ui.preview_interval_ms)
        QtWidgets.QShortcut(QtGui.QKeySequence("Ctrl+Q"), self, activated=self.close)
        self.refresh()

    # --- Building the pages ---------------------------------------------------

    def _button(self, text: str, handler: Callable[[], object], *, primary: bool = False) -> Any:
        button = QtWidgets.QPushButton(text)
        if primary:
            button.setObjectName("primary")
        button.clicked.connect(lambda _checked=False: handler())
        return button

    def _label(self, text: str = "", name: str | None = None, *, wrap: bool = True) -> Any:
        label = QtWidgets.QLabel(text)
        if name is not None:
            label.setObjectName(name)
        label.setWordWrap(wrap)
        return label

    def _picture(self, width: int, height: int) -> Any:
        label = QtWidgets.QLabel()
        label.setObjectName("picture")
        label.setFixedSize(width, height)
        label.setAlignment(QtCore.Qt.AlignCenter)
        return label

    def _build_reference_page(self) -> Any:
        page = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(page)
        layout.setSpacing(5)
        layout.setContentsMargins(9, 6, 9, 6)
        layout.addWidget(self._label(self._demo("Enter the study reference code"), "title"))
        self.code_label = self._label("", "code", wrap=False)
        self.code_label.setMinimumHeight(42)
        layout.addWidget(self.code_label)
        layout.addWidget(
            self._label("Use the code from the research team. Never enter a name.", "note")
        )
        self.info_label = self._label("", "info")
        layout.addWidget(self.info_label)
        self.key_buttons: dict[str, Any] = {}
        for row in KEY_ROWS:
            line = QtWidgets.QHBoxLayout()
            for character in row:
                button = self._button(character, partial(self.type_character, character))
                self.key_buttons[character] = button
                line.addWidget(button)
            layout.addLayout(line)
        actions = QtWidgets.QHBoxLayout()
        for text, handler in (
            ("Exit", self.close),
            ("Delete", self.delete_character),
            ("Clear", self.clear_code),
        ):
            button = self._button(text, handler)
            button.setMinimumWidth(MIN_TOUCH_WIDTH_PX)
            actions.addWidget(button)
        self.start_button = self._button("Start rest period", self.submit_code, primary=True)
        actions.addWidget(self.start_button, 2)
        layout.addLayout(actions)
        return page

    def _build_prepare_page(self) -> Any:
        page = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(page)
        pictures = QtWidgets.QVBoxLayout()
        self.thermal_preview = self._picture(PREVIEW_WIDTH_PX, PREVIEW_HEIGHT_PX)
        self.color_preview = self._picture(PREVIEW_WIDTH_PX, PREVIEW_HEIGHT_PX // 2 + 40)
        pictures.addWidget(self._label("Thermal view: place both soles inside", "note"))
        pictures.addWidget(self.thermal_preview)
        pictures.addWidget(self._label("Colour view (unlit until capture)", "note"))
        pictures.addWidget(self.color_preview)
        layout.addLayout(pictures)

        side = QtWidgets.QVBoxLayout()
        self.patient_label = self._label("", "title")
        self.countdown_label = self._label("--:--", "big", wrap=False)
        self.state_label = self._label("")
        self.ambient_label = self._label("")
        self.capture_button = self._button("CAPTURE", self.start_capture, primary=True)
        self.capture_button.setMinimumHeight(80)
        side.addWidget(self.patient_label)
        side.addWidget(self._label("Rest time remaining", "note"))
        side.addWidget(self.countdown_label)
        side.addWidget(self.state_label)
        side.addWidget(self.ambient_label)
        side.addStretch(1)
        side.addWidget(self.capture_button)
        side.addWidget(self._button("Restart rest period", self.restart_rest))
        side.addWidget(self._button("Change patient", self.next_patient))
        layout.addLayout(side, 1)
        return page

    def _build_confirm_page(self) -> Any:
        page = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(page)
        self.confirm_picture = self._picture(480, 360)
        layout.addWidget(self.confirm_picture)
        side = QtWidgets.QVBoxLayout()
        side.addWidget(self._label(self._demo("Which is the patient's LEFT foot?"), "title"))
        self.proposal_label = self._label("")
        side.addWidget(self.proposal_label)
        self.left_is_a_button = self._button("Foot A is the LEFT foot", lambda: self.confirm(True))
        self.left_is_b_button = self._button("Foot B is the LEFT foot", lambda: self.confirm(False))
        for button in (self.left_is_a_button, self.left_is_b_button):
            button.setMinimumHeight(70)
            side.addWidget(button)
        side.addWidget(
            self._label("Look at the patient, not the picture, before you answer.", "note")
        )
        side.addStretch(1)
        side.addWidget(self._button("Discard and scan again", self.retake))
        layout.addLayout(side, 1)
        return page

    def _build_results_page(self) -> Any:
        page = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(page)
        pictures = QtWidgets.QVBoxLayout()
        self.result_heatmap = self._picture(RESULT_MAP_WIDTH_PX, RESULT_MAP_HEIGHT_PX)
        self.result_color = self._picture(200, 150)
        pictures.addWidget(self.result_heatmap)
        pictures.addWidget(self.result_color)
        layout.addLayout(pictures)

        side = QtWidgets.QVBoxLayout()
        self.result_title = self._label("", "title")
        side.addWidget(self.result_title)
        self.table = QtWidgets.QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Region", "Left °C", "Right °C", "L minus R °C"])
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(TABLE_ROW_HEIGHT_PX)
        self.table.horizontalHeader().setFixedHeight(TABLE_ROW_HEIGHT_PX)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        for column, width in enumerate(TABLE_VALUE_COLUMN_WIDTHS_PX, start=1):
            header.setSectionResizeMode(column, QtWidgets.QHeaderView.Fixed)
            self.table.setColumnWidth(column, width)
        # All eight regions are shown at once, so there is nothing to scroll.
        self.table.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.table.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.table.verticalHeader().setMinimumSectionSize(TABLE_ROW_HEIGHT_PX)
        self.table.verticalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Fixed)
        side.addWidget(self.table)
        side.addStretch(1)
        self.summary_label = self._label("", "note")
        side.addWidget(self.summary_label)
        actions = QtWidgets.QHBoxLayout()
        actions.addWidget(self._button("Scan again", self.scan_again))
        actions.addWidget(self._button("Next patient", self.next_patient, primary=True))
        side.addLayout(actions)
        layout.addLayout(side, 1)
        return page

    # --- Reference code entry -------------------------------------------------

    def type_character(self, character: str) -> None:
        if len(self._entered) < self.station.config.reference_code.max_length:
            self._entered += character
            self.code_label.setText(self._entered)

    def delete_character(self) -> None:
        self._entered = self._entered[:-1]
        self.code_label.setText(self._entered)

    def clear_code(self) -> None:
        self._entered = ""
        self.code_label.setText("")

    def submit_code(self) -> None:
        if self.controller.submit_reference_code(self._entered):
            self.clear_code()
        self.refresh()

    # --- Actions --------------------------------------------------------------

    def _run(self, task: Callable[[], object]) -> None:
        """Run a blocking controller call, then redraw."""
        if self._worker is not None:
            return
        self._set_enabled(False)
        if self._synchronous:
            task()
            self._task_finished()
            return
        self._worker = Worker(task)
        self._worker.done.connect(self._task_finished)
        self._worker.start()

    def _task_finished(self) -> None:
        if self._worker is not None:
            self._worker.wait()
            self._worker = None
        self._set_enabled(True)
        self.refresh()

    def _set_enabled(self, enabled: bool) -> None:
        self.stack.setEnabled(enabled)

    def start_capture(self) -> None:
        """The on-screen button and the physical button both arrive here."""
        if self.controller.screen is not Screen.PREPARE:
            return
        self.state_label.setText("Capturing. Keep still.")
        self._run(self.controller.request_capture)

    def confirm(self, left_is_foot_a: bool) -> None:
        # Foot A is the foot on the left of the picture.
        self._run(lambda: self.controller.confirm_sides(left_is_foot_a))

    def retake(self) -> None:
        self.controller.retake()
        self.refresh()

    def scan_again(self) -> None:
        self.controller.scan_again()
        self.refresh()

    def next_patient(self) -> None:
        self.controller.next_patient()
        self.refresh()

    def restart_rest(self) -> None:
        self.controller.restart_rest_period()
        self.tick()

    # --- Drawing --------------------------------------------------------------

    def tick(self) -> None:
        """Update the station info, countdown, room status and live previews."""
        if self._worker is not None:
            return
        if self.controller.screen is Screen.REFERENCE:
            self._draw_station_info()
            return
        if self.controller.screen is not Screen.PREPARE:
            return
        status = self.controller.prepare_status()
        if status is None:
            return
        self.countdown_label.setText(render.countdown_text(status.remaining_s))
        self.ambient_label.setText(status.ambient_text)
        if status.ready:
            self.state_label.setText("Ready to scan.")
        elif status.remaining_s > 0:
            self.state_label.setText("Resting. Keep feet uncovered and still.")
        else:
            self.state_label.setText("Waiting for the room temperature.")
        self.capture_button.setEnabled(status.ready)
        previews = self.controller.previews()
        if previews.thermal_bgr is not None:
            self.thermal_preview.setPixmap(
                to_pixmap(previews.thermal_bgr, PREVIEW_WIDTH_PX, PREVIEW_HEIGHT_PX, smooth=False)
            )
        else:
            self.thermal_preview.setText("No thermal picture")
        if previews.color_bgr is not None:
            self.color_preview.setPixmap(
                to_pixmap(
                    previews.color_bgr,
                    self.color_preview.width(),
                    self.color_preview.height(),
                    smooth=True,
                )
            )
        else:
            self.color_preview.setText("No colour picture")

    def _demo(self, text: str) -> str:
        """Mark a heading when the stand-in drivers are in use, on every screen."""
        return f"DEMO: {text}" if self.station.config.is_fake else text

    def _draw_station_info(self) -> None:
        info = self.controller.station_info()
        self.info_label.setText("\n".join(info.lines()))
        self.info_label.setProperty("alert", info.low_space or info.fake_mode)
        self.info_label.style().unpolish(self.info_label)
        self.info_label.style().polish(self.info_label)

    def refresh(self) -> None:
        """Show the controller's current screen and any message."""
        screen = self.controller.screen
        self.stack.setCurrentWidget(self._pages[screen])
        if screen is Screen.REFERENCE:
            self._draw_station_info()
        elif screen is Screen.PREPARE:
            self.patient_label.setText(self._demo(f"Patient {self.controller.reference_code}"))
            self.tick()
        elif screen is Screen.CONFIRM_SIDES:
            self._draw_confirm()
        elif screen is Screen.RESULTS:
            self._draw_results()
        self._show_message()

    def _draw_confirm(self) -> None:
        prepared = self.controller.prepared
        if prepared is None:
            return
        self.confirm_picture.setPixmap(
            to_pixmap(render.confirm_picture(prepared), 480, 360, smooth=False)
        )
        proposal = prepared.proposal.left_is_image_left
        if proposal is None:
            self.proposal_label.setText("The station could not tell from the foot shapes.")
        else:
            self.proposal_label.setText(
                f"From the foot shapes, the station thinks foot {'A' if proposal else 'B'} "
                "is the left foot. Confirm or correct it."
            )

    def _draw_results(self) -> None:
        scan = self.controller.result
        if scan is None:
            return
        config = self.station.config
        self.result_title.setText(self._demo(f"Patient {scan.record.reference_code}: scan saved"))
        self.result_heatmap.setPixmap(
            to_pixmap(
                render.results_heatmap(scan, config),
                RESULT_MAP_WIDTH_PX,
                RESULT_MAP_HEIGHT_PX,
                smooth=False,
            )
        )
        self.result_color.setPixmap(to_pixmap(scan.registered.crop_bgr, 200, 150, smooth=True))
        rows = render.region_rows(scan)
        self.table.setRowCount(len(rows))
        for index, row in enumerate(rows):
            delta = f"{row.delta}  FLAG" if row.flagged else row.delta
            for column, text in enumerate((row.name, row.left, row.right, delta)):
                item = QtWidgets.QTableWidgetItem(text)
                if row.flagged:
                    font = item.font()
                    font.setBold(True)
                    item.setFont(font)
                    item.setBackground(QtGui.QColor("#5a3a12"))
                self.table.setItem(index, column, item)
        self._fit_table_height()
        self.summary_label.setText("\n".join(summary_lines(scan.fused)))

    def _fit_table_height(self) -> None:
        """Size the table to show every row, whatever height the font gives them."""
        rows_px = sum(self.table.rowHeight(row) for row in range(self.table.rowCount()))
        header_px = self.table.horizontalHeader().height()
        self.table.setFixedHeight(rows_px + header_px + 2 * self.table.frameWidth())

    def _show_message(self) -> None:
        message = self.controller.message
        if message is None or message is self._shown_message:
            return
        self._shown_message = message
        if self._synchronous:
            self.last_message_text = f"{message.title}: {message.text}"
            self.controller.dismiss_message()
            return
        box = QtWidgets.QMessageBox(self)
        box.setWindowTitle(message.title)
        box.setText(f"<b>{message.title}</b>")
        box.setInformativeText(message.text)
        box.setStandardButtons(QtWidgets.QMessageBox.Ok)
        box.exec_()
        self.controller.dismiss_message()

    def closeEvent(self, event: Any) -> None:  # noqa: N802 - Qt naming
        self.timer.stop()
        if self._worker is not None:
            self._worker.wait()
        self.controller.set_capture_hook(None)
        self.station.close()
        event.accept()


def run_ui(station: Station) -> int:
    """Start the touchscreen app. Returns the process exit code."""
    application = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    window = MainWindow(station)
    if station.config.ui.fullscreen:
        window.showFullScreen()
    else:
        window.resize(SCREEN_WIDTH_PX, SCREEN_HEIGHT_PX)
        window.show()
    return int(application.exec_())
