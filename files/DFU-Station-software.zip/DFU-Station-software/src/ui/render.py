"""Pictures for the touchscreen. Everything here is for display only.

The thermal frame is enlarged with nearest-neighbour so each thermal pixel
stays a visible block. No temperature is ever read back from these pictures.
"""

from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from src.config import Config
from src.datamodel import ImageArray, RegionResult
from src.pipeline import AnalysedScan, PreparedScan
from src.registration.apply import thermal_display_bgr
from src.segmentation.geometry import FootFrame

DISPLAY_SCALE = 4
FLAG_COLOR_BGR = (255, 255, 255)
REGION_COLOR_BGR = (150, 150, 150)
LABEL_COLOR_BGR = (255, 255, 255)
LABEL_SHADOW_BGR = (0, 0, 0)
FONT = cv2.FONT_HERSHEY_SIMPLEX


@dataclass(frozen=True)
class RegionRow:
    """One line of the results table, already formatted."""

    name: str
    left: str
    right: str
    delta: str
    flagged: bool


def enlarge(image_bgr: ImageArray, scale: int = DISPLAY_SCALE) -> ImageArray:
    """Enlarge for viewing with nearest-neighbour. Display only."""
    height, width = image_bgr.shape[:2]
    enlarged = cv2.resize(
        image_bgr, (width * scale, height * scale), interpolation=cv2.INTER_NEAREST
    )
    return np.asarray(enlarged, dtype=np.uint8)


def _to_display(xs: np.ndarray, ys: np.ndarray, scale: int) -> np.ndarray:
    """Thermal pixel centres to coordinates on the enlarged picture."""
    points = np.stack([xs * scale + (scale - 1) / 2.0, ys * scale + (scale - 1) / 2.0], axis=1)
    return np.asarray(np.rint(points), dtype=np.int32)


def _label(image: ImageArray, text: str, x: int, y: int, size: float = 0.5) -> None:
    cv2.putText(image, text, (x + 1, y + 1), FONT, size, LABEL_SHADOW_BGR, 2, cv2.LINE_AA)
    cv2.putText(image, text, (x, y), FONT, size, LABEL_COLOR_BGR, 1, cv2.LINE_AA)


def _draw_regions(
    image: ImageArray,
    frame: FootFrame,
    config: Config,
    results: dict[str, RegionResult],
    scale: int,
    *,
    label_deltas: bool,
) -> None:
    for name, polygon in config.regions.polygons:
        u = np.array([point[0] for point in polygon], dtype=np.float64)
        v = np.array([point[1] for point in polygon], dtype=np.float64)
        xs, ys = frame.image_xy(u, v)
        outline = _to_display(xs, ys, scale)
        result = results[name]
        color = FLAG_COLOR_BGR if result.flagged else REGION_COLOR_BGR
        cv2.polylines(image, [outline], True, color, 2 if result.flagged else 1, cv2.LINE_AA)
        if label_deltas and result.delta_c is not None and result.flagged:
            centre = outline.mean(axis=0)
            _label(image, f"{result.delta_c:+.1f}", int(centre[0]) - 24, int(centre[1]) + 6, 0.65)


def _foot_title(image: ImageArray, frame: FootFrame, text: str, scale: int) -> None:
    xs, ys = frame.image_xy(np.array([0.5]), np.array([0.0]))
    point = _to_display(xs, ys, scale)[0]
    _label(image, text, int(point[0]) - 22, max(int(point[1]) - 8, 14), 0.55)


def results_heatmap(scan: AnalysedScan, config: Config, scale: int = DISPLAY_SCALE) -> ImageArray:
    """Thermal false colour with the region map, flags and left/right marked."""
    image = enlarge(thermal_display_bgr(scan.record.thermal.temps_c), scale)
    results = {region.name: region for region in scan.asymmetry.regions}
    _draw_regions(image, scan.oriented.left, config, results, scale, label_deltas=True)
    _draw_regions(image, scan.oriented.right, config, results, scale, label_deltas=False)
    _foot_title(image, scan.oriented.left, "LEFT", scale)
    _foot_title(image, scan.oriented.right, "RIGHT", scale)
    return image


def confirm_picture(prepared: PreparedScan, scale: int = DISPLAY_SCALE) -> ImageArray:
    """Thermal false colour with the two feet marked A and B by picture position."""
    image = enlarge(thermal_display_bgr(prepared.record.thermal.temps_c), scale)
    for mask, text in ((prepared.masks.image_left, "A"), (prepared.masks.image_right, "B")):
        rows, columns = np.nonzero(mask)
        x = int(columns.mean() * scale) - 10
        y = int(rows.mean() * scale) + 10
        _label(image, text, x, y, 1.2)
    return image


def _temperature(value: float | None) -> str:
    return "n/a" if value is None else f"{value:.1f}"


def region_rows(scan: AnalysedScan) -> list[RegionRow]:
    """The results table. A region that could not be compared shows n/a."""
    rows: list[RegionRow] = []
    for region in scan.asymmetry.regions:
        delta = "n/a" if region.delta_c is None else f"{region.delta_c:+.2f}"
        rows.append(
            RegionRow(
                name=region.name.replace("_", " "),
                left=_temperature(region.left_mean_c),
                right=_temperature(region.right_mean_c),
                delta=delta,
                flagged=region.flagged,
            )
        )
    return rows


def countdown_text(remaining_s: float) -> str:
    whole = max(0, int(np.ceil(remaining_s)))
    return f"{whole // 60:02d}:{whole % 60:02d}"
