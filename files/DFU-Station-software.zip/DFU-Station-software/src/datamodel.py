"""Data carried through the pipeline.

Temperatures are float degrees Celsius everywhere. The only place raw sensor
counts are interpreted is `src/thermal/`; other code may carry the raw array
(storage keeps it for the record) but must not read values from it.

No model output here is a clinical grade. The classifier's result is a
`predicted_class`, and a test enforces that no field is named otherwise.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Literal

import numpy as np
from numpy.typing import NDArray

TempArray = NDArray[np.float64]
RawArray = NDArray[np.uint16]
ImageArray = NDArray[np.uint8]
MaskArray = NDArray[np.bool_]


class FfcState(StrEnum):
    """Flat-field correction state of the Lepton when a frame was read."""

    NEVER = "never"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"


@dataclass(frozen=True)
class RawThermalFrame:
    """One Y16 frame straight from the driver. Not yet a measurement."""

    raw: RawArray
    monotonic_s: float
    captured_at: datetime
    ffc_state: FfcState


@dataclass(frozen=True)
class ThermalFrame:
    """A validated, calibrated thermal frame."""

    temps_c: TempArray
    raw: RawArray
    captured_at: datetime
    monotonic_s: float
    ffc_state: FfcState


@dataclass(frozen=True)
class ColorFrame:
    """One colour frame from the Camera Module 3, BGR, full resolution."""

    image_bgr: ImageArray
    captured_at: datetime
    monotonic_s: float


@dataclass(frozen=True)
class AmbientReading:
    temp_c: float
    humidity_pct: float
    captured_at: datetime
    monotonic_s: float


@dataclass(frozen=True)
class ScanRecord:
    """One paired colour + thermal capture from a single trigger."""

    scan_id: str
    session_id: str
    reference_code: str
    color: ColorFrame
    thermal: ThermalFrame
    ambient: AmbientReading
    step_timestamps: dict[str, str]
    config_hash: str


SidednessSource = Literal["geometry_confirmed", "operator_override"]


@dataclass(frozen=True)
class SidednessDecision:
    """Which foot in the image is the patient's left, and who decided."""

    left_is_image_left: bool
    source: SidednessSource
    geometry_left_is_image_left: bool | None


@dataclass(frozen=True)
class RegionResult:
    """One plantar region. `delta_c` is left minus right.

    When either foot has too few pixels in the region (a missing toe, a cold
    area outside the mask) the region is not comparable: `delta_c` is None and
    it is never flagged. A missing value is never filled in.
    """

    name: str
    left_mean_c: float | None
    right_mean_c: float | None
    delta_c: float | None
    flagged: bool
    left_pixel_count: int
    right_pixel_count: int


@dataclass(frozen=True)
class AsymmetryResult:
    regions: tuple[RegionResult, ...]
    threshold_c: float
    max_abs_delta_c: float
    flagged_regions: tuple[str, ...]
    # Left minus mirrored right on a canonical grid. For display only; NaN
    # where either foot has no pixel. Not a measurement.
    difference_map_c: TempArray = field(repr=False, compare=False)

    def region(self, name: str) -> RegionResult:
        for result in self.regions:
            if result.name == name:
                return result
        raise KeyError(name)


@dataclass(frozen=True)
class ClassifierResult:
    """Output of the colour-image classifier. A model output, never a label."""

    predicted_class: int
    predicted_label: str
    confidence: float
    model_id: str


@dataclass(frozen=True)
class FusedResult:
    """Asymmetry flags and the classifier output side by side."""

    any_region_flagged: bool
    flagged_regions: tuple[str, ...]
    max_abs_delta_c: float
    region_deltas_c: dict[str, float | None]
    asymmetry_threshold_c: float
    # None when the station runs with no classifier (data collection).
    predicted_class: int | None
    predicted_label: str | None
    confidence: float | None
    model_id: str | None
